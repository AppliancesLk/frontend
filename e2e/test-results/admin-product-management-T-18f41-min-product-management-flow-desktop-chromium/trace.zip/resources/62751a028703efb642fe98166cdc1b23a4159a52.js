import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Auth/components/AuthForm.tsx");const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import { BrandLogo } from "/src/components/common/BrandLogo.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { Link, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuthForm } from "/src/pages/Auth/hooks/useAuthForm.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { accountText } from "/src/utils/accountText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/components/AuthForm.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function AuthForm({ mode }) {
	_s();
	const { registering, user, loading, location, destination, username, setUsername, email, setEmail, password, setPassword, confirm, setConfirm, showPassword, setShowPassword, busy, error, submit } = useAuthForm(mode);
	if (loading) return /* @__PURE__ */ _jsxDEV(LoadingState, {
		label: translations.auth.checkingSession,
		compact: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 7
	}, this);
	if (user) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: destination,
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 20
	}, this);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "auth-page",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "auth-shell",
			children: [/* @__PURE__ */ _jsxDEV("aside", {
				className: "auth-story",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.home,
						"aria-label": "Appliances.lk home",
						children: /* @__PURE__ */ _jsxDEV(BrandLogo, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "auth-story-content",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: [
								"Good things.",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 47,
									columnNumber: 15
								}, this),
								"Every day."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Your next upgrade. A device you can rely on. A little help when you need it. All in one place." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "auth-brand-plate",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between border-b border-line-strong px-5 py-4",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-display text-lg font-semibold",
										children: "Appliances.lk"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 56,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(Icon, { name: "appliance" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 59,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 55,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("dl", { children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Made for" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: "Everyday living" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 64,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "From" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: "Sri Lanka, with care" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 66,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Here for" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 71,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: "Your next chapter" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 72,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 70,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.products,
						className: "hidden min-h-11 items-center gap-2 text-sm font-semibold text-fg-link md:flex",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "arrow",
							className: "h-4 w-4 rotate-180"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this), "Continue exploring"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("section", {
				className: "auth-form-section",
				"aria-labelledby": "auth-heading",
				children: [
					/* @__PURE__ */ _jsxDEV("h1", {
						id: "auth-heading",
						className: "ui-page-title",
						children: registering ? translations.auth.registerTitle : translations.auth.loginTitle
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm leading-6 text-fg-muted",
						children: registering ? translations.auth.registerDescription : translations.auth.loginDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: submit,
						className: "mt-8 space-y-5",
						"aria-busy": busy,
						children: [
							error && /* @__PURE__ */ _jsxDEV("div", {
								role: "alert",
								id: "auth-error",
								className: "rounded-sm border border-danger/25 bg-danger-bg px-4 py-3 text-sm text-danger",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									htmlFor: "username",
									className: "auth-label",
									children: registering ? translations.auth.username : translations.auth.usernameOrEmail
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									id: "username",
									className: "ui-field auth-input",
									"aria-describedby": error ? "auth-error" : undefined,
									value: username,
									onChange: (e) => setUsername(e.target.value),
									autoComplete: "username",
									autoCapitalize: "none",
									spellCheck: false,
									required: true,
									minLength: 3,
									maxLength: registering ? 32 : 254,
									pattern: registering ? "[a-zA-Z0-9_]{3,32}" : undefined,
									disabled: busy
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 15
								}, this),
								registering && /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1.5 text-xs text-fg-muted",
									children: translations.auth.usernameHint
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 13
							}, this),
							registering && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "email",
								className: "auth-label",
								children: translations.auth.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "email",
								type: "email",
								className: "ui-field auth-input",
								"aria-describedby": error ? "auth-error" : undefined,
								value: email,
								onChange: (e) => setEmail(e.target.value),
								autoComplete: "email",
								required: true,
								maxLength: 254,
								disabled: busy
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "password",
										className: "auth-label",
										children: translations.auth.password
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										"aria-controls": "password",
										"aria-pressed": showPassword,
										onClick: () => setShowPassword(!showPassword),
										className: "-mr-2 mb-1 min-h-11 rounded-sm px-2 text-xs font-semibold text-fg-link",
										children: showPassword ? translations.auth.hide : translations.auth.show
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									id: "password",
									type: showPassword ? "text" : "password",
									className: "ui-field auth-input",
									"aria-describedby": error ? "auth-error" : undefined,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									autoComplete: registering ? "new-password" : "current-password",
									required: true,
									minLength: 8,
									maxLength: 72,
									disabled: busy
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 15
								}, this),
								registering && /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1.5 text-xs text-fg-muted",
									children: translations.auth.passwordHint
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 183,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this),
							registering && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "confirm",
								className: "auth-label",
								children: translations.auth.confirmPassword
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "confirm",
								type: showPassword ? "text" : "password",
								className: "ui-field auth-input",
								"aria-describedby": error ? "auth-error" : undefined,
								value: confirm,
								onChange: (e) => setConfirm(e.target.value),
								autoComplete: "new-password",
								required: true,
								minLength: 8,
								maxLength: 72,
								disabled: busy
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								disabled: busy,
								className: "auth-primary w-full",
								children: [busy && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 209,
									columnNumber: 24
								}, this), busy ? registering ? "Creating your account…" : "Signing in…" : registering ? translations.auth.createAccount : translations.auth.signIn]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 11
					}, this),
					!registering && /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-5 flex flex-wrap justify-between gap-3 text-sm font-semibold text-fg-link",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.forgotPassword,
							children: accountText.forgot
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.verifyEmail,
							children: accountText.unverified
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 220,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-6 text-center text-sm text-fg-muted",
						children: [registering ? translations.auth.alreadyRegistered : translations.auth.newCustomer, /* @__PURE__ */ _jsxDEV(Link, {
							state: location.state,
							to: registering ? ROUTES.login : ROUTES.register,
							className: "font-semibold text-fg-link hover:text-fg-link",
							children: registering ? translations.auth.signIn : translations.auth.createAnAccount
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_s(AuthForm, "szW63bD9wWY0y1I2q/U2o9+ir8Y=", false, function() {
	return [useAuthForm];
});
_c = AuthForm;
var _c;
$RefreshReg$(_c, "AuthForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Auth/components/AuthForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/components/AuthForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/components/AuthForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/components/AuthForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLE1BQU0sZ0JBQWdCO0FBQy9CLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG1CQUFtQjs7OztBQUU1QixlQUFlLFNBQVMsU0FBUyxFQUFFLFFBQXdDOztDQUN6RSxNQUFNLEVBQ0osYUFDQSxNQUNBLFNBQ0EsVUFDQSxhQUNBLFVBQ0EsYUFDQSxPQUNBLFVBQ0EsVUFDQSxhQUNBLFNBQ0EsWUFDQSxjQUNBLGlCQUNBLE1BQ0EsT0FDQSxXQUNFLFlBQVksSUFBSTtDQUNwQixJQUFJLFNBQ0YsT0FDRSx3QkFBQyxjQUFEO0VBQWMsT0FBTyxhQUFhLEtBQUs7RUFBaUIsU0FBUztDQUFPOzs7OztDQUU1RSxJQUFJLE1BQU0sT0FBTyx3QkFBQyxVQUFEO0VBQVUsSUFBSTtFQUFhO0NBQVM7Ozs7O0NBQ3JELE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakI7S0FDRSx3QkFBQyxNQUFEO01BQU0sSUFBSSxPQUFPO01BQU0sY0FBVztnQkFDaEMsd0JBQUMsV0FBRCxDQUFZOzs7OztLQUNSOzs7OztLQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJO1FBRUYsd0JBQUMsTUFBRCxDQUFLOzs7OztRQUFDO09BRUo7Ozs7O09BQ0osd0JBQUMsS0FBRCxZQUFHLGlHQUdBOzs7OztPQUNILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBcUM7U0FFL0M7Ozs7bUJBQ04sd0JBQUMsTUFBRCxFQUFNLE1BQUssWUFBYTs7OztpQkFDckI7Ozs7O2tCQUNMLHdCQUFDLE1BQUQ7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7bUJBQ2hCLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7aUJBQ3BCOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksT0FBUTs7OzttQkFDWix3QkFBQyxNQUFELFlBQUksdUJBQXdCOzs7O2lCQUN6Qjs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7bUJBQ2hCLHdCQUFDLE1BQUQsWUFBSSxvQkFBcUI7Ozs7aUJBQ3RCOzs7OztRQUNIOzs7O2dCQUNEOzs7Ozs7TUFDRjs7Ozs7O0tBQ0wsd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTztNQUNYLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxNQUFEO09BQU0sTUFBSztPQUFRLFdBQVU7TUFBc0I7Ozs7Z0JBQUMsb0JBRWhEOzs7Ozs7SUFDRDs7Ozs7YUFDUCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtJQUFvQixtQkFBZ0I7Y0FBdkQ7S0FDRSx3QkFBQyxNQUFEO01BQUksSUFBRztNQUFlLFdBQVU7Z0JBQzdCLGNBQ0csYUFBYSxLQUFLLGdCQUNsQixhQUFhLEtBQUs7S0FDcEI7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsY0FDRyxhQUFhLEtBQUssc0JBQ2xCLGFBQWEsS0FBSztLQUNyQjs7Ozs7S0FDSCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUFRLFdBQVU7TUFBaUIsYUFBVztnQkFBOUQ7T0FDRyxTQUNDLHdCQUFDLE9BQUQ7UUFDRSxNQUFLO1FBQ0wsSUFBRztRQUNILFdBQVU7a0JBRVQ7T0FDRTs7Ozs7T0FFUCx3QkFBQyxPQUFEO1FBQ0Usd0JBQUMsU0FBRDtTQUFPLFNBQVE7U0FBVyxXQUFVO21CQUNqQyxjQUNHLGFBQWEsS0FBSyxXQUNsQixhQUFhLEtBQUs7UUFDakI7Ozs7O1FBQ1Asd0JBQUMsU0FBRDtTQUNFLElBQUc7U0FDSCxXQUFVO1NBQ1Ysb0JBQWtCLFFBQVEsZUFBZTtTQUN6QyxPQUFPO1NBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7U0FDM0MsY0FBYTtTQUNiLGdCQUFlO1NBQ2YsWUFBWTtTQUNaO1NBQ0EsV0FBVztTQUNYLFdBQVcsY0FBYyxLQUFLO1NBQzlCLFNBQVMsY0FBYyx1QkFBdUI7U0FDOUMsVUFBVTtRQUNYOzs7OztRQUNBLGVBQ0Msd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsYUFBYSxLQUFLO1FBQ2xCOzs7OztPQUVGOzs7OztPQUNKLGVBQ0Msd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxTQUFRO1FBQVEsV0FBVTtrQkFDOUIsYUFBYSxLQUFLO09BQ2Q7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLElBQUc7UUFDSCxNQUFLO1FBQ0wsV0FBVTtRQUNWLG9CQUFrQixRQUFRLGVBQWU7UUFDekMsT0FBTztRQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO1FBQ3hDLGNBQWE7UUFDYjtRQUNBLFdBQVc7UUFDWCxVQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFUCx3QkFBQyxPQUFEO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sU0FBUTtVQUFXLFdBQVU7b0JBQ2pDLGFBQWEsS0FBSztTQUNkOzs7O21CQUNQLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsaUJBQWM7VUFDZCxnQkFBYztVQUNkLGVBQWUsZ0JBQWdCLENBQUMsWUFBWTtVQUM1QyxXQUFVO29CQUVULGVBQ0csYUFBYSxLQUFLLE9BQ2xCLGFBQWEsS0FBSztTQUNoQjs7OztpQkFDTDs7Ozs7O1FBQ0wsd0JBQUMsU0FBRDtTQUNFLElBQUc7U0FDSCxNQUFNLGVBQWUsU0FBUztTQUM5QixXQUFVO1NBQ1Ysb0JBQWtCLFFBQVEsZUFBZTtTQUN6QyxPQUFPO1NBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7U0FDM0MsY0FBYyxjQUFjLGlCQUFpQjtTQUM3QztTQUNBLFdBQVc7U0FDWCxXQUFXO1NBQ1gsVUFBVTtRQUNYOzs7OztRQUNBLGVBQ0Msd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsYUFBYSxLQUFLO1FBQ2xCOzs7OztPQUVGOzs7OztPQUNKLGVBQ0Msd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxTQUFRO1FBQVUsV0FBVTtrQkFDaEMsYUFBYSxLQUFLO09BQ2Q7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLElBQUc7UUFDSCxNQUFNLGVBQWUsU0FBUztRQUM5QixXQUFVO1FBQ1Ysb0JBQWtCLFFBQVEsZUFBZTtRQUN6QyxPQUFPO1FBQ1AsV0FBVyxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUs7UUFDMUMsY0FBYTtRQUNiO1FBQ0EsV0FBVztRQUNYLFdBQVc7UUFDWCxVQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFUCx3QkFBQyxVQUFEO1FBQVEsVUFBVTtRQUFNLFdBQVU7a0JBQWxDLENBQ0csUUFBUSx3QkFBQyxTQUFELEVBQVMsV0FBVSxPQUFROzs7O2tCQUNuQyxPQUNHLGNBQ0UsMkJBQ0EsZ0JBQ0YsY0FDRSxhQUFhLEtBQUssZ0JBQ2xCLGFBQWEsS0FBSyxNQUNsQjs7Ozs7O01BQ0o7Ozs7OztLQUNMLENBQUMsZUFDQSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBTSxJQUFJLE9BQU87aUJBQWlCLFlBQVk7TUFBYTs7OztnQkFDM0Qsd0JBQUMsTUFBRDtPQUFNLElBQUksT0FBTztpQkFBYyxZQUFZO01BQWlCOzs7O2NBQ3pEOzs7Ozs7S0FFUCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUNHLGNBQ0csYUFBYSxLQUFLLG9CQUNsQixhQUFhLEtBQUssYUFDdEIsd0JBQUMsTUFBRDtPQUNFLE9BQU8sU0FBUztPQUNoQixJQUFJLGNBQWMsT0FBTyxRQUFRLE9BQU87T0FDeEMsV0FBVTtpQkFFVCxjQUNHLGFBQWEsS0FBSyxTQUNsQixhQUFhLEtBQUs7TUFDbEI7Ozs7Y0FDTDs7Ozs7O0lBQ0k7Ozs7O1dBQ047Ozs7OztDQUNEOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dGhGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCcmFuZExvZ28gfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9CcmFuZExvZ28nO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IExpbmssIE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUF1dGhGb3JtIH0gZnJvbSAnLi4vaG9va3MvdXNlQXV0aEZvcm0nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgYWNjb3VudFRleHQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9hY2NvdW50VGV4dCc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBdXRoRm9ybSh7IG1vZGUgfTogeyBtb2RlOiAnbG9naW4nIHwgJ3JlZ2lzdGVyJyB9KSB7XHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXJpbmcsXHJcbiAgICB1c2VyLFxyXG4gICAgbG9hZGluZyxcclxuICAgIGxvY2F0aW9uLFxyXG4gICAgZGVzdGluYXRpb24sXHJcbiAgICB1c2VybmFtZSxcclxuICAgIHNldFVzZXJuYW1lLFxyXG4gICAgZW1haWwsXHJcbiAgICBzZXRFbWFpbCxcclxuICAgIHBhc3N3b3JkLFxyXG4gICAgc2V0UGFzc3dvcmQsXHJcbiAgICBjb25maXJtLFxyXG4gICAgc2V0Q29uZmlybSxcclxuICAgIHNob3dQYXNzd29yZCxcclxuICAgIHNldFNob3dQYXNzd29yZCxcclxuICAgIGJ1c3ksXHJcbiAgICBlcnJvcixcclxuICAgIHN1Ym1pdCxcclxuICB9ID0gdXNlQXV0aEZvcm0obW9kZSk7XHJcbiAgaWYgKGxvYWRpbmcpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0cmFuc2xhdGlvbnMuYXV0aC5jaGVja2luZ1Nlc3Npb259IGNvbXBhY3Q9e3RydWV9IC8+XHJcbiAgICApO1xyXG4gIGlmICh1c2VyKSByZXR1cm4gPE5hdmlnYXRlIHRvPXtkZXN0aW5hdGlvbn0gcmVwbGFjZSAvPjtcclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYXV0aC1wYWdlXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1zaGVsbFwiPlxyXG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJhdXRoLXN0b3J5XCI+XHJcbiAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLmhvbWV9IGFyaWEtbGFiZWw9XCJBcHBsaWFuY2VzLmxrIGhvbWVcIj5cclxuICAgICAgICAgICAgPEJyYW5kTG9nbyAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXN0b3J5LWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgPGgyPlxyXG4gICAgICAgICAgICAgIEdvb2QgdGhpbmdzLlxyXG4gICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgIEV2ZXJ5IGRheS5cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgWW91ciBuZXh0IHVwZ3JhZGUuIEEgZGV2aWNlIHlvdSBjYW4gcmVseSBvbi4gQSBsaXR0bGUgaGVscCB3aGVuXHJcbiAgICAgICAgICAgICAgeW91IG5lZWQgaXQuIEFsbCBpbiBvbmUgcGxhY2UuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWJyYW5kLXBsYXRlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWxpbmUtc3Ryb25nIHB4LTUgcHktNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICBBcHBsaWFuY2VzLmxrXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYXBwbGlhbmNlXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZHQ+TWFkZSBmb3I8L2R0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGQ+RXZlcnlkYXkgbGl2aW5nPC9kZD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGR0PkZyb208L2R0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGQ+U3JpIExhbmthLCB3aXRoIGNhcmU8L2RkPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZHQ+SGVyZSBmb3I8L2R0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGQ+WW91ciBuZXh0IGNoYXB0ZXI8L2RkPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kbD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMucHJvZHVjdHN9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlbiBtaW4taC0xMSBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZmctbGluayBtZDpmbGV4XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cImFycm93XCIgY2xhc3NOYW1lPVwiaC00IHctNCByb3RhdGUtMTgwXCIgLz5cclxuICAgICAgICAgICAgQ29udGludWUgZXhwbG9yaW5nXHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJhdXRoLWZvcm0tc2VjdGlvblwiIGFyaWEtbGFiZWxsZWRieT1cImF1dGgtaGVhZGluZ1wiPlxyXG4gICAgICAgICAgPGgxIGlkPVwiYXV0aC1oZWFkaW5nXCIgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZVwiPlxyXG4gICAgICAgICAgICB7cmVnaXN0ZXJpbmdcclxuICAgICAgICAgICAgICA/IHRyYW5zbGF0aW9ucy5hdXRoLnJlZ2lzdGVyVGl0bGVcclxuICAgICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5hdXRoLmxvZ2luVGl0bGV9XHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHtyZWdpc3RlcmluZ1xyXG4gICAgICAgICAgICAgID8gdHJhbnNsYXRpb25zLmF1dGgucmVnaXN0ZXJEZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLmF1dGgubG9naW5EZXNjcmlwdGlvbn1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtzdWJtaXR9IGNsYXNzTmFtZT1cIm10LTggc3BhY2UteS01XCIgYXJpYS1idXN5PXtidXN5fT5cclxuICAgICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgICAgICAgaWQ9XCJhdXRoLWVycm9yXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1kYW5nZXIvMjUgYmctZGFuZ2VyLWJnIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtZGFuZ2VyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ1c2VybmFtZVwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgIHtyZWdpc3RlcmluZ1xyXG4gICAgICAgICAgICAgICAgICA/IHRyYW5zbGF0aW9ucy5hdXRoLnVzZXJuYW1lXHJcbiAgICAgICAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLmF1dGgudXNlcm5hbWVPckVtYWlsfVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD1cInVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17ZXJyb3IgPyAnYXV0aC1lcnJvcicgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJuYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cInVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgIGF1dG9DYXBpdGFsaXplPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICBzcGVsbENoZWNrPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBtaW5MZW5ndGg9ezN9XHJcbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9e3JlZ2lzdGVyaW5nID8gMzIgOiAyNTR9XHJcbiAgICAgICAgICAgICAgICBwYXR0ZXJuPXtyZWdpc3RlcmluZyA/ICdbYS16QS1aMC05X117MywzMn0nIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7cmVnaXN0ZXJpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMS41IHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmF1dGgudXNlcm5hbWVIaW50fVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7cmVnaXN0ZXJpbmcgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCIgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmF1dGguZW1haWx9XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0XCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17ZXJyb3IgPyAnYXV0aC1lcnJvcicgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsyNTR9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5hdXRoLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtY29udHJvbHM9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17c2hvd1Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoIXNob3dQYXNzd29yZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIi1tci0yIG1iLTEgbWluLWgtMTEgcm91bmRlZC1zbSBweC0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7c2hvd1Bhc3N3b3JkXHJcbiAgICAgICAgICAgICAgICAgICAgPyB0cmFuc2xhdGlvbnMuYXV0aC5oaWRlXHJcbiAgICAgICAgICAgICAgICAgICAgOiB0cmFuc2xhdGlvbnMuYXV0aC5zaG93fVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0XCJcclxuICAgICAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e2Vycm9yID8gJ2F1dGgtZXJyb3InIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9e3JlZ2lzdGVyaW5nID8gJ25ldy1wYXNzd29yZCcgOiAnY3VycmVudC1wYXNzd29yZCd9XHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgbWluTGVuZ3RoPXs4fVxyXG4gICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs3Mn1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge3JlZ2lzdGVyaW5nICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5hdXRoLnBhc3N3b3JkSGludH1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3JlZ2lzdGVyaW5nICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjb25maXJtXCIgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmF1dGguY29uZmlybVBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cImNvbmZpcm1cIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPXtzaG93UGFzc3dvcmQgPyAndGV4dCcgOiAncGFzc3dvcmQnfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0XCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17ZXJyb3IgPyAnYXV0aC1lcnJvcicgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbmZpcm0oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBtaW5MZW5ndGg9ezh9XHJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NzJ9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGJ1dHRvbiBkaXNhYmxlZD17YnVzeX0gY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgIHtidXN5ICYmIDxTcGlubmVyIGNsYXNzTmFtZT1cIm1yLTJcIiAvPn1cclxuICAgICAgICAgICAgICB7YnVzeVxyXG4gICAgICAgICAgICAgICAgPyByZWdpc3RlcmluZ1xyXG4gICAgICAgICAgICAgICAgICA/ICdDcmVhdGluZyB5b3VyIGFjY291bnTigKYnXHJcbiAgICAgICAgICAgICAgICAgIDogJ1NpZ25pbmcgaW7igKYnXHJcbiAgICAgICAgICAgICAgICA6IHJlZ2lzdGVyaW5nXHJcbiAgICAgICAgICAgICAgICAgID8gdHJhbnNsYXRpb25zLmF1dGguY3JlYXRlQWNjb3VudFxyXG4gICAgICAgICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5hdXRoLnNpZ25Jbn1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICB7IXJlZ2lzdGVyaW5nICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGZsZXggZmxleC13cmFwIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZy1saW5rXCI+XHJcbiAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5mb3Jnb3RQYXNzd29yZH0+e2FjY291bnRUZXh0LmZvcmdvdH08L0xpbms+XHJcbiAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy52ZXJpZnlFbWFpbH0+e2FjY291bnRUZXh0LnVudmVyaWZpZWR9PC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC02IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICB7cmVnaXN0ZXJpbmdcclxuICAgICAgICAgICAgICA/IHRyYW5zbGF0aW9ucy5hdXRoLmFscmVhZHlSZWdpc3RlcmVkXHJcbiAgICAgICAgICAgICAgOiB0cmFuc2xhdGlvbnMuYXV0aC5uZXdDdXN0b21lcn1cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICBzdGF0ZT17bG9jYXRpb24uc3RhdGV9XHJcbiAgICAgICAgICAgICAgdG89e3JlZ2lzdGVyaW5nID8gUk9VVEVTLmxvZ2luIDogUk9VVEVTLnJlZ2lzdGVyfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7cmVnaXN0ZXJpbmdcclxuICAgICAgICAgICAgICAgID8gdHJhbnNsYXRpb25zLmF1dGguc2lnbkluXHJcbiAgICAgICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5hdXRoLmNyZWF0ZUFuQWNjb3VudH1cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXX0=