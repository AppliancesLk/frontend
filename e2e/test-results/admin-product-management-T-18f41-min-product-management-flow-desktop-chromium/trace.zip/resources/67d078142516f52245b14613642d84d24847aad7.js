import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/Price.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { formatCurrency } from "/src/utils/currency.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Price.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function Price({ value, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `price ${className}`,
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "font-medium text-fg-secondary",
				children: "LKR"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this),
			"\xA0",
			formatCurrency(value).slice(4)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_c = Price;
var _c;
$RefreshReg$(_c, "Price");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/Price.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Price.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Price.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Price.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7OztBQUMvQixPQUFPLFNBQVMsTUFBTSxFQUNwQixPQUNBLFlBQVksTUFJWDtDQUNELE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVcsU0FBUztZQUExQjtHQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWdDO0dBQVM7Ozs7O0dBQ3hEO0dBQ0EsZUFBZSxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7RUFDMUI7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByaWNlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuZXhwb3J0IGZ1bmN0aW9uIFByaWNlKHtcclxuICB2YWx1ZSxcclxuICBjbGFzc05hbWUgPSAnJyxcclxufToge1xyXG4gIHZhbHVlOiBzdHJpbmcgfCBudW1iZXI7XHJcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuIGNsYXNzTmFtZT17YHByaWNlICR7Y2xhc3NOYW1lfWB9PlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnLXNlY29uZGFyeVwiPkxLUjwvc3Bhbj5cclxuICAgICAgeydcXHUwMGEwJ31cclxuICAgICAge2Zvcm1hdEN1cnJlbmN5KHZhbHVlKS5zbGljZSg0KX1cclxuICAgIDwvc3Bhbj5cclxuICApO1xyXG59XHJcbiJdfQ==