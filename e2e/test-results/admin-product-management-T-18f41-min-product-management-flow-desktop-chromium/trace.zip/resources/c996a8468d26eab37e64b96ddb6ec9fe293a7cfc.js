import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Users/index.tsx");const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import { useAuth } from "/src/hooks/useAuth.ts";
import { Button } from "/src/components/ui/Button.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { accountText as t } from "/src/utils/accountText.ts";
import { translations } from "/src/utils/translations.ts";
import { formatDate } from "/src/utils/date.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { useUsersPage } from "/src/pages/Admin/Users/hooks/useUsersPage.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Users/index.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function UsersPage() {
	_s();
	const page = useUsersPage();
	const { user } = useAuth();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title",
				children: t.usersTitle
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-secondary",
				children: t.usersDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (e) => e.preventDefault(),
				className: "grid gap-4 rounded-md border border-line bg-surface p-5 md:grid-cols-[minmax(0,1fr)_auto_auto]",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "user-search",
						className: "auth-label",
						children: t.search
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "user-search",
						className: "ui-field",
						type: "search",
						maxLength: 100,
						value: page.filters.search,
						onChange: (e) => page.setFilters({
							...page.filters,
							page: 1,
							search: e.target.value
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "user-role",
						className: "auth-label",
						children: "Role"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: "user-role",
						className: "ui-field",
						value: page.filters.role,
						onChange: (e) => page.setFilters({
							...page.filters,
							page: 1,
							role: e.target.value
						}),
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: t.allRoles
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "CUSTOMER",
								children: "Customer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "ADMIN",
								children: "Admin"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "REPAIRER",
								children: "Repairer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "user-status",
						className: "auth-label",
						children: "Status"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: "user-status",
						className: "ui-field",
						value: page.filters.status,
						onChange: (e) => page.setFilters({
							...page.filters,
							page: 1,
							status: e.target.value
						}),
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: t.allStatuses
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "active",
								children: t.active
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "inactive",
								children: t.inactive
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "pending",
								children: t.pending
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "ui-alert ui-tone-danger",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: page.error }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					variant: "secondary",
					onClick: page.refresh,
					children: translations.common.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this),
			page.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: t.usersTitle }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 97,
				columnNumber: 9
			}, this) : page.result && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [!page.result.items.length ? /* @__PURE__ */ _jsxDEV("p", {
				className: "ui-panel p-8 text-center text-fg-muted",
				children: t.noUsers
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 15
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto rounded-md border border-line bg-surface",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full min-w-[680px] text-left text-sm",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-subtle text-fg-secondary",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							"User",
							"Role",
							"Status",
							"Joined",
							"Loyalty credit",
							"Access"
						].map((label) => /* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-5 py-4 font-medium",
							children: label
						}, label, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 25
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-line",
						children: page.result.items.map((item) => /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								scope: "row",
								className: "px-5 py-4 font-normal",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-semibold",
									children: item.username
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 27
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 break-all text-xs text-fg-muted",
									children: item.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 27
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-4",
								children: item.role
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-4",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: `inline-block rounded-sm px-2 py-1 text-xs ${item.isActive ? "bg-success-bg text-success" : item.deactivatedAt ? "bg-danger-bg text-danger" : "bg-warning-bg text-warning"}`,
									children: item.isActive ? t.active : item.deactivatedAt ? t.inactive : t.pending
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 27
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-4 text-fg-secondary",
								children: formatDate(item.createdAt)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-4",
								children: formatCurrency(item.loyaltyBalance)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-4",
								children: item.id === user?.id ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-fg-muted",
									children: "Your account"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 29
								}, this) : item.deactivatedAt ? /* @__PURE__ */ _jsxDEV(Button, {
									variant: "secondary",
									busy: page.saving,
									onClick: () => void page.update(item, true),
									children: t.reactivate
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 29
								}, this) : /* @__PURE__ */ _jsxDEV(Button, {
									variant: "secondary",
									disabled: page.saving,
									onClick: () => page.setTarget(item),
									children: t.deactivate
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 25
							}, this)
						] }, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 23
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: [
					page.result.total,
					" users · Page ",
					page.filters.page
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: page.filters.page <= 1,
						onClick: () => page.setFilters({
							...page.filters,
							page: page.filters.page - 1
						}),
						children: "Previous"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: page.filters.page * page.result.limit >= page.result.total,
						onClick: () => page.setFilters({
							...page.filters,
							page: page.filters.page + 1
						}),
						children: "Next"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: Boolean(page.target),
				onClose: () => page.setTarget(null),
				title: t.deactivate,
				description: t.deactivateDescription,
				busy: page.saving,
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "font-semibold",
						children: page.target?.username
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 227,
						columnNumber: 9
					}, this),
					page.error && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "ui-alert ui-tone-danger mt-3",
						children: page.error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 229,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-6 flex flex-wrap justify-end gap-3",
						children: [/* @__PURE__ */ _jsxDEV(Button, {
							variant: "secondary",
							disabled: page.saving,
							onClick: () => page.setTarget(null),
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							variant: "danger",
							busy: page.saving,
							onClick: () => page.target && void page.update(page.target, false),
							children: t.deactivate
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_s(UsersPage, "vM7OKIPU+rYquAPt/2absWOUtqA=", false, function() {
	return [useUsersPage, useAuth];
});
_c = UsersPage;
var _c;
$RefreshReg$(_c, "UsersPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Users/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Users/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Users/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Users/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxlQUFlLFNBQVM7QUFDakMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxzQkFBc0I7QUFFL0IsU0FBUyxvQkFBb0I7Ozs7QUFDN0IsZUFBZSxTQUFTLFlBQVk7O0NBQ2xDLE1BQU0sT0FBTyxhQUFhO0NBQzFCLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLFVBQUQsYUFDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFpQixFQUFFO0dBQWU7Ozs7YUFDaEQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBa0MsRUFBRTtHQUFvQjs7OztXQUMvRDs7Ozs7R0FDUix3QkFBQyxRQUFEO0lBQ0UsV0FBVyxNQUFNLEVBQUUsZUFBZTtJQUNsQyxXQUFVO2NBRlo7S0FJRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFNBQVE7TUFBYyxXQUFVO2dCQUNwQyxFQUFFO0tBQ0U7Ozs7ZUFDUCx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILFdBQVU7TUFDVixNQUFLO01BQ0wsV0FBVztNQUNYLE9BQU8sS0FBSyxRQUFRO01BQ3BCLFdBQVcsTUFDVCxLQUFLLFdBQVc7T0FDZCxHQUFHLEtBQUs7T0FDUixNQUFNO09BQ04sUUFBUSxFQUFFLE9BQU87TUFDbkIsQ0FBQztLQUVKOzs7O2FBQ0U7Ozs7O0tBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO01BQVksV0FBVTtnQkFBYTtLQUUzQzs7OztlQUNQLHdCQUFDLFVBQUQ7TUFDRSxJQUFHO01BQ0gsV0FBVTtNQUNWLE9BQU8sS0FBSyxRQUFRO01BQ3BCLFdBQVcsTUFDVCxLQUFLLFdBQVc7T0FDZCxHQUFHLEtBQUs7T0FDUixNQUFNO09BQ04sTUFBTSxFQUFFLE9BQU87TUFDakIsQ0FBQztnQkFUTDtPQVlFLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFJLEVBQUU7T0FBaUI7Ozs7O09BQ3JDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFXO09BQWdCOzs7OztPQUN6Qyx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBUTtPQUFhOzs7OztPQUNuQyx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBVztPQUFnQjs7Ozs7TUFDbkM7Ozs7O2FBQ0w7Ozs7O0tBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO01BQWMsV0FBVTtnQkFBYTtLQUU3Qzs7OztlQUNQLHdCQUFDLFVBQUQ7TUFDRSxJQUFHO01BQ0gsV0FBVTtNQUNWLE9BQU8sS0FBSyxRQUFRO01BQ3BCLFdBQVcsTUFDVCxLQUFLLFdBQVc7T0FDZCxHQUFHLEtBQUs7T0FDUixNQUFNO09BQ04sUUFBUSxFQUFFLE9BQU87TUFDbkIsQ0FBQztnQkFUTDtPQVlFLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFJLEVBQUU7T0FBb0I7Ozs7O09BQ3hDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFVLEVBQUU7T0FBZTs7Ozs7T0FDekMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVksRUFBRTtPQUFpQjs7Ozs7T0FDN0Msd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVcsRUFBRTtPQUFnQjs7Ozs7TUFDckM7Ozs7O2FBQ0w7Ozs7O0lBQ0Q7Ozs7OztHQUNMLEtBQUssU0FDSix3QkFBQyxPQUFEO0lBQUssTUFBSztJQUFRLFdBQVU7Y0FBNUIsQ0FDRSx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7O2NBQ2xCLHdCQUFDLFFBQUQ7S0FBUSxTQUFRO0tBQVksU0FBUyxLQUFLO2VBQ3ZDLGFBQWEsT0FBTztJQUNmOzs7O1lBQ0w7Ozs7OztHQUVOLEtBQUssVUFDSix3QkFBQyxjQUFELEVBQWMsT0FBTyxFQUFFLFdBQWE7Ozs7Y0FFcEMsS0FBSyxVQUNILGdEQUNHLENBQUMsS0FBSyxPQUFPLE1BQU0sU0FDbEIsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixFQUFFO0dBQ0Y7Ozs7Y0FFSCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2Ysd0JBQUMsTUFBRCxZQUNHO09BQ0M7T0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO01BQ0YsQ0FBQyxDQUFDLEtBQUssVUFDTCx3QkFBQyxNQUFEO09BRUUsT0FBTTtPQUNOLFdBQVU7aUJBRVQ7TUFDQyxHQUxHOzs7O2FBS0gsQ0FDTCxFQUNDOzs7OztLQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2QsS0FBSyxPQUFPLE1BQU0sS0FBSyxTQUN0Qix3QkFBQyxNQUFEO09BQ0Usd0JBQUMsTUFBRDtRQUFJLE9BQU07UUFBTSxXQUFVO2tCQUExQixDQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFpQixLQUFLO1FBQVk7Ozs7a0JBQy9DLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLEtBQUs7UUFDTDs7OztnQkFDRDs7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWEsS0FBSztPQUFTOzs7OztPQUN6Qyx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWix3QkFBQyxRQUFEO1NBQ0UsV0FBVyw2Q0FBNkMsS0FBSyxXQUFXLCtCQUErQixLQUFLLGdCQUFnQiw2QkFBNkI7bUJBRXhKLEtBQUssV0FDRixFQUFFLFNBQ0YsS0FBSyxnQkFDSCxFQUFFLFdBQ0YsRUFBRTtRQUNKOzs7OztPQUNKOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLFdBQVcsS0FBSyxTQUFTO09BQ3hCOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLGVBQWUsS0FBSyxjQUFjO09BQ2pDOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLEtBQUssT0FBTyxNQUFNLEtBQ2pCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF3QjtRQUVsQzs7OzttQkFDSixLQUFLLGdCQUNQLHdCQUFDLFFBQUQ7U0FDRSxTQUFRO1NBQ1IsTUFBTSxLQUFLO1NBQ1gsZUFBZSxLQUFLLEtBQUssT0FBTyxNQUFNLElBQUk7bUJBRXpDLEVBQUU7UUFDRzs7OzttQkFFUix3QkFBQyxRQUFEO1NBQ0UsU0FBUTtTQUNSLFVBQVUsS0FBSztTQUNmLGVBQWUsS0FBSyxVQUFVLElBQUk7bUJBRWpDLEVBQUU7UUFDRzs7Ozs7T0FFUjs7Ozs7TUFDRixLQWhESyxLQUFLOzs7O2FBZ0RWLENBQ0w7S0FDSTs7OzthQUNGOzs7Ozs7R0FDSjs7OzthQUVQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxLQUFEO0tBQ0csS0FBSyxPQUFPO0tBQU07S0FBZSxLQUFLLFFBQVE7SUFDOUM7Ozs7Y0FDSCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixVQUFVLEtBQUssUUFBUSxRQUFRO01BQy9CLGVBQ0UsS0FBSyxXQUFXO09BQ2QsR0FBRyxLQUFLO09BQ1IsTUFBTSxLQUFLLFFBQVEsT0FBTztNQUM1QixDQUFDO2dCQUVKO0tBRU87Ozs7ZUFDUix3QkFBQyxRQUFEO01BQ0UsU0FBUTtNQUNSLFVBQ0UsS0FBSyxRQUFRLE9BQU8sS0FBSyxPQUFPLFNBQVMsS0FBSyxPQUFPO01BRXZELGVBQ0UsS0FBSyxXQUFXO09BQ2QsR0FBRyxLQUFLO09BQ1IsTUFBTSxLQUFLLFFBQVEsT0FBTztNQUM1QixDQUFDO2dCQUVKO0tBRU87Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7V0FDTDs7Ozs7R0FHTix3QkFBQyxRQUFEO0lBQ0UsTUFBTSxRQUFRLEtBQUssTUFBTTtJQUN6QixlQUFlLEtBQUssVUFBVSxJQUFJO0lBQ2xDLE9BQU8sRUFBRTtJQUNULGFBQWEsRUFBRTtJQUNmLE1BQU0sS0FBSztjQUxiO0tBT0Usd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWlCLEtBQUssUUFBUTtLQUFZOzs7OztLQUN0RCxLQUFLLFNBQ0osd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBUSxXQUFVO2dCQUN2QixLQUFLO0tBQ0w7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQ0UsU0FBUTtPQUNSLFVBQVUsS0FBSztPQUNmLGVBQWUsS0FBSyxVQUFVLElBQUk7aUJBRWpDO01BQ0s7Ozs7Z0JBQ1Isd0JBQUMsUUFBRDtPQUNFLFNBQVE7T0FDUixNQUFNLEtBQUs7T0FDWCxlQUFlLEtBQUssVUFBVSxLQUFLLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSztpQkFFaEUsRUFBRTtNQUNHOzs7O2NBQ0w7Ozs7OztJQUNDOzs7Ozs7RUFDRDs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VBdXRoJztcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9CdXR0b24nO1xyXG5pbXBvcnQgeyBEaWFsb2cgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0RpYWxvZyc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBhY2NvdW50VGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvYWNjb3VudFRleHQnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY3VycmVuY3knO1xyXG5pbXBvcnQgdHlwZSB7IFVzZXJGaWx0ZXJzIH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvdXNlci50eXBlcyc7XHJcbmltcG9ydCB7IHVzZVVzZXJzUGFnZSB9IGZyb20gJy4vaG9va3MvdXNlVXNlcnNQYWdlJztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVXNlcnNQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VVc2Vyc1BhZ2UoKTtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIDxoZWFkZXI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGVcIj57dC51c2Vyc1RpdGxlfTwvaDE+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+e3QudXNlcnNEZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgICA8Zm9ybVxyXG4gICAgICAgIG9uU3VibWl0PXsoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTUgbWQ6Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpX2F1dG9fYXV0b11cIlxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidXNlci1zZWFyY2hcIiBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCI+XHJcbiAgICAgICAgICAgIHt0LnNlYXJjaH1cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9XCJ1c2VyLXNlYXJjaFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkXCJcclxuICAgICAgICAgICAgdHlwZT1cInNlYXJjaFwiXHJcbiAgICAgICAgICAgIG1heExlbmd0aD17MTAwfVxyXG4gICAgICAgICAgICB2YWx1ZT17cGFnZS5maWx0ZXJzLnNlYXJjaH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgIHBhZ2Uuc2V0RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgICAuLi5wYWdlLmZpbHRlcnMsXHJcbiAgICAgICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICAgICAgc2VhcmNoOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXItcm9sZVwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgUm9sZVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgaWQ9XCJ1c2VyLXJvbGVcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtwYWdlLmZpbHRlcnMucm9sZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgIHBhZ2Uuc2V0RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgICAuLi5wYWdlLmZpbHRlcnMsXHJcbiAgICAgICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICAgICAgcm9sZTogZS50YXJnZXQudmFsdWUgYXMgVXNlckZpbHRlcnNbJ3JvbGUnXSxcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj57dC5hbGxSb2xlc308L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNVU1RPTUVSXCI+Q3VzdG9tZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFETUlOXCI+QWRtaW48L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJFUEFJUkVSXCI+UmVwYWlyZXI8L29wdGlvbj5cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXItc3RhdHVzXCIgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICBTdGF0dXNcclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgIGlkPVwidXNlci1zdGF0dXNcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtwYWdlLmZpbHRlcnMuc3RhdHVzfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgcGFnZS5zZXRGaWx0ZXJzKHtcclxuICAgICAgICAgICAgICAgIC4uLnBhZ2UuZmlsdGVycyxcclxuICAgICAgICAgICAgICAgIHBhZ2U6IDEsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LnZhbHVlIGFzIFVzZXJGaWx0ZXJzWydzdGF0dXMnXSxcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj57dC5hbGxTdGF0dXNlc308L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFjdGl2ZVwiPnt0LmFjdGl2ZX08L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImluYWN0aXZlXCI+e3QuaW5hY3RpdmV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwZW5kaW5nXCI+e3QucGVuZGluZ308L29wdGlvbj5cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Zvcm0+XHJcbiAgICAgIHtwYWdlLmVycm9yICYmIChcclxuICAgICAgICA8ZGl2IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtZGFuZ2VyXCI+XHJcbiAgICAgICAgICA8cD57cGFnZS5lcnJvcn08L3A+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXtwYWdlLnJlZnJlc2h9PlxyXG4gICAgICAgICAgICB7dHJhbnNsYXRpb25zLmNvbW1vbi5yZXRyeX1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICB7cGFnZS5sb2FkaW5nID8gKFxyXG4gICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9e3QudXNlcnNUaXRsZX0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICBwYWdlLnJlc3VsdCAmJiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICB7IXBhZ2UucmVzdWx0Lml0ZW1zLmxlbmd0aCA/IChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ1aS1wYW5lbCBwLTggdGV4dC1jZW50ZXIgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAge3Qubm9Vc2Vyc31cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZVwiPlxyXG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCBtaW4tdy1bNjgwcHhdIHRleHQtbGVmdCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zdWJ0bGUgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAnVXNlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdSb2xlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ1N0YXR1cycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdKb2luZWQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTG95YWx0eSBjcmVkaXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQWNjZXNzJyxcclxuICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChsYWJlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2xhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlPVwiY29sXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTQgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1saW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3BhZ2UucmVzdWx0Lml0ZW1zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aXRlbS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiIGNsYXNzTmFtZT1cInB4LTUgcHktNCBmb250LW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57aXRlbS51c2VybmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSBicmVhay1hbGwgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTRcIj57aXRlbS5yb2xlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWJsb2NrIHJvdW5kZWQtc20gcHgtMiBweS0xIHRleHQteHMgJHtpdGVtLmlzQWN0aXZlID8gJ2JnLXN1Y2Nlc3MtYmcgdGV4dC1zdWNjZXNzJyA6IGl0ZW0uZGVhY3RpdmF0ZWRBdCA/ICdiZy1kYW5nZXItYmcgdGV4dC1kYW5nZXInIDogJ2JnLXdhcm5pbmctYmcgdGV4dC13YXJuaW5nJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdC5hY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBpdGVtLmRlYWN0aXZhdGVkQXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHQuaW5hY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHQucGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShpdGVtLmNyZWF0ZWRBdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koaXRlbS5sb3lhbHR5QmFsYW5jZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5pZCA9PT0gdXNlcj8uaWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgWW91ciBhY2NvdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGl0ZW0uZGVhY3RpdmF0ZWRBdCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1c3k9e3BhZ2Uuc2F2aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UudXBkYXRlKGl0ZW0sIHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dC5yZWFjdGl2YXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnNhdmluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRUYXJnZXQoaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0LmRlYWN0aXZhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5yZXN1bHQudG90YWx9IHVzZXJzIMK3IFBhZ2Uge3BhZ2UuZmlsdGVycy5wYWdlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLmZpbHRlcnMucGFnZSA8PSAxfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2Uuc2V0RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wYWdlLmZpbHRlcnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwYWdlOiBwYWdlLmZpbHRlcnMucGFnZSAtIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQcmV2aW91c1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgcGFnZS5maWx0ZXJzLnBhZ2UgKiBwYWdlLnJlc3VsdC5saW1pdCA+PSBwYWdlLnJlc3VsdC50b3RhbFxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgcGFnZS5zZXRGaWx0ZXJzKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnBhZ2UuZmlsdGVycyxcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZ2U6IHBhZ2UuZmlsdGVycy5wYWdlICsgMSxcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIE5leHRcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgIClcclxuICAgICAgKX1cclxuICAgICAgPERpYWxvZ1xyXG4gICAgICAgIG9wZW49e0Jvb2xlYW4ocGFnZS50YXJnZXQpfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHBhZ2Uuc2V0VGFyZ2V0KG51bGwpfVxyXG4gICAgICAgIHRpdGxlPXt0LmRlYWN0aXZhdGV9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3QuZGVhY3RpdmF0ZURlc2NyaXB0aW9ufVxyXG4gICAgICAgIGJ1c3k9e3BhZ2Uuc2F2aW5nfVxyXG4gICAgICA+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntwYWdlLnRhcmdldD8udXNlcm5hbWV9PC9wPlxyXG4gICAgICAgIHtwYWdlLmVycm9yICYmIChcclxuICAgICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtZGFuZ2VyIG10LTNcIj5cclxuICAgICAgICAgICAge3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBmbGV4LXdyYXAganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnNhdmluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRUYXJnZXQobnVsbCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHsnQ2FuY2VsJ31cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgYnVzeT17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHBhZ2UudGFyZ2V0ICYmIHZvaWQgcGFnZS51cGRhdGUocGFnZS50YXJnZXQsIGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3QuZGVhY3RpdmF0ZX1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0RpYWxvZz5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==