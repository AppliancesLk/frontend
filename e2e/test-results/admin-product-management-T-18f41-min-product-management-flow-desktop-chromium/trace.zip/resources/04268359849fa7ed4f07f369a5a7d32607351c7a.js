import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/AccountDetails.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { useAuth } from "/src/hooks/useAuth.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AccountDetails.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function AccountDetails() {
	_s();
	const { user } = useAuth();
	return /* @__PURE__ */ _jsxDEV("dl", {
		className: "my-8 divide-y divide-line-subtle rounded-md border border-line px-5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "py-4",
			children: [/* @__PURE__ */ _jsxDEV("dt", {
				className: "text-xs tracking-wide text-fg-muted",
				children: translations.auth.email
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("dd", {
				className: "mt-1 break-all font-medium text-fg",
				children: user?.email
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "py-4",
			children: [/* @__PURE__ */ _jsxDEV("dt", {
				className: "text-xs tracking-wide text-fg-muted",
				children: translations.auth.accountRole
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("dd", {
				className: "mt-2",
				children: /* @__PURE__ */ _jsxDEV("span", {
					className: "rounded-full bg-subtle px-3 py-1 text-xs font-semibold text-fg-secondary",
					children: user?.role
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_s(AccountDetails, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = AccountDetails;
var _c;
$RefreshReg$(_c, "AccountDetails");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/AccountDetails.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AccountDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AccountDetails.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AccountDetails.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsb0JBQW9COzs7O0FBQzdCLE9BQU8sU0FBUyxpQkFBaUI7O0NBQy9CLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FDRSx3QkFBQyxNQUFEO0VBQUksV0FBVTtZQUFkLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsYUFBYSxLQUFLO0dBQ2pCOzs7O2FBQ0osd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBc0MsTUFBTTtHQUFVOzs7O1dBQ2pFOzs7OztZQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLGFBQWEsS0FBSztHQUNqQjs7OzthQUNKLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1osd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDYixNQUFNO0lBQ0g7Ozs7O0dBQ0o7Ozs7V0FDRDs7Ozs7VUFDSDs7Ozs7O0FBRVIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWNjb3VudERldGFpbHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9ob29rcy91c2VBdXRoJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuZXhwb3J0IGZ1bmN0aW9uIEFjY291bnREZXRhaWxzKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGwgY2xhc3NOYW1lPVwibXktOCBkaXZpZGUteSBkaXZpZGUtbGluZS1zdWJ0bGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgcHgtNVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTRcIj5cclxuICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0cmFja2luZy13aWRlIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYXV0aC5lbWFpbH1cclxuICAgICAgICA8L2R0PlxyXG4gICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIGJyZWFrLWFsbCBmb250LW1lZGl1bSB0ZXh0LWZnXCI+e3VzZXI/LmVtYWlsfTwvZGQ+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTRcIj5cclxuICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0cmFja2luZy13aWRlIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYXV0aC5hY2NvdW50Um9sZX1cclxuICAgICAgICA8L2R0PlxyXG4gICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0yXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctc3VidGxlIHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAge3VzZXI/LnJvbGV9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kZD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2RsPlxyXG4gICk7XHJcbn1cclxuIl19