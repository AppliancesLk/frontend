import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/seasonal/SeasonalArtwork.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalArtwork.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function SeasonalArtwork({ theme, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("svg", {
		viewBox: "0 0 300 180",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		className,
		children: [
			theme === "CHRISTMAS" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "208",
					cy: "81",
					r: "68",
					fill: "#ffffff",
					fillOpacity: ".07"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m172 20 22 33h-12l25 35h-15l29 42h-98l29-42h-15l25-35h-12l22-33Z",
					fill: "#2f775c",
					stroke: "#a4c7ab",
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M172 130v17",
					stroke: "#d5a968",
					strokeWidth: "7"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m172 14 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1 3-6Z",
					fill: "#efd28b"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M154 67c12 7 25 7 36 0m-47 31c17 9 40 9 57 0",
					stroke: "#f2d593",
					strokeWidth: "2",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "172",
					cy: "53",
					r: "3",
					fill: "#f4b2b7"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "153",
					cy: "90",
					r: "3",
					fill: "#ecca83"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "190",
					cy: "111",
					r: "3",
					fill: "#f4b2b7"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "61",
					y: "110",
					width: "57",
					height: "41",
					rx: "4",
					fill: "#ba3d51"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "56",
					y: "103",
					width: "67",
					height: "13",
					rx: "3",
					fill: "#d66070"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M90 104v48m-2-48c-31-3-24-26-10-19 9 4 11 19 11 19Zm3 0c27-9 18-26 8-18-6 4-8 18-8 18Z",
					stroke: "#f4deb1",
					strokeWidth: "4"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m241 32 0 13m-6-6h12m-99-28v9m-4-4h8M48 57v12m-6-6h12",
					stroke: "#f5e7cb",
					strokeWidth: "1.5",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("g", {
					fill: "#e8efe7",
					children: [
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "222",
							cy: "83",
							r: "2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "66",
							cy: "30",
							r: "2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "118",
							cy: "41",
							r: "1.5"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "258",
							cy: "114",
							r: "2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "42",
							cy: "126",
							r: "1.5"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M36 154c63-9 144-9 234 0",
					stroke: "#d9e6d6",
					strokeOpacity: ".35",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this),
			theme === "AVURUDU" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "156",
					cy: "76",
					r: "53",
					fill: "#f5d77e",
					fillOpacity: ".22"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "156",
					cy: "76",
					r: "30",
					fill: "#edb94f",
					stroke: "#f7dea1",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("g", {
					className: "season-sun-rays season-animated",
					stroke: "#ebc260",
					strokeWidth: "3",
					strokeLinecap: "round",
					children: /* @__PURE__ */ _jsxDEV("path", { d: "M156 30V17m0 118v-13m46-46h14m-120 0h14m79-33 10-10m-76 86-10 10m76-10 10 10m-76-86-10-10" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "season-leaves-left season-animated",
					d: "M65 133c3-30 13-47 36-62m-27 46c-25-7-28-21-26-36 19 4 30 16 26 36Zm8-19c-12-22-7-39 4-50 13 16 15 33-4 50Z",
					fill: "#73834e",
					stroke: "#b8c17e",
					strokeWidth: "2",
					strokeLinejoin: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "season-leaves-right season-animated",
					d: "M238 134c-7-23-20-37-39-44m29 26c20-8 21-22 16-33-16 5-23 15-16 33Zm-15-16c7-20 0-33-12-41-8 15-7 29 12 41Z",
					fill: "#657b4c",
					stroke: "#afbb7a",
					strokeWidth: "2",
					strokeLinejoin: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M107 147c14-25 84-26 98 0H107Z",
					fill: "#b66a37",
					stroke: "#f5d899",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M121 148v8h69v-8",
					stroke: "#eac77e",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M119 140h74m-62-7h50",
					stroke: "#dfac6b",
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("g", {
					fill: "#f5d68b",
					children: [
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "50",
							cy: "42",
							r: "2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "244",
							cy: "39",
							r: "2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("path", { d: "m245 63 3 4-3 4-3-4 3-4Z" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this),
			theme === "HALLOWEEN" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M214 20a31 31 0 1 0 14 57 29 29 0 0 1-14-57Z",
					fill: "#ead8b4"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "season-bats season-animated",
					d: "m51 50 10-8 9 8 10-8 10 8-19-2-1 6-1-6-18 2Zm156 45 9-7 8 7 9-7 9 7-17-2-1 6-1-6-16 2Z",
					fill: "#bca6cc"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M138 86c-2-13 3-22 11-24",
					stroke: "#b1bd87",
					strokeWidth: "7",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M141 89c-34-19-66 4-66 34 0 31 32 44 65 31 33 13 65 0 65-31 0-30-31-53-64-34Z",
					fill: "#db7b36",
					stroke: "#f5bd79",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("ellipse", {
					cx: "140",
					cy: "122",
					rx: "25",
					ry: "37",
					stroke: "#a94823",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m108 113 9-12 8 13-17-1Zm48 0 8-12 9 13-17-1Z",
					fill: "#38253d"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 150,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "season-pumpkin-smile season-animated",
					d: "m118 134 10 6 12-5 12 5 11-6c-8 17-35 19-45 0Z",
					fill: "#38253d"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("g", {
					stroke: "#d4beda",
					strokeWidth: "1.5",
					strokeLinecap: "round",
					children: /* @__PURE__ */ _jsxDEV("path", { d: "M52 94v10m-5-5h10m184 26v10m-5-5h10M116 36v7m-3-4h6" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M63 162c48-6 112-6 165 0",
					stroke: "#c2a4d0",
					strokeOpacity: ".35",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 9
			}, this),
			theme === "EASTER" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "154",
					cy: "79",
					r: "66",
					fill: "#ffffff",
					fillOpacity: ".14"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M67 151c-3-23-13-41-28-51m23 25c-24 1-29-12-28-25 16 0 27 8 28 25Zm-5-20c-15-14-15-27-8-39 14 9 20 23 8 39Z",
					fill: "#7d987a"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M237 149c7-25 20-39 35-47m-26 26c23 3 30-8 31-21-17-3-28 5-31 21Zm8-21c16-12 19-24 14-36-15 6-23 18-14 36Z",
					fill: "#7d987a"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M160 57c-21 0-40 36-40 62 0 27 19 39 40 39s40-12 40-39c0-26-19-62-40-62Z",
					fill: "#bca1d3",
					stroke: "#eadff3",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m122 114 12-9 13 9 13-9 13 9 13-9 12 9m-75 19h74",
					stroke: "#f6e4a7",
					strokeWidth: "5",
					strokeLinejoin: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M101 90c-16 0-31 27-31 47 0 19 15 28 31 28s31-9 31-28c0-20-15-47-31-47Z",
					fill: "#e4bdaf",
					stroke: "#f8e4d7",
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("g", {
					fill: "#faf2d9",
					children: [
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "90",
							cy: "125",
							r: "3"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "110",
							cy: "139",
							r: "3"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "91",
							cy: "150",
							r: "3"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("circle", {
							cx: "110",
							cy: "112",
							r: "3"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 199,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m77 44 3 8 8 3-8 3-3 8-3-8-8-3 8-3 3-8Zm154 18 2 6 6 2-6 2-2 6-2-6-6-2 6-2 2-6Z",
					fill: "#f4dda0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 205,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 9
			}, this),
			theme === "DEFAULT" && /* @__PURE__ */ _jsxDEV("g", {
				stroke: "currentColor",
				strokeWidth: "2",
				opacity: ".7",
				children: [
					/* @__PURE__ */ _jsxDEV("rect", {
						x: "106",
						y: "39",
						width: "90",
						height: "107",
						rx: "22"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("path", { d: "M134 67v18m33-18v18m-43 0h53v8a26 26 0 0 1-53 0v-8Zm27 35v14" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("circle", {
						cx: "180",
						cy: "53",
						r: "5",
						fill: "#facc15",
						stroke: "none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_c = SeasonalArtwork;
export function BrandOrnament({ theme }) {
	if (theme === "DEFAULT") return null;
	return /* @__PURE__ */ _jsxDEV("svg", {
		viewBox: "0 0 44 34",
		fill: "none",
		className: `season-logo-ornament season-logo-${theme.toLowerCase()}`,
		"data-ornament": theme,
		"aria-hidden": "true",
		focusable: "false",
		children: [
			theme === "CHRISTMAS" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M7 25C13 5 25 1 35 15l-7 2c-4-5-7-4-8 1l-1 9-12-2Z",
					fill: "#b32840",
					stroke: "#79243b",
					strokeWidth: "1"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 235,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "4",
					y: "23",
					width: "23",
					height: "7",
					rx: "3.5",
					transform: "rotate(-9 4 23)",
					fill: "#fff8ec",
					stroke: "#c8d1c7"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "35",
					cy: "16",
					r: "5",
					fill: "#fff8ec",
					stroke: "#c8d1c7"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 251,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 234,
				columnNumber: 9
			}, this),
			theme === "AVURUDU" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("g", {
					stroke: "#c98b25",
					strokeWidth: "1.5",
					strokeLinecap: "round",
					children: /* @__PURE__ */ _jsxDEV("path", { d: "M25 2v4m0 22v4M10 17h4m22 0h4M14 6l3 3m16 16 3 3m0-22-3 3M17 25l-3 3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "25",
					cy: "17",
					r: "8",
					fill: "#f2cc6e",
					stroke: "#b7721f"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 259,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M5 28c-2-8 0-13 8-16 4 8 1 14-8 16Z",
					fill: "#71834c",
					stroke: "#b4c17f"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 260,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 255,
				columnNumber: 9
			}, this),
			theme === "HALLOWEEN" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m10 25 9-23 5 11 9 6-6 6H10Z",
					fill: "#573469",
					stroke: "#b8a0c6"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 269,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m13 17 15 3-3 5-13-2 1-6Z",
					fill: "#ed9b4e"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("ellipse", {
					cx: "22",
					cy: "26",
					rx: "19",
					ry: "4",
					fill: "#452952",
					stroke: "#b8a0c6"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 275,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m20 8 1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3Z",
					fill: "#f8d68d"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 283,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 268,
				columnNumber: 9
			}, this),
			theme === "EASTER" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("ellipse", {
					cx: "15",
					cy: "15",
					rx: "5",
					ry: "14",
					transform: "rotate(-19 15 15)",
					fill: "#f4e7f5",
					stroke: "#9d78b7",
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 288,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("ellipse", {
					cx: "29",
					cy: "15",
					rx: "5",
					ry: "14",
					transform: "rotate(17 29 15)",
					fill: "#f4e7f5",
					stroke: "#9d78b7",
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 298,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "m12 8 4 14m15-14-3 14",
					stroke: "#d9b3cf",
					strokeWidth: "3",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 308,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 287,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 225,
		columnNumber: 5
	}, this);
}
_c2 = BrandOrnament;
var _c, _c2;
$RefreshReg$(_c, "SeasonalArtwork");
$RefreshReg$(_c2, "BrandOrnament");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/seasonal/SeasonalArtwork.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalArtwork.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalArtwork.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalArtwork.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFFQSxPQUFPLFNBQVMsZ0JBQWdCLEVBQzlCLE9BQ0EsWUFBWSxNQUlYO0NBQ0QsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsU0FBUTtFQUNSLE1BQUs7RUFDTCxlQUFZO0VBQ1osV0FBVTtFQUNDO1lBTGI7R0FPRyxVQUFVLGVBQ1Q7SUFDRSx3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFNLElBQUc7S0FBSyxHQUFFO0tBQUssTUFBSztLQUFVLGFBQVk7SUFBTzs7Ozs7SUFDbEUsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxRQUFEO0tBQU0sR0FBRTtLQUFjLFFBQU87S0FBVSxhQUFZO0lBQUs7Ozs7O0lBQ3hELHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsTUFBSztJQUNOOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsUUFBTztLQUNQLGFBQVk7S0FDWixlQUFjO0lBQ2Y7Ozs7O0lBQ0Qsd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBTSxJQUFHO0tBQUssR0FBRTtLQUFJLE1BQUs7SUFBVzs7Ozs7SUFDL0Msd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBTSxJQUFHO0tBQUssR0FBRTtLQUFJLE1BQUs7SUFBVzs7Ozs7SUFDL0Msd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBTSxJQUFHO0tBQU0sR0FBRTtLQUFJLE1BQUs7SUFBVzs7Ozs7SUFDaEQsd0JBQUMsUUFBRDtLQUFNLEdBQUU7S0FBSyxHQUFFO0tBQU0sT0FBTTtLQUFLLFFBQU87S0FBSyxJQUFHO0tBQUksTUFBSztJQUFXOzs7OztJQUNuRSx3QkFBQyxRQUFEO0tBQU0sR0FBRTtLQUFLLEdBQUU7S0FBTSxPQUFNO0tBQUssUUFBTztLQUFLLElBQUc7S0FBSSxNQUFLO0lBQVc7Ozs7O0lBQ25FLHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxRQUFEO0tBQ0UsR0FBRTtLQUNGLFFBQU87S0FDUCxhQUFZO0tBQ1osZUFBYztJQUNmOzs7OztJQUNELHdCQUFDLEtBQUQ7S0FBRyxNQUFLO2VBQVI7TUFDRSx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFNLElBQUc7T0FBSyxHQUFFO01BQUs7Ozs7O01BQ2hDLHdCQUFDLFVBQUQ7T0FBUSxJQUFHO09BQUssSUFBRztPQUFLLEdBQUU7TUFBSzs7Ozs7TUFDL0Isd0JBQUMsVUFBRDtPQUFRLElBQUc7T0FBTSxJQUFHO09BQUssR0FBRTtNQUFPOzs7OztNQUNsQyx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFNLElBQUc7T0FBTSxHQUFFO01BQUs7Ozs7O01BQ2pDLHdCQUFDLFVBQUQ7T0FBUSxJQUFHO09BQUssSUFBRztPQUFNLEdBQUU7TUFBTzs7Ozs7S0FDakM7Ozs7OztJQUNILHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsUUFBTztLQUNQLGVBQWM7S0FDZCxlQUFjO0lBQ2Y7Ozs7O0dBQ0Q7Ozs7O0dBRUgsVUFBVSxhQUNUO0lBQ0Usd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBTSxJQUFHO0tBQUssR0FBRTtLQUFLLE1BQUs7S0FBVSxhQUFZO0lBQU87Ozs7O0lBQ2xFLHdCQUFDLFVBQUQ7S0FDRSxJQUFHO0tBQ0gsSUFBRztLQUNILEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxLQUFEO0tBQ0UsV0FBVTtLQUNWLFFBQU87S0FDUCxhQUFZO0tBQ1osZUFBYztlQUVkLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDRGQUE2Rjs7Ozs7SUFDcEc7Ozs7O0lBQ0gsd0JBQUMsUUFBRDtLQUNFLFdBQVU7S0FDVixHQUFFO0tBQ0YsTUFBSztLQUNMLFFBQU87S0FDUCxhQUFZO0tBQ1osZ0JBQWU7SUFDaEI7Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUNFLFdBQVU7S0FDVixHQUFFO0tBQ0YsTUFBSztLQUNMLFFBQU87S0FDUCxhQUFZO0tBQ1osZ0JBQWU7SUFDaEI7Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxRQUFEO0tBQU0sR0FBRTtLQUFtQixRQUFPO0tBQVUsYUFBWTtJQUFLOzs7OztJQUM3RCx3QkFBQyxRQUFEO0tBQU0sR0FBRTtLQUF1QixRQUFPO0tBQVUsYUFBWTtJQUFPOzs7OztJQUNuRSx3QkFBQyxLQUFEO0tBQUcsTUFBSztlQUFSO01BQ0Usd0JBQUMsVUFBRDtPQUFRLElBQUc7T0FBSyxJQUFHO09BQUssR0FBRTtNQUFLOzs7OztNQUMvQix3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFNLElBQUc7T0FBSyxHQUFFO01BQUs7Ozs7O01BQ2hDLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDJCQUE0Qjs7Ozs7S0FDbkM7Ozs7OztHQUNIOzs7OztHQUVILFVBQVUsZUFDVDtJQUNFLHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsTUFBSztJQUNOOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FDRSxXQUFVO0tBQ1YsR0FBRTtLQUNGLE1BQUs7SUFDTjs7Ozs7SUFDRCx3QkFBQyxRQUFEO0tBQ0UsR0FBRTtLQUNGLFFBQU87S0FDUCxhQUFZO0tBQ1osZUFBYztJQUNmOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsTUFBSztLQUNMLFFBQU87S0FDUCxhQUFZO0lBQ2I7Ozs7O0lBQ0Qsd0JBQUMsV0FBRDtLQUNFLElBQUc7S0FDSCxJQUFHO0tBQ0gsSUFBRztLQUNILElBQUc7S0FDSCxRQUFPO0tBQ1AsYUFBWTtJQUNiOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsTUFBSztJQUNOOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FDRSxXQUFVO0tBQ1YsR0FBRTtLQUNGLE1BQUs7SUFDTjs7Ozs7SUFDRCx3QkFBQyxLQUFEO0tBQUcsUUFBTztLQUFVLGFBQVk7S0FBTSxlQUFjO2VBQ2xELHdCQUFDLFFBQUQsRUFBTSxHQUFFLHNEQUF1RDs7Ozs7SUFDOUQ7Ozs7O0lBQ0gsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixRQUFPO0tBQ1AsZUFBYztLQUNkLGVBQWM7SUFDZjs7Ozs7R0FDRDs7Ozs7R0FFSCxVQUFVLFlBQ1Q7SUFDRSx3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFNLElBQUc7S0FBSyxHQUFFO0tBQUssTUFBSztLQUFVLGFBQVk7SUFBTzs7Ozs7SUFDbEUsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0lBQ047Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0lBQ047Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxRQUFEO0tBQ0UsR0FBRTtLQUNGLFFBQU87S0FDUCxhQUFZO0tBQ1osZ0JBQWU7SUFDaEI7Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxLQUFEO0tBQUcsTUFBSztlQUFSO01BQ0Usd0JBQUMsVUFBRDtPQUFRLElBQUc7T0FBSyxJQUFHO09BQU0sR0FBRTtNQUFLOzs7OztNQUNoQyx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFNLElBQUc7T0FBTSxHQUFFO01BQUs7Ozs7O01BQ2pDLHdCQUFDLFVBQUQ7T0FBUSxJQUFHO09BQUssSUFBRztPQUFNLEdBQUU7TUFBSzs7Ozs7TUFDaEMsd0JBQUMsVUFBRDtPQUFRLElBQUc7T0FBTSxJQUFHO09BQU0sR0FBRTtNQUFLOzs7OztLQUNoQzs7Ozs7O0lBQ0gsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0lBQ047Ozs7O0dBQ0Q7Ozs7O0dBRUgsVUFBVSxhQUNULHdCQUFDLEtBQUQ7SUFBRyxRQUFPO0lBQWUsYUFBWTtJQUFJLFNBQVE7Y0FBakQ7S0FDRSx3QkFBQyxRQUFEO01BQU0sR0FBRTtNQUFNLEdBQUU7TUFBSyxPQUFNO01BQUssUUFBTztNQUFNLElBQUc7S0FBTTs7Ozs7S0FDdEQsd0JBQUMsUUFBRCxFQUFNLEdBQUUsK0RBQWdFOzs7OztLQUN4RSx3QkFBQyxVQUFEO01BQVEsSUFBRztNQUFNLElBQUc7TUFBSyxHQUFFO01BQUksTUFBSztNQUFVLFFBQU87S0FBUTs7Ozs7SUFDNUQ7Ozs7OztFQUVGOzs7Ozs7QUFFVDs7QUFFQSxPQUFPLFNBQVMsY0FBYyxFQUFFLFNBQW1DO0NBQ2pFLElBQUksVUFBVSxXQUFXLE9BQU87Q0FDaEMsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsU0FBUTtFQUNSLE1BQUs7RUFDTCxXQUFXLG9DQUFvQyxNQUFNLFlBQVk7RUFDakUsaUJBQWU7RUFDZixlQUFZO0VBQ1osV0FBVTtZQU5aO0dBUUcsVUFBVSxlQUNUO0lBQ0Usd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztLQUNQLGFBQVk7SUFDYjs7Ozs7SUFDRCx3QkFBQyxRQUFEO0tBQ0UsR0FBRTtLQUNGLEdBQUU7S0FDRixPQUFNO0tBQ04sUUFBTztLQUNQLElBQUc7S0FDSCxXQUFVO0tBQ1YsTUFBSztLQUNMLFFBQU87SUFDUjs7Ozs7SUFDRCx3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFLLElBQUc7S0FBSyxHQUFFO0tBQUksTUFBSztLQUFVLFFBQU87SUFBVzs7Ozs7R0FDL0Q7Ozs7O0dBRUgsVUFBVSxhQUNUO0lBQ0Usd0JBQUMsS0FBRDtLQUFHLFFBQU87S0FBVSxhQUFZO0tBQU0sZUFBYztlQUNsRCx3QkFBQyxRQUFELEVBQU0sR0FBRSx1RUFBd0U7Ozs7O0lBQy9FOzs7OztJQUNILHdCQUFDLFVBQUQ7S0FBUSxJQUFHO0tBQUssSUFBRztLQUFLLEdBQUU7S0FBSSxNQUFLO0tBQVUsUUFBTztJQUFXOzs7OztJQUMvRCx3QkFBQyxRQUFEO0tBQ0UsR0FBRTtLQUNGLE1BQUs7S0FDTCxRQUFPO0lBQ1I7Ozs7O0dBQ0Q7Ozs7O0dBRUgsVUFBVSxlQUNUO0lBQ0Usd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFLO0tBQ0wsUUFBTztJQUNSOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FBTSxHQUFFO0tBQTRCLE1BQUs7SUFBVzs7Ozs7SUFDcEQsd0JBQUMsV0FBRDtLQUNFLElBQUc7S0FDSCxJQUFHO0tBQ0gsSUFBRztLQUNILElBQUc7S0FDSCxNQUFLO0tBQ0wsUUFBTztJQUNSOzs7OztJQUNELHdCQUFDLFFBQUQ7S0FBTSxHQUFFO0tBQXlDLE1BQUs7SUFBVzs7Ozs7R0FDakU7Ozs7O0dBRUgsVUFBVSxZQUNUO0lBQ0Usd0JBQUMsV0FBRDtLQUNFLElBQUc7S0FDSCxJQUFHO0tBQ0gsSUFBRztLQUNILElBQUc7S0FDSCxXQUFVO0tBQ1YsTUFBSztLQUNMLFFBQU87S0FDUCxhQUFZO0lBQ2I7Ozs7O0lBQ0Qsd0JBQUMsV0FBRDtLQUNFLElBQUc7S0FDSCxJQUFHO0tBQ0gsSUFBRztLQUNILElBQUc7S0FDSCxXQUFVO0tBQ1YsTUFBSztLQUNMLFFBQU87S0FDUCxhQUFZO0lBQ2I7Ozs7O0lBQ0Qsd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixRQUFPO0tBQ1AsYUFBWTtLQUNaLGVBQWM7SUFDZjs7Ozs7R0FDRDs7Ozs7RUFFRDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2Vhc29uYWxBcnR3b3JrLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFNlYXNvbmFsVGhlbWUgfSBmcm9tICcuLi8uLi90eXBlcy9zZWFzb25hbC10aGVtZS50eXBlcyc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2Vhc29uYWxBcnR3b3JrKHtcclxuICB0aGVtZSxcclxuICBjbGFzc05hbWUgPSAnJyxcclxufToge1xyXG4gIHRoZW1lOiBTZWFzb25hbFRoZW1lO1xyXG4gIGNsYXNzTmFtZT86IHN0cmluZztcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIHZpZXdCb3g9XCIwIDAgMzAwIDE4MFwiXHJcbiAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgZm9jdXNhYmxlPVwiZmFsc2VcIlxyXG4gICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cclxuICAgID5cclxuICAgICAge3RoZW1lID09PSAnQ0hSSVNUTUFTJyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxjaXJjbGUgY3g9XCIyMDhcIiBjeT1cIjgxXCIgcj1cIjY4XCIgZmlsbD1cIiNmZmZmZmZcIiBmaWxsT3BhY2l0eT1cIi4wN1wiIC8+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwibTE3MiAyMCAyMiAzM2gtMTJsMjUgMzVoLTE1bDI5IDQyaC05OGwyOS00MmgtMTVsMjUtMzVoLTEybDIyLTMzWlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjMmY3NzVjXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2E0YzdhYlwiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMS41XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cGF0aCBkPVwiTTE3MiAxMzB2MTdcIiBzdHJva2U9XCIjZDVhOTY4XCIgc3Ryb2tlV2lkdGg9XCI3XCIgLz5cclxuICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgIGQ9XCJtMTcyIDE0IDMgNiA3IDEtNSA1IDEgNy02LTMtNiAzIDEtNy01LTUgNy0xIDMtNlpcIlxyXG4gICAgICAgICAgICBmaWxsPVwiI2VmZDI4YlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk0xNTQgNjdjMTIgNyAyNSA3IDM2IDBtLTQ3IDMxYzE3IDkgNDAgOSA1NyAwXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2YyZDU5M1wiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGNpcmNsZSBjeD1cIjE3MlwiIGN5PVwiNTNcIiByPVwiM1wiIGZpbGw9XCIjZjRiMmI3XCIgLz5cclxuICAgICAgICAgIDxjaXJjbGUgY3g9XCIxNTNcIiBjeT1cIjkwXCIgcj1cIjNcIiBmaWxsPVwiI2VjY2E4M1wiIC8+XHJcbiAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTkwXCIgY3k9XCIxMTFcIiByPVwiM1wiIGZpbGw9XCIjZjRiMmI3XCIgLz5cclxuICAgICAgICAgIDxyZWN0IHg9XCI2MVwiIHk9XCIxMTBcIiB3aWR0aD1cIjU3XCIgaGVpZ2h0PVwiNDFcIiByeD1cIjRcIiBmaWxsPVwiI2JhM2Q1MVwiIC8+XHJcbiAgICAgICAgICA8cmVjdCB4PVwiNTZcIiB5PVwiMTAzXCIgd2lkdGg9XCI2N1wiIGhlaWdodD1cIjEzXCIgcng9XCIzXCIgZmlsbD1cIiNkNjYwNzBcIiAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk05MCAxMDR2NDhtLTItNDhjLTMxLTMtMjQtMjYtMTAtMTkgOSA0IDExIDE5IDExIDE5Wm0zIDBjMjctOSAxOC0yNiA4LTE4LTYgNC04IDE4LTggMThaXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2Y0ZGViMVwiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIm0yNDEgMzIgMCAxM20tNi02aDEybS05OS0yOHY5bS00LTRoOE00OCA1N3YxMm0tNi02aDEyXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2Y1ZTdjYlwiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMS41XCJcclxuICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZyBmaWxsPVwiI2U4ZWZlN1wiPlxyXG4gICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMjIyXCIgY3k9XCI4M1wiIHI9XCIyXCIgLz5cclxuICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjY2XCIgY3k9XCIzMFwiIHI9XCIyXCIgLz5cclxuICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjExOFwiIGN5PVwiNDFcIiByPVwiMS41XCIgLz5cclxuICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjI1OFwiIGN5PVwiMTE0XCIgcj1cIjJcIiAvPlxyXG4gICAgICAgICAgICA8Y2lyY2xlIGN4PVwiNDJcIiBjeT1cIjEyNlwiIHI9XCIxLjVcIiAvPlxyXG4gICAgICAgICAgPC9nPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk0zNiAxNTRjNjMtOSAxNDQtOSAyMzQgMFwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNkOWU2ZDZcIlxyXG4gICAgICAgICAgICBzdHJva2VPcGFjaXR5PVwiLjM1XCJcclxuICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHt0aGVtZSA9PT0gJ0FWVVJVRFUnICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGNpcmNsZSBjeD1cIjE1NlwiIGN5PVwiNzZcIiByPVwiNTNcIiBmaWxsPVwiI2Y1ZDc3ZVwiIGZpbGxPcGFjaXR5PVwiLjIyXCIgLz5cclxuICAgICAgICAgIDxjaXJjbGVcclxuICAgICAgICAgICAgY3g9XCIxNTZcIlxyXG4gICAgICAgICAgICBjeT1cIjc2XCJcclxuICAgICAgICAgICAgcj1cIjMwXCJcclxuICAgICAgICAgICAgZmlsbD1cIiNlZGI5NGZcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjZjdkZWExXCJcclxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Z1xyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFzb24tc3VuLXJheXMgc2Vhc29uLWFuaW1hdGVkXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2ViYzI2MFwiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiM1wiXHJcbiAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTU2IDMwVjE3bTAgMTE4di0xM200Ni00NmgxNG0tMTIwIDBoMTRtNzktMzMgMTAtMTBtLTc2IDg2LTEwIDEwbTc2LTEwIDEwIDEwbS03Ni04Ni0xMC0xMFwiIC8+XHJcbiAgICAgICAgICA8L2c+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFzb24tbGVhdmVzLWxlZnQgc2Vhc29uLWFuaW1hdGVkXCJcclxuICAgICAgICAgICAgZD1cIk02NSAxMzNjMy0zMCAxMy00NyAzNi02Mm0tMjcgNDZjLTI1LTctMjgtMjEtMjYtMzYgMTkgNCAzMCAxNiAyNiAzNlptOC0xOWMtMTItMjItNy0zOSA0LTUwIDEzIDE2IDE1IDMzLTQgNTBaXCJcclxuICAgICAgICAgICAgZmlsbD1cIiM3MzgzNGVcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjYjhjMTdlXCJcclxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic2Vhc29uLWxlYXZlcy1yaWdodCBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgICAgICBkPVwiTTIzOCAxMzRjLTctMjMtMjAtMzctMzktNDRtMjkgMjZjMjAtOCAyMS0yMiAxNi0zMy0xNiA1LTIzIDE1LTE2IDMzWm0tMTUtMTZjNy0yMCAwLTMzLTEyLTQxLTggMTUtNyAyOSAxMiA0MVpcIlxyXG4gICAgICAgICAgICBmaWxsPVwiIzY1N2I0Y1wiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNhZmJiN2FcIlxyXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwiTTEwNyAxNDdjMTQtMjUgODQtMjYgOTggMEgxMDdaXCJcclxuICAgICAgICAgICAgZmlsbD1cIiNiNjZhMzdcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjZjVkODk5XCJcclxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cGF0aCBkPVwiTTEyMSAxNDh2OGg2OXYtOFwiIHN0cm9rZT1cIiNlYWM3N2VcIiBzdHJva2VXaWR0aD1cIjJcIiAvPlxyXG4gICAgICAgICAgPHBhdGggZD1cIk0xMTkgMTQwaDc0bS02Mi03aDUwXCIgc3Ryb2tlPVwiI2RmYWM2YlwiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cclxuICAgICAgICAgIDxnIGZpbGw9XCIjZjVkNjhiXCI+XHJcbiAgICAgICAgICAgIDxjaXJjbGUgY3g9XCI1MFwiIGN5PVwiNDJcIiByPVwiMlwiIC8+XHJcbiAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIyNDRcIiBjeT1cIjM5XCIgcj1cIjJcIiAvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwibTI0NSA2MyAzIDQtMyA0LTMtNCAzLTRaXCIgLz5cclxuICAgICAgICAgIDwvZz5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAge3RoZW1lID09PSAnSEFMTE9XRUVOJyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgIGQ9XCJNMjE0IDIwYTMxIDMxIDAgMSAwIDE0IDU3IDI5IDI5IDAgMCAxLTE0LTU3WlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjZWFkOGI0XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFzb24tYmF0cyBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgICAgICBkPVwibTUxIDUwIDEwLTggOSA4IDEwLTggMTAgOC0xOS0yLTEgNi0xLTYtMTggMlptMTU2IDQ1IDktNyA4IDcgOS03IDkgNy0xNy0yLTEgNi0xLTYtMTYgMlpcIlxyXG4gICAgICAgICAgICBmaWxsPVwiI2JjYTZjY1wiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk0xMzggODZjLTItMTMgMy0yMiAxMS0yNFwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNiMWJkODdcIlxyXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjdcIlxyXG4gICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgIGQ9XCJNMTQxIDg5Yy0zNC0xOS02NiA0LTY2IDM0IDAgMzEgMzIgNDQgNjUgMzEgMzMgMTMgNjUgMCA2NS0zMSAwLTMwLTMxLTUzLTY0LTM0WlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjZGI3YjM2XCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2Y1YmQ3OVwiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGVsbGlwc2VcclxuICAgICAgICAgICAgY3g9XCIxNDBcIlxyXG4gICAgICAgICAgICBjeT1cIjEyMlwiXHJcbiAgICAgICAgICAgIHJ4PVwiMjVcIlxyXG4gICAgICAgICAgICByeT1cIjM3XCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2E5NDgyM1wiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIm0xMDggMTEzIDktMTIgOCAxMy0xNy0xWm00OCAwIDgtMTIgOSAxMy0xNy0xWlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjMzgyNTNkXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFzb24tcHVtcGtpbi1zbWlsZSBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgICAgICBkPVwibTExOCAxMzQgMTAgNiAxMi01IDEyIDUgMTEtNmMtOCAxNy0zNSAxOS00NSAwWlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjMzgyNTNkXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZyBzdHJva2U9XCIjZDRiZWRhXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIj5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk01MiA5NHYxMG0tNS01aDEwbTE4NCAyNnYxMG0tNS01aDEwTTExNiAzNnY3bS0zLTRoNlwiIC8+XHJcbiAgICAgICAgICA8L2c+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwiTTYzIDE2MmM0OC02IDExMi02IDE2NSAwXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2MyYTRkMFwiXHJcbiAgICAgICAgICAgIHN0cm9rZU9wYWNpdHk9XCIuMzVcIlxyXG4gICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAge3RoZW1lID09PSAnRUFTVEVSJyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxjaXJjbGUgY3g9XCIxNTRcIiBjeT1cIjc5XCIgcj1cIjY2XCIgZmlsbD1cIiNmZmZmZmZcIiBmaWxsT3BhY2l0eT1cIi4xNFwiIC8+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwiTTY3IDE1MWMtMy0yMy0xMy00MS0yOC01MW0yMyAyNWMtMjQgMS0yOS0xMi0yOC0yNSAxNiAwIDI3IDggMjggMjVabS01LTIwYy0xNS0xNC0xNS0yNy04LTM5IDE0IDkgMjAgMjMgOCAzOVpcIlxyXG4gICAgICAgICAgICBmaWxsPVwiIzdkOTg3YVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk0yMzcgMTQ5YzctMjUgMjAtMzkgMzUtNDdtLTI2IDI2YzIzIDMgMzAtOCAzMS0yMS0xNy0zLTI4IDUtMzEgMjFabTgtMjFjMTYtMTIgMTktMjQgMTQtMzYtMTUgNi0yMyAxOC0xNCAzNlpcIlxyXG4gICAgICAgICAgICBmaWxsPVwiIzdkOTg3YVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk0xNjAgNTdjLTIxIDAtNDAgMzYtNDAgNjIgMCAyNyAxOSAzOSA0MCAzOXM0MC0xMiA0MC0zOWMwLTI2LTE5LTYyLTQwLTYyWlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjYmNhMWQzXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2VhZGZmM1wiXHJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIm0xMjIgMTE0IDEyLTkgMTMgOSAxMy05IDEzIDkgMTMtOSAxMiA5bS03NSAxOWg3NFwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNmNmU0YTdcIlxyXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjVcIlxyXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwiTTEwMSA5MGMtMTYgMC0zMSAyNy0zMSA0NyAwIDE5IDE1IDI4IDMxIDI4czMxLTkgMzEtMjhjMC0yMC0xNS00Ny0zMS00N1pcIlxyXG4gICAgICAgICAgICBmaWxsPVwiI2U0YmRhZlwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNmOGU0ZDdcIlxyXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxnIGZpbGw9XCIjZmFmMmQ5XCI+XHJcbiAgICAgICAgICAgIDxjaXJjbGUgY3g9XCI5MFwiIGN5PVwiMTI1XCIgcj1cIjNcIiAvPlxyXG4gICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTEwXCIgY3k9XCIxMzlcIiByPVwiM1wiIC8+XHJcbiAgICAgICAgICAgIDxjaXJjbGUgY3g9XCI5MVwiIGN5PVwiMTUwXCIgcj1cIjNcIiAvPlxyXG4gICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTEwXCIgY3k9XCIxMTJcIiByPVwiM1wiIC8+XHJcbiAgICAgICAgICA8L2c+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwibTc3IDQ0IDMgOCA4IDMtOCAzLTMgOC0zLTgtOC0zIDgtMyAzLThabTE1NCAxOCAyIDYgNiAyLTYgMi0yIDYtMi02LTYtMiA2LTIgMi02WlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjZjRkZGEwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHt0aGVtZSA9PT0gJ0RFRkFVTFQnICYmIChcclxuICAgICAgICA8ZyBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBvcGFjaXR5PVwiLjdcIj5cclxuICAgICAgICAgIDxyZWN0IHg9XCIxMDZcIiB5PVwiMzlcIiB3aWR0aD1cIjkwXCIgaGVpZ2h0PVwiMTA3XCIgcng9XCIyMlwiIC8+XHJcbiAgICAgICAgICA8cGF0aCBkPVwiTTEzNCA2N3YxOG0zMy0xOHYxOG0tNDMgMGg1M3Y4YTI2IDI2IDAgMCAxLTUzIDB2LThabTI3IDM1djE0XCIgLz5cclxuICAgICAgICAgIDxjaXJjbGUgY3g9XCIxODBcIiBjeT1cIjUzXCIgcj1cIjVcIiBmaWxsPVwiI2ZhY2MxNVwiIHN0cm9rZT1cIm5vbmVcIiAvPlxyXG4gICAgICAgIDwvZz5cclxuICAgICAgKX1cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBCcmFuZE9ybmFtZW50KHsgdGhlbWUgfTogeyB0aGVtZTogU2Vhc29uYWxUaGVtZSB9KSB7XHJcbiAgaWYgKHRoZW1lID09PSAnREVGQVVMVCcpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIHZpZXdCb3g9XCIwIDAgNDQgMzRcIlxyXG4gICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgIGNsYXNzTmFtZT17YHNlYXNvbi1sb2dvLW9ybmFtZW50IHNlYXNvbi1sb2dvLSR7dGhlbWUudG9Mb3dlckNhc2UoKX1gfVxyXG4gICAgICBkYXRhLW9ybmFtZW50PXt0aGVtZX1cclxuICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgZm9jdXNhYmxlPVwiZmFsc2VcIlxyXG4gICAgPlxyXG4gICAgICB7dGhlbWUgPT09ICdDSFJJU1RNQVMnICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk03IDI1QzEzIDUgMjUgMSAzNSAxNWwtNyAyYy00LTUtNy00LTggMWwtMSA5LTEyLTJaXCJcclxuICAgICAgICAgICAgZmlsbD1cIiNiMzI4NDBcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjNzkyNDNiXCJcclxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICB4PVwiNFwiXHJcbiAgICAgICAgICAgIHk9XCIyM1wiXHJcbiAgICAgICAgICAgIHdpZHRoPVwiMjNcIlxyXG4gICAgICAgICAgICBoZWlnaHQ9XCI3XCJcclxuICAgICAgICAgICAgcng9XCIzLjVcIlxyXG4gICAgICAgICAgICB0cmFuc2Zvcm09XCJyb3RhdGUoLTkgNCAyMylcIlxyXG4gICAgICAgICAgICBmaWxsPVwiI2ZmZjhlY1wiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNjOGQxYzdcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxjaXJjbGUgY3g9XCIzNVwiIGN5PVwiMTZcIiByPVwiNVwiIGZpbGw9XCIjZmZmOGVjXCIgc3Ryb2tlPVwiI2M4ZDFjN1wiIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHt0aGVtZSA9PT0gJ0FWVVJVRFUnICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGcgc3Ryb2tlPVwiI2M5OGIyNVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMjUgMnY0bTAgMjJ2NE0xMCAxN2g0bTIyIDBoNE0xNCA2bDMgM20xNiAxNiAzIDNtMC0yMi0zIDNNMTcgMjVsLTMgM1wiIC8+XHJcbiAgICAgICAgICA8L2c+XHJcbiAgICAgICAgICA8Y2lyY2xlIGN4PVwiMjVcIiBjeT1cIjE3XCIgcj1cIjhcIiBmaWxsPVwiI2YyY2M2ZVwiIHN0cm9rZT1cIiNiNzcyMWZcIiAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIk01IDI4Yy0yLTggMC0xMyA4LTE2IDQgOCAxIDE0LTggMTZaXCJcclxuICAgICAgICAgICAgZmlsbD1cIiM3MTgzNGNcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjYjRjMTdmXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHt0aGVtZSA9PT0gJ0hBTExPV0VFTicgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBkPVwibTEwIDI1IDktMjMgNSAxMSA5IDYtNiA2SDEwWlwiXHJcbiAgICAgICAgICAgIGZpbGw9XCIjNTczNDY5XCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiI2I4YTBjNlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGggZD1cIm0xMyAxNyAxNSAzLTMgNS0xMy0yIDEtNlpcIiBmaWxsPVwiI2VkOWI0ZVwiIC8+XHJcbiAgICAgICAgICA8ZWxsaXBzZVxyXG4gICAgICAgICAgICBjeD1cIjIyXCJcclxuICAgICAgICAgICAgY3k9XCIyNlwiXHJcbiAgICAgICAgICAgIHJ4PVwiMTlcIlxyXG4gICAgICAgICAgICByeT1cIjRcIlxyXG4gICAgICAgICAgICBmaWxsPVwiIzQ1Mjk1MlwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNiOGEwYzZcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxwYXRoIGQ9XCJtMjAgOCAxIDMgMyAxLTMgMS0xIDMtMS0zLTMtMSAzLTEgMS0zWlwiIGZpbGw9XCIjZjhkNjhkXCIgLz5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAge3RoZW1lID09PSAnRUFTVEVSJyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxlbGxpcHNlXHJcbiAgICAgICAgICAgIGN4PVwiMTVcIlxyXG4gICAgICAgICAgICBjeT1cIjE1XCJcclxuICAgICAgICAgICAgcng9XCI1XCJcclxuICAgICAgICAgICAgcnk9XCIxNFwiXHJcbiAgICAgICAgICAgIHRyYW5zZm9ybT1cInJvdGF0ZSgtMTkgMTUgMTUpXCJcclxuICAgICAgICAgICAgZmlsbD1cIiNmNGU3ZjVcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjOWQ3OGI3XCJcclxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxLjVcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxlbGxpcHNlXHJcbiAgICAgICAgICAgIGN4PVwiMjlcIlxyXG4gICAgICAgICAgICBjeT1cIjE1XCJcclxuICAgICAgICAgICAgcng9XCI1XCJcclxuICAgICAgICAgICAgcnk9XCIxNFwiXHJcbiAgICAgICAgICAgIHRyYW5zZm9ybT1cInJvdGF0ZSgxNyAyOSAxNSlcIlxyXG4gICAgICAgICAgICBmaWxsPVwiI2Y0ZTdmNVwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiM5ZDc4YjdcIlxyXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgZD1cIm0xMiA4IDQgMTRtMTUtMTQtMyAxNFwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cIiNkOWIzY2ZcIlxyXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjNcIlxyXG4gICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuIl19