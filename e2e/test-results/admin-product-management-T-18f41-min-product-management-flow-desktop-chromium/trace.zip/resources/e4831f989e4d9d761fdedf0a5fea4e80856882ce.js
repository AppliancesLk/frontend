import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Orders/components/AdminOrderDetails.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { uiText } from "/src/utils/uiText.ts";
import { OrderProgress } from "/src/components/ui/OrderProgress.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { formatDate } from "/src/utils/date.ts";
import { translations } from "/src/utils/translations.ts";
import { nextOrderStatuses } from "/src/pages/Admin/Orders/helpers/admin-order.helpers.ts";
import { AdminOrderStatusBadge, PaymentBadge } from "/src/pages/Admin/Orders/components/AdminOrderBadges.tsx";
import { commerceText as c } from "/src/utils/commerceText.ts";
import { OrderTimeline } from "/src/components/common/OrderTimeline.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderDetails.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.adminOrders;
export function AdminOrderDetails({ order, page }) {
	_s();
	const [confirmCancel, setConfirmCancel] = useState(false);
	const [cashCollected, setCashCollected] = useState(false);
	const transitions = nextOrderStatuses(order.status);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: confirmCancel,
				onClose: () => setConfirmCancel(false),
				title: uiText.cancelOrder,
				description: uiText.cancelOrderDescription,
				busy: page.saving,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap justify-end gap-3",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: page.saving,
						onClick: () => setConfirmCancel(false),
						children: uiText.cancel
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "danger",
						busy: page.saving,
						onClick: async () => {
							await page.updateStatus("CANCELLED");
							setConfirmCancel(false);
						},
						children: uiText.cancelOrderAction
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "rounded-md border border-line bg-surface p-5  sm:p-6",
				children: /* @__PURE__ */ _jsxDEV("dl", {
					className: "grid gap-5 text-sm sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-fg-muted",
							children: translations.orders.id
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-2 break-all font-medium text-fg",
							children: order.id
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-fg-muted",
								children: t.customer
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-2 font-medium text-fg",
								children: order.customer.username
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 break-all text-fg-muted",
								children: order.customer.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-fg-muted",
							children: translations.orders.date
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-2 text-fg",
							children: formatDate(order.createdAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-fg-muted",
							children: translations.orders.total
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-2 text-lg font-semibold text-fg",
							children: formatCurrency(order.total)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-fg-muted",
							children: translations.orders.status
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-2",
							children: /* @__PURE__ */ _jsxDEV(AdminOrderStatusBadge, { status: order.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-fg-muted",
							children: t.payment
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-2",
							children: order.payment ? /* @__PURE__ */ _jsxDEV(PaymentBadge, { status: order.payment.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "text-fg-muted",
								children: t.noPayment
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(OrderProgress, {
				status: order.status,
				paymentMethod: order.paymentMethod
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(OrderTimeline, { history: order.history }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "ui-panel flex flex-wrap gap-6 p-5 text-sm",
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: [
						c.method,
						":",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: order.paymentMethod === "CASH_ON_DELIVERY" ? c.cod : order.paymentMethod === "LOYALTY" ? c.loyalty : c.payHere }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 11
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						c.creditUsed,
						":",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: formatCurrency(order.loyaltyRedeemed ?? "0.00") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 11
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						c.earned,
						":",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: formatCurrency(order.loyaltyEarned ?? "0.00") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 11
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]",
				children: [/* @__PURE__ */ _jsxDEV("section", {
					className: "rounded-md border border-line bg-surface ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "border-b border-line p-5 text-xl font-semibold text-fg",
						children: translations.orders.items
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("ul", {
						className: "divide-y divide-line",
						children: order.items.map((item) => /* @__PURE__ */ _jsxDEV("li", {
							className: "grid gap-3 p-5 text-sm sm:grid-cols-[minmax(0,1fr)_auto_auto_auto]",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-semibold text-fg",
									children: item.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 text-xs text-fg-muted",
									children: item.SKU
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-fg-muted",
									children: [
										translations.cart.quantity,
										":",
										" "
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 19
								}, this), item.quantity] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: formatCurrency(item.unitPrice) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "font-semibold",
									children: formatCurrency(item.lineTotal)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 17
								}, this)
							]
						}, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("section", {
						className: "rounded-md border border-line bg-surface p-5 ",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-semibold text-fg",
								children: t.updateStatus
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this),
							page.updateError && /* @__PURE__ */ _jsxDEV("p", {
								role: "alert",
								className: "mt-4 rounded-sm bg-danger-bg p-3 text-sm text-danger",
								children: page.updateError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 15
							}, this),
							page.success && /* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								className: "mt-4 rounded-sm bg-success-bg p-3 text-sm text-success",
								children: page.success
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 15
							}, this),
							transitions.length ? /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 space-y-3",
								children: [order.status === "SHIPPED" && order.paymentMethod === "CASH_ON_DELIVERY" && order.payment?.status !== "SUCCESS" && /* @__PURE__ */ _jsxDEV("label", {
									className: "flex items-start gap-3 rounded-sm bg-warning-bg p-3 text-sm text-warning",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										checked: cashCollected,
										onChange: (e) => setCashCollected(e.target.checked),
										disabled: page.saving,
										className: "mt-1 h-5 w-5 shrink-0 accent-primary"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 23
									}, this), c.cashCollected]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 21
								}, this), transitions.map((status) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: page.saving || status === "DELIVERED" && order.paymentMethod === "CASH_ON_DELIVERY" && order.payment?.status !== "SUCCESS" && !cashCollected,
									onClick: () => {
										if (status === "CANCELLED") setConfirmCancel(true);
										else void page.updateStatus(status, cashCollected);
									},
									className: status === "CANCELLED" ? "auth-secondary w-full text-danger" : "auth-primary w-full",
									children: [page.saving && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 210,
										columnNumber: 37
									}, this), page.saving ? t.savingStatus : `${t.saveStatus}: ${translations.orders.statuses[status]}`]
								}, status, true, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 19
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-4 text-sm text-fg-muted",
								children: t.finalStatus
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("section", {
						className: "rounded-md border border-line bg-surface p-5 ",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-semibold text-fg",
							children: translations.orders.delivery
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("address", {
							className: "mt-4 space-y-2 break-words text-sm not-italic text-fg-secondary",
							children: [
								/* @__PURE__ */ _jsxDEV("p", {
									className: "font-medium text-fg",
									children: [
										order.delivery?.firstName,
										" ",
										order.delivery?.lastName
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: order.delivery?.addressLine1 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 15
								}, this),
								order.delivery?.addressLine2 && /* @__PURE__ */ _jsxDEV("p", { children: order.delivery.addressLine2 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: [
									order.delivery?.city,
									" ",
									order.delivery?.postalCode
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: order.delivery?.phone }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 236,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 221,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
}
_s(AdminOrderDetails, "UE51ZNGj6wLXyLbgucpaXO+FIGE=");
_c = AdminOrderDetails;
var _c;
$RefreshReg$(_c, "AdminOrderDetails");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Orders/components/AdminOrderDetails.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderDetails.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderDetails.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxlQUFlO0FBRXhCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMseUJBQXlCO0FBRWxDLFNBQVMsdUJBQXVCLG9CQUFvQjtBQUNwRCxTQUFTLGdCQUFnQixTQUFTO0FBQ2xDLFNBQVMscUJBQXFCOzs7O0FBRTlCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxrQkFBa0IsRUFDaEMsT0FDQSxRQUlDOztDQUNELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLGNBQWMsa0JBQWtCLE1BQU0sTUFBTTtDQUNsRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxRQUFEO0lBQ0UsTUFBTTtJQUNOLGVBQWUsaUJBQWlCLEtBQUs7SUFDckMsT0FBTyxPQUFPO0lBQ2QsYUFBYSxPQUFPO0lBQ3BCLE1BQU0sS0FBSztjQUVYLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQ0UsU0FBUTtNQUNSLFVBQVUsS0FBSztNQUNmLGVBQWUsaUJBQWlCLEtBQUs7Z0JBRXBDLE9BQU87S0FDRjs7OztlQUNSLHdCQUFDLFFBQUQ7TUFDRSxTQUFRO01BQ1IsTUFBTSxLQUFLO01BQ1gsU0FBUyxZQUFZO09BQ25CLE1BQU0sS0FBSyxhQUFhLFdBQVc7T0FDbkMsaUJBQWlCLEtBQUs7TUFDeEI7Z0JBRUMsT0FBTztLQUNGOzs7O2FBQ0w7Ozs7OztHQUNDOzs7OztHQUNSLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQ2pCLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlCLGFBQWEsT0FBTztNQUFPOzs7O2dCQUMxRCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBc0MsTUFBTTtNQUFPOzs7O2NBQzlEOzs7OztNQUNMLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBaUIsRUFBRTtPQUFhOzs7OztPQUM5Qyx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxNQUFNLFNBQVM7T0FDZDs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxNQUFNLFNBQVM7T0FDZDs7Ozs7TUFDRDs7Ozs7TUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlCLGFBQWEsT0FBTztNQUFTOzs7O2dCQUM1RCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZ0IsV0FBVyxNQUFNLFNBQVM7TUFBTTs7OztjQUMzRDs7Ozs7TUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlCLGFBQWEsT0FBTztNQUFVOzs7O2dCQUM3RCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxlQUFlLE1BQU0sS0FBSztNQUN6Qjs7OztjQUNEOzs7OztNQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBaUIsYUFBYSxPQUFPO01BQVc7Ozs7Z0JBQzlELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNaLHdCQUFDLHVCQUFELEVBQXVCLFFBQVEsTUFBTSxPQUFTOzs7OztNQUM1Qzs7OztjQUNEOzs7OztNQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBaUIsRUFBRTtNQUFZOzs7O2dCQUM3Qyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxNQUFNLFVBQ0wsd0JBQUMsY0FBRCxFQUFjLFFBQVEsTUFBTSxRQUFRLE9BQVM7Ozs7a0JBRTdDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpQixFQUFFO09BQWdCOzs7OztNQUVuRDs7OztjQUNEOzs7OztLQUNIOzs7Ozs7R0FDRzs7Ozs7R0FDVCx3QkFBQyxlQUFEO0lBQ0UsUUFBUSxNQUFNO0lBQ2QsZUFBZSxNQUFNO0dBQ3RCOzs7OztHQUNELHdCQUFDLGVBQUQsRUFBZSxTQUFTLE1BQU0sUUFBVTs7Ozs7R0FDeEMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLEtBQUQ7TUFDRyxFQUFFO01BQU87TUFBRTtNQUNaLHdCQUFDLFVBQUQsWUFDRyxNQUFNLGtCQUFrQixxQkFDckIsRUFBRSxNQUNGLE1BQU0sa0JBQWtCLFlBQ3RCLEVBQUUsVUFDRixFQUFFLFFBQ0Y7Ozs7O0tBQ1A7Ozs7O0tBQ0gsd0JBQUMsS0FBRDtNQUNHLEVBQUU7TUFBVztNQUFFO01BQ2hCLHdCQUFDLFVBQUQsWUFBUyxlQUFlLE1BQU0sbUJBQW1CLE1BQU0sRUFBVTs7Ozs7S0FDaEU7Ozs7O0tBQ0gsd0JBQUMsS0FBRDtNQUNHLEVBQUU7TUFBTztNQUFFO01BQ1osd0JBQUMsVUFBRCxZQUFTLGVBQWUsTUFBTSxpQkFBaUIsTUFBTSxFQUFVOzs7OztLQUM5RDs7Ozs7SUFDQTs7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsYUFBYSxPQUFPO0tBQ25COzs7O2VBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsTUFBTSxNQUFNLEtBQUssU0FDaEIsd0JBQUMsTUFBRDtPQUVFLFdBQVU7aUJBRlo7UUFJRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlCLEtBQUs7UUFBUTs7OztrQkFDbkQsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQThCLEtBQUs7UUFBTzs7OztnQkFDcEQ7Ozs7O1FBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUNHLGFBQWEsS0FBSztVQUFTO1VBQUU7U0FDMUI7Ozs7O2tCQUNMLEtBQUssUUFDSDs7Ozs7UUFDTCx3QkFBQyxPQUFELFlBQU0sZUFBZSxLQUFLLFNBQVMsRUFBTzs7Ozs7UUFDMUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osZUFBZSxLQUFLLFNBQVM7UUFDM0I7Ozs7O09BQ0g7U0FqQkcsS0FBSzs7OzthQWlCUixDQUNMO0tBQ0M7Ozs7YUFDRzs7Ozs7Y0FDVCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWlDLEVBQUU7T0FBaUI7Ozs7O09BQ2pFLEtBQUssZUFDSix3QkFBQyxLQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBRVQsS0FBSztPQUNMOzs7OztPQUVKLEtBQUssV0FDSix3QkFBQyxLQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBRVQsS0FBSztPQUNMOzs7OztPQUVKLFlBQVksU0FDWCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNHLE1BQU0sV0FBVyxhQUNoQixNQUFNLGtCQUFrQixzQkFDeEIsTUFBTSxTQUFTLFdBQVcsYUFDeEIsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxTQUFTO1VBQ1QsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sT0FBTztVQUNsRCxVQUFVLEtBQUs7VUFDZixXQUFVO1NBQ1g7Ozs7bUJBQ0EsRUFBRSxhQUNFOzs7OztrQkFFVixZQUFZLEtBQUssV0FDaEIsd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxVQUNFLEtBQUssVUFDSixXQUFXLGVBQ1YsTUFBTSxrQkFBa0Isc0JBQ3hCLE1BQU0sU0FBUyxXQUFXLGFBQzFCLENBQUM7U0FFTCxlQUFlO1VBQ2IsSUFBSSxXQUFXLGFBQWEsaUJBQWlCLElBQUk7ZUFDNUMsS0FBSyxLQUFLLGFBQWEsUUFBUSxhQUFhO1NBQ25EO1NBQ0EsV0FDRSxXQUFXLGNBQ1Asc0NBQ0E7bUJBakJSLENBb0JHLEtBQUssVUFBVSx3QkFBQyxTQUFELEVBQVMsV0FBVSxPQUFROzs7O21CQUMxQyxLQUFLLFNBQ0YsRUFBRSxlQUNGLEdBQUcsRUFBRSxXQUFXLElBQUksYUFBYSxPQUFPLFNBQVMsU0FDL0M7V0F2QkQ7Ozs7ZUF1QkMsQ0FDVCxDQUNFOzs7OztrQkFFTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBOEIsRUFBRTtPQUFlOzs7OztNQUV2RDs7Ozs7ZUFDVCx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxhQUFhLE9BQU87TUFDbkI7Ozs7Z0JBQ0osd0JBQUMsV0FBRDtPQUFTLFdBQVU7aUJBQW5CO1FBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFDRyxNQUFNLFVBQVU7VUFBVTtVQUFFLE1BQU0sVUFBVTtTQUM1Qzs7Ozs7O1FBQ0gsd0JBQUMsS0FBRCxZQUFJLE1BQU0sVUFBVSxhQUFnQjs7Ozs7UUFDbkMsTUFBTSxVQUFVLGdCQUNmLHdCQUFDLEtBQUQsWUFBSSxNQUFNLFNBQVMsYUFBZ0I7Ozs7O1FBRXJDLHdCQUFDLEtBQUQ7U0FDRyxNQUFNLFVBQVU7U0FBSztTQUFFLE1BQU0sVUFBVTtRQUN2Qzs7Ozs7UUFDSCx3QkFBQyxLQUFELFlBQUksTUFBTSxVQUFVLE1BQVM7Ozs7O09BQ3RCOzs7OztjQUNGOzs7OzthQUNOOzs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWRtaW5PcmRlckRldGFpbHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBEaWFsb2cgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0RpYWxvZyc7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgdWlUZXh0IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdWlUZXh0JztcclxuaW1wb3J0IHsgT3JkZXJQcm9ncmVzcyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvT3JkZXJQcm9ncmVzcyc7XHJcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHR5cGUgeyBBZG1pbk9yZGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvb3JkZXIudHlwZXMnO1xyXG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGUnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBuZXh0T3JkZXJTdGF0dXNlcyB9IGZyb20gJy4uL2hlbHBlcnMvYWRtaW4tb3JkZXIuaGVscGVycyc7XHJcbmltcG9ydCB0eXBlIHsgdXNlQWRtaW5PcmRlcnNQYWdlIH0gZnJvbSAnLi4vaG9va3MvdXNlQWRtaW5PcmRlcnNQYWdlJztcclxuaW1wb3J0IHsgQWRtaW5PcmRlclN0YXR1c0JhZGdlLCBQYXltZW50QmFkZ2UgfSBmcm9tICcuL0FkbWluT3JkZXJCYWRnZXMnO1xyXG5pbXBvcnQgeyBjb21tZXJjZVRleHQgYXMgYyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2NvbW1lcmNlVGV4dCc7XHJcbmltcG9ydCB7IE9yZGVyVGltZWxpbmUgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9PcmRlclRpbWVsaW5lJztcclxuXHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuYWRtaW5PcmRlcnM7XHJcbmV4cG9ydCBmdW5jdGlvbiBBZG1pbk9yZGVyRGV0YWlscyh7XHJcbiAgb3JkZXIsXHJcbiAgcGFnZSxcclxufToge1xyXG4gIG9yZGVyOiBBZG1pbk9yZGVyO1xyXG4gIHBhZ2U6IFJldHVyblR5cGU8dHlwZW9mIHVzZUFkbWluT3JkZXJzUGFnZT47XHJcbn0pIHtcclxuICBjb25zdCBbY29uZmlybUNhbmNlbCwgc2V0Q29uZmlybUNhbmNlbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Nhc2hDb2xsZWN0ZWQsIHNldENhc2hDb2xsZWN0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHRyYW5zaXRpb25zID0gbmV4dE9yZGVyU3RhdHVzZXMob3JkZXIuc3RhdHVzKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPERpYWxvZ1xyXG4gICAgICAgIG9wZW49e2NvbmZpcm1DYW5jZWx9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Q29uZmlybUNhbmNlbChmYWxzZSl9XHJcbiAgICAgICAgdGl0bGU9e3VpVGV4dC5jYW5jZWxPcmRlcn1cclxuICAgICAgICBkZXNjcmlwdGlvbj17dWlUZXh0LmNhbmNlbE9yZGVyRGVzY3JpcHRpb259XHJcbiAgICAgICAgYnVzeT17cGFnZS5zYXZpbmd9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1DYW5jZWwoZmFsc2UpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dWlUZXh0LmNhbmNlbH1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgYnVzeT17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICBhd2FpdCBwYWdlLnVwZGF0ZVN0YXR1cygnQ0FOQ0VMTEVEJyk7XHJcbiAgICAgICAgICAgICAgc2V0Q29uZmlybUNhbmNlbChmYWxzZSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt1aVRleHQuY2FuY2VsT3JkZXJBY3Rpb259XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EaWFsb2c+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01ICBzbTpwLTZcIj5cclxuICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNSB0ZXh0LXNtIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPnt0cmFuc2xhdGlvbnMub3JkZXJzLmlkfTwvZHQ+XHJcbiAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0yIGJyZWFrLWFsbCBmb250LW1lZGl1bSB0ZXh0LWZnXCI+e29yZGVyLmlkfTwvZGQ+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LWZnLW11dGVkXCI+e3QuY3VzdG9tZXJ9PC9kdD5cclxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTIgZm9udC1tZWRpdW0gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgIHtvcmRlci5jdXN0b21lci51c2VybmFtZX1cclxuICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgYnJlYWstYWxsIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICB7b3JkZXIuY3VzdG9tZXIuZW1haWx9XHJcbiAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LWZnLW11dGVkXCI+e3RyYW5zbGF0aW9ucy5vcmRlcnMuZGF0ZX08L2R0PlxyXG4gICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWZnXCI+e2Zvcm1hdERhdGUob3JkZXIuY3JlYXRlZEF0KX08L2RkPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPnt0cmFuc2xhdGlvbnMub3JkZXJzLnRvdGFsfTwvZHQ+XHJcbiAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0yIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KG9yZGVyLnRvdGFsKX1cclxuICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtZmctbXV0ZWRcIj57dHJhbnNsYXRpb25zLm9yZGVycy5zdGF0dXN9PC9kdD5cclxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTJcIj5cclxuICAgICAgICAgICAgICA8QWRtaW5PcmRlclN0YXR1c0JhZGdlIHN0YXR1cz17b3JkZXIuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPnt0LnBheW1lbnR9PC9kdD5cclxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTJcIj5cclxuICAgICAgICAgICAgICB7b3JkZXIucGF5bWVudCA/IChcclxuICAgICAgICAgICAgICAgIDxQYXltZW50QmFkZ2Ugc3RhdHVzPXtvcmRlci5wYXltZW50LnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPnt0Lm5vUGF5bWVudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGw+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPE9yZGVyUHJvZ3Jlc3NcclxuICAgICAgICBzdGF0dXM9e29yZGVyLnN0YXR1c31cclxuICAgICAgICBwYXltZW50TWV0aG9kPXtvcmRlci5wYXltZW50TWV0aG9kfVxyXG4gICAgICAvPlxyXG4gICAgICA8T3JkZXJUaW1lbGluZSBoaXN0b3J5PXtvcmRlci5oaXN0b3J5fSAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXBhbmVsIGZsZXggZmxleC13cmFwIGdhcC02IHAtNSB0ZXh0LXNtXCI+XHJcbiAgICAgICAgPHA+XHJcbiAgICAgICAgICB7Yy5tZXRob2R9OnsnICd9XHJcbiAgICAgICAgICA8c3Ryb25nPlxyXG4gICAgICAgICAgICB7b3JkZXIucGF5bWVudE1ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknXHJcbiAgICAgICAgICAgICAgPyBjLmNvZFxyXG4gICAgICAgICAgICAgIDogb3JkZXIucGF5bWVudE1ldGhvZCA9PT0gJ0xPWUFMVFknXHJcbiAgICAgICAgICAgICAgICA/IGMubG95YWx0eVxyXG4gICAgICAgICAgICAgICAgOiBjLnBheUhlcmV9XHJcbiAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPHA+XHJcbiAgICAgICAgICB7Yy5jcmVkaXRVc2VkfTp7JyAnfVxyXG4gICAgICAgICAgPHN0cm9uZz57Zm9ybWF0Q3VycmVuY3kob3JkZXIubG95YWx0eVJlZGVlbWVkID8/ICcwLjAwJyl9PC9zdHJvbmc+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAge2MuZWFybmVkfTp7JyAnfVxyXG4gICAgICAgICAgPHN0cm9uZz57Zm9ybWF0Q3VycmVuY3kob3JkZXIubG95YWx0eUVhcm5lZCA/PyAnMC4wMCcpfTwvc3Ryb25nPlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNiBsZzpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfMjJyZW1dXCI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZSBwLTUgdGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5vcmRlcnMuaXRlbXN9XHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1saW5lXCI+XHJcbiAgICAgICAgICAgIHtvcmRlci5pdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgcC01IHRleHQtc20gc206Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpX2F1dG9fYXV0b19hdXRvXVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e2l0ZW0ubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+e2l0ZW0uU0tVfTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY2FydC5xdWFudGl0eX06eycgJ31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS5xdWFudGl0eX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj57Zm9ybWF0Q3VycmVuY3koaXRlbS51bml0UHJpY2UpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShpdGVtLmxpbmVUb3RhbCl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNSBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3QudXBkYXRlU3RhdHVzfTwvaDI+XHJcbiAgICAgICAgICAgIHtwYWdlLnVwZGF0ZUVycm9yICYmIChcclxuICAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC1zbSBiZy1kYW5nZXItYmcgcC0zIHRleHQtc20gdGV4dC1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtwYWdlLnVwZGF0ZUVycm9yfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge3BhZ2Uuc3VjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLXNtIGJnLXN1Y2Nlc3MtYmcgcC0zIHRleHQtc20gdGV4dC1zdWNjZXNzXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5zdWNjZXNzfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge3RyYW5zaXRpb25zLmxlbmd0aCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICB7b3JkZXIuc3RhdHVzID09PSAnU0hJUFBFRCcgJiZcclxuICAgICAgICAgICAgICAgICAgb3JkZXIucGF5bWVudE1ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknICYmXHJcbiAgICAgICAgICAgICAgICAgIG9yZGVyLnBheW1lbnQ/LnN0YXR1cyAhPT0gJ1NVQ0NFU1MnICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyByb3VuZGVkLXNtIGJnLXdhcm5pbmctYmcgcC0zIHRleHQtc20gdGV4dC13YXJuaW5nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Y2FzaENvbGxlY3RlZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXNoQ29sbGVjdGVkKGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgaC01IHctNSBzaHJpbmstMCBhY2NlbnQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2MuY2FzaENvbGxlY3RlZH1cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge3RyYW5zaXRpb25zLm1hcCgoc3RhdHVzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICBwYWdlLnNhdmluZyB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgKHN0YXR1cyA9PT0gJ0RFTElWRVJFRCcgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3JkZXIucGF5bWVudE1ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVyLnBheW1lbnQ/LnN0YXR1cyAhPT0gJ1NVQ0NFU1MnICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICFjYXNoQ29sbGVjdGVkKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdHVzID09PSAnQ0FOQ0VMTEVEJykgc2V0Q29uZmlybUNhbmNlbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGVsc2Ugdm9pZCBwYWdlLnVwZGF0ZVN0YXR1cyhzdGF0dXMsIGNhc2hDb2xsZWN0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cyA9PT0gJ0NBTkNFTExFRCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYXV0aC1zZWNvbmRhcnkgdy1mdWxsIHRleHQtZGFuZ2VyJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdhdXRoLXByaW1hcnkgdy1mdWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYWdlLnNhdmluZyAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAge3BhZ2Uuc2F2aW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IHQuc2F2aW5nU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGAke3Quc2F2ZVN0YXR1c306ICR7dHJhbnNsYXRpb25zLm9yZGVycy5zdGF0dXNlc1tzdGF0dXNdfWB9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5maW5hbFN0YXR1c308L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNSBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5vcmRlcnMuZGVsaXZlcnl9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDxhZGRyZXNzIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0yIGJyZWFrLXdvcmRzIHRleHQtc20gbm90LWl0YWxpYyB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgIHtvcmRlci5kZWxpdmVyeT8uZmlyc3ROYW1lfSB7b3JkZXIuZGVsaXZlcnk/Lmxhc3ROYW1lfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cD57b3JkZXIuZGVsaXZlcnk/LmFkZHJlc3NMaW5lMX08L3A+XHJcbiAgICAgICAgICAgICAge29yZGVyLmRlbGl2ZXJ5Py5hZGRyZXNzTGluZTIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHA+e29yZGVyLmRlbGl2ZXJ5LmFkZHJlc3NMaW5lMn08L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgIHtvcmRlci5kZWxpdmVyeT8uY2l0eX0ge29yZGVyLmRlbGl2ZXJ5Py5wb3N0YWxDb2RlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cD57b3JkZXIuZGVsaXZlcnk/LnBob25lfTwvcD5cclxuICAgICAgICAgICAgPC9hZGRyZXNzPlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19