import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Repairer/Repairs/Details/index.tsx");const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import { formatDate } from "/src/utils/date.ts";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { useRepairerRepairDetails } from "/src/pages/Repairer/Repairs/Details/hooks/useRepairerRepairDetails.ts";
import { RepairStatusBadge } from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
import { getValidNextStatuses, getStatusLabel } from "/src/utils/statusTransitions.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/Details/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function RepairerRepairDetailsPage() {
	_s();
	const page = useRepairerRepairDetails();
	const [showStatusDialog, setShowStatusDialog] = useState(false);
	const [selectedStatus, setSelectedStatus] = useState(null);
	useEffect(() => {
		const previous = document.title;
		document.title = "Repair Details | Appliances LK";
		return () => {
			document.title = previous;
		};
	}, []);
	const handleStatusUpdate = async () => {
		if (selectedStatus) {
			await page.updateStatus(selectedStatus);
			if (!page.updateError) {
				setShowStatusDialog(false);
				setSelectedStatus(null);
			}
		}
	};
	if (page.loading) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 md:py-8 lg:px-8",
			children: /* @__PURE__ */ _jsxDEV(LoadingState, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 7
		}, this);
	}
	if (page.error) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 md:py-8 lg:px-8",
			children: /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-danger/25 bg-danger-bg p-8 text-center ",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "font-medium text-danger",
						children: "Repair Not Found"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-danger",
						children: page.error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => void page.refresh(),
						className: "mt-4 auth-secondary",
						children: "Try Again"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this);
	}
	if (!page.repair) {
		return null;
	}
	const validNextStatuses = getValidNextStatuses(page.repair.status);
	const canUpdateStatus = validNextStatuses.length > 0;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: page.goBack,
						className: "mb-2 text-sm font-medium text-fg-link hover:text-fg-link",
						children: "← Back to Repairs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title text-fg",
						children: "Repair Details"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 tabular-nums text-sm text-fg-muted",
						children: page.repair.reference
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => void page.refresh(),
						disabled: page.processing,
						className: "auth-secondary",
						children: "Refresh"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 13
					}, this), canUpdateStatus && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setShowStatusDialog(true),
						disabled: page.processing,
						className: "ui-button ui-button-primary rounded-sm border border-transparent bg-primary px-4 py-2 text-sm font-medium text-primary-on  hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:cursor-not-allowed ",
						children: "Update Status"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this),
			page.updateError && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-sm border border-danger/25 bg-danger-bg p-4",
				children: /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-danger",
					children: page.updateError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: "Customer"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("dl", {
						className: "mt-4 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Name"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.customer.username
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Email"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.customer.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: "Device"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("dl", {
						className: "mt-4 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: "Type"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 text-sm text-fg",
								children: page.repair.device.deviceType
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: "Brand"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 text-sm text-fg",
								children: page.repair.device.brand
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: "Model"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 text-sm text-fg",
								children: page.repair.device.model
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 15
							}, this),
							page.repair.device.serialNumber && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: "Serial Number"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 tabular-nums text-sm text-fg",
								children: page.repair.device.serialNumber
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 17
							}, this),
							page.repair.device.purchaseDate && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: "Purchase Date"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 text-sm text-fg",
								children: new Date(page.repair.device.purchaseDate).toLocaleDateString()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-6 ",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-fg",
					children: "Problem Description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-4 whitespace-pre-wrap text-sm text-fg-secondary",
					children: page.repair.problemDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-6 ",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-fg",
					children: "Status"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status: page.repair.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 13
					}, this), canUpdateStatus && /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-fg-muted",
						children: [
							"Can be updated to:",
							" ",
							validNextStatuses.map(getStatusLabel).join(", ")
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 196,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-6 ",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-fg",
					children: "Timeline"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 210,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("dl", {
					className: "mt-4 space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Created"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: formatDate(page.repair.createdAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 13
						}, this),
						page.repair.reviewedAt && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Reviewed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: formatDate(page.repair.reviewedAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Last Updated"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: formatDate(page.repair.updatedAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 211,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 209,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 7
	}, this), showStatusDialog && /* @__PURE__ */ _jsxDEV(Dialog, {
		open: true,
		onClose: () => {
			setShowStatusDialog(false);
			setSelectedStatus(null);
		},
		title: "Update repair status",
		description: "Select the next status for this repair ticket.",
		busy: page.processing,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mt-4 space-y-2",
			children: validNextStatuses.map((status) => /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-pressed": selectedStatus === status,
				onClick: () => setSelectedStatus(status),
				className: `w-full rounded-sm border p-3 text-left text-sm font-medium transition-colors ${selectedStatus === status ? "border-primary bg-primary-subtle text-fg-link" : "border-line bg-surface text-fg hover:bg-page"}`,
				children: [/* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 262,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-fg-muted",
					children: getStatusDescription(status)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 263,
					columnNumber: 17
				}, this)]
			}, status, true, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 15
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 249,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "mt-6 flex gap-3",
			children: [/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => {
					setShowStatusDialog(false);
					setSelectedStatus(null);
				},
				disabled: page.processing,
				className: "flex-1 auth-secondary",
				children: "Cancel"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 271,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => void handleStatusUpdate(),
				disabled: !selectedStatus || page.processing,
				className: "ui-button ui-button-primary flex-1 rounded-sm border border-transparent bg-primary px-4 py-2 text-sm font-medium text-primary-on  hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:cursor-not-allowed ",
				children: [page.processing && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 288,
					columnNumber: 35
				}, this), page.processing ? "Updating..." : "Update Status"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 282,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 270,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 239,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
}
_s(RepairerRepairDetailsPage, "wtn7SidRYxVzclLPVJalio6nvQ4=", false, function() {
	return [useRepairerRepairDetails];
});
_c = RepairerRepairDetailsPage;
function getStatusDescription(status) {
	const descriptions = {
		PENDING: "Repair is pending review",
		APPROVED: "Repair has been approved",
		REJECTED: "Repair has been rejected",
		ASSIGNED: "Repair has been assigned",
		IN_PROGRESS: "Currently working on the repair",
		AWAITING_PARTS: "Waiting for spare parts to arrive",
		READY_FOR_COLLECTION: "Repair completed, ready for customer pickup",
		COMPLETED: "Repair completed and collected",
		CANCELLED: "Repair has been cancelled"
	};
	return descriptions[status] || "";
}
var _c;
$RefreshReg$(_c, "RepairerRepairDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Repairer/Repairs/Details/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/Details/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/Details/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/Details/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFdBQVcsZ0JBQWdCO0FBQ3BDLFNBQVMsZ0NBQWdDO0FBQ3pDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQ0Usc0JBQ0Esc0JBQ0s7Ozs7QUFHUCxlQUFlLFNBQVMsNEJBQTRCOztDQUNsRCxNQUFNLE9BQU8seUJBQXlCO0NBQ3RDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUMxQyxJQUNGO0NBRUEsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLFNBQVM7RUFDMUIsU0FBUyxRQUFRO0VBQ2pCLGFBQWE7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0scUJBQXFCLFlBQVk7RUFDckMsSUFBSSxnQkFBZ0I7R0FDbEIsTUFBTSxLQUFLLGFBQWEsY0FBYztHQUN0QyxJQUFJLENBQUMsS0FBSyxhQUFhO0lBQ3JCLG9CQUFvQixLQUFLO0lBQ3pCLGtCQUFrQixJQUFJO0dBQ3hCO0VBQ0Y7Q0FDRjtDQUVBLElBQUksS0FBSyxTQUFTO0VBQ2hCLE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDZCx3QkFBQyxjQUFELENBQWU7Ozs7O0VBQ1g7Ozs7O0NBRVY7Q0FFQSxJQUFJLEtBQUssT0FBTztFQUNkLE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDZCx3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FGWjtLQUlFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUEwQjtLQUFtQjs7Ozs7S0FDMUQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTRCLEtBQUs7S0FBUzs7Ozs7S0FDdkQsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxlQUFlLEtBQUssS0FBSyxRQUFRO01BQ2pDLFdBQVU7Z0JBQ1g7S0FFTzs7Ozs7SUFDTDs7Ozs7O0VBQ0Q7Ozs7O0NBRVY7Q0FFQSxJQUFJLENBQUMsS0FBSyxRQUFRO0VBQ2hCLE9BQU87Q0FDVDtDQUVBLE1BQU0sb0JBQW9CLHFCQUFxQixLQUFLLE9BQU8sTUFBTTtDQUNqRSxNQUFNLGtCQUFrQixrQkFBa0IsU0FBUztDQUVuRCxPQUNFLGdEQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVMsS0FBSztNQUNkLFdBQVU7Z0JBQ1g7S0FFTzs7Ozs7S0FDUix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBd0I7S0FBa0I7Ozs7O0tBQ3hELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLEtBQUssT0FBTztLQUNaOzs7OztJQUNBOzs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsZUFBZSxLQUFLLEtBQUssUUFBUTtNQUNqQyxVQUFVLEtBQUs7TUFDZixXQUFVO2dCQUNYO0tBRU87Ozs7ZUFDUCxtQkFDQyx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsb0JBQW9CLElBQUk7TUFDdkMsVUFBVSxLQUFLO01BQ2YsV0FBVTtnQkFDWDtLQUVPOzs7O2FBRVA7Ozs7O1lBQ0Y7Ozs7OztHQUVKLEtBQUssZUFDSix3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FFVix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF1QixLQUFLO0lBQWU7Ozs7O0dBQ3JEOzs7OztHQUdQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWdDO0tBQVk7Ozs7ZUFDMUQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9DO01BQVE7Ozs7Z0JBQzFELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLEtBQUssT0FBTyxTQUFTO01BQ3BCOzs7O2NBQ0Q7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQztNQUFTOzs7O2dCQUMzRCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxLQUFLLE9BQU8sU0FBUztNQUNwQjs7OztjQUNEOzs7O2NBQ0g7Ozs7O2FBQ0Q7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFnQztLQUFVOzs7O2VBQ3hELHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvQztPQUFROzs7O2lCQUMxRCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxLQUFLLE9BQU8sT0FBTztPQUNsQjs7OztlQUNEOzs7OztPQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBb0M7T0FBUzs7OztpQkFDM0Qsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsS0FBSyxPQUFPLE9BQU87T0FDbEI7Ozs7ZUFDRDs7Ozs7T0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW9DO09BQVM7Ozs7aUJBQzNELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLEtBQUssT0FBTyxPQUFPO09BQ2xCOzs7O2VBQ0Q7Ozs7O09BQ0osS0FBSyxPQUFPLE9BQU8sZ0JBQ2xCLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBb0M7T0FFOUM7Ozs7aUJBQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsS0FBSyxPQUFPLE9BQU87T0FDbEI7Ozs7ZUFDRDs7Ozs7T0FFTixLQUFLLE9BQU8sT0FBTyxnQkFDbEIsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvQztPQUU5Qzs7OztpQkFDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxJQUFJLEtBQ0gsS0FBSyxPQUFPLE9BQU8sWUFDckIsQ0FBQyxDQUFDLG1CQUFtQjtPQUNuQjs7OztlQUNEOzs7OztNQUVMOzs7OzthQUNEOzs7OztZQUNGOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZ0M7SUFBdUI7Ozs7Y0FDckUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixLQUFLLE9BQU87SUFDWjs7OztZQUNBOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZ0M7SUFBVTs7OztjQUN4RCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsbUJBQUQsRUFBbUIsUUFBUSxLQUFLLE9BQU8sT0FBUzs7OztlQUMvQyxtQkFDQyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUFxQztPQUNoQjtPQUNsQixrQkFBa0IsSUFBSSxjQUFjLENBQUMsQ0FBQyxLQUFLLElBQUk7TUFDL0M7Ozs7O2FBRUY7Ozs7O1lBQ0Y7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFnQztJQUFZOzs7O2NBQzFELHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9DO01BQVc7Ozs7Z0JBQzdELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLFdBQVcsS0FBSyxPQUFPLFNBQVM7TUFDL0I7Ozs7Y0FDRDs7Ozs7TUFDSixLQUFLLE9BQU8sY0FDWCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9DO01BQVk7Ozs7Z0JBQzlELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLFdBQVcsS0FBSyxPQUFPLFVBQVU7TUFDaEM7Ozs7Y0FDRDs7Ozs7TUFFUCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9DO01BRTlDOzs7O2dCQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLFdBQVcsS0FBSyxPQUFPLFNBQVM7TUFDL0I7Ozs7Y0FDRDs7Ozs7S0FDSDs7Ozs7WUFDRDs7Ozs7O0VBQ0Q7Ozs7O1dBRUwsb0JBQ0Msd0JBQUMsUUFBRDtFQUNFO0VBQ0EsZUFBZTtHQUNiLG9CQUFvQixLQUFLO0dBQ3pCLGtCQUFrQixJQUFJO0VBQ3hCO0VBQ0EsT0FBTztFQUNQLGFBQWE7RUFDYixNQUFNLEtBQUs7WUFSYixDQVVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osa0JBQWtCLEtBQUssV0FDdEIsd0JBQUMsVUFBRDtJQUVFLE1BQUs7SUFDTCxnQkFBYyxtQkFBbUI7SUFDakMsZUFBZSxrQkFBa0IsTUFBTTtJQUN2QyxXQUFXLGdGQUNULG1CQUFtQixTQUNmLGtEQUNBO2NBUlIsQ0FXRSx3QkFBQyxtQkFBRCxFQUEyQixPQUFTOzs7O2NBQ3BDLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YscUJBQXFCLE1BQU07SUFDM0I7Ozs7WUFDRztNQWREOzs7O1VBY0MsQ0FDVDtFQUNFOzs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsZUFBZTtLQUNiLG9CQUFvQixLQUFLO0tBQ3pCLGtCQUFrQixJQUFJO0lBQ3hCO0lBQ0EsVUFBVSxLQUFLO0lBQ2YsV0FBVTtjQUNYO0dBRU87Ozs7YUFDUix3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLGVBQWUsS0FBSyxtQkFBbUI7SUFDdkMsVUFBVSxDQUFDLGtCQUFrQixLQUFLO0lBQ2xDLFdBQVU7Y0FKWixDQU1HLEtBQUssY0FBYyx3QkFBQyxTQUFELEVBQVMsV0FBVSxPQUFROzs7O2NBQzlDLEtBQUssYUFBYSxnQkFBZ0IsZUFDN0I7Ozs7O1dBQ0w7Ozs7O1VBQ0M7Ozs7O1NBRVY7Ozs7O0FBRU47Ozs7O0FBRUEsU0FBUyxxQkFBcUIsUUFBOEI7Q0FDMUQsTUFBTSxlQUE2QztFQUNqRCxTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVU7RUFDVixVQUFVO0VBQ1YsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIsV0FBVztFQUNYLFdBQVc7Q0FDYjtDQUVBLE9BQU8sYUFBYSxXQUFXO0FBQ2pDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IERpYWxvZyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBMb2FkaW5nU3RhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlUmVwYWlyZXJSZXBhaXJEZXRhaWxzIH0gZnJvbSAnLi9ob29rcy91c2VSZXBhaXJlclJlcGFpckRldGFpbHMnO1xyXG5pbXBvcnQgeyBSZXBhaXJTdGF0dXNCYWRnZSB9IGZyb20gJy4uLy4uLy4uL0FkbWluL1JlcGFpcnMvY29tcG9uZW50cy9SZXBhaXJTdGF0dXNCYWRnZSc7XHJcbmltcG9ydCB7XHJcbiAgZ2V0VmFsaWROZXh0U3RhdHVzZXMsXHJcbiAgZ2V0U3RhdHVzTGFiZWwsXHJcbn0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvc3RhdHVzVHJhbnNpdGlvbnMnO1xyXG5pbXBvcnQgdHlwZSB7IFJlcGFpclN0YXR1cyB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3JlcGFpci50eXBlcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBhaXJlclJlcGFpckRldGFpbHNQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VSZXBhaXJlclJlcGFpckRldGFpbHMoKTtcclxuICBjb25zdCBbc2hvd1N0YXR1c0RpYWxvZywgc2V0U2hvd1N0YXR1c0RpYWxvZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkU3RhdHVzLCBzZXRTZWxlY3RlZFN0YXR1c10gPSB1c2VTdGF0ZTxSZXBhaXJTdGF0dXMgfCBudWxsPihcclxuICAgIG51bGwsXHJcbiAgKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHByZXZpb3VzID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICBkb2N1bWVudC50aXRsZSA9ICdSZXBhaXIgRGV0YWlscyB8IEFwcGxpYW5jZXMgTEsnO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdGF0dXNVcGRhdGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRTdGF0dXMpIHtcclxuICAgICAgYXdhaXQgcGFnZS51cGRhdGVTdGF0dXMoc2VsZWN0ZWRTdGF0dXMpO1xyXG4gICAgICBpZiAoIXBhZ2UudXBkYXRlRXJyb3IpIHtcclxuICAgICAgICBzZXRTaG93U3RhdHVzRGlhbG9nKGZhbHNlKTtcclxuICAgICAgICBzZXRTZWxlY3RlZFN0YXR1cyhudWxsKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGlmIChwYWdlLmxvYWRpbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctN3hsIHNwYWNlLXktNiBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgICA8TG9hZGluZ1N0YXRlIC8+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAocGFnZS5lcnJvcikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy03eGwgc3BhY2UteS02IHB4LTQgcHktNiBzbTpweC02IG1kOnB5LTggbGc6cHgtOFwiPlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZGFuZ2VyLzI1IGJnLWRhbmdlci1iZyBwLTggdGV4dC1jZW50ZXIgXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWRhbmdlclwiPlJlcGFpciBOb3QgRm91bmQ8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1kYW5nZXJcIj57cGFnZS5lcnJvcn08L3A+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVmcmVzaCgpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IGF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgVHJ5IEFnYWluXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmICghcGFnZS5yZXBhaXIpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdmFsaWROZXh0U3RhdHVzZXMgPSBnZXRWYWxpZE5leHRTdGF0dXNlcyhwYWdlLnJlcGFpci5zdGF0dXMpO1xyXG4gIGNvbnN0IGNhblVwZGF0ZVN0YXR1cyA9IHZhbGlkTmV4dFN0YXR1c2VzLmxlbmd0aCA+IDA7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bCBzcGFjZS15LTYgcHgtNCBweS02IHNtOnB4LTYgbWQ6cHktOCBsZzpweC04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtwYWdlLmdvQmFja31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICDihpAgQmFjayB0byBSZXBhaXJzXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+UmVwYWlyIERldGFpbHM8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRhYnVsYXItbnVtcyB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIucmVmZXJlbmNlfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwYWdlLnJlZnJlc2goKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5wcm9jZXNzaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlZnJlc2hcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIHtjYW5VcGRhdGVTdGF0dXMgJiYgKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1N0YXR1c0RpYWxvZyh0cnVlKX1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnByb2Nlc3Npbmd9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLXByaW1hcnkgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LW9uICBob3ZlcjpiZy1wcmltYXJ5LWhvdmVyIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOnJpbmctb2Zmc2V0LTIgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIFN0YXR1c1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtwYWdlLnVwZGF0ZUVycm9yICYmIChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWRhbmdlci8yNSBiZy1kYW5nZXItYmcgcC00XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWRhbmdlclwiPntwYWdlLnVwZGF0ZUVycm9yfTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBsZzpncmlkLWNvbHMtMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+Q3VzdG9tZXI8L2gyPlxyXG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPk5hbWU8L2R0PlxyXG4gICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5jdXN0b21lci51c2VybmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbXV0ZWRcIj5FbWFpbDwvZHQ+XHJcbiAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmN1c3RvbWVyLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kbD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTYgXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPkRldmljZTwvaDI+XHJcbiAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+VHlwZTwvZHQ+XHJcbiAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5kZXZpY2VUeXBlfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPkJyYW5kPC9kdD5cclxuICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuZGV2aWNlLmJyYW5kfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPk1vZGVsPC9kdD5cclxuICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuZGV2aWNlLm1vZGVsfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuZGV2aWNlLnNlcmlhbE51bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VyaWFsIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0YWJ1bGFyLW51bXMgdGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5zZXJpYWxOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5kZXZpY2UucHVyY2hhc2VEYXRlICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBQdXJjaGFzZSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZ2UucmVwYWlyLmRldmljZS5wdXJjaGFzZURhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlByb2JsZW0gRGVzY3JpcHRpb248L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB3aGl0ZXNwYWNlLXByZS13cmFwIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAge3BhZ2UucmVwYWlyLnByb2JsZW1EZXNjcmlwdGlvbn1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlN0YXR1czwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPFJlcGFpclN0YXR1c0JhZGdlIHN0YXR1cz17cGFnZS5yZXBhaXIuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICB7Y2FuVXBkYXRlU3RhdHVzICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgIENhbiBiZSB1cGRhdGVkIHRvOnsnICd9XHJcbiAgICAgICAgICAgICAgICB7dmFsaWROZXh0U3RhdHVzZXMubWFwKGdldFN0YXR1c0xhYmVsKS5qb2luKCcsICcpfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC02IFwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+VGltZWxpbmU8L2gyPlxyXG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPkNyZWF0ZWQ8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocGFnZS5yZXBhaXIuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3BhZ2UucmVwYWlyLnJldmlld2VkQXQgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+UmV2aWV3ZWQ8L2R0PlxyXG4gICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKHBhZ2UucmVwYWlyLnJldmlld2VkQXQpfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICBMYXN0IFVwZGF0ZWRcclxuICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocGFnZS5yZXBhaXIudXBkYXRlZEF0KX1cclxuICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgIHtzaG93U3RhdHVzRGlhbG9nICYmIChcclxuICAgICAgICA8RGlhbG9nXHJcbiAgICAgICAgICBvcGVuXHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dTdGF0dXNEaWFsb2coZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RlZFN0YXR1cyhudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICB0aXRsZT17J1VwZGF0ZSByZXBhaXIgc3RhdHVzJ31cclxuICAgICAgICAgIGRlc2NyaXB0aW9uPXsnU2VsZWN0IHRoZSBuZXh0IHN0YXR1cyBmb3IgdGhpcyByZXBhaXIgdGlja2V0Lid9XHJcbiAgICAgICAgICBidXN5PXtwYWdlLnByb2Nlc3Npbmd9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICB7dmFsaWROZXh0U3RhdHVzZXMubWFwKChzdGF0dXMpID0+IChcclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBrZXk9e3N0YXR1c31cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtzZWxlY3RlZFN0YXR1cyA9PT0gc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTdGF0dXMoc3RhdHVzKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLXNtIGJvcmRlciBwLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRTdGF0dXMgPT09IHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1wcmltYXJ5IGJnLXByaW1hcnktc3VidGxlIHRleHQtZmctbGluaydcclxuICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItbGluZSBiZy1zdXJmYWNlIHRleHQtZmcgaG92ZXI6YmctcGFnZSdcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxSZXBhaXJTdGF0dXNCYWRnZSBzdGF0dXM9e3N0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNEZXNjcmlwdGlvbihzdGF0dXMpfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93U3RhdHVzRGlhbG9nKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkU3RhdHVzKG51bGwpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UucHJvY2Vzc2luZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYXV0aC1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5kbGVTdGF0dXNVcGRhdGUoKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkU3RhdHVzIHx8IHBhZ2UucHJvY2Vzc2luZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgZmxleC0xIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBiZy1wcmltYXJ5IHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcHJpbWFyeS1vbiAgaG92ZXI6YmctcHJpbWFyeS1ob3ZlciBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpyaW5nLW9mZnNldC0yIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3BhZ2UucHJvY2Vzc2luZyAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICAgICAge3BhZ2UucHJvY2Vzc2luZyA/ICdVcGRhdGluZy4uLicgOiAnVXBkYXRlIFN0YXR1cyd9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRTdGF0dXNEZXNjcmlwdGlvbihzdGF0dXM6IFJlcGFpclN0YXR1cyk6IHN0cmluZyB7XHJcbiAgY29uc3QgZGVzY3JpcHRpb25zOiBSZWNvcmQ8UmVwYWlyU3RhdHVzLCBzdHJpbmc+ID0ge1xyXG4gICAgUEVORElORzogJ1JlcGFpciBpcyBwZW5kaW5nIHJldmlldycsXHJcbiAgICBBUFBST1ZFRDogJ1JlcGFpciBoYXMgYmVlbiBhcHByb3ZlZCcsXHJcbiAgICBSRUpFQ1RFRDogJ1JlcGFpciBoYXMgYmVlbiByZWplY3RlZCcsXHJcbiAgICBBU1NJR05FRDogJ1JlcGFpciBoYXMgYmVlbiBhc3NpZ25lZCcsXHJcbiAgICBJTl9QUk9HUkVTUzogJ0N1cnJlbnRseSB3b3JraW5nIG9uIHRoZSByZXBhaXInLFxyXG4gICAgQVdBSVRJTkdfUEFSVFM6ICdXYWl0aW5nIGZvciBzcGFyZSBwYXJ0cyB0byBhcnJpdmUnLFxyXG4gICAgUkVBRFlfRk9SX0NPTExFQ1RJT046ICdSZXBhaXIgY29tcGxldGVkLCByZWFkeSBmb3IgY3VzdG9tZXIgcGlja3VwJyxcclxuICAgIENPTVBMRVRFRDogJ1JlcGFpciBjb21wbGV0ZWQgYW5kIGNvbGxlY3RlZCcsXHJcbiAgICBDQU5DRUxMRUQ6ICdSZXBhaXIgaGFzIGJlZW4gY2FuY2VsbGVkJyxcclxuICB9O1xyXG5cclxuICByZXR1cm4gZGVzY3JpcHRpb25zW3N0YXR1c10gfHwgJyc7XHJcbn1cclxuIl19