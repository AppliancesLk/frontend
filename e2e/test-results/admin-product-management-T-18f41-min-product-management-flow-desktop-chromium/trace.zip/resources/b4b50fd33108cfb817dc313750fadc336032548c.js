import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Cart/components/CartItemRow.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/components/common/Icon.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { translations } from "/src/utils/translations.ts";
import { nextQuantity } from "/src/pages/Customer/Cart/helpers/cart.helpers.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartItemRow.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.cart;
export function CartItemRow({ item, disabled, updating, removing, onQuantity, onRemove }) {
	const detailUrl = ROUTES.productDetail.replace(":id", encodeURIComponent(item.productId));
	return /* @__PURE__ */ _jsxDEV("li", {
		className: "cart-line",
		"aria-busy": updating || removing,
		children: [/* @__PURE__ */ _jsxDEV(Link, {
			to: detailUrl,
			className: "cart-line-image",
			children: /* @__PURE__ */ _jsxDEV(ProductImage, {
				src: item.images[0],
				alt: item.name,
				className: "h-full w-full"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "cart-line-content",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-sans text-sm font-semibold text-fg",
							children: /* @__PURE__ */ _jsxDEV(Link, {
								to: detailUrl,
								className: "hover:text-fg-link",
								children: item.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 42,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-fg-muted",
							children: ["SKU: ", item.SKU]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "price shrink-0 text-sm font-semibold text-fg sm:text-base",
						children: updating ? /* @__PURE__ */ _jsxDEV("span", {
							role: "status",
							children: t.updating
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 15
						}, this) : formatCurrency(item.lineTotal)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: `mt-2 flex items-center gap-1.5 text-xs ${item.isAvailable ? "text-success" : "text-danger"}`,
					children: [/* @__PURE__ */ _jsxDEV(Icon, {
						name: item.isAvailable ? "check" : "info",
						className: "h-3.5 w-3.5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this), item.isAvailable ? translations.productDetails.inStock : translations.productDetails.outOfStock]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				item.quantity > 1 && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs text-fg-muted",
					children: [formatCurrency(item.unitPrice), " each"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 11
				}, this),
				!item.isAvailable && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-3 rounded-sm bg-danger-bg px-3 py-2 text-sm text-danger",
					children: item.quantity > item.stockQty && item.stockQty > 0 ? `${t.stockChanged} ${item.stockQty.toLocaleString()}. ${t.reduceQuantity}` : t.unavailable
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex flex-wrap items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						role: "group",
						"aria-label": `${t.quantity}: ${item.name}`,
						className: "inline-flex h-11 items-center overflow-hidden rounded-sm border border-line bg-surface",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-label": `${t.decrease} ${item.name}`,
								disabled: disabled || nextQuantity(item, -1) === null,
								onClick: () => onQuantity(-1),
								className: "h-full w-10 text-lg text-fg-secondary hover:bg-subtle disabled:text-fg-disabled",
								children: "−"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								"aria-label": `${t.quantity}: ${item.quantity}`,
								className: "min-w-10 px-2 text-center text-sm font-semibold tabular-nums",
								children: item.quantity
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-label": `${t.increase} ${item.name}`,
								disabled: disabled || nextQuantity(item, 1) === null,
								onClick: () => onQuantity(1),
								className: "h-full w-10 text-lg text-fg-secondary hover:bg-subtle disabled:text-fg-disabled",
								children: "+"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled,
						onClick: onRemove,
						"aria-label": `${t.remove} ${item.name}`,
						className: "flex min-h-11 items-center gap-2 rounded-sm px-2 text-sm text-danger hover:bg-danger-bg",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "trash",
							className: "h-4 w-4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 13
						}, this), removing ? t.removing : "Remove"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_c = CartItemRow;
var _c;
$RefreshReg$(_c, "CartItemRow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Cart/components/CartItemRow.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartItemRow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartItemRow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartItemRow.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsWUFBWTtBQUVyQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsWUFBWSxFQUMxQixNQUNBLFVBQ0EsVUFDQSxVQUNBLFlBQ0EsWUFRQztDQUNELE1BQU0sWUFBWSxPQUFPLGNBQWMsUUFDckMsT0FDQSxtQkFBbUIsS0FBSyxTQUFTLENBQ25DO0NBQ0EsT0FDRSx3QkFBQyxNQUFEO0VBQUksV0FBVTtFQUFZLGFBQVcsWUFBWTtZQUFqRCxDQUNFLHdCQUFDLE1BQUQ7R0FBTSxJQUFJO0dBQVcsV0FBVTthQUM3Qix3QkFBQyxjQUFEO0lBQ0UsS0FBSyxLQUFLLE9BQU87SUFDakIsS0FBSyxLQUFLO0lBQ1YsV0FBVTtHQUNYOzs7OztFQUNHOzs7O1lBQ04sd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNaLHdCQUFDLE1BQUQ7UUFBTSxJQUFJO1FBQVcsV0FBVTtrQkFDNUIsS0FBSztPQUNGOzs7OztNQUNKOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiLENBQTBDLFNBQU0sS0FBSyxHQUFPOzs7OztjQUN6RDs7Ozs7ZUFDTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixXQUNDLHdCQUFDLFFBQUQ7T0FBTSxNQUFLO2lCQUFVLEVBQUU7TUFBZTs7OztpQkFFdEMsZUFBZSxLQUFLLFNBQVM7S0FFOUI7Ozs7YUFDQTs7Ozs7O0lBQ0wsd0JBQUMsS0FBRDtLQUNFLFdBQVcsMENBQTBDLEtBQUssY0FBYyxpQkFBaUI7ZUFEM0YsQ0FHRSx3QkFBQyxNQUFEO01BQ0UsTUFBTSxLQUFLLGNBQWMsVUFBVTtNQUNuQyxXQUFVO0tBQ1g7Ozs7ZUFDQSxLQUFLLGNBQ0YsYUFBYSxlQUFlLFVBQzVCLGFBQWEsZUFBZSxVQUMvQjs7Ozs7O0lBQ0YsS0FBSyxXQUFXLEtBQ2Ysd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYixDQUNHLGVBQWUsS0FBSyxTQUFTLEdBQUUsT0FDL0I7Ozs7OztJQUVKLENBQUMsS0FBSyxlQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsS0FBSyxXQUFXLEtBQUssWUFBWSxLQUFLLFdBQVcsSUFDOUMsR0FBRyxFQUFFLGFBQWEsR0FBRyxLQUFLLFNBQVMsZUFBZSxFQUFFLElBQUksRUFBRSxtQkFDMUQsRUFBRTtJQUNMOzs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQ0UsTUFBSztNQUNMLGNBQVksR0FBRyxFQUFFLFNBQVMsSUFBSSxLQUFLO01BQ25DLFdBQVU7Z0JBSFo7T0FLRSx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGNBQVksR0FBRyxFQUFFLFNBQVMsR0FBRyxLQUFLO1FBQ2xDLFVBQVUsWUFBWSxhQUFhLE1BQU0sQ0FBQyxDQUFDLE1BQU07UUFDakQsZUFBZSxXQUFXLENBQUMsQ0FBQztRQUM1QixXQUFVO2tCQUNYO09BRU87Ozs7O09BQ1Isd0JBQUMsUUFBRDtRQUNFLGNBQVksR0FBRyxFQUFFLFNBQVMsSUFBSSxLQUFLO1FBQ25DLFdBQVU7a0JBRVQsS0FBSztPQUNGOzs7OztPQUNOLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsY0FBWSxHQUFHLEVBQUUsU0FBUyxHQUFHLEtBQUs7UUFDbEMsVUFBVSxZQUFZLGFBQWEsTUFBTSxDQUFDLE1BQU07UUFDaEQsZUFBZSxXQUFXLENBQUM7UUFDM0IsV0FBVTtrQkFDWDtPQUVPOzs7OztNQUNMOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0s7TUFDVixTQUFTO01BQ1QsY0FBWSxHQUFHLEVBQUUsT0FBTyxHQUFHLEtBQUs7TUFDaEMsV0FBVTtnQkFMWixDQU9FLHdCQUFDLE1BQUQ7T0FBTSxNQUFLO09BQVEsV0FBVTtNQUFXOzs7O2dCQUN2QyxXQUFXLEVBQUUsV0FBVyxRQUNuQjs7Ozs7YUFDTDs7Ozs7O0dBQ0Y7Ozs7O1VBQ0g7Ozs7OztBQUVSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcnRJdGVtUm93LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHR5cGUgeyBDYXJ0SXRlbSB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL2NhcnQudHlwZXMnO1xyXG5pbXBvcnQgeyBQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0SW1hZ2UnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9jdXJyZW5jeSc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IG5leHRRdWFudGl0eSB9IGZyb20gJy4uL2hlbHBlcnMvY2FydC5oZWxwZXJzJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5jYXJ0O1xyXG5leHBvcnQgZnVuY3Rpb24gQ2FydEl0ZW1Sb3coe1xyXG4gIGl0ZW0sXHJcbiAgZGlzYWJsZWQsXHJcbiAgdXBkYXRpbmcsXHJcbiAgcmVtb3ZpbmcsXHJcbiAgb25RdWFudGl0eSxcclxuICBvblJlbW92ZSxcclxufToge1xyXG4gIGl0ZW06IENhcnRJdGVtO1xyXG4gIGRpc2FibGVkOiBib29sZWFuO1xyXG4gIHVwZGF0aW5nOiBib29sZWFuO1xyXG4gIHJlbW92aW5nOiBib29sZWFuO1xyXG4gIG9uUXVhbnRpdHk6IChkaXJlY3Rpb246IC0xIHwgMSkgPT4gdm9pZDtcclxuICBvblJlbW92ZTogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IGRldGFpbFVybCA9IFJPVVRFUy5wcm9kdWN0RGV0YWlsLnJlcGxhY2UoXHJcbiAgICAnOmlkJyxcclxuICAgIGVuY29kZVVSSUNvbXBvbmVudChpdGVtLnByb2R1Y3RJZCksXHJcbiAgKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGxpIGNsYXNzTmFtZT1cImNhcnQtbGluZVwiIGFyaWEtYnVzeT17dXBkYXRpbmcgfHwgcmVtb3Zpbmd9PlxyXG4gICAgICA8TGluayB0bz17ZGV0YWlsVXJsfSBjbGFzc05hbWU9XCJjYXJ0LWxpbmUtaW1hZ2VcIj5cclxuICAgICAgICA8UHJvZHVjdEltYWdlXHJcbiAgICAgICAgICBzcmM9e2l0ZW0uaW1hZ2VzWzBdfVxyXG4gICAgICAgICAgYWx0PXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgdy1mdWxsXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1saW5lLWNvbnRlbnRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2FucyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgIDxMaW5rIHRvPXtkZXRhaWxVcmx9IGNsYXNzTmFtZT1cImhvdmVyOnRleHQtZmctbGlua1wiPlxyXG4gICAgICAgICAgICAgICAge2l0ZW0ubmFtZX1cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+U0tVOiB7aXRlbS5TS1V9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwcmljZSBzaHJpbmstMCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZyBzbTp0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAge3VwZGF0aW5nID8gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIHJvbGU9XCJzdGF0dXNcIj57dC51cGRhdGluZ308L3NwYW4+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgZm9ybWF0Q3VycmVuY3koaXRlbS5saW5lVG90YWwpXHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIGNsYXNzTmFtZT17YG10LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzICR7aXRlbS5pc0F2YWlsYWJsZSA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtZGFuZ2VyJ31gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uXHJcbiAgICAgICAgICAgIG5hbWU9e2l0ZW0uaXNBdmFpbGFibGUgPyAnY2hlY2snIDogJ2luZm8nfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAge2l0ZW0uaXNBdmFpbGFibGVcclxuICAgICAgICAgICAgPyB0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMuaW5TdG9ja1xyXG4gICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5vdXRPZlN0b2NrfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICB7aXRlbS5xdWFudGl0eSA+IDEgJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGl0ZW0udW5pdFByaWNlKX0gZWFjaFxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgeyFpdGVtLmlzQXZhaWxhYmxlICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC1zbSBiZy1kYW5nZXItYmcgcHgtMyBweS0yIHRleHQtc20gdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgICAge2l0ZW0ucXVhbnRpdHkgPiBpdGVtLnN0b2NrUXR5ICYmIGl0ZW0uc3RvY2tRdHkgPiAwXHJcbiAgICAgICAgICAgICAgPyBgJHt0LnN0b2NrQ2hhbmdlZH0gJHtpdGVtLnN0b2NrUXR5LnRvTG9jYWxlU3RyaW5nKCl9LiAke3QucmVkdWNlUXVhbnRpdHl9YFxyXG4gICAgICAgICAgICAgIDogdC51bmF2YWlsYWJsZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgcm9sZT1cImdyb3VwXCJcclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dC5xdWFudGl0eX06ICR7aXRlbS5uYW1lfWB9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGgtMTEgaXRlbXMtY2VudGVyIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2Ake3QuZGVjcmVhc2V9ICR7aXRlbS5uYW1lfWB9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IG5leHRRdWFudGl0eShpdGVtLCAtMSkgPT09IG51bGx9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25RdWFudGl0eSgtMSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctMTAgdGV4dC1sZyB0ZXh0LWZnLXNlY29uZGFyeSBob3ZlcjpiZy1zdWJ0bGUgZGlzYWJsZWQ6dGV4dC1mZy1kaXNhYmxlZFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICDiiJJcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dC5xdWFudGl0eX06ICR7aXRlbS5xdWFudGl0eX1gfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTEwIHB4LTIgdGV4dC1jZW50ZXIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRhYnVsYXItbnVtc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aXRlbS5xdWFudGl0eX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dC5pbmNyZWFzZX0gJHtpdGVtLm5hbWV9YH1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWQgfHwgbmV4dFF1YW50aXR5KGl0ZW0sIDEpID09PSBudWxsfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUXVhbnRpdHkoMSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctMTAgdGV4dC1sZyB0ZXh0LWZnLXNlY29uZGFyeSBob3ZlcjpiZy1zdWJ0bGUgZGlzYWJsZWQ6dGV4dC1mZy1kaXNhYmxlZFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICArXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uUmVtb3ZlfVxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHt0LnJlbW92ZX0gJHtpdGVtLm5hbWV9YH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0xMSBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1zbSBweC0yIHRleHQtc20gdGV4dC1kYW5nZXIgaG92ZXI6YmctZGFuZ2VyLWJnXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cInRyYXNoXCIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgIHtyZW1vdmluZyA/IHQucmVtb3ZpbmcgOiAnUmVtb3ZlJ31cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbGk+XHJcbiAgKTtcclxufVxyXG4iXX0=