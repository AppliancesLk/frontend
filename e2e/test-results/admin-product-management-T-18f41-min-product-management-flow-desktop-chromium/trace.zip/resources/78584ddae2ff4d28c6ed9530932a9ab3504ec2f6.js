import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Checkout/components/DeliveryForm.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/DeliveryForm.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.checkout;
const fields = [
	{
		name: "firstName",
		label: t.firstName,
		autoComplete: "given-name",
		maxLength: 80
	},
	{
		name: "lastName",
		label: t.lastName,
		autoComplete: "family-name",
		maxLength: 80
	},
	{
		name: "email",
		label: t.email,
		autoComplete: "email",
		type: "email",
		maxLength: 254
	},
	{
		name: "phone",
		label: t.phone,
		autoComplete: "tel",
		type: "tel",
		maxLength: 30,
		hint: t.phoneHint
	},
	{
		name: "addressLine1",
		label: t.addressLine1,
		autoComplete: "address-line1",
		maxLength: 200,
		full: true
	},
	{
		name: "addressLine2",
		label: t.addressLine2,
		autoComplete: "address-line2",
		maxLength: 200,
		full: true,
		optional: true
	},
	{
		name: "city",
		label: t.city,
		autoComplete: "address-level2",
		maxLength: 100
	},
	{
		name: "postalCode",
		label: t.postalCode,
		autoComplete: "postal-code",
		maxLength: 20
	},
	{
		name: "countryCode",
		label: t.countryCode,
		autoComplete: "country",
		maxLength: 2,
		hint: t.countryHint
	}
];
export function DeliveryForm({ page }) {
	const blocked = !page.cart?.items.length || page.cart.items.some((item) => !item.isAvailable);
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: (event) => void page.submit(event),
		noValidate: true,
		className: "rounded-md border border-line bg-surface p-5  sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "flex items-center gap-3 text-xl font-semibold text-fg",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "form-step-number",
					children: "1"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this), t.deliveryTitle]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm leading-6 text-fg-muted",
				children: t.deliveryDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				disabled: page.locked,
				className: "mt-6 grid min-w-0 gap-5 sm:grid-cols-2",
				children: [/* @__PURE__ */ _jsxDEV("legend", {
					className: "sr-only",
					children: t.deliveryTitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 9
				}, this), fields.map((field) => /* @__PURE__ */ _jsxDEV("div", {
					className: field.full ? "sm:col-span-2" : "",
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: `checkout-${field.name}`,
							className: "auth-label",
							children: [field.label, field.optional && /* @__PURE__ */ _jsxDEV("span", {
								className: "ml-1 font-normal text-fg-muted",
								children: t.optional
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							id: `checkout-${field.name}`,
							name: field.name,
							type: field.type ?? "text",
							autoComplete: field.autoComplete,
							required: !field.optional,
							maxLength: field.maxLength,
							value: page.draft[field.name],
							onChange: (event) => page.change(field.name, event.target.value),
							"aria-invalid": !!page.errors[field.name],
							"aria-describedby": page.errors[field.name] ? `${field.name}-error` : field.hint ? `${field.name}-hint` : undefined,
							className: `auth-input ${page.errors[field.name] ? "border-danger/25" : ""}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this),
						field.hint && /* @__PURE__ */ _jsxDEV("p", {
							id: `${field.name}-hint`,
							className: "mt-1.5 text-xs leading-5 text-fg-muted",
							children: field.hint
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 15
						}, this),
						page.errors[field.name] && /* @__PURE__ */ _jsxDEV("p", {
							id: `${field.name}-error`,
							className: "mt-1.5 text-sm text-danger",
							children: page.errors[field.name]
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 15
						}, this)
					]
				}, field.name, true, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 11
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 border-t border-line pt-5",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: page.locked || blocked,
					className: "auth-primary h-12 w-full",
					children: [page.saving && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 27
					}, this), page.saving ? t.preparing : page.summary ? t.validateAgain : t.prepare]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-3 text-xs leading-5 text-fg-muted",
					children: t.prepareHint
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 87,
		columnNumber: 5
	}, this);
}
_c = DeliveryForm;
var _c;
$RefreshReg$(_c, "DeliveryForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Checkout/components/DeliveryForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/DeliveryForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/DeliveryForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/DeliveryForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsb0JBQW9COzs7QUFHN0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsTUFBTSxTQVNBO0NBQ0o7RUFDRSxNQUFNO0VBQ04sT0FBTyxFQUFFO0VBQ1QsY0FBYztFQUNkLFdBQVc7Q0FDYjtDQUNBO0VBQ0UsTUFBTTtFQUNOLE9BQU8sRUFBRTtFQUNULGNBQWM7RUFDZCxXQUFXO0NBQ2I7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxjQUFjO0VBQ2QsTUFBTTtFQUNOLFdBQVc7Q0FDYjtDQUNBO0VBQ0UsTUFBTTtFQUNOLE9BQU8sRUFBRTtFQUNULGNBQWM7RUFDZCxNQUFNO0VBQ04sV0FBVztFQUNYLE1BQU0sRUFBRTtDQUNWO0NBQ0E7RUFDRSxNQUFNO0VBQ04sT0FBTyxFQUFFO0VBQ1QsY0FBYztFQUNkLFdBQVc7RUFDWCxNQUFNO0NBQ1I7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxjQUFjO0VBQ2QsV0FBVztFQUNYLE1BQU07RUFDTixVQUFVO0NBQ1o7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxjQUFjO0VBQ2QsV0FBVztDQUNiO0NBQ0E7RUFDRSxNQUFNO0VBQ04sT0FBTyxFQUFFO0VBQ1QsY0FBYztFQUNkLFdBQVc7Q0FDYjtDQUNBO0VBQ0UsTUFBTTtFQUNOLE9BQU8sRUFBRTtFQUNULGNBQWM7RUFDZCxXQUFXO0VBQ1gsTUFBTSxFQUFFO0NBQ1Y7QUFDRjtBQUNBLE9BQU8sU0FBUyxhQUFhLEVBQzNCLFFBR0M7Q0FDRCxNQUFNLFVBQ0osQ0FBQyxLQUFLLE1BQU0sTUFBTSxVQUNsQixLQUFLLEtBQUssTUFBTSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVc7Q0FDbEQsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyxVQUFVLEtBQUssS0FBSyxPQUFPLEtBQUs7RUFDM0M7RUFDQSxXQUFVO1lBSFo7R0FLRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFkLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBbUI7SUFBTzs7OztjQUN6QyxFQUFFLGFBQ0Q7Ozs7OztHQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsRUFBRTtHQUNGOzs7OztHQUNILHdCQUFDLFlBQUQ7SUFDRSxVQUFVLEtBQUs7SUFDZixXQUFVO2NBRlosQ0FJRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUFXLEVBQUU7SUFBc0I7Ozs7Y0FDcEQsT0FBTyxLQUFLLFVBQ1gsd0JBQUMsT0FBRDtLQUFzQixXQUFXLE1BQU0sT0FBTyxrQkFBa0I7ZUFBaEU7TUFDRSx3QkFBQyxTQUFEO09BQU8sU0FBUyxZQUFZLE1BQU07T0FBUSxXQUFVO2lCQUFwRCxDQUNHLE1BQU0sT0FDTixNQUFNLFlBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsRUFBRTtPQUNDOzs7O2VBRUg7Ozs7OztNQUNQLHdCQUFDLFNBQUQ7T0FDRSxJQUFJLFlBQVksTUFBTTtPQUN0QixNQUFNLE1BQU07T0FDWixNQUFNLE1BQU0sUUFBUTtPQUNwQixjQUFjLE1BQU07T0FDcEIsVUFBVSxDQUFDLE1BQU07T0FDakIsV0FBVyxNQUFNO09BQ2pCLE9BQU8sS0FBSyxNQUFNLE1BQU07T0FDeEIsV0FBVyxVQUFVLEtBQUssT0FBTyxNQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUs7T0FDL0QsZ0JBQWMsQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNO09BQ2xDLG9CQUNFLEtBQUssT0FBTyxNQUFNLFFBQ2QsR0FBRyxNQUFNLEtBQUssVUFDZCxNQUFNLE9BQ0osR0FBRyxNQUFNLEtBQUssU0FDZDtPQUVSLFdBQVcsY0FBYyxLQUFLLE9BQU8sTUFBTSxRQUFRLHFCQUFxQjtNQUN6RTs7Ozs7TUFDQSxNQUFNLFFBQ0wsd0JBQUMsS0FBRDtPQUNFLElBQUksR0FBRyxNQUFNLEtBQUs7T0FDbEIsV0FBVTtpQkFFVCxNQUFNO01BQ047Ozs7O01BRUosS0FBSyxPQUFPLE1BQU0sU0FDakIsd0JBQUMsS0FBRDtPQUNFLElBQUksR0FBRyxNQUFNLEtBQUs7T0FDbEIsV0FBVTtpQkFFVCxLQUFLLE9BQU8sTUFBTTtNQUNsQjs7Ozs7S0FFRjtPQTVDSyxNQUFNOzs7O1dBNENYLENBQ04sQ0FDTzs7Ozs7O0dBQ1Ysd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsVUFBVSxLQUFLLFVBQVU7S0FDekIsV0FBVTtlQUhaLENBS0csS0FBSyxVQUFVLHdCQUFDLFNBQUQsRUFBUyxXQUFVLE9BQVE7Ozs7ZUFDMUMsS0FBSyxTQUNGLEVBQUUsWUFDRixLQUFLLFVBQ0gsRUFBRSxnQkFDRixFQUFFLE9BQ0Y7Ozs7O2NBQ1Isd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBd0MsRUFBRTtJQUFlOzs7O1lBQ25FOzs7Ozs7RUFDRDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGVsaXZlcnlGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB0eXBlIHsgdXNlQ2hlY2tvdXRQYWdlIH0gZnJvbSAnLi4vaG9va3MvdXNlQ2hlY2tvdXRQYWdlJztcclxuaW1wb3J0IHR5cGUgeyBEZWxpdmVyeURyYWZ0IH0gZnJvbSAnLi4vdHlwZXMvY2hlY2tvdXQudHlwZXMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmNoZWNrb3V0O1xyXG5jb25zdCBmaWVsZHM6IHtcclxuICBuYW1lOiBrZXlvZiBEZWxpdmVyeURyYWZ0O1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgYXV0b0NvbXBsZXRlOiBzdHJpbmc7XHJcbiAgdHlwZT86IHN0cmluZztcclxuICBtYXhMZW5ndGg6IG51bWJlcjtcclxuICBmdWxsPzogYm9vbGVhbjtcclxuICBvcHRpb25hbD86IGJvb2xlYW47XHJcbiAgaGludD86IHN0cmluZztcclxufVtdID0gW1xyXG4gIHtcclxuICAgIG5hbWU6ICdmaXJzdE5hbWUnLFxyXG4gICAgbGFiZWw6IHQuZmlyc3ROYW1lLFxyXG4gICAgYXV0b0NvbXBsZXRlOiAnZ2l2ZW4tbmFtZScsXHJcbiAgICBtYXhMZW5ndGg6IDgwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogJ2xhc3ROYW1lJyxcclxuICAgIGxhYmVsOiB0Lmxhc3ROYW1lLFxyXG4gICAgYXV0b0NvbXBsZXRlOiAnZmFtaWx5LW5hbWUnLFxyXG4gICAgbWF4TGVuZ3RoOiA4MCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6ICdlbWFpbCcsXHJcbiAgICBsYWJlbDogdC5lbWFpbCxcclxuICAgIGF1dG9Db21wbGV0ZTogJ2VtYWlsJyxcclxuICAgIHR5cGU6ICdlbWFpbCcsXHJcbiAgICBtYXhMZW5ndGg6IDI1NCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6ICdwaG9uZScsXHJcbiAgICBsYWJlbDogdC5waG9uZSxcclxuICAgIGF1dG9Db21wbGV0ZTogJ3RlbCcsXHJcbiAgICB0eXBlOiAndGVsJyxcclxuICAgIG1heExlbmd0aDogMzAsXHJcbiAgICBoaW50OiB0LnBob25lSGludCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6ICdhZGRyZXNzTGluZTEnLFxyXG4gICAgbGFiZWw6IHQuYWRkcmVzc0xpbmUxLFxyXG4gICAgYXV0b0NvbXBsZXRlOiAnYWRkcmVzcy1saW5lMScsXHJcbiAgICBtYXhMZW5ndGg6IDIwMCxcclxuICAgIGZ1bGw6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiAnYWRkcmVzc0xpbmUyJyxcclxuICAgIGxhYmVsOiB0LmFkZHJlc3NMaW5lMixcclxuICAgIGF1dG9Db21wbGV0ZTogJ2FkZHJlc3MtbGluZTInLFxyXG4gICAgbWF4TGVuZ3RoOiAyMDAsXHJcbiAgICBmdWxsOiB0cnVlLFxyXG4gICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiAnY2l0eScsXHJcbiAgICBsYWJlbDogdC5jaXR5LFxyXG4gICAgYXV0b0NvbXBsZXRlOiAnYWRkcmVzcy1sZXZlbDInLFxyXG4gICAgbWF4TGVuZ3RoOiAxMDAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiAncG9zdGFsQ29kZScsXHJcbiAgICBsYWJlbDogdC5wb3N0YWxDb2RlLFxyXG4gICAgYXV0b0NvbXBsZXRlOiAncG9zdGFsLWNvZGUnLFxyXG4gICAgbWF4TGVuZ3RoOiAyMCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6ICdjb3VudHJ5Q29kZScsXHJcbiAgICBsYWJlbDogdC5jb3VudHJ5Q29kZSxcclxuICAgIGF1dG9Db21wbGV0ZTogJ2NvdW50cnknLFxyXG4gICAgbWF4TGVuZ3RoOiAyLFxyXG4gICAgaGludDogdC5jb3VudHJ5SGludCxcclxuICB9LFxyXG5dO1xyXG5leHBvcnQgZnVuY3Rpb24gRGVsaXZlcnlGb3JtKHtcclxuICBwYWdlLFxyXG59OiB7XHJcbiAgcGFnZTogUmV0dXJuVHlwZTx0eXBlb2YgdXNlQ2hlY2tvdXRQYWdlPjtcclxufSkge1xyXG4gIGNvbnN0IGJsb2NrZWQgPVxyXG4gICAgIXBhZ2UuY2FydD8uaXRlbXMubGVuZ3RoIHx8XHJcbiAgICBwYWdlLmNhcnQuaXRlbXMuc29tZSgoaXRlbSkgPT4gIWl0ZW0uaXNBdmFpbGFibGUpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybVxyXG4gICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB2b2lkIHBhZ2Uuc3VibWl0KGV2ZW50KX1cclxuICAgICAgbm9WYWxpZGF0ZVxyXG4gICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNSAgc206cC02XCJcclxuICAgID5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9ybS1zdGVwLW51bWJlclwiPjE8L3NwYW4+XHJcbiAgICAgICAge3QuZGVsaXZlcnlUaXRsZX1cclxuICAgICAgPC9oMj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAge3QuZGVsaXZlcnlEZXNjcmlwdGlvbn1cclxuICAgICAgPC9wPlxyXG4gICAgICA8ZmllbGRzZXRcclxuICAgICAgICBkaXNhYmxlZD17cGFnZS5sb2NrZWR9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibXQtNiBncmlkIG1pbi13LTAgZ2FwLTUgc206Z3JpZC1jb2xzLTJcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPGxlZ2VuZCBjbGFzc05hbWU9XCJzci1vbmx5XCI+e3QuZGVsaXZlcnlUaXRsZX08L2xlZ2VuZD5cclxuICAgICAgICB7ZmllbGRzLm1hcCgoZmllbGQpID0+IChcclxuICAgICAgICAgIDxkaXYga2V5PXtmaWVsZC5uYW1lfSBjbGFzc05hbWU9e2ZpZWxkLmZ1bGwgPyAnc206Y29sLXNwYW4tMicgOiAnJ30+XHJcbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtgY2hlY2tvdXQtJHtmaWVsZC5uYW1lfWB9IGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICB7ZmllbGQubGFiZWx9XHJcbiAgICAgICAgICAgICAge2ZpZWxkLm9wdGlvbmFsICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTEgZm9udC1ub3JtYWwgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dC5vcHRpb25hbH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICBpZD17YGNoZWNrb3V0LSR7ZmllbGQubmFtZX1gfVxyXG4gICAgICAgICAgICAgIG5hbWU9e2ZpZWxkLm5hbWV9XHJcbiAgICAgICAgICAgICAgdHlwZT17ZmllbGQudHlwZSA/PyAndGV4dCd9XHJcbiAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPXtmaWVsZC5hdXRvQ29tcGxldGV9XHJcbiAgICAgICAgICAgICAgcmVxdWlyZWQ9eyFmaWVsZC5vcHRpb25hbH1cclxuICAgICAgICAgICAgICBtYXhMZW5ndGg9e2ZpZWxkLm1heExlbmd0aH1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGFnZS5kcmFmdFtmaWVsZC5uYW1lXX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBwYWdlLmNoYW5nZShmaWVsZC5uYW1lLCBldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17ISFwYWdlLmVycm9yc1tmaWVsZC5uYW1lXX1cclxuICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtcclxuICAgICAgICAgICAgICAgIHBhZ2UuZXJyb3JzW2ZpZWxkLm5hbWVdXHJcbiAgICAgICAgICAgICAgICAgID8gYCR7ZmllbGQubmFtZX0tZXJyb3JgXHJcbiAgICAgICAgICAgICAgICAgIDogZmllbGQuaGludFxyXG4gICAgICAgICAgICAgICAgICAgID8gYCR7ZmllbGQubmFtZX0taGludGBcclxuICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhdXRoLWlucHV0ICR7cGFnZS5lcnJvcnNbZmllbGQubmFtZV0gPyAnYm9yZGVyLWRhbmdlci8yNScgOiAnJ31gfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB7ZmllbGQuaGludCAmJiAoXHJcbiAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgIGlkPXtgJHtmaWVsZC5uYW1lfS1oaW50YH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZmllbGQuaGludH1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtwYWdlLmVycm9yc1tmaWVsZC5uYW1lXSAmJiAoXHJcbiAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgIGlkPXtgJHtmaWVsZC5uYW1lfS1lcnJvcmB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xLjUgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UuZXJyb3JzW2ZpZWxkLm5hbWVdfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgYm9yZGVyLXQgYm9yZGVyLWxpbmUgcHQtNVwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UubG9ja2VkIHx8IGJsb2NrZWR9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnkgaC0xMiB3LWZ1bGxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtwYWdlLnNhdmluZyAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICB7cGFnZS5zYXZpbmdcclxuICAgICAgICAgICAgPyB0LnByZXBhcmluZ1xyXG4gICAgICAgICAgICA6IHBhZ2Uuc3VtbWFyeVxyXG4gICAgICAgICAgICAgID8gdC52YWxpZGF0ZUFnYWluXHJcbiAgICAgICAgICAgICAgOiB0LnByZXBhcmV9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+e3QucHJlcGFyZUhpbnR9PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZm9ybT5cclxuICApO1xyXG59XHJcbiJdfQ==