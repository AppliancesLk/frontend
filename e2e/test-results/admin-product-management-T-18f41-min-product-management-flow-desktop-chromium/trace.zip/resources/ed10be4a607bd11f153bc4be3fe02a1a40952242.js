import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/BrandLogo.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { useSeasonalTheme } from "/src/hooks/useSeasonalTheme.ts";
import { BrandOrnament } from "/src/components/seasonal/SeasonalArtwork.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/BrandLogo.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function BrandLogo({ inverse = false, compact = false, theme, decorations }) {
	_s();
	const { active } = useSeasonalTheme();
	const selected = theme ?? active.theme;
	const decorated = (decorations ?? active.decorations) && selected !== "DEFAULT";
	const mark = /* @__PURE__ */ _jsxDEV("svg", {
		viewBox: "0 0 36 36",
		fill: "none",
		"aria-hidden": "true",
		className: "h-9 w-9 shrink-0",
		children: [
			/* @__PURE__ */ _jsxDEV("rect", {
				x: "2",
				y: "2",
				width: "32",
				height: "32",
				rx: "9",
				stroke: "currentColor",
				strokeWidth: "1.75"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M13 9v6m10-6v6M10 15h16v3a8 8 0 0 1-16 0v-3Zm8 11v4",
				stroke: "currentColor",
				strokeWidth: "1.75",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "28",
				cy: "8",
				r: "2",
				className: "brand-spark"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `brand-logo ${inverse ? "brand-logo-inverse" : ""}`,
		"data-logo-season": selected !== "DEFAULT" ? selected : undefined,
		children: [decorated ? /* @__PURE__ */ _jsxDEV("span", {
			className: "season-logo-mark",
			children: [mark, /* @__PURE__ */ _jsxDEV(BrandOrnament, { theme: selected }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 9
		}, this) : mark, !compact && /* @__PURE__ */ _jsxDEV("span", {
			className: "brand-wordmark",
			children: ["Appliances", /* @__PURE__ */ _jsxDEV("span", {
				className: "brand-domain",
				children: ".lk"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 21
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
}
_s(BrandLogo, "MZMqSovULttIiMLBPJLy0WjJ/6o=", false, function() {
	return [useSeasonalTheme];
});
_c = BrandLogo;
var _c;
$RefreshReg$(_c, "BrandLogo");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/BrandLogo.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/BrandLogo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/BrandLogo.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/BrandLogo.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyx3QkFBd0I7QUFFakMsU0FBUyxxQkFBcUI7Ozs7QUFDOUIsT0FBTyxTQUFTLFVBQVUsRUFDeEIsVUFBVSxPQUNWLFVBQVUsT0FDVixPQUNBLGVBTUM7O0NBQ0QsTUFBTSxFQUFFLFdBQVcsaUJBQWlCO0NBQ3BDLE1BQU0sV0FBVyxTQUFTLE9BQU87Q0FDakMsTUFBTSxhQUNILGVBQWUsT0FBTyxnQkFBZ0IsYUFBYTtDQUN0RCxNQUFNLE9BQ0osd0JBQUMsT0FBRDtFQUNFLFNBQVE7RUFDUixNQUFLO0VBQ0wsZUFBWTtFQUNaLFdBQVU7WUFKWjtHQU1FLHdCQUFDLFFBQUQ7SUFDRSxHQUFFO0lBQ0YsR0FBRTtJQUNGLE9BQU07SUFDTixRQUFPO0lBQ1AsSUFBRztJQUNILFFBQU87SUFDUCxhQUFZO0dBQ2I7Ozs7O0dBQ0Qsd0JBQUMsUUFBRDtJQUNFLEdBQUU7SUFDRixRQUFPO0lBQ1AsYUFBWTtJQUNaLGVBQWM7SUFDZCxnQkFBZTtHQUNoQjs7Ozs7R0FDRCx3QkFBQyxVQUFEO0lBQVEsSUFBRztJQUFLLElBQUc7SUFBSSxHQUFFO0lBQUksV0FBVTtHQUFlOzs7OztFQUNuRDs7Ozs7O0NBRVAsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyxjQUFjLFVBQVUsdUJBQXVCO0VBQzFELG9CQUFrQixhQUFhLFlBQVksV0FBVztZQUZ4RCxDQUlHLFlBQ0Msd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FDRyxNQUNELHdCQUFDLGVBQUQsRUFBZSxPQUFPLFNBQVc7Ozs7V0FDN0I7Ozs7O2FBRU4sTUFFRCxDQUFDLFdBQ0Esd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FBaUMsY0FDckIsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBZTtHQUFTOzs7O1dBQzlDOzs7OztVQUVKOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCcmFuZExvZ28udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVNlYXNvbmFsVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcy91c2VTZWFzb25hbFRoZW1lJztcclxuaW1wb3J0IHR5cGUgeyBTZWFzb25hbFRoZW1lIH0gZnJvbSAnLi4vLi4vdHlwZXMvc2Vhc29uYWwtdGhlbWUudHlwZXMnO1xyXG5pbXBvcnQgeyBCcmFuZE9ybmFtZW50IH0gZnJvbSAnLi4vc2Vhc29uYWwvU2Vhc29uYWxBcnR3b3JrJztcclxuZXhwb3J0IGZ1bmN0aW9uIEJyYW5kTG9nbyh7XHJcbiAgaW52ZXJzZSA9IGZhbHNlLFxyXG4gIGNvbXBhY3QgPSBmYWxzZSxcclxuICB0aGVtZSxcclxuICBkZWNvcmF0aW9ucyxcclxufToge1xyXG4gIGludmVyc2U/OiBib29sZWFuO1xyXG4gIGNvbXBhY3Q/OiBib29sZWFuO1xyXG4gIHRoZW1lPzogU2Vhc29uYWxUaGVtZTtcclxuICBkZWNvcmF0aW9ucz86IGJvb2xlYW47XHJcbn0pIHtcclxuICBjb25zdCB7IGFjdGl2ZSB9ID0gdXNlU2Vhc29uYWxUaGVtZSgpO1xyXG4gIGNvbnN0IHNlbGVjdGVkID0gdGhlbWUgPz8gYWN0aXZlLnRoZW1lO1xyXG4gIGNvbnN0IGRlY29yYXRlZCA9XHJcbiAgICAoZGVjb3JhdGlvbnMgPz8gYWN0aXZlLmRlY29yYXRpb25zKSAmJiBzZWxlY3RlZCAhPT0gJ0RFRkFVTFQnO1xyXG4gIGNvbnN0IG1hcmsgPSAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIHZpZXdCb3g9XCIwIDAgMzYgMzZcIlxyXG4gICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgIGNsYXNzTmFtZT1cImgtOSB3LTkgc2hyaW5rLTBcIlxyXG4gICAgPlxyXG4gICAgICA8cmVjdFxyXG4gICAgICAgIHg9XCIyXCJcclxuICAgICAgICB5PVwiMlwiXHJcbiAgICAgICAgd2lkdGg9XCIzMlwiXHJcbiAgICAgICAgaGVpZ2h0PVwiMzJcIlxyXG4gICAgICAgIHJ4PVwiOVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICBzdHJva2VXaWR0aD1cIjEuNzVcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMTMgOXY2bTEwLTZ2Nk0xMCAxNWgxNnYzYTggOCAwIDAgMS0xNiAwdi0zWm04IDExdjRcIlxyXG4gICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9XCIxLjc1XCJcclxuICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAvPlxyXG4gICAgICA8Y2lyY2xlIGN4PVwiMjhcIiBjeT1cIjhcIiByPVwiMlwiIGNsYXNzTmFtZT1cImJyYW5kLXNwYXJrXCIgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuXHJcbiAgICAgIGNsYXNzTmFtZT17YGJyYW5kLWxvZ28gJHtpbnZlcnNlID8gJ2JyYW5kLWxvZ28taW52ZXJzZScgOiAnJ31gfVxyXG4gICAgICBkYXRhLWxvZ28tc2Vhc29uPXtzZWxlY3RlZCAhPT0gJ0RFRkFVTFQnID8gc2VsZWN0ZWQgOiB1bmRlZmluZWR9XHJcbiAgICA+XHJcbiAgICAgIHtkZWNvcmF0ZWQgPyAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2Vhc29uLWxvZ28tbWFya1wiPlxyXG4gICAgICAgICAge21hcmt9XHJcbiAgICAgICAgICA8QnJhbmRPcm5hbWVudCB0aGVtZT17c2VsZWN0ZWR9IC8+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIG1hcmtcclxuICAgICAgKX1cclxuICAgICAgeyFjb21wYWN0ICYmIChcclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJicmFuZC13b3JkbWFya1wiPlxyXG4gICAgICAgICAgQXBwbGlhbmNlczxzcGFuIGNsYXNzTmFtZT1cImJyYW5kLWRvbWFpblwiPi5sazwvc3Bhbj5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICl9XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufVxyXG4iXX0=