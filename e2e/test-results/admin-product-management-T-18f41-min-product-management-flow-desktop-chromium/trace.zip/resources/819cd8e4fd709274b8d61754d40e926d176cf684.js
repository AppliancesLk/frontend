import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Repairs/Details/index.tsx");const useEffect = __vite__cjsImport2_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import { formatDate } from "/src/utils/date.ts";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { translations } from "/src/utils/translations.ts";
import { useAdminRepairDetails } from "/src/pages/Admin/Repairs/Details/hooks/useAdminRepairDetails.ts";
import { ActionDialog } from "/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx";
import { RepairStatusBadge } from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/index.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.adminRepairs;
export default function AdminRepairDetailsPage() {
	_s();
	const page = useAdminRepairDetails();
	useEffect(() => {
		const previous = document.title;
		document.title = `${t.detailsTitle} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, []);
	if (page.loading) {
		return /* @__PURE__ */ _jsxDEV("section", {
			className: "space-y-6",
			children: /* @__PURE__ */ _jsxDEV(LoadingState, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this);
	}
	if (page.error) {
		return /* @__PURE__ */ _jsxDEV("section", {
			className: "space-y-6",
			children: /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-danger/25 bg-danger-bg p-8 text-center ",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "font-medium text-danger",
						children: t.notFound
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-danger",
						children: page.error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => void page.refresh(),
						className: "mt-4 auth-secondary",
						children: translations.common.retry
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this);
	}
	if (!page.repair) {
		return null;
	}
	const isPending = page.repair.status === "PENDING";
	const canAssign = page.repair.status === "APPROVED" || page.repair.status === "ASSIGNED";
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: page.goBack,
						className: "mb-2 text-sm font-medium text-fg-link hover:text-fg-link",
						children: ["← ", t.back]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title text-fg",
						children: t.detailsTitle
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 tabular-nums text-sm text-fg-muted",
						children: page.repair.reference
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void page.refresh(),
					disabled: page.processing,
					className: "auth-secondary",
					children: t.refresh
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: t.customer
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("dl", {
						className: "mt-4 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Username"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.customer.username
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: "Email"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.customer.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: t.status
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: "Current status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-2",
								children: /* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status: page.repair.status }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: t.submittedDate
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 text-sm text-fg",
								children: formatDate(page.repair.createdAt)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this),
							page.repair.reviewedAt && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-sm font-medium text-fg-muted",
								children: t.reviewedDate
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "mt-1 text-sm text-fg",
								children: formatDate(page.repair.reviewedAt)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-6 ",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-fg",
					children: t.deviceInfo
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("dl", {
					className: "mt-4 grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: t.deviceType
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.device.deviceType
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: t.brand
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.device.brand
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: t.model
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.device.model
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 13
						}, this),
						page.repair.device.serialNumber && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: t.serialNumber
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.device.serialNumber
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 15
						}, this),
						page.repair.device.purchaseDate && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
							className: "text-sm font-medium text-fg-muted",
							children: t.purchaseDate
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("dd", {
							className: "mt-1 text-sm text-fg",
							children: page.repair.device.purchaseDate
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-6 ",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-fg",
					children: t.problem
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-4 whitespace-pre-wrap text-sm text-fg-secondary",
					children: page.repair.problemDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 186,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 9
			}, this),
			(canAssign || page.repair.assignedRepairer) && /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-6",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: "Repairer assignment"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 193,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "repairer-assignment",
							className: "auth-label",
							children: "Assigned repairer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 17
						}, this), canAssign ? /* @__PURE__ */ _jsxDEV("select", {
							id: "repairer-assignment",
							className: "ui-field",
							defaultValue: page.repair.assignedRepairerId ?? "",
							disabled: page.processing || page.repairers.length === 0,
							onChange: (event) => void page.assignRepair(event.target.value),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: "Select an active repairer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 21
							}, this), page.repairers.map((repairer) => /* @__PURE__ */ _jsxDEV("option", {
								value: repairer.id,
								children: [
									repairer.username,
									" (",
									repairer.email,
									")"
								]
							}, repairer.id, true, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 23
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-fg",
							children: page.repair.assignedRepairer?.username ?? "Not assigned"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 15
						}, this), page.repair.assignedRepairer && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-fg-muted",
							children: page.repair.assignedRepairer.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 13
					}, this),
					canAssign && page.repairers.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm text-warning",
						children: "No active repairer accounts are available."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 227,
						columnNumber: 15
					}, this),
					page.actionError && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "mt-3 text-sm text-danger",
						children: page.actionError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 192,
				columnNumber: 11
			}, this),
			isPending && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => page.setAction("approve"),
					disabled: page.processing,
					className: "auth-primary bg-success hover:bg-success flex-1",
					children: t.approve
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => page.setAction("reject"),
					disabled: page.processing,
					className: "auth-primary bg-danger hover:bg-danger flex-1",
					children: t.reject
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 249,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 240,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(ActionDialog, { page }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 261,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
}
_s(AdminRepairDetailsPage, "96D4i2zWJy1wpv0O59Fq0byRr2Q=", false, function() {
	return [useAdminRepairDetails];
});
_c = AdminRepairDetailsPage;
var _c;
$RefreshReg$(_c, "AdminRepairDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Repairs/Details/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx5QkFBeUI7Ozs7QUFFbEMsTUFBTSxJQUFJLGFBQWE7QUFFdkIsZUFBZSxTQUFTLHlCQUF5Qjs7Q0FDL0MsTUFBTSxPQUFPLHNCQUFzQjtDQUVuQyxnQkFBZ0I7RUFDZCxNQUFNLFdBQVcsU0FBUztFQUMxQixTQUFTLFFBQVEsR0FBRyxFQUFFLGFBQWEsS0FBSyxhQUFhLE9BQU87RUFDNUQsYUFBYTtHQUNYLFNBQVMsUUFBUTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsSUFBSSxLQUFLLFNBQVM7RUFDaEIsT0FDRSx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUNqQix3QkFBQyxjQUFELENBQWU7Ozs7O0VBQ1I7Ozs7O0NBRWI7Q0FFQSxJQUFJLEtBQUssT0FBTztFQUNkLE9BQ0Usd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFDakIsd0JBQUMsT0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRlo7S0FJRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBMkIsRUFBRTtLQUFZOzs7OztLQUN0RCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNEIsS0FBSztLQUFTOzs7OztLQUN2RCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsS0FBSyxLQUFLLFFBQVE7TUFDakMsV0FBVTtnQkFFVCxhQUFhLE9BQU87S0FDZjs7Ozs7SUFDTDs7Ozs7O0VBQ0U7Ozs7O0NBRWI7Q0FFQSxJQUFJLENBQUMsS0FBSyxRQUFRO0VBQ2hCLE9BQU87Q0FDVDtDQUVBLE1BQU0sWUFBWSxLQUFLLE9BQU8sV0FBVztDQUN6QyxNQUFNLFlBQ0osS0FBSyxPQUFPLFdBQVcsY0FBYyxLQUFLLE9BQU8sV0FBVztDQUU5RCxPQUNFLGdEQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVMsS0FBSztNQUNkLFdBQVU7Z0JBSFosQ0FJQyxNQUNJLEVBQUUsSUFDQzs7Ozs7O0tBQ1Isd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCLEVBQUU7S0FBaUI7Ozs7O0tBQzFELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLEtBQUssT0FBTztLQUNaOzs7OztJQUNBOzs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLEtBQUssS0FBSyxRQUFRO0tBQ2pDLFVBQVUsS0FBSztLQUNmLFdBQVU7ZUFFVCxFQUFFO0lBQ0c7Ozs7WUFDTDs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBaUMsRUFBRTtLQUFhOzs7O2VBQzlELHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQztNQUFZOzs7O2dCQUM5RCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxLQUFLLE9BQU8sU0FBUztNQUNwQjs7OztjQUNEOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBb0M7TUFBUzs7OztnQkFDM0Qsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsS0FBSyxPQUFPLFNBQVM7TUFDcEI7Ozs7Y0FDRDs7OztjQUNIOzs7OzthQUNEOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBaUMsRUFBRTtLQUFXOzs7O2VBQzVELHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvQztPQUU5Qzs7OztpQkFDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWix3QkFBQyxtQkFBRCxFQUFtQixRQUFRLEtBQUssT0FBTyxPQUFTOzs7OztPQUM5Qzs7OztlQUNEOzs7OztPQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxFQUFFO09BQ0Q7Ozs7aUJBQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsV0FBVyxLQUFLLE9BQU8sU0FBUztPQUMvQjs7OztlQUNEOzs7OztPQUNKLEtBQUssT0FBTyxjQUNYLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxFQUFFO09BQ0Q7Ozs7aUJBQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsV0FBVyxLQUFLLE9BQU8sVUFBVTtPQUNoQzs7OztlQUNEOzs7OztNQUVKOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBaUMsRUFBRTtJQUFlOzs7O2NBQ2hFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsRUFBRTtNQUNEOzs7O2dCQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLEtBQUssT0FBTyxPQUFPO01BQ2xCOzs7O2NBQ0Q7Ozs7O01BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFxQyxFQUFFO01BQVU7Ozs7Z0JBQy9ELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLEtBQUssT0FBTyxPQUFPO01BQ2xCOzs7O2NBQ0Q7Ozs7O01BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFxQyxFQUFFO01BQVU7Ozs7Z0JBQy9ELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLEtBQUssT0FBTyxPQUFPO01BQ2xCOzs7O2NBQ0Q7Ozs7O01BQ0osS0FBSyxPQUFPLE9BQU8sZ0JBQ2xCLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxFQUFFO01BQ0Q7Ozs7Z0JBQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsS0FBSyxPQUFPLE9BQU87TUFDbEI7Ozs7Y0FDRDs7Ozs7TUFFTixLQUFLLE9BQU8sT0FBTyxnQkFDbEIsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLEVBQUU7TUFDRDs7OztnQkFDSix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxLQUFLLE9BQU8sT0FBTztNQUNsQjs7OztjQUNEOzs7OztLQUVMOzs7OztZQUNEOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBaUMsRUFBRTtJQUFZOzs7O2NBQzdELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsS0FBSyxPQUFPO0lBQ1o7Ozs7WUFDQTs7Ozs7O0lBRUgsYUFBYSxLQUFLLE9BQU8scUJBQ3pCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZ0M7S0FBdUI7Ozs7O0tBQ3JFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxTQUFRO09BQXNCLFdBQVU7aUJBQWE7TUFFckQ7Ozs7Z0JBQ04sWUFDQyx3QkFBQyxVQUFEO09BQ0UsSUFBRztPQUNILFdBQVU7T0FDVixjQUFjLEtBQUssT0FBTyxzQkFBc0I7T0FDaEQsVUFBVSxLQUFLLGNBQWMsS0FBSyxVQUFVLFdBQVc7T0FDdkQsV0FBVyxVQUFVLEtBQUssS0FBSyxhQUFhLE1BQU0sT0FBTyxLQUFLO2lCQUxoRSxDQU9FLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFHO09BQWlDOzs7O2lCQUNqRCxLQUFLLFVBQVUsS0FBSyxhQUNuQix3QkFBQyxVQUFEO1FBQTBCLE9BQU8sU0FBUztrQkFBMUM7U0FDRyxTQUFTO1NBQVM7U0FBRyxTQUFTO1NBQU07UUFDL0I7VUFGSyxTQUFTOzs7O2NBRWQsQ0FDVCxDQUNLOzs7OztpQkFFUix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixLQUFLLE9BQU8sa0JBQWtCLFlBQVk7TUFDMUM7Ozs7Y0FFRjs7OztnQkFDSixLQUFLLE9BQU8sb0JBQ1gsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsS0FBSyxPQUFPLGlCQUFpQjtNQUM3Qjs7OztjQUVGOzs7Ozs7S0FDSixhQUFhLEtBQUssVUFBVSxXQUFXLEtBQ3RDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE0QjtLQUV0Qzs7Ozs7S0FFSixLQUFLLGVBQ0osd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBUSxXQUFVO2dCQUN2QixLQUFLO0tBQ0w7Ozs7O0lBRUY7Ozs7OztHQUdOLGFBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxLQUFLLFVBQVUsU0FBUztLQUN2QyxVQUFVLEtBQUs7S0FDZixXQUFVO2VBRVQsRUFBRTtJQUNHOzs7O2NBQ1Isd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLEtBQUssVUFBVSxRQUFRO0tBQ3RDLFVBQVUsS0FBSztLQUNmLFdBQVU7ZUFFVCxFQUFFO0lBQ0c7Ozs7WUFDTDs7Ozs7O0VBRUE7Ozs7O1dBRVQsd0JBQUMsY0FBRCxFQUFvQixLQUFPOzs7O1NBQzNCOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IHVzZUFkbWluUmVwYWlyRGV0YWlscyB9IGZyb20gJy4vaG9va3MvdXNlQWRtaW5SZXBhaXJEZXRhaWxzJztcclxuaW1wb3J0IHsgQWN0aW9uRGlhbG9nIH0gZnJvbSAnLi9jb21wb25lbnRzL0FjdGlvbkRpYWxvZyc7XHJcbmltcG9ydCB7IFJlcGFpclN0YXR1c0JhZGdlIH0gZnJvbSAnLi4vY29tcG9uZW50cy9SZXBhaXJTdGF0dXNCYWRnZSc7XHJcblxyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmFkbWluUmVwYWlycztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFkbWluUmVwYWlyRGV0YWlsc1BhZ2UoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZUFkbWluUmVwYWlyRGV0YWlscygpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgcHJldmlvdXMgPSBkb2N1bWVudC50aXRsZTtcclxuICAgIGRvY3VtZW50LnRpdGxlID0gYCR7dC5kZXRhaWxzVGl0bGV9IHwgJHt0cmFuc2xhdGlvbnMuY29tbW9uLnN0b3JlTmFtZX1gO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICBpZiAocGFnZS5sb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICA8TG9hZGluZ1N0YXRlIC8+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAocGFnZS5lcnJvcikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1kYW5nZXIvMjUgYmctZGFuZ2VyLWJnIHAtOCB0ZXh0LWNlbnRlciBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZGFuZ2VyXCI+e3Qubm90Rm91bmR9PC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+e3BhZ2UuZXJyb3J9PC9wPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwYWdlLnJlZnJlc2goKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCBhdXRoLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLnJldHJ5fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoIXBhZ2UucmVwYWlyKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIGNvbnN0IGlzUGVuZGluZyA9IHBhZ2UucmVwYWlyLnN0YXR1cyA9PT0gJ1BFTkRJTkcnO1xyXG4gIGNvbnN0IGNhbkFzc2lnbiA9XHJcbiAgICBwYWdlLnJlcGFpci5zdGF0dXMgPT09ICdBUFBST1ZFRCcgfHwgcGFnZS5yZXBhaXIuc3RhdHVzID09PSAnQVNTSUdORUQnO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtwYWdlLmdvQmFja31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICDihpAge3QuYmFja31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIHRleHQtZmdcIj57dC5kZXRhaWxzVGl0bGV9PC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0YWJ1bGFyLW51bXMgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLnJlZmVyZW5jZX1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVmcmVzaCgpfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5wcm9jZXNzaW5nfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LnJlZnJlc2h9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IGxnOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC02IFwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dC5jdXN0b21lcn08L2gyPlxyXG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPlVzZXJuYW1lPC9kdD5cclxuICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuY3VzdG9tZXIudXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+RW1haWw8L2R0PlxyXG4gICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5jdXN0b21lci5lbWFpbH1cclxuICAgICAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC02IFwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dC5zdGF0dXN9PC9oMj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIEN1cnJlbnQgc3RhdHVzXHJcbiAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPFJlcGFpclN0YXR1c0JhZGdlIHN0YXR1cz17cGFnZS5yZXBhaXIuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dC5zdWJtaXR0ZWREYXRlfVxyXG4gICAgICAgICAgICAgICAgPC9kdD5cclxuICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShwYWdlLnJlcGFpci5jcmVhdGVkQXQpfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIucmV2aWV3ZWRBdCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3QucmV2aWV3ZWREYXRlfVxyXG4gICAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShwYWdlLnJlcGFpci5yZXZpZXdlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTYgXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dC5kZXZpY2VJbmZvfTwvaDI+XHJcbiAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC00IHNtOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAge3QuZGV2aWNlVHlwZX1cclxuICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5kZXZpY2VUeXBlfVxyXG4gICAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbXV0ZWRcIj57dC5icmFuZH08L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5icmFuZH1cclxuICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+e3QubW9kZWx9PC9kdD5cclxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5kZXZpY2UubW9kZWx9XHJcbiAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtwYWdlLnJlcGFpci5kZXZpY2Uuc2VyaWFsTnVtYmVyICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dC5zZXJpYWxOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5kZXZpY2Uuc2VyaWFsTnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5wdXJjaGFzZURhdGUgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt0LnB1cmNoYXNlRGF0ZX1cclxuICAgICAgICAgICAgICAgIDwvZHQ+XHJcbiAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5wdXJjaGFzZURhdGV9XHJcbiAgICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kbD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt0LnByb2JsZW19PC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgd2hpdGVzcGFjZS1wcmUtd3JhcCB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgIHtwYWdlLnJlcGFpci5wcm9ibGVtRGVzY3JpcHRpb259XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsoY2FuQXNzaWduIHx8IHBhZ2UucmVwYWlyLmFzc2lnbmVkUmVwYWlyZXIpICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTZcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+UmVwYWlyZXIgYXNzaWdubWVudDwvaDI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC0zIHNtOmdyaWQtY29scy1bbWlubWF4KDAsMWZyKV9hdXRvXSBzbTppdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJyZXBhaXJlci1hc3NpZ25tZW50XCIgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICBBc3NpZ25lZCByZXBhaXJlclxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIHtjYW5Bc3NpZ24gPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInJlcGFpcmVyLWFzc2lnbm1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e3BhZ2UucmVwYWlyLmFzc2lnbmVkUmVwYWlyZXJJZCA/PyAnJ31cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5wcm9jZXNzaW5nIHx8IHBhZ2UucmVwYWlyZXJzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB2b2lkIHBhZ2UuYXNzaWduUmVwYWlyKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGFuIGFjdGl2ZSByZXBhaXJlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpcmVycy5tYXAoKHJlcGFpcmVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cmVwYWlyZXIuaWR9IHZhbHVlPXtyZXBhaXJlci5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZXBhaXJlci51c2VybmFtZX0gKHtyZXBhaXJlci5lbWFpbH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuYXNzaWduZWRSZXBhaXJlcj8udXNlcm5hbWUgPz8gJ05vdCBhc3NpZ25lZCd9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmFzc2lnbmVkUmVwYWlyZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5hc3NpZ25lZFJlcGFpcmVyLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7Y2FuQXNzaWduICYmIHBhZ2UucmVwYWlyZXJzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIHRleHQtd2FybmluZ1wiPlxyXG4gICAgICAgICAgICAgICAgTm8gYWN0aXZlIHJlcGFpcmVyIGFjY291bnRzIGFyZSBhdmFpbGFibGUuXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7cGFnZS5hY3Rpb25FcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5hY3Rpb25FcnJvcn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7aXNQZW5kaW5nICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBzbTpmbGV4LXJvd1wiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRBY3Rpb24oJ2FwcHJvdmUnKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5wcm9jZXNzaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtcHJpbWFyeSBiZy1zdWNjZXNzIGhvdmVyOmJnLXN1Y2Nlc3MgZmxleC0xXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHt0LmFwcHJvdmV9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRBY3Rpb24oJ3JlamVjdCcpfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnByb2Nlc3Npbmd9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IGJnLWRhbmdlciBob3ZlcjpiZy1kYW5nZXIgZmxleC0xXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHt0LnJlamVjdH1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8QWN0aW9uRGlhbG9nIHBhZ2U9e3BhZ2V9IC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdfQ==