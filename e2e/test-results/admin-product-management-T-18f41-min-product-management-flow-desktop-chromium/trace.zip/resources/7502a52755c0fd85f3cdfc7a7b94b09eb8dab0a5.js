import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Products/components/CatalogFilters.tsx");const useId = __vite__cjsImport1_react["useId"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { formatCategoryName } from "/src/utils/category.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { translations } from "/src/utils/translations.ts";
import { CategoryIcon } from "/src/pages/Products/components/CategoryIcon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogFilters.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.catalog;
function CategoryList({ categories, parentId, selected, update, depth = 0 }) {
	if (depth > 10) return null;
	return /* @__PURE__ */ _jsxDEV("ul", {
		className: depth ? "ml-4 border-l border-line-subtle pl-2" : "",
		children: categories.filter((category) => category.parentId === parentId).map((category) => /* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-pressed": selected === category.categoryID,
			onClick: () => update({ category: category.categoryID }),
			className: `my-0.5 flex min-h-10 w-full items-center gap-2 rounded-sm px-2 text-left text-sm ${selected === category.categoryID ? "bg-primary-subtle font-semibold text-fg-link" : "text-fg-secondary hover:bg-page"}`,
			children: [
				/* @__PURE__ */ _jsxDEV(CategoryIcon, { name: formatCategoryName(category.name) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "min-w-0 flex-1 break-words",
					children: formatCategoryName(category.name)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs tabular-nums",
					children: category.count.toLocaleString()
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 15
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV(CategoryList, {
			categories,
			parentId: category.categoryID,
			selected,
			update,
			depth: depth + 1
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 13
		}, this)] }, category.categoryID, true, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 11
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_c = CategoryList;
export function CatalogFilters({ facets, query, update, clear }) {
	_s();
	const id = useId();
	const [brandSearch, setBrandSearch] = useState("");
	const [showAll, setShowAll] = useState(false);
	const [min, setMin] = useState(query.minPrice?.toString() ?? "");
	const [max, setMax] = useState(query.maxPrice?.toString() ?? "");
	const selected = query.brands?.split(",") ?? [];
	const brands = facets.brands.filter((brand) => brand.name.toLowerCase().includes(brandSearch.toLowerCase()));
	function toggle(name) {
		const chosen = selected.some((value) => value.toLowerCase() === name.toLowerCase());
		const next = chosen ? selected.filter((value) => value.toLowerCase() !== name.toLowerCase()) : [...selected, name];
		update({ brands: next.join(",") || undefined });
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-7 rounded-md border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mb-3 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "font-semibold text-fg",
						children: t.categories
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: clear,
						className: "text-xs font-medium text-fg-link hover:underline",
						children: t.clear
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					"aria-pressed": !query.categoryId,
					onClick: () => update({ category: undefined }),
					className: `flex min-h-10 w-full items-center gap-2 rounded-sm px-2 text-left text-sm ${!query.categoryId ? "bg-primary-subtle font-semibold text-fg-link" : "text-fg-secondary hover:bg-page"}`,
					children: [
						/* @__PURE__ */ _jsxDEV(CategoryIcon, { name: "all" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "flex-1",
							children: t.all
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs",
							children: facets.allCount.toLocaleString()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(CategoryList, {
					categories: facets.categories,
					parentId: null,
					selected: query.categoryId,
					update
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 9
				}, this),
				!facets.categories.length && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs leading-5 text-fg-muted",
					children: t.noCategories
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", { children: [
				/* @__PURE__ */ _jsxDEV("legend", {
					className: "mb-3 font-semibold text-fg",
					children: t.brands
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 118,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "sr-only",
					htmlFor: id + "-brand-search",
					children: t.searchBrands
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: id + "-brand-search",
					value: brandSearch,
					onChange: (event) => setBrandSearch(event.target.value),
					placeholder: t.searchBrands,
					className: "ui-field mb-3 min-h-11 w-full rounded-sm border border-line bg-page px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-1",
					children: brands.slice(0, showAll ? undefined : 8).map((brand) => /* @__PURE__ */ _jsxDEV("label", {
						className: "flex min-h-9 cursor-pointer items-center gap-3 rounded-sm px-1 text-sm text-fg-secondary hover:bg-page",
						children: [
							/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								className: "h-4 w-4 accent-primary",
								checked: selected.some((value) => value.toLowerCase() === brand.name.toLowerCase()),
								onChange: () => toggle(brand.name)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "min-w-0 flex-1 break-words",
								children: brand.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs tabular-nums",
								children: brand.count.toLocaleString()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 15
							}, this)
						]
					}, brand.name, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 9
				}, this),
				!brands.length && /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-fg-muted",
					children: t.noBrands
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 11
				}, this),
				brands.length > 8 && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setShowAll((value) => !value),
					className: "mt-3 text-xs font-medium text-fg-link",
					children: showAll ? t.showLess : t.showMore
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (event) => {
					event.preventDefault();
					update({
						minPrice: min || undefined,
						maxPrice: max || undefined
					});
				},
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "mb-4 font-semibold text-fg",
						children: t.price
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "sr-only",
						htmlFor: id + "-max-price-slider",
						children: t.maxPriceSlider
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: id + "-max-price-slider",
						type: "range",
						min: 0,
						max: Math.max(Number(facets.price.max), Number(max) || 0, 1),
						step: "0.01",
						value: max || facets.price.max,
						onChange: (event) => setMax(event.target.value),
						className: "mb-4 w-full accent-primary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-2",
						children: [{
							label: t.minPrice,
							value: min,
							set: setMin
						}, {
							label: t.maxPrice,
							value: max,
							set: setMax
						}].map((field, index) => /* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs text-fg-muted",
							children: [field.label, /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								min: index === 1 && min ? Number(min) : 0,
								max: 9999999999.99,
								step: "0.01",
								value: field.value,
								onChange: (event) => field.set(event.target.value),
								className: "ui-field mt-2 min-h-11 w-full rounded-sm border border-line px-2 text-sm text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 15
							}, this)]
						}, field.label, true, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "ui-button ui-button-primary mt-3 min-h-11 w-full rounded-sm bg-primary text-sm font-semibold text-primary-on hover:bg-primary-hover",
						children: t.apply
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 163,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 5
	}, this);
}
_s(CatalogFilters, "urpqC6leD+f5clB1i8ARSFGNY0U=");
_c2 = CatalogFilters;
var _c, _c2;
$RefreshReg$(_c, "CategoryList");
$RefreshReg$(_c2, "CatalogFilters");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Products/components/CatalogFilters.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogFilters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogFilters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogFilters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxPQUFPLGdCQUFnQjtBQU1oQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjs7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQU92QixTQUFTLGFBQWEsRUFDcEIsWUFDQSxVQUNBLFVBQ0EsUUFDQSxRQUFRLEtBT1A7Q0FDRCxJQUFJLFFBQVEsSUFBSSxPQUFPO0NBQ3ZCLE9BQ0Usd0JBQUMsTUFBRDtFQUFJLFdBQVcsUUFBUSwwQ0FBMEM7WUFDOUQsV0FDRSxRQUFRLGFBQWEsU0FBUyxhQUFhLFFBQVEsQ0FBQyxDQUNwRCxLQUFLLGFBQ0osd0JBQUMsTUFBRCxhQUNFLHdCQUFDLFVBQUQ7R0FDRSxNQUFLO0dBQ0wsZ0JBQWMsYUFBYSxTQUFTO0dBQ3BDLGVBQWUsT0FBTyxFQUFFLFVBQVUsU0FBUyxXQUFXLENBQUM7R0FDdkQsV0FBVyxvRkFBb0YsYUFBYSxTQUFTLGFBQWEsaURBQWlEO2FBSnJMO0lBTUUsd0JBQUMsY0FBRCxFQUFjLE1BQU0sbUJBQW1CLFNBQVMsSUFBSSxFQUFJOzs7OztJQUN4RCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNiLG1CQUFtQixTQUFTLElBQUk7SUFDN0I7Ozs7O0lBQ04sd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDYixTQUFTLE1BQU0sZUFBZTtJQUMzQjs7Ozs7R0FDQTs7Ozs7WUFDUix3QkFBQyxjQUFEO0dBQ2M7R0FDWixVQUFVLFNBQVM7R0FDVDtHQUNGO0dBQ1IsT0FBTyxRQUFRO0VBQ2hCOzs7O1VBQ0MsS0F0QkssU0FBUzs7OztTQXNCZCxDQUNMO0NBQ0Q7Ozs7O0FBRVI7O0FBQ0EsT0FBTyxTQUFTLGVBQWUsRUFBRSxRQUFRLE9BQU8sUUFBUSxTQUFnQjs7Q0FDdEUsTUFBTSxLQUFLLE1BQU07Q0FDakIsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsTUFBTSxVQUFVLFNBQVMsS0FBSyxFQUFFO0NBQy9ELE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxNQUFNLFVBQVUsU0FBUyxLQUFLLEVBQUU7Q0FDL0QsTUFBTSxXQUFXLE1BQU0sUUFBUSxNQUFNLEdBQUcsS0FBSyxDQUFDO0NBQzlDLE1BQU0sU0FBUyxPQUFPLE9BQU8sUUFBUSxVQUNuQyxNQUFNLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxDQUM3RDtDQUNBLFNBQVMsT0FBTyxNQUFjO0VBQzVCLE1BQU0sU0FBUyxTQUFTLE1BQ3JCLFVBQVUsTUFBTSxZQUFZLE1BQU0sS0FBSyxZQUFZLENBQ3REO0VBQ0EsTUFBTSxPQUFPLFNBQ1QsU0FBUyxRQUFRLFVBQVUsTUFBTSxZQUFZLE1BQU0sS0FBSyxZQUFZLENBQUMsSUFDckUsQ0FBQyxHQUFHLFVBQVUsSUFBSTtFQUN0QixPQUFPLEVBQUUsUUFBUSxLQUFLLEtBQUssR0FBRyxLQUFLLFVBQVUsQ0FBQztDQUNoRDtDQUNBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCLEVBQUU7S0FBZTs7OztlQUN4RCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO2dCQUVULEVBQUU7S0FDRzs7OzthQUNMOzs7Ozs7SUFDTCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGdCQUFjLENBQUMsTUFBTTtLQUNyQixlQUFlLE9BQU8sRUFBRSxVQUFVLFVBQVUsQ0FBQztLQUM3QyxXQUFXLDZFQUE2RSxDQUFDLE1BQU0sYUFBYSxpREFBaUQ7ZUFKL0o7TUFNRSx3QkFBQyxjQUFELEVBQWMsTUFBSyxNQUFPOzs7OztNQUMxQix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVSxFQUFFO01BQVU7Ozs7O01BQ3RDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXLE9BQU8sU0FBUyxlQUFlO01BQVE7Ozs7O0tBQzVEOzs7Ozs7SUFDUix3QkFBQyxjQUFEO0tBQ0UsWUFBWSxPQUFPO0tBQ25CLFVBQVU7S0FDVixVQUFVLE1BQU07S0FDUjtJQUNUOzs7OztJQUNBLENBQUMsT0FBTyxXQUFXLFVBQ2xCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsRUFBRTtJQUNGOzs7OztHQUVGOzs7OztHQUNMLHdCQUFDLFlBQUQ7SUFDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUE4QixFQUFFO0lBQWU7Ozs7O0lBQ2pFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO0tBQVUsU0FBUyxLQUFLO2VBQ3RDLEVBQUU7SUFDRTs7Ozs7SUFDUCx3QkFBQyxTQUFEO0tBQ0UsSUFBSSxLQUFLO0tBQ1QsT0FBTztLQUNQLFdBQVcsVUFBVSxlQUFlLE1BQU0sT0FBTyxLQUFLO0tBQ3RELGFBQWEsRUFBRTtLQUNmLFdBQVU7SUFDWDs7Ozs7SUFDRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLE9BQU8sTUFBTSxHQUFHLFVBQVUsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQzdDLHdCQUFDLFNBQUQ7TUFFRSxXQUFVO2dCQUZaO09BSUUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO1FBQ1YsU0FBUyxTQUFTLE1BQ2YsVUFBVSxNQUFNLFlBQVksTUFBTSxNQUFNLEtBQUssWUFBWSxDQUM1RDtRQUNBLGdCQUFnQixPQUFPLE1BQU0sSUFBSTtPQUNsQzs7Ozs7T0FDRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBOEIsTUFBTTtPQUFXOzs7OztPQUMvRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixNQUFNLE1BQU0sZUFBZTtPQUN4Qjs7Ozs7TUFDRDtRQWZBLE1BQU07Ozs7WUFlTixDQUNSO0lBQ0U7Ozs7O0lBQ0osQ0FBQyxPQUFPLFVBQ1Asd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBeUIsRUFBRTtJQUFZOzs7OztJQUVyRCxPQUFPLFNBQVMsS0FDZix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsWUFBWSxVQUFVLENBQUMsS0FBSztLQUMzQyxXQUFVO2VBRVQsVUFBVSxFQUFFLFdBQVcsRUFBRTtJQUNwQjs7Ozs7R0FFRjs7Ozs7R0FDVix3QkFBQyxRQUFEO0lBQ0UsV0FBVyxVQUFVO0tBQ25CLE1BQU0sZUFBZTtLQUNyQixPQUFPO01BQUUsVUFBVSxPQUFPO01BQVcsVUFBVSxPQUFPO0tBQVUsQ0FBQztJQUNuRTtjQUpGO0tBTUUsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQThCLEVBQUU7S0FBVTs7Ozs7S0FDeEQsd0JBQUMsU0FBRDtNQUFPLFdBQVU7TUFBVSxTQUFTLEtBQUs7Z0JBQ3RDLEVBQUU7S0FDRTs7Ozs7S0FDUCx3QkFBQyxTQUFEO01BQ0UsSUFBSSxLQUFLO01BQ1QsTUFBSztNQUNMLEtBQUs7TUFDTCxLQUFLLEtBQUssSUFBSSxPQUFPLE9BQU8sTUFBTSxHQUFHLEdBQUcsT0FBTyxHQUFHLEtBQUssR0FBRyxDQUFDO01BQzNELE1BQUs7TUFDTCxPQUFPLE9BQU8sT0FBTyxNQUFNO01BQzNCLFdBQVcsVUFBVSxPQUFPLE1BQU0sT0FBTyxLQUFLO01BQzlDLFdBQVU7S0FDWDs7Ozs7S0FDRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixDQUNDO09BQUUsT0FBTyxFQUFFO09BQVUsT0FBTztPQUFLLEtBQUs7TUFBTyxHQUM3QztPQUFFLE9BQU8sRUFBRTtPQUFVLE9BQU87T0FBSyxLQUFLO01BQU8sQ0FDL0MsQ0FBQyxDQUFDLEtBQUssT0FBTyxVQUNaLHdCQUFDLFNBQUQ7T0FBeUIsV0FBVTtpQkFBbkMsQ0FDRyxNQUFNLE9BQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxLQUFLLFVBQVUsS0FBSyxNQUFNLE9BQU8sR0FBRyxJQUFJO1FBQ3hDLEtBQUs7UUFDTCxNQUFLO1FBQ0wsT0FBTyxNQUFNO1FBQ2IsV0FBVyxVQUFVLE1BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSztRQUNqRCxXQUFVO09BQ1g7Ozs7ZUFDSTtTQVhLLE1BQU07Ozs7YUFXWCxDQUNSO0tBQ0U7Ozs7O0tBQ0wsd0JBQUMsVUFBRDtNQUFRLFdBQVU7Z0JBQ2YsRUFBRTtLQUNHOzs7OztJQUNKOzs7Ozs7RUFDSDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2F0YWxvZ0ZpbHRlcnMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGZvcm1hdENhdGVnb3J5TmFtZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2NhdGVnb3J5JztcclxuaW1wb3J0IHsgdXNlSWQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgQ2F0YWxvZ1F1ZXJ5LFxyXG4gIENhdGFsb2dSZXN1bHQsXHJcbiAgQ2F0ZWdvcnlGYWNldCxcclxufSBmcm9tICcuLi8uLi8uLi90eXBlcy9jYXRhbG9nLnR5cGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgQ2F0ZWdvcnlJY29uIH0gZnJvbSAnLi9DYXRlZ29yeUljb24nO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmNhdGFsb2c7XHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgZmFjZXRzOiBDYXRhbG9nUmVzdWx0WydmYWNldHMnXTtcclxuICBxdWVyeTogQ2F0YWxvZ1F1ZXJ5O1xyXG4gIHVwZGF0ZTogKGNoYW5nZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IHVuZGVmaW5lZD4pID0+IHZvaWQ7XHJcbiAgY2xlYXI6ICgpID0+IHZvaWQ7XHJcbn1cclxuZnVuY3Rpb24gQ2F0ZWdvcnlMaXN0KHtcclxuICBjYXRlZ29yaWVzLFxyXG4gIHBhcmVudElkLFxyXG4gIHNlbGVjdGVkLFxyXG4gIHVwZGF0ZSxcclxuICBkZXB0aCA9IDAsXHJcbn06IHtcclxuICBjYXRlZ29yaWVzOiBDYXRlZ29yeUZhY2V0W107XHJcbiAgcGFyZW50SWQ6IHN0cmluZyB8IG51bGw7XHJcbiAgc2VsZWN0ZWQ/OiBzdHJpbmc7XHJcbiAgdXBkYXRlOiBQcm9wc1sndXBkYXRlJ107XHJcbiAgZGVwdGg/OiBudW1iZXI7XHJcbn0pIHtcclxuICBpZiAoZGVwdGggPiAxMCkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIChcclxuICAgIDx1bCBjbGFzc05hbWU9e2RlcHRoID8gJ21sLTQgYm9yZGVyLWwgYm9yZGVyLWxpbmUtc3VidGxlIHBsLTInIDogJyd9PlxyXG4gICAgICB7Y2F0ZWdvcmllc1xyXG4gICAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiBjYXRlZ29yeS5wYXJlbnRJZCA9PT0gcGFyZW50SWQpXHJcbiAgICAgICAgLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgICAgICAgIDxsaSBrZXk9e2NhdGVnb3J5LmNhdGVnb3J5SUR9PlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtzZWxlY3RlZCA9PT0gY2F0ZWdvcnkuY2F0ZWdvcnlJRH1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGUoeyBjYXRlZ29yeTogY2F0ZWdvcnkuY2F0ZWdvcnlJRCB9KX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BteS0wLjUgZmxleCBtaW4taC0xMCB3LWZ1bGwgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtc20gcHgtMiB0ZXh0LWxlZnQgdGV4dC1zbSAke3NlbGVjdGVkID09PSBjYXRlZ29yeS5jYXRlZ29yeUlEID8gJ2JnLXByaW1hcnktc3VidGxlIGZvbnQtc2VtaWJvbGQgdGV4dC1mZy1saW5rJyA6ICd0ZXh0LWZnLXNlY29uZGFyeSBob3ZlcjpiZy1wYWdlJ31gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPENhdGVnb3J5SWNvbiBuYW1lPXtmb3JtYXRDYXRlZ29yeU5hbWUoY2F0ZWdvcnkubmFtZSl9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTEgYnJlYWstd29yZHNcIj5cclxuICAgICAgICAgICAgICAgIHtmb3JtYXRDYXRlZ29yeU5hbWUoY2F0ZWdvcnkubmFtZSl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuY291bnQudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnlMaXN0XHJcbiAgICAgICAgICAgICAgY2F0ZWdvcmllcz17Y2F0ZWdvcmllc31cclxuICAgICAgICAgICAgICBwYXJlbnRJZD17Y2F0ZWdvcnkuY2F0ZWdvcnlJRH1cclxuICAgICAgICAgICAgICBzZWxlY3RlZD17c2VsZWN0ZWR9XHJcbiAgICAgICAgICAgICAgdXBkYXRlPXt1cGRhdGV9XHJcbiAgICAgICAgICAgICAgZGVwdGg9e2RlcHRoICsgMX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgKSl9XHJcbiAgICA8L3VsPlxyXG4gICk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIENhdGFsb2dGaWx0ZXJzKHsgZmFjZXRzLCBxdWVyeSwgdXBkYXRlLCBjbGVhciB9OiBQcm9wcykge1xyXG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcclxuICBjb25zdCBbYnJhbmRTZWFyY2gsIHNldEJyYW5kU2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbc2hvd0FsbCwgc2V0U2hvd0FsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21pbiwgc2V0TWluXSA9IHVzZVN0YXRlKHF1ZXJ5Lm1pblByaWNlPy50b1N0cmluZygpID8/ICcnKTtcclxuICBjb25zdCBbbWF4LCBzZXRNYXhdID0gdXNlU3RhdGUocXVlcnkubWF4UHJpY2U/LnRvU3RyaW5nKCkgPz8gJycpO1xyXG4gIGNvbnN0IHNlbGVjdGVkID0gcXVlcnkuYnJhbmRzPy5zcGxpdCgnLCcpID8/IFtdO1xyXG4gIGNvbnN0IGJyYW5kcyA9IGZhY2V0cy5icmFuZHMuZmlsdGVyKChicmFuZCkgPT5cclxuICAgIGJyYW5kLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhicmFuZFNlYXJjaC50b0xvd2VyQ2FzZSgpKSxcclxuICApO1xyXG4gIGZ1bmN0aW9uIHRvZ2dsZShuYW1lOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGNob3NlbiA9IHNlbGVjdGVkLnNvbWUoXHJcbiAgICAgICh2YWx1ZSkgPT4gdmFsdWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpLFxyXG4gICAgKTtcclxuICAgIGNvbnN0IG5leHQgPSBjaG9zZW5cclxuICAgICAgPyBzZWxlY3RlZC5maWx0ZXIoKHZhbHVlKSA9PiB2YWx1ZS50b0xvd2VyQ2FzZSgpICE9PSBuYW1lLnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgIDogWy4uLnNlbGVjdGVkLCBuYW1lXTtcclxuICAgIHVwZGF0ZSh7IGJyYW5kczogbmV4dC5qb2luKCcsJykgfHwgdW5kZWZpbmVkIH0pO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTcgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTRcIj5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3QuY2F0ZWdvcmllc308L2gyPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17Y2xlYXJ9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LmNsZWFyfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBhcmlhLXByZXNzZWQ9eyFxdWVyeS5jYXRlZ29yeUlkfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlKHsgY2F0ZWdvcnk6IHVuZGVmaW5lZCB9KX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggbWluLWgtMTAgdy1mdWxsIGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXNtIHB4LTIgdGV4dC1sZWZ0IHRleHQtc20gJHshcXVlcnkuY2F0ZWdvcnlJZCA/ICdiZy1wcmltYXJ5LXN1YnRsZSBmb250LXNlbWlib2xkIHRleHQtZmctbGluaycgOiAndGV4dC1mZy1zZWNvbmRhcnkgaG92ZXI6YmctcGFnZSd9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8Q2F0ZWdvcnlJY29uIG5hbWU9XCJhbGxcIiAvPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC0xXCI+e3QuYWxsfTwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHNcIj57ZmFjZXRzLmFsbENvdW50LnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxDYXRlZ29yeUxpc3RcclxuICAgICAgICAgIGNhdGVnb3JpZXM9e2ZhY2V0cy5jYXRlZ29yaWVzfVxyXG4gICAgICAgICAgcGFyZW50SWQ9e251bGx9XHJcbiAgICAgICAgICBzZWxlY3RlZD17cXVlcnkuY2F0ZWdvcnlJZH1cclxuICAgICAgICAgIHVwZGF0ZT17dXBkYXRlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgeyFmYWNldHMuY2F0ZWdvcmllcy5sZW5ndGggJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHt0Lm5vQ2F0ZWdvcmllc31cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGZpZWxkc2V0PlxyXG4gICAgICAgIDxsZWdlbmQgY2xhc3NOYW1lPVwibWItMyBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dC5icmFuZHN9PC9sZWdlbmQ+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNyLW9ubHlcIiBodG1sRm9yPXtpZCArICctYnJhbmQtc2VhcmNoJ30+XHJcbiAgICAgICAgICB7dC5zZWFyY2hCcmFuZHN9XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPXtpZCArICctYnJhbmQtc2VhcmNoJ31cclxuICAgICAgICAgIHZhbHVlPXticmFuZFNlYXJjaH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEJyYW5kU2VhcmNoKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17dC5zZWFyY2hCcmFuZHN9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBtYi0zIG1pbi1oLTExIHctZnVsbCByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBiZy1wYWdlIHB4LTMgdGV4dC1zbSBmb2N1czpib3JkZXItcHJpbWFyeSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeS8yMFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAge2JyYW5kcy5zbGljZSgwLCBzaG93QWxsID8gdW5kZWZpbmVkIDogOCkubWFwKChicmFuZCkgPT4gKFxyXG4gICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICBrZXk9e2JyYW5kLm5hbWV9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4taC05IGN1cnNvci1wb2ludGVyIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLXNtIHB4LTEgdGV4dC1zbSB0ZXh0LWZnLXNlY29uZGFyeSBob3ZlcjpiZy1wYWdlXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNCB3LTQgYWNjZW50LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWQuc29tZShcclxuICAgICAgICAgICAgICAgICAgKHZhbHVlKSA9PiB2YWx1ZS50b0xvd2VyQ2FzZSgpID09PSBicmFuZC5uYW1lLnRvTG93ZXJDYXNlKCksXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZShicmFuZC5uYW1lKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIGJyZWFrLXdvcmRzXCI+e2JyYW5kLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgICAgICB7YnJhbmQuY291bnQudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7IWJyYW5kcy5sZW5ndGggJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+e3Qubm9CcmFuZHN9PC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2JyYW5kcy5sZW5ndGggPiA4ICYmIChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBbGwoKHZhbHVlKSA9PiAhdmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3Nob3dBbGwgPyB0LnNob3dMZXNzIDogdC5zaG93TW9yZX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZmllbGRzZXQ+XHJcbiAgICAgIDxmb3JtXHJcbiAgICAgICAgb25TdWJtaXQ9eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgIHVwZGF0ZSh7IG1pblByaWNlOiBtaW4gfHwgdW5kZWZpbmVkLCBtYXhQcmljZTogbWF4IHx8IHVuZGVmaW5lZCB9KTtcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3QucHJpY2V9PC9oMj5cclxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic3Itb25seVwiIGh0bWxGb3I9e2lkICsgJy1tYXgtcHJpY2Utc2xpZGVyJ30+XHJcbiAgICAgICAgICB7dC5tYXhQcmljZVNsaWRlcn1cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgaWQ9e2lkICsgJy1tYXgtcHJpY2Utc2xpZGVyJ31cclxuICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXHJcbiAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICBtYXg9e01hdGgubWF4KE51bWJlcihmYWNldHMucHJpY2UubWF4KSwgTnVtYmVyKG1heCkgfHwgMCwgMSl9XHJcbiAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICB2YWx1ZT17bWF4IHx8IGZhY2V0cy5wcmljZS5tYXh9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRNYXgoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTQgdy1mdWxsIGFjY2VudC1wcmltYXJ5XCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxyXG4gICAgICAgICAge1tcclxuICAgICAgICAgICAgeyBsYWJlbDogdC5taW5QcmljZSwgdmFsdWU6IG1pbiwgc2V0OiBzZXRNaW4gfSxcclxuICAgICAgICAgICAgeyBsYWJlbDogdC5tYXhQcmljZSwgdmFsdWU6IG1heCwgc2V0OiBzZXRNYXggfSxcclxuICAgICAgICAgIF0ubWFwKChmaWVsZCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPGxhYmVsIGtleT17ZmllbGQubGFiZWx9IGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgIHtmaWVsZC5sYWJlbH1cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgbWluPXtpbmRleCA9PT0gMSAmJiBtaW4gPyBOdW1iZXIobWluKSA6IDB9XHJcbiAgICAgICAgICAgICAgICBtYXg9ezk5OTk5OTk5OTkuOTl9XHJcbiAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZmllbGQudmFsdWV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBmaWVsZC5zZXQoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIG10LTIgbWluLWgtMTEgdy1mdWxsIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIHB4LTIgdGV4dC1zbSB0ZXh0LWZnIGZvY3VzOmJvcmRlci1wcmltYXJ5IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgbXQtMyBtaW4taC0xMSB3LWZ1bGwgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXByaW1hcnktb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlclwiPlxyXG4gICAgICAgICAge3QuYXBwbHl9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19