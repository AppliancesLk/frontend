import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/components/SendHistory.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { getPromotionRun } from "/src/services/promotionService.ts";
import { promotionText as t } from "/src/utils/promotionText.ts";
import { formatDate } from "/src/utils/date.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { Button } from "/src/components/ui/Button.tsx";
import { EmailPreview } from "/src/pages/Admin/Promotions/components/EmailPreview.tsx";
import { PromotionBadge } from "/src/pages/Admin/Promotions/components/PromotionBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/SendHistory.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function SendHistory({ id, runs }) {
	_s();
	const [runId, setRunId] = useState(""), [page, setPage] = useState(1), [detail, setDetail] = useState(null), [error, setError] = useState(""), [loading, setLoading] = useState(false), [revision, setRevision] = useState(0);
	useEffect(() => {
		if (!runId) return;
		const controller = new AbortController();
		async function load() {
			setLoading(true);
			setError("");
			try {
				const next = await getPromotionRun(id, runId, page, controller.signal);
				if (!controller.signal.aborted) setDetail(next);
			} catch (err) {
				if (!controller.signal.aborted) setError(getApiError(err, "Unable to load the send report. Please try again."));
			} finally {
				if (!controller.signal.aborted) setLoading(false);
			}
		}
		void load();
		return () => controller.abort();
	}, [
		id,
		runId,
		page,
		runs,
		revision
	]);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "ui-panel p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-semibold",
				children: t.history
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-xs leading-5 text-fg-muted",
				children: t.historyHint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-xs leading-5 text-fg-muted",
				children: t.deliveryHint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 7
			}, this),
			!runs.length ? /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-5 text-sm text-fg-muted",
				children: "This promotion has not been sent yet."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("ul", {
				className: "mt-5 divide-y divide-line",
				children: runs.map((run) => /* @__PURE__ */ _jsxDEV("li", {
					className: "flex flex-wrap items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm font-medium",
						children: formatDate(run.createdAt)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-xs text-fg-muted",
						children: [
							run.counts.SENT,
							" sent ·",
							" ",
							run.counts.QUEUED + run.counts.PROCESSING,
							" pending ·",
							" ",
							run.counts.FAILED,
							" failed · ",
							run.counts.SKIPPED,
							" skipped ·",
							" ",
							run.counts.UNKNOWN,
							" unknown"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV(PromotionBadge, { status: run.status }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							variant: "secondary",
							onClick: () => {
								setRunId(runId === run.id ? "" : run.id);
								setPage(1);
								setDetail(null);
							},
							children: runId === run.id ? "Close report" : t.viewSent
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 15
					}, this)]
				}, run.id, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 9
			}, this),
			runId && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-5 space-y-4 border-t border-line pt-5",
				children: [
					loading && /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-fg-muted",
						children: "Updating report…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 23
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "text-sm text-danger",
						children: [
							error,
							" ",
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "underline",
								onClick: () => setRevision((n) => n + 1),
								children: "Retry"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this),
					detail && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-semibold",
							children: ["Sent version: ", detail.subject]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto rounded-md border border-line",
							children: /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full min-w-[420px] text-left text-xs",
								children: [/* @__PURE__ */ _jsxDEV("thead", {
									className: "bg-subtle",
									children: /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("th", {
										className: "p-3",
										children: "Recipient"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 116,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("th", {
										className: "p-3",
										children: "Result"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 117,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 115,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: detail.recipients.map((recipient) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-t border-line",
									children: [/* @__PURE__ */ _jsxDEV("td", {
										className: "p-3",
										children: [/* @__PURE__ */ _jsxDEV("p", { children: recipient.username }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 124,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "mt-1 text-fg-muted",
											children: recipient.email
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 125,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("td", {
										className: "p-3",
										children: /* @__PURE__ */ _jsxDEV(PromotionBadge, { status: recipient.status }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 130,
											columnNumber: 27
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 25
									}, this)]
								}, recipient.id, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 23
								}, this)) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "secondary",
								disabled: page <= 1 || loading,
								onClick: () => setPage(page - 1),
								children: "Previous recipients"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								variant: "secondary",
								disabled: page * detail.limit >= detail.total || loading,
								onClick: () => setPage(page + 1),
								children: "Next recipients"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(EmailPreview, {
							html: detail.preview.html,
							subject: detail.preview.subject
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
}
_s(SendHistory, "I6+frfSmxJ+siQGIC5Br3td0L68=");
_c = SendHistory;
var _c;
$RefreshReg$(_c, "SendHistory");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/components/SendHistory.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/SendHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/SendHistory.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/SendHistory.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUtwQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGlCQUFpQixTQUFTO0FBQ25DLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHNCQUFzQjs7OztBQUMvQixPQUFPLFNBQVMsWUFBWSxFQUMxQixJQUNBLFFBSUM7O0NBQ0QsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUUsR0FDbkMsQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDLEdBQzVCLENBQUMsUUFBUSxhQUFhLFNBQW9DLElBQUksR0FDOUQsQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFLEdBQy9CLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSyxHQUN0QyxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FDdEMsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE9BQU87RUFDWixNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFDdkMsZUFBZSxPQUFPO0dBQ3BCLFdBQVcsSUFBSTtHQUNmLFNBQVMsRUFBRTtHQUNYLElBQUk7SUFDRixNQUFNLE9BQU8sTUFBTSxnQkFBZ0IsSUFBSSxPQUFPLE1BQU0sV0FBVyxNQUFNO0lBQ3JFLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUyxVQUFVLElBQUk7R0FDaEQsU0FBUyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUNyQixTQUNFLFlBQ0UsS0FDQSxtREFDRixDQUNGO0dBQ0osVUFBVTtJQUNSLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7R0FDbEQ7RUFDRjtFQUNBLEtBQUssS0FBSztFQUNWLGFBQWEsV0FBVyxNQUFNO0NBQ2hDLEdBQUc7RUFBQztFQUFJO0VBQU87RUFBTTtFQUFNO0NBQVEsQ0FBQztDQUNwQyxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBeUIsRUFBRTtHQUFZOzs7OztHQUNyRCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF3QyxFQUFFO0dBQWU7Ozs7O0dBQ3RFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXdDLEVBQUU7R0FBZ0I7Ozs7O0dBQ3RFLENBQUMsS0FBSyxTQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTZCO0dBRXZDOzs7O2NBRUgsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FDWCxLQUFLLEtBQUssUUFDVCx3QkFBQyxNQUFEO0tBRUUsV0FBVTtlQUZaLENBSUUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLFdBQVcsSUFBSSxTQUFTO0tBQ3hCOzs7O2VBQ0gsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FDRyxJQUFJLE9BQU87T0FBSztPQUFRO09BQ3hCLElBQUksT0FBTyxTQUFTLElBQUksT0FBTztPQUFXO09BQVc7T0FDckQsSUFBSSxPQUFPO09BQU87T0FBVyxJQUFJLE9BQU87T0FBUTtPQUFXO09BQzNELElBQUksT0FBTztPQUFRO01BQ25COzs7OzthQUNBOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxnQkFBRCxFQUFnQixRQUFRLElBQUksT0FBUzs7OztnQkFDckMsd0JBQUMsUUFBRDtPQUNFLFNBQVE7T0FDUixlQUFlO1FBQ2IsU0FBUyxVQUFVLElBQUksS0FBSyxLQUFLLElBQUksRUFBRTtRQUN2QyxRQUFRLENBQUM7UUFDVCxVQUFVLElBQUk7T0FDaEI7aUJBRUMsVUFBVSxJQUFJLEtBQUssaUJBQWlCLEVBQUU7TUFDakM7Ozs7Y0FDTDs7Ozs7YUFDSDtPQTNCRyxJQUFJOzs7O1dBMkJQLENBQ0w7R0FDQzs7Ozs7R0FFTCxTQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRyxXQUFXLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF3QjtLQUFtQjs7Ozs7S0FDbkUsU0FDQyx3QkFBQyxLQUFEO01BQUcsTUFBSztNQUFRLFdBQVU7Z0JBQTFCO09BQ0c7T0FBTztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsV0FBVTtRQUNWLGVBQWUsYUFBYSxNQUFNLElBQUksQ0FBQztrQkFDeEM7T0FFTzs7Ozs7TUFDUDs7Ozs7O0tBRUosVUFDQztNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQThCLGtCQUFlLE9BQU8sT0FBWTs7Ozs7O01BQ2hFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUNmLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBTTtTQUFhOzs7O21CQUNqQyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBTTtTQUFVOzs7O2lCQUM1Qjs7Ozs7UUFDQzs7OztrQkFDUCx3QkFBQyxTQUFELFlBQ0csT0FBTyxXQUFXLEtBQUssY0FDdEIsd0JBQUMsTUFBRDtTQUF1QixXQUFVO21CQUFqQyxDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsS0FBRCxZQUFJLFVBQVUsU0FBWTs7OztvQkFDMUIsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsVUFBVTtVQUNWOzs7O2tCQUNEOzs7OzttQkFDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxnQkFBRCxFQUFnQixRQUFRLFVBQVUsT0FBUzs7Ozs7U0FDekM7Ozs7aUJBQ0Y7V0FWSyxVQUFVOzs7O2VBVWYsQ0FDTCxFQUNJOzs7O2dCQUNGOzs7Ozs7TUFDSjs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFDRSxTQUFRO1FBQ1IsVUFBVSxRQUFRLEtBQUs7UUFDdkIsZUFBZSxRQUFRLE9BQU8sQ0FBQztrQkFDaEM7T0FFTzs7OztpQkFDUix3QkFBQyxRQUFEO1FBQ0UsU0FBUTtRQUNSLFVBQVUsT0FBTyxPQUFPLFNBQVMsT0FBTyxTQUFTO1FBQ2pELGVBQWUsUUFBUSxPQUFPLENBQUM7a0JBQ2hDO09BRU87Ozs7ZUFDTDs7Ozs7O01BQ0wsd0JBQUMsY0FBRDtPQUNFLE1BQU0sT0FBTyxRQUFRO09BQ3JCLFNBQVMsT0FBTyxRQUFRO01BQ3pCOzs7OztLQUNEOzs7OztJQUVEOzs7Ozs7RUFFQTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2VuZEhpc3RvcnkudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBQcm9tb3Rpb25SdW4sXHJcbiAgUHJvbW90aW9uUnVuRGV0YWlsLFxyXG59IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3Byb21vdGlvbi50eXBlcyc7XHJcbmltcG9ydCB7IGdldFByb21vdGlvblJ1biB9IGZyb20gJy4uLy4uLy4uLy4uL3NlcnZpY2VzL3Byb21vdGlvblNlcnZpY2UnO1xyXG5pbXBvcnQgeyBwcm9tb3Rpb25UZXh0IGFzIHQgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9wcm9tb3Rpb25UZXh0JztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGUnO1xyXG5pbXBvcnQgeyBnZXRBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2FwaUVycm9ycyc7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgRW1haWxQcmV2aWV3IH0gZnJvbSAnLi9FbWFpbFByZXZpZXcnO1xyXG5pbXBvcnQgeyBQcm9tb3Rpb25CYWRnZSB9IGZyb20gJy4vUHJvbW90aW9uQmFkZ2UnO1xyXG5leHBvcnQgZnVuY3Rpb24gU2VuZEhpc3Rvcnkoe1xyXG4gIGlkLFxyXG4gIHJ1bnMsXHJcbn06IHtcclxuICBpZDogc3RyaW5nO1xyXG4gIHJ1bnM6IFByb21vdGlvblJ1bltdO1xyXG59KSB7XHJcbiAgY29uc3QgW3J1bklkLCBzZXRSdW5JZF0gPSB1c2VTdGF0ZSgnJyksXHJcbiAgICBbcGFnZSwgc2V0UGFnZV0gPSB1c2VTdGF0ZSgxKSxcclxuICAgIFtkZXRhaWwsIHNldERldGFpbF0gPSB1c2VTdGF0ZTxQcm9tb3Rpb25SdW5EZXRhaWwgfCBudWxsPihudWxsKSxcclxuICAgIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpLFxyXG4gICAgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpLFxyXG4gICAgW3JldmlzaW9uLCBzZXRSZXZpc2lvbl0gPSB1c2VTdGF0ZSgwKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFydW5JZCkgcmV0dXJuO1xyXG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGxvYWQoKSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9yKCcnKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBuZXh0ID0gYXdhaXQgZ2V0UHJvbW90aW9uUnVuKGlkLCBydW5JZCwgcGFnZSwgY29udHJvbGxlci5zaWduYWwpO1xyXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgc2V0RGV0YWlsKG5leHQpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpXHJcbiAgICAgICAgICBzZXRFcnJvcihcclxuICAgICAgICAgICAgZ2V0QXBpRXJyb3IoXHJcbiAgICAgICAgICAgICAgZXJyLFxyXG4gICAgICAgICAgICAgICdVbmFibGUgdG8gbG9hZCB0aGUgc2VuZCByZXBvcnQuIFBsZWFzZSB0cnkgYWdhaW4uJyxcclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdm9pZCBsb2FkKCk7XHJcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpO1xyXG4gIH0sIFtpZCwgcnVuSWQsIHBhZ2UsIHJ1bnMsIHJldmlzaW9uXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInVpLXBhbmVsIHAtNSBzbTpwLTZcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPnt0Lmhpc3Rvcnl9PC9oMj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+e3QuaGlzdG9yeUhpbnR9PC9wPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj57dC5kZWxpdmVyeUhpbnR9PC9wPlxyXG4gICAgICB7IXJ1bnMubGVuZ3RoID8gKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTUgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICBUaGlzIHByb21vdGlvbiBoYXMgbm90IGJlZW4gc2VudCB5ZXQuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC01IGRpdmlkZS15IGRpdmlkZS1saW5lXCI+XHJcbiAgICAgICAgICB7cnVucy5tYXAoKHJ1bikgPT4gKFxyXG4gICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICBrZXk9e3J1bi5pZH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB5LTRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocnVuLmNyZWF0ZWRBdCl9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7cnVuLmNvdW50cy5TRU5UfSBzZW50IMK3eycgJ31cclxuICAgICAgICAgICAgICAgICAge3J1bi5jb3VudHMuUVVFVUVEICsgcnVuLmNvdW50cy5QUk9DRVNTSU5HfSBwZW5kaW5nIMK3eycgJ31cclxuICAgICAgICAgICAgICAgICAge3J1bi5jb3VudHMuRkFJTEVEfSBmYWlsZWQgwrcge3J1bi5jb3VudHMuU0tJUFBFRH0gc2tpcHBlZCDCt3snICd9XHJcbiAgICAgICAgICAgICAgICAgIHtydW4uY291bnRzLlVOS05PV059IHVua25vd25cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8UHJvbW90aW9uQmFkZ2Ugc3RhdHVzPXtydW4uc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJ1bklkKHJ1bklkID09PSBydW4uaWQgPyAnJyA6IHJ1bi5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UGFnZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXREZXRhaWwobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtydW5JZCA9PT0gcnVuLmlkID8gJ0Nsb3NlIHJlcG9ydCcgOiB0LnZpZXdTZW50fVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L3VsPlxyXG4gICAgICApfVxyXG4gICAgICB7cnVuSWQgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBzcGFjZS15LTQgYm9yZGVyLXQgYm9yZGVyLWxpbmUgcHQtNVwiPlxyXG4gICAgICAgICAge2xvYWRpbmcgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+VXBkYXRpbmcgcmVwb3J04oCmPC9wPn1cclxuICAgICAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgICAgICB7ZXJyb3J9eycgJ31cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVuZGVybGluZVwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXZpc2lvbigobikgPT4gbiArIDEpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFJldHJ5XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICB7ZGV0YWlsICYmIChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlNlbnQgdmVyc2lvbjoge2RldGFpbC5zdWJqZWN0fTwvaDM+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmVcIj5cclxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgbWluLXctWzQyMHB4XSB0ZXh0LWxlZnQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc3VidGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtM1wiPlJlY2lwaWVudDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zXCI+UmVzdWx0PC90aD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAge2RldGFpbC5yZWNpcGllbnRzLm1hcCgocmVjaXBpZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyZWNpcGllbnQuaWR9IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1saW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cD57cmVjaXBpZW50LnVzZXJuYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWNpcGllbnQuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFByb21vdGlvbkJhZGdlIHN0YXR1cz17cmVjaXBpZW50LnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPD0gMSB8fCBsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKHBhZ2UgLSAxKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUHJldmlvdXMgcmVjaXBpZW50c1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZSAqIGRldGFpbC5saW1pdCA+PSBkZXRhaWwudG90YWwgfHwgbG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnZShwYWdlICsgMSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIE5leHQgcmVjaXBpZW50c1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPEVtYWlsUHJldmlld1xyXG4gICAgICAgICAgICAgICAgaHRtbD17ZGV0YWlsLnByZXZpZXcuaHRtbH1cclxuICAgICAgICAgICAgICAgIHN1YmplY3Q9e2RldGFpbC5wcmV2aWV3LnN1YmplY3R9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19