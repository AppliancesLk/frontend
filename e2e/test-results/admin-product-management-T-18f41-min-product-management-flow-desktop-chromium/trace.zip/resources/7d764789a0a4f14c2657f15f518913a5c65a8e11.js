import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ProductImage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { translations } from "/src/utils/translations.ts";
import { imageUrl } from "/src/utils/imageUrl.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ProductImage.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function ProductImage({ src, alt, className = "", eager = false }) {
	_s();
	const [failedSource, setFailedSource] = useState(null);
	if (!src || failedSource === src) return /* @__PURE__ */ _jsxDEV("div", {
		className: `flex flex-col items-center justify-center gap-3 bg-page text-fg-muted ${className}`,
		role: "img",
		"aria-label": `${alt}: ${translations.productDetails.noImage}`,
		children: [/* @__PURE__ */ _jsxDEV("svg", {
			"aria-hidden": "true",
			className: "h-8 w-8",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5",
			viewBox: "0 0 48 48",
			children: [
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "7",
					y: "7",
					width: "34",
					height: "34",
					rx: "5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "17",
					cy: "18",
					r: "3"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("path", { d: "m8 34 11-11 8 8 6-6 8 9" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "px-2 text-center text-xs",
			children: translations.productDetails.noImage
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 7
	}, this);
	return /* @__PURE__ */ _jsxDEV("img", {
		src: imageUrl(src),
		alt,
		loading: eager ? "eager" : "lazy",
		decoding: "async",
		width: 800,
		height: 800,
		fetchPriority: eager ? "high" : undefined,
		onError: () => setFailedSource(src),
		className: `object-contain ${className}`
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_s(ProductImage, "4L6bL/FD7mtTIrpv2c+tiP/x6b8=");
_c = ProductImage;
var _c;
$RefreshReg$(_c, "ProductImage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/ProductImage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ProductImage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ProductImage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ProductImage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxnQkFBZ0I7Ozs7QUFDekIsT0FBTyxTQUFTLGFBQWEsRUFDM0IsS0FDQSxLQUNBLFlBQVksSUFDWixRQUFRLFNBTVA7O0NBQ0QsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLElBQUk7Q0FDcEUsSUFBSSxDQUFDLE9BQU8saUJBQWlCLEtBQzNCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVcseUVBQXlFO0VBQ3BGLE1BQUs7RUFDTCxjQUFZLEdBQUcsSUFBSSxJQUFJLGFBQWEsZUFBZTtZQUhyRCxDQUtFLHdCQUFDLE9BQUQ7R0FDRSxlQUFZO0dBQ1osV0FBVTtHQUNWLE1BQUs7R0FDTCxRQUFPO0dBQ1AsYUFBWTtHQUNaLFNBQVE7YUFOVjtJQVFFLHdCQUFDLFFBQUQ7S0FBTSxHQUFFO0tBQUksR0FBRTtLQUFJLE9BQU07S0FBSyxRQUFPO0tBQUssSUFBRztJQUFLOzs7OztJQUNqRCx3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFLLElBQUc7S0FBSyxHQUFFO0lBQUs7Ozs7O0lBQy9CLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDBCQUEyQjs7Ozs7R0FDaEM7Ozs7O1lBQ0wsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDYixhQUFhLGVBQWU7RUFDekI7Ozs7VUFDSDs7Ozs7O0NBRVQsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsS0FBSyxTQUFTLEdBQUc7RUFDWjtFQUNMLFNBQVMsUUFBUSxVQUFVO0VBQzNCLFVBQVM7RUFDVCxPQUFPO0VBQ1AsUUFBUTtFQUNSLGVBQWUsUUFBUSxTQUFTO0VBQ2hDLGVBQWUsZ0JBQWdCLEdBQUc7RUFDbEMsV0FBVyxrQkFBa0I7Q0FDOUI7Ozs7O0FBRUwiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEltYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgaW1hZ2VVcmwgfSBmcm9tICcuLi8uLi91dGlscy9pbWFnZVVybCc7XHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0SW1hZ2Uoe1xyXG4gIHNyYyxcclxuICBhbHQsXHJcbiAgY2xhc3NOYW1lID0gJycsXHJcbiAgZWFnZXIgPSBmYWxzZSxcclxufToge1xyXG4gIHNyYz86IHN0cmluZztcclxuICBhbHQ6IHN0cmluZztcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbiAgZWFnZXI/OiBib29sZWFuO1xyXG59KSB7XHJcbiAgY29uc3QgW2ZhaWxlZFNvdXJjZSwgc2V0RmFpbGVkU291cmNlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGlmICghc3JjIHx8IGZhaWxlZFNvdXJjZSA9PT0gc3JjKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIGJnLXBhZ2UgdGV4dC1mZy1tdXRlZCAke2NsYXNzTmFtZX1gfVxyXG4gICAgICAgIHJvbGU9XCJpbWdcIlxyXG4gICAgICAgIGFyaWEtbGFiZWw9e2Ake2FsdH06ICR7dHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLm5vSW1hZ2V9YH1cclxuICAgICAgPlxyXG4gICAgICAgIDxzdmdcclxuICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04XCJcclxuICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICB2aWV3Qm94PVwiMCAwIDQ4IDQ4XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8cmVjdCB4PVwiN1wiIHk9XCI3XCIgd2lkdGg9XCIzNFwiIGhlaWdodD1cIjM0XCIgcng9XCI1XCIgLz5cclxuICAgICAgICAgIDxjaXJjbGUgY3g9XCIxN1wiIGN5PVwiMThcIiByPVwiM1wiIC8+XHJcbiAgICAgICAgICA8cGF0aCBkPVwibTggMzQgMTEtMTEgOCA4IDYtNiA4IDlcIiAvPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgdGV4dC1jZW50ZXIgdGV4dC14c1wiPlxyXG4gICAgICAgICAge3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5ub0ltYWdlfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIHJldHVybiAoXHJcbiAgICA8aW1nXHJcbiAgICAgIHNyYz17aW1hZ2VVcmwoc3JjKX1cclxuICAgICAgYWx0PXthbHR9XHJcbiAgICAgIGxvYWRpbmc9e2VhZ2VyID8gJ2VhZ2VyJyA6ICdsYXp5J31cclxuICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXHJcbiAgICAgIHdpZHRoPXs4MDB9XHJcbiAgICAgIGhlaWdodD17ODAwfVxyXG4gICAgICBmZXRjaFByaW9yaXR5PXtlYWdlciA/ICdoaWdoJyA6IHVuZGVmaW5lZH1cclxuICAgICAgb25FcnJvcj17KCkgPT4gc2V0RmFpbGVkU291cmNlKHNyYyl9XHJcbiAgICAgIGNsYXNzTmFtZT17YG9iamVjdC1jb250YWluICR7Y2xhc3NOYW1lfWB9XHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuIl19