import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { RatingPlate } from "/src/components/common/RatingPlate.tsx";
import { formatSpecificationValue, getSpecificationEntries, formatSpecificationLabel } from "/src/pages/Customer/ProductDetails/helpers/product-details.helpers.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.productDetails;
export function ProductSpecifications({ specifications }) {
	const entries = getSpecificationEntries(specifications);
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "specifications",
		"aria-labelledby": "specifications-title",
		className: "scroll-mt-6",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			id: "specifications-title",
			className: "sr-only",
			children: t.specifications
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this), entries.length ? /* @__PURE__ */ _jsxDEV(RatingPlate, {
			title: t.specifications,
			rows: entries.map(([label, value]) => ({
				label: formatSpecificationLabel(label),
				value: formatSpecificationValue(value)
			}))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("p", {
			className: "p-5 text-sm leading-6 text-fg-muted sm:px-8",
			children: t.noSpecifications
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_c = ProductSpecifications;
var _c;
$RefreshReg$(_c, "ProductSpecifications");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FDRSwwQkFDQSx5QkFDQSxnQ0FDSztBQUNQLFNBQVMsb0JBQW9COzs7QUFDN0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLHNCQUFzQixFQUNwQyxrQkFHQztDQUNELE1BQU0sVUFBVSx3QkFBd0IsY0FBYztDQUN0RCxPQUNFLHdCQUFDLFdBQUQ7RUFDRSxJQUFHO0VBQ0gsbUJBQWdCO0VBQ2hCLFdBQVU7WUFIWixDQUtFLHdCQUFDLE1BQUQ7R0FBSSxJQUFHO0dBQXVCLFdBQVU7YUFDckMsRUFBRTtFQUNEOzs7O1lBQ0gsUUFBUSxTQUNQLHdCQUFDLGFBQUQ7R0FDRSxPQUFPLEVBQUU7R0FDVCxNQUFNLFFBQVEsS0FBSyxDQUFDLE9BQU8sWUFBWTtJQUNyQyxPQUFPLHlCQUF5QixLQUFLO0lBQ3JDLE9BQU8seUJBQXlCLEtBQUs7R0FDdkMsRUFBRTtFQUNIOzs7O2FBRUQsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFDVixFQUFFO0VBQ0Y7Ozs7VUFFRTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdFNwZWNpZmljYXRpb25zLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSYXRpbmdQbGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JhdGluZ1BsYXRlJztcclxuaW1wb3J0IHtcclxuICBmb3JtYXRTcGVjaWZpY2F0aW9uVmFsdWUsXHJcbiAgZ2V0U3BlY2lmaWNhdGlvbkVudHJpZXMsXHJcbiAgZm9ybWF0U3BlY2lmaWNhdGlvbkxhYmVsLFxyXG59IGZyb20gJy4uL2hlbHBlcnMvcHJvZHVjdC1kZXRhaWxzLmhlbHBlcnMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzO1xyXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdFNwZWNpZmljYXRpb25zKHtcclxuICBzcGVjaWZpY2F0aW9ucyxcclxufToge1xyXG4gIHNwZWNpZmljYXRpb25zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGw7XHJcbn0pIHtcclxuICBjb25zdCBlbnRyaWVzID0gZ2V0U3BlY2lmaWNhdGlvbkVudHJpZXMoc3BlY2lmaWNhdGlvbnMpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvblxyXG4gICAgICBpZD1cInNwZWNpZmljYXRpb25zXCJcclxuICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwic3BlY2lmaWNhdGlvbnMtdGl0bGVcIlxyXG4gICAgICBjbGFzc05hbWU9XCJzY3JvbGwtbXQtNlwiXHJcbiAgICA+XHJcbiAgICAgIDxoMiBpZD1cInNwZWNpZmljYXRpb25zLXRpdGxlXCIgY2xhc3NOYW1lPVwic3Itb25seVwiPlxyXG4gICAgICAgIHt0LnNwZWNpZmljYXRpb25zfVxyXG4gICAgICA8L2gyPlxyXG4gICAgICB7ZW50cmllcy5sZW5ndGggPyAoXHJcbiAgICAgICAgPFJhdGluZ1BsYXRlXHJcbiAgICAgICAgICB0aXRsZT17dC5zcGVjaWZpY2F0aW9uc31cclxuICAgICAgICAgIHJvd3M9e2VudHJpZXMubWFwKChbbGFiZWwsIHZhbHVlXSkgPT4gKHtcclxuICAgICAgICAgICAgbGFiZWw6IGZvcm1hdFNwZWNpZmljYXRpb25MYWJlbChsYWJlbCksXHJcbiAgICAgICAgICAgIHZhbHVlOiBmb3JtYXRTcGVjaWZpY2F0aW9uVmFsdWUodmFsdWUpLFxyXG4gICAgICAgICAgfSkpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicC01IHRleHQtc20gbGVhZGluZy02IHRleHQtZmctbXV0ZWQgc206cHgtOFwiPlxyXG4gICAgICAgICAge3Qubm9TcGVjaWZpY2F0aW9uc31cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=