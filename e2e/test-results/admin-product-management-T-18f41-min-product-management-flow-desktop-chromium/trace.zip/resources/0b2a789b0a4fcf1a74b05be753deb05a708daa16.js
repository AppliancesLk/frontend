import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Orders/Details/index.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { useOrdersPage } from "/src/pages/Customer/Orders/hooks/useOrdersPage.ts";
import { OrdersShell } from "/src/pages/Customer/Orders/components/OrdersShell.tsx";
import { OrderDetails } from "/src/pages/Customer/Orders/components/OrderDetails.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/Details/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export default function OrderDetailsPage() {
	_s();
	const { user } = useAuth();
	const { id } = useParams();
	return user && id ? /* @__PURE__ */ _jsxDEV(DetailsContent, { id }, `${user.id}:${id}`, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this) : null;
}
_s(OrderDetailsPage, "vsrfM0KYZhl0Ml2OiqssffPVJ/s=", false, function() {
	return [useAuth, useParams];
});
_c = OrderDetailsPage;
function DetailsContent({ id }) {
	_s2();
	const page = useOrdersPage(id);
	const t = translations.orders;
	return /* @__PURE__ */ _jsxDEV(OrdersShell, {
		details: true,
		refresh: page.refresh,
		loading: page.loading,
		children: [
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 7
			}, this),
			page.refreshError && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "ui-alert ui-tone-warning",
				children: page.refreshError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this),
			page.notFound && /* @__PURE__ */ _jsxDEV("section", {
				className: "rounded-md border border-line bg-surface p-8 text-center",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-semibold text-fg",
						children: t.notFound
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: t.notFoundDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.orders,
						className: "auth-primary mt-6",
						children: t.back
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this),
			!page.loading && !page.error && !page.notFound && page.data[0] && /* @__PURE__ */ _jsxDEV(OrderDetails, {
				order: page.data[0],
				refresh: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_s2(DetailsContent, "1YbIMycOVZtF0WErg5hZHU8BUcg=", false, function() {
	return [useOrdersPage];
});
_c2 = DetailsContent;
var _c, _c2;
$RefreshReg$(_c, "OrderDetailsPage");
$RefreshReg$(_c2, "DetailsContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Orders/Details/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/Details/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/Details/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/Details/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGlCQUFpQjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsb0JBQW9COzs7O0FBQzdCLGVBQWUsU0FBUyxtQkFBbUI7O0NBQ3pDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsTUFBTSxFQUFFLE9BQU8sVUFBMEI7Q0FDekMsT0FBTyxRQUFRLEtBQ2Isd0JBQUMsZ0JBQUQsRUFBNkMsR0FBSyxHQUE3QixHQUFHLEtBQUssR0FBRyxHQUFHOzs7O1FBQWUsSUFDaEQ7QUFDTjs7Ozs7QUFDQSxTQUFTLGVBQWUsRUFBRSxNQUFzQjs7Q0FDOUMsTUFBTSxPQUFPLGNBQWMsRUFBRTtDQUM3QixNQUFNLElBQUksYUFBYTtDQUN2QixPQUNFLHdCQUFDLGFBQUQ7RUFBYTtFQUFRLFNBQVMsS0FBSztFQUFTLFNBQVMsS0FBSztZQUExRDtHQUNFLHdCQUFDLGlCQUFEO0lBQ0UsU0FBUyxLQUFLO0lBQ2QsT0FBTyxLQUFLO0lBQ1osT0FBTyxLQUFLO0dBQ2I7Ozs7O0dBQ0EsS0FBSyxnQkFDSix3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFTLFdBQVU7Y0FDeEIsS0FBSztHQUNMOzs7OztHQUVKLEtBQUssWUFDSix3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQyxFQUFFO0tBQWE7Ozs7O0tBQzlELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE4QixFQUFFO0tBQXVCOzs7OztLQUNwRSx3QkFBQyxNQUFEO01BQU0sSUFBSSxPQUFPO01BQVEsV0FBVTtnQkFDaEMsRUFBRTtLQUNDOzs7OztJQUNDOzs7Ozs7R0FFVixDQUFDLEtBQUssV0FBVyxDQUFDLEtBQUssU0FBUyxDQUFDLEtBQUssWUFBWSxLQUFLLEtBQUssTUFDM0Qsd0JBQUMsY0FBRDtJQUFjLE9BQU8sS0FBSyxLQUFLO0lBQUksU0FBUyxLQUFLO0dBQVU7Ozs7O0VBRWxEOzs7Ozs7QUFFakIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZU9yZGVyc1BhZ2UgfSBmcm9tICcuLi9ob29rcy91c2VPcmRlcnNQYWdlJztcclxuaW1wb3J0IHsgT3JkZXJzU2hlbGwgfSBmcm9tICcuLi9jb21wb25lbnRzL09yZGVyc1NoZWxsJztcclxuaW1wb3J0IHsgT3JkZXJEZXRhaWxzIH0gZnJvbSAnLi4vY29tcG9uZW50cy9PcmRlckRldGFpbHMnO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPcmRlckRldGFpbHNQYWdlKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcclxuICByZXR1cm4gdXNlciAmJiBpZCA/IChcclxuICAgIDxEZXRhaWxzQ29udGVudCBrZXk9e2Ake3VzZXIuaWR9OiR7aWR9YH0gaWQ9e2lkfSAvPlxyXG4gICkgOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIERldGFpbHNDb250ZW50KHsgaWQgfTogeyBpZDogc3RyaW5nIH0pIHtcclxuICBjb25zdCBwYWdlID0gdXNlT3JkZXJzUGFnZShpZCk7XHJcbiAgY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5vcmRlcnM7XHJcbiAgcmV0dXJuIChcclxuICAgIDxPcmRlcnNTaGVsbCBkZXRhaWxzIHJlZnJlc2g9e3BhZ2UucmVmcmVzaH0gbG9hZGluZz17cGFnZS5sb2FkaW5nfT5cclxuICAgICAgPENhdGFsb2dGZWVkYmFja1xyXG4gICAgICAgIGxvYWRpbmc9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICBlcnJvcj17cGFnZS5lcnJvcn1cclxuICAgICAgICByZXRyeT17cGFnZS5yZWZyZXNofVxyXG4gICAgICAvPlxyXG4gICAgICB7cGFnZS5yZWZyZXNoRXJyb3IgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJ1aS1hbGVydCB1aS10b25lLXdhcm5pbmdcIj5cclxuICAgICAgICAgIHtwYWdlLnJlZnJlc2hFcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLm5vdEZvdW5kICYmIChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtOCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3Qubm90Rm91bmR9PC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3Qubm90Rm91bmREZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLm9yZGVyc30gY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IG10LTZcIj5cclxuICAgICAgICAgICAge3QuYmFja31cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICl9XHJcbiAgICAgIHshcGFnZS5sb2FkaW5nICYmICFwYWdlLmVycm9yICYmICFwYWdlLm5vdEZvdW5kICYmIHBhZ2UuZGF0YVswXSAmJiAoXHJcbiAgICAgICAgPE9yZGVyRGV0YWlscyBvcmRlcj17cGFnZS5kYXRhWzBdfSByZWZyZXNoPXtwYWdlLnJlZnJlc2h9IC8+XHJcbiAgICAgICl9XHJcbiAgICA8L09yZGVyc1NoZWxsPlxyXG4gICk7XHJcbn1cclxuIl19