import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/LiveChat/index.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import { ChatPane } from "/src/components/chat/ChatPane.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { useAuth } from "/src/hooks/useAuth.ts";
import { useSupportChat } from "/src/hooks/useSupportChat.ts";
import { ChatConversation } from "/src/components/chat/ChatConversation.tsx";
import { ChatSessionList } from "/src/components/chat/ChatSessionList.tsx";
import { ChatConnection } from "/src/components/chat/ChatConnection.tsx";
import { chatText as t } from "/src/utils/chatText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/LiveChat/index.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export default function AdminChatPage() {
	_s();
	const { user } = useAuth();
	return /* @__PURE__ */ _jsxDEV(AdminChat, {}, user?.id, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 10
	}, this);
}
_s(AdminChatPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = AdminChatPage;
function AdminChat() {
	_s2();
	const [showConversation, setShowConversation] = useState(false);
	const chat = useSupportChat("ADMIN");
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.adminTitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.adminDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(ChatConnection, {
					state: chat.connection,
					reconnect: chat.reconnect
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 7
			}, this),
			chat.actionError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "rounded-sm bg-danger-bg p-3 text-sm text-danger",
				children: chat.actionError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid items-start gap-5 lg:grid-cols-[20rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ _jsxDEV("aside", {
					className: (showConversation && chat.selectedId ? "hidden lg:block " : "") + "min-w-0 rounded-md border border-line bg-surface ",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-line p-4",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "font-semibold text-fg",
								children: t.sessions
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 42,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "chat-status",
								className: "mt-3 block text-xs text-fg-muted",
								children: t.status
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 43,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("select", {
								id: "chat-status",
								value: chat.status ?? "",
								onChange: (event) => chat.filter(event.target.value === "OPEN" ? "OPEN" : event.target.value === "CLOSED" ? "CLOSED" : undefined),
								className: "ui-field mt-1 min-h-11 w-full rounded-sm border border-line px-3 text-sm focus:outline-primary",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: t.all
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "OPEN",
										children: t.open
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 64,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "CLOSED",
										children: t.closed
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this), chat.listError ? /* @__PURE__ */ _jsxDEV("div", {
						role: "alert",
						className: "p-4 text-sm text-danger",
						children: [/* @__PURE__ */ _jsxDEV("p", { children: chat.listError }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => void chat.refresh(),
							className: "mt-2 rounded underline",
							children: t.retry
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this) : !chat.list ? /* @__PURE__ */ _jsxDEV(LoadingState, {
						label: t.loading,
						compact: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(ChatSessionList, {
						sessions: chat.list.items,
						selectedId: chat.selectedId,
						role: "ADMIN",
						select: (id) => {
							chat.select(id);
							setShowConversation(true);
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 15
					}, this), chat.list.totalPages > 1 && /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-2 border-t border-line p-3 text-sm",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: chat.list.page <= 1,
								onClick: () => chat.setPage(chat.list.page - 1),
								className: "ui-button ui-button-secondary rounded-sm border border-line px-3 py-2 ",
								children: t.previous
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: [
								chat.list.page,
								"/",
								chat.list.totalPages
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: chat.list.page >= chat.list.totalPages,
								onClick: () => chat.setPage(chat.list.page + 1),
								className: "ui-button ui-button-secondary rounded-sm border border-line px-3 py-2 ",
								children: t.next
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(ChatPane, {
					chat,
					back: () => {
						chat.deselect();
						setShowConversation(false);
					},
					children: /* @__PURE__ */ _jsxDEV(ChatConversation, {
						chat,
						admin: true
					}, chat.selectedId, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_s2(AdminChat, "CN4PBeqGWNbZW0lfxtMPZDN1Km4=", false, function() {
	return [useSupportChat];
});
_c2 = AdminChat;
var _c, _c2;
$RefreshReg$(_c, "AdminChatPage");
$RefreshReg$(_c2, "AdminChat");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/LiveChat/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/LiveChat/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/LiveChat/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/LiveChat/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsWUFBWSxTQUFTOzs7O0FBQzlCLGVBQWUsU0FBUyxnQkFBZ0I7O0NBQ3RDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FBTyx3QkFBQyxXQUFELENBQTJCLEdBQVgsTUFBTTs7OztRQUFLO0FBQ3BDOzs7OztBQUNBLFNBQVMsWUFBWTs7Q0FDbkIsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLO0NBQzlELE1BQU0sT0FBTyxlQUFlLE9BQU87Q0FDbkMsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXlCLEVBQUU7SUFBZTs7OztjQUN4RCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE4QixFQUFFO0lBQW9COzs7O1lBQzlEOzs7O2NBQ0wsd0JBQUMsZ0JBQUQ7S0FBZ0IsT0FBTyxLQUFLO0tBQVksV0FBVyxLQUFLO0lBQVk7Ozs7WUFDOUQ7Ozs7OztHQUNQLEtBQUssZUFDSix3QkFBQyxLQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FFVCxLQUFLO0dBQ0w7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFNBQUQ7S0FDRSxZQUNHLG9CQUFvQixLQUFLLGFBQWEscUJBQXFCLE1BQzVEO2VBSEosQ0FNRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF5QixFQUFFO09BQWE7Ozs7O09BQ3RELHdCQUFDLFNBQUQ7UUFDRSxTQUFRO1FBQ1IsV0FBVTtrQkFFVCxFQUFFO09BQ0U7Ozs7O09BQ1Asd0JBQUMsVUFBRDtRQUNFLElBQUc7UUFDSCxPQUFPLEtBQUssVUFBVTtRQUN0QixXQUFXLFVBQ1QsS0FBSyxPQUNILE1BQU0sT0FBTyxVQUFVLFNBQ25CLFNBQ0EsTUFBTSxPQUFPLFVBQVUsV0FDckIsV0FDQSxTQUNSO1FBRUYsV0FBVTtrQkFaWjtTQWNFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFJLEVBQUU7U0FBWTs7Ozs7U0FDaEMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVEsRUFBRTtTQUFhOzs7OztTQUNyQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBVSxFQUFFO1NBQWU7Ozs7O1FBQ25DOzs7Ozs7TUFDTDs7Ozs7ZUFDSixLQUFLLFlBQ0osd0JBQUMsT0FBRDtNQUFLLE1BQUs7TUFBUSxXQUFVO2dCQUE1QixDQUNFLHdCQUFDLEtBQUQsWUFBSSxLQUFLLFVBQWE7Ozs7Z0JBQ3RCLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLEtBQUssS0FBSyxRQUFRO09BQ2pDLFdBQVU7aUJBRVQsRUFBRTtNQUNHOzs7O2NBQ0w7Ozs7O2dCQUNILENBQUMsS0FBSyxPQUNSLHdCQUFDLGNBQUQ7TUFBYyxPQUFPLEVBQUU7TUFBUyxTQUFTO0tBQU87Ozs7Z0JBRWhELGdEQUNFLHdCQUFDLGlCQUFEO01BQ0UsVUFBVSxLQUFLLEtBQUs7TUFDcEIsWUFBWSxLQUFLO01BQ2pCLE1BQUs7TUFDTCxTQUFTLE9BQU87T0FDZCxLQUFLLE9BQU8sRUFBRTtPQUNkLG9CQUFvQixJQUFJO01BQzFCO0tBQ0Q7Ozs7ZUFDQSxLQUFLLEtBQUssYUFBYSxLQUN0Qix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVSxLQUFLLEtBQUssUUFBUTtRQUM1QixlQUFlLEtBQUssUUFBUSxLQUFLLEtBQU0sT0FBTyxDQUFDO1FBQy9DLFdBQVU7a0JBRVQsRUFBRTtPQUNHOzs7OztPQUNSLHdCQUFDLFFBQUQ7UUFDRyxLQUFLLEtBQUs7UUFBSztRQUFFLEtBQUssS0FBSztPQUN4Qjs7Ozs7T0FDTix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVUsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLO1FBQ3RDLGVBQWUsS0FBSyxRQUFRLEtBQUssS0FBTSxPQUFPLENBQUM7UUFDL0MsV0FBVTtrQkFFVCxFQUFFO09BQ0c7Ozs7O01BQ0w7Ozs7O2FBRVA7Ozs7YUFFQzs7Ozs7Y0FDUCx3QkFBQyxVQUFEO0tBQ1E7S0FDTixZQUFZO01BQ1YsS0FBSyxTQUFTO01BQ2Qsb0JBQW9CLEtBQUs7S0FDM0I7ZUFFQSx3QkFBQyxrQkFBRDtNQUE4QztNQUFNO0tBQU8sR0FBcEMsS0FBSzs7OztZQUErQjtJQUNuRDs7OztZQUNQOzs7Ozs7RUFDRTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoYXRQYW5lIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jaGF0L0NoYXRQYW5lJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IHVzZVN1cHBvcnRDaGF0IH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlU3VwcG9ydENoYXQnO1xyXG5pbXBvcnQgeyBDaGF0Q29udmVyc2F0aW9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jaGF0L0NoYXRDb252ZXJzYXRpb24nO1xyXG5pbXBvcnQgeyBDaGF0U2Vzc2lvbkxpc3QgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NoYXQvQ2hhdFNlc3Npb25MaXN0JztcclxuaW1wb3J0IHsgQ2hhdENvbm5lY3Rpb24gfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NoYXQvQ2hhdENvbm5lY3Rpb24nO1xyXG5pbXBvcnQgeyBjaGF0VGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY2hhdFRleHQnO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBZG1pbkNoYXRQYWdlKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIHJldHVybiA8QWRtaW5DaGF0IGtleT17dXNlcj8uaWR9IC8+O1xyXG59XHJcbmZ1bmN0aW9uIEFkbWluQ2hhdCgpIHtcclxuICBjb25zdCBbc2hvd0NvbnZlcnNhdGlvbiwgc2V0U2hvd0NvbnZlcnNhdGlvbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgY2hhdCA9IHVzZVN1cHBvcnRDaGF0KCdBRE1JTicpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGUgdGV4dC1mZ1wiPnt0LmFkbWluVGl0bGV9PC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3QuYWRtaW5EZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPENoYXRDb25uZWN0aW9uIHN0YXRlPXtjaGF0LmNvbm5lY3Rpb259IHJlY29ubmVjdD17Y2hhdC5yZWNvbm5lY3R9IC8+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgICB7Y2hhdC5hY3Rpb25FcnJvciAmJiAoXHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIGJnLWRhbmdlci1iZyBwLTMgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2NoYXQuYWN0aW9uRXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgaXRlbXMtc3RhcnQgZ2FwLTUgbGc6Z3JpZC1jb2xzLVsyMHJlbV9taW5tYXgoMCwxZnIpXVwiPlxyXG4gICAgICAgIDxhc2lkZVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgKHNob3dDb252ZXJzYXRpb24gJiYgY2hhdC5zZWxlY3RlZElkID8gJ2hpZGRlbiBsZzpibG9jayAnIDogJycpICtcclxuICAgICAgICAgICAgJ21pbi13LTAgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSAnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZSBwLTRcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt0LnNlc3Npb25zfTwvaDI+XHJcbiAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgIGh0bWxGb3I9XCJjaGF0LXN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyBibG9jayB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3Quc3RhdHVzfVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgaWQ9XCJjaGF0LXN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NoYXQuc3RhdHVzID8/ICcnfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICBjaGF0LmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgZXZlbnQudGFyZ2V0LnZhbHVlID09PSAnT1BFTidcclxuICAgICAgICAgICAgICAgICAgICA/ICdPUEVOJ1xyXG4gICAgICAgICAgICAgICAgICAgIDogZXZlbnQudGFyZ2V0LnZhbHVlID09PSAnQ0xPU0VEJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyAnQ0xPU0VEJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIG10LTEgbWluLWgtMTEgdy1mdWxsIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIHB4LTMgdGV4dC1zbSBmb2N1czpvdXRsaW5lLXByaW1hcnlcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0LmFsbH08L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT1BFTlwiPnt0Lm9wZW59PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNMT1NFRFwiPnt0LmNsb3NlZH08L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIHtjaGF0Lmxpc3RFcnJvciA/IChcclxuICAgICAgICAgICAgPGRpdiByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSB0ZXh0LWRhbmdlclwiPlxyXG4gICAgICAgICAgICAgIDxwPntjaGF0Lmxpc3RFcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBjaGF0LnJlZnJlc2goKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgcm91bmRlZCB1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0LnJldHJ5fVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAhY2hhdC5saXN0ID8gKFxyXG4gICAgICAgICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LmxvYWRpbmd9IGNvbXBhY3Q9e3RydWV9IC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxDaGF0U2Vzc2lvbkxpc3RcclxuICAgICAgICAgICAgICAgIHNlc3Npb25zPXtjaGF0Lmxpc3QuaXRlbXN9XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZElkPXtjaGF0LnNlbGVjdGVkSWR9XHJcbiAgICAgICAgICAgICAgICByb2xlPVwiQURNSU5cIlxyXG4gICAgICAgICAgICAgICAgc2VsZWN0PXsoaWQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY2hhdC5zZWxlY3QoaWQpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93Q29udmVyc2F0aW9uKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIHtjaGF0Lmxpc3QudG90YWxQYWdlcyA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgYm9yZGVyLXQgYm9yZGVyLWxpbmUgcC0zIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjaGF0Lmxpc3QucGFnZSA8PSAxfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNoYXQuc2V0UGFnZShjaGF0Lmxpc3QhLnBhZ2UgLSAxKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXNlY29uZGFyeSByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBweC0zIHB5LTIgXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0LnByZXZpb3VzfVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge2NoYXQubGlzdC5wYWdlfS97Y2hhdC5saXN0LnRvdGFsUGFnZXN9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjaGF0Lmxpc3QucGFnZSA+PSBjaGF0Lmxpc3QudG90YWxQYWdlc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjaGF0LnNldFBhZ2UoY2hhdC5saXN0IS5wYWdlICsgMSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgcHgtMyBweS0yIFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dC5uZXh0fVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgIDxDaGF0UGFuZVxyXG4gICAgICAgICAgY2hhdD17Y2hhdH1cclxuICAgICAgICAgIGJhY2s9eygpID0+IHtcclxuICAgICAgICAgICAgY2hhdC5kZXNlbGVjdCgpO1xyXG4gICAgICAgICAgICBzZXRTaG93Q29udmVyc2F0aW9uKGZhbHNlKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPENoYXRDb252ZXJzYXRpb24ga2V5PXtjaGF0LnNlbGVjdGVkSWR9IGNoYXQ9e2NoYXR9IGFkbWluIC8+XHJcbiAgICAgICAgPC9DaGF0UGFuZT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=