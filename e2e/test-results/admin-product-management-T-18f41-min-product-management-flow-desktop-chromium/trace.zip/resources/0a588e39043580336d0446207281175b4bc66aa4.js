import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Dialog } from "/src/components/ui/Dialog.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.adminRepairs;
export function ActionDialog({ page }) {
	if (!page.action) return null;
	const isApprove = page.action === "approve";
	return /* @__PURE__ */ _jsxDEV(Dialog, {
		open: true,
		onClose: () => page.setAction(null),
		title: isApprove ? t.approveConfirm : t.rejectConfirm,
		description: isApprove ? t.approveDescription : t.rejectDescription,
		busy: page.processing,
		children: [
			!isApprove && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "rejection-reason",
						className: "auth-label",
						children: t.rejectionReason
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						id: "rejection-reason",
						rows: 3,
						maxLength: 500,
						value: page.rejectionReason,
						onChange: (e) => page.setRejectionReason(e.target.value),
						placeholder: t.rejectionReasonHint,
						disabled: page.processing,
						className: "ui-field auth-input resize-none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1.5 text-xs text-fg-muted",
						children: [page.rejectionReason.length, " / 500 characters"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 9
			}, this),
			page.actionError && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "mt-4 rounded-sm border border-danger/25 bg-danger-bg p-3 text-sm text-danger",
				children: page.actionError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 flex flex-col gap-3 sm:flex-row-reverse",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void (isApprove ? page.approveRepair() : page.rejectRepair()),
					disabled: page.processing,
					className: `auth-primary ${isApprove ? "bg-success hover:bg-success" : "bg-danger hover:bg-danger"}`,
					children: [page.processing && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 31
					}, this), page.processing ? isApprove ? t.approving : t.rejecting : t.confirmAction]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => page.setAction(null),
					disabled: page.processing,
					className: "auth-secondary",
					children: t.cancelAction
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_c = ActionDialog;
var _c;
$RefreshReg$(_c, "ActionDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/Details/components/ActionDialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG9CQUFvQjs7O0FBRzdCLE1BQU0sSUFBSSxhQUFhO0FBRXZCLE9BQU8sU0FBUyxhQUFhLEVBQzNCLFFBR0M7Q0FDRCxJQUFJLENBQUMsS0FBSyxRQUFRLE9BQU87Q0FFekIsTUFBTSxZQUFZLEtBQUssV0FBVztDQUVsQyxPQUNFLHdCQUFDLFFBQUQ7RUFDRTtFQUNBLGVBQWUsS0FBSyxVQUFVLElBQUk7RUFDbEMsT0FBTyxZQUFZLEVBQUUsaUJBQWlCLEVBQUU7RUFDeEMsYUFBYSxZQUFZLEVBQUUscUJBQXFCLEVBQUU7RUFDbEQsTUFBTSxLQUFLO1lBTGI7R0FPRyxDQUFDLGFBQ0Esd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO01BQW1CLFdBQVU7Z0JBQ3pDLEVBQUU7S0FDRTs7Ozs7S0FDUCx3QkFBQyxZQUFEO01BQ0UsSUFBRztNQUNILE1BQU07TUFDTixXQUFXO01BQ1gsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLEtBQUssbUJBQW1CLEVBQUUsT0FBTyxLQUFLO01BQ3ZELGFBQWEsRUFBRTtNQUNmLFVBQVUsS0FBSztNQUNmLFdBQVU7S0FDWDs7Ozs7S0FDRCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUNHLEtBQUssZ0JBQWdCLFFBQU8sbUJBQzVCOzs7Ozs7SUFDQTs7Ozs7O0dBR04sS0FBSyxlQUNKLHdCQUFDLE9BQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtjQUVULEtBQUs7R0FDSDs7Ozs7R0FHUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUNFLE1BQU0sWUFBWSxLQUFLLGNBQWMsSUFBSSxLQUFLLGFBQWE7S0FFN0QsVUFBVSxLQUFLO0tBQ2YsV0FBVyxnQkFBZ0IsWUFBWSxnQ0FBZ0M7ZUFOekUsQ0FRRyxLQUFLLGNBQWMsd0JBQUMsU0FBRCxFQUFTLFdBQVUsT0FBUTs7OztlQUM5QyxLQUFLLGFBQ0YsWUFDRSxFQUFFLFlBQ0YsRUFBRSxZQUNKLEVBQUUsYUFDQTs7Ozs7Y0FDUix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsS0FBSyxVQUFVLElBQUk7S0FDbEMsVUFBVSxLQUFLO0tBQ2YsV0FBVTtlQUVULEVBQUU7SUFDRzs7OztZQUNMOzs7Ozs7RUFDQzs7Ozs7O0FBRVoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWN0aW9uRGlhbG9nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaWFsb2cgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0RpYWxvZyc7XHJcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHR5cGUgeyB1c2VBZG1pblJlcGFpckRldGFpbHMgfSBmcm9tICcuLi9ob29rcy91c2VBZG1pblJlcGFpckRldGFpbHMnO1xyXG5cclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pblJlcGFpcnM7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQWN0aW9uRGlhbG9nKHtcclxuICBwYWdlLFxyXG59OiB7XHJcbiAgcGFnZTogUmV0dXJuVHlwZTx0eXBlb2YgdXNlQWRtaW5SZXBhaXJEZXRhaWxzPjtcclxufSkge1xyXG4gIGlmICghcGFnZS5hY3Rpb24pIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBpc0FwcHJvdmUgPSBwYWdlLmFjdGlvbiA9PT0gJ2FwcHJvdmUnO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPERpYWxvZ1xyXG4gICAgICBvcGVuXHJcbiAgICAgIG9uQ2xvc2U9eygpID0+IHBhZ2Uuc2V0QWN0aW9uKG51bGwpfVxyXG4gICAgICB0aXRsZT17aXNBcHByb3ZlID8gdC5hcHByb3ZlQ29uZmlybSA6IHQucmVqZWN0Q29uZmlybX1cclxuICAgICAgZGVzY3JpcHRpb249e2lzQXBwcm92ZSA/IHQuYXBwcm92ZURlc2NyaXB0aW9uIDogdC5yZWplY3REZXNjcmlwdGlvbn1cclxuICAgICAgYnVzeT17cGFnZS5wcm9jZXNzaW5nfVxyXG4gICAgPlxyXG4gICAgICB7IWlzQXBwcm92ZSAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJlamVjdGlvbi1yZWFzb25cIiBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCI+XHJcbiAgICAgICAgICAgIHt0LnJlamVjdGlvblJlYXNvbn1cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgaWQ9XCJyZWplY3Rpb24tcmVhc29uXCJcclxuICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgbWF4TGVuZ3RoPXs1MDB9XHJcbiAgICAgICAgICAgIHZhbHVlPXtwYWdlLnJlamVjdGlvblJlYXNvbn1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBwYWdlLnNldFJlamVjdGlvblJlYXNvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0LnJlamVjdGlvblJlYXNvbkhpbnR9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnByb2Nlc3Npbmd9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXQgcmVzaXplLW5vbmVcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAge3BhZ2UucmVqZWN0aW9uUmVhc29uLmxlbmd0aH0gLyA1MDAgY2hhcmFjdGVyc1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3BhZ2UuYWN0aW9uRXJyb3IgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1kYW5nZXIvMjUgYmctZGFuZ2VyLWJnIHAtMyB0ZXh0LXNtIHRleHQtZGFuZ2VyXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7cGFnZS5hY3Rpb25FcnJvcn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGZsZXgtY29sIGdhcC0zIHNtOmZsZXgtcm93LXJldmVyc2VcIj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgIHZvaWQgKGlzQXBwcm92ZSA/IHBhZ2UuYXBwcm92ZVJlcGFpcigpIDogcGFnZS5yZWplY3RSZXBhaXIoKSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnByb2Nlc3Npbmd9XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BhdXRoLXByaW1hcnkgJHtpc0FwcHJvdmUgPyAnYmctc3VjY2VzcyBob3ZlcjpiZy1zdWNjZXNzJyA6ICdiZy1kYW5nZXIgaG92ZXI6YmctZGFuZ2VyJ31gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtwYWdlLnByb2Nlc3NpbmcgJiYgPFNwaW5uZXIgY2xhc3NOYW1lPVwibXItMlwiIC8+fVxyXG4gICAgICAgICAge3BhZ2UucHJvY2Vzc2luZ1xyXG4gICAgICAgICAgICA/IGlzQXBwcm92ZVxyXG4gICAgICAgICAgICAgID8gdC5hcHByb3ZpbmdcclxuICAgICAgICAgICAgICA6IHQucmVqZWN0aW5nXHJcbiAgICAgICAgICAgIDogdC5jb25maXJtQWN0aW9ufVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRBY3Rpb24obnVsbCl9XHJcbiAgICAgICAgICBkaXNhYmxlZD17cGFnZS5wcm9jZXNzaW5nfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0LmNhbmNlbEFjdGlvbn1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L0RpYWxvZz5cclxuICApO1xyXG59XHJcbiJdfQ==