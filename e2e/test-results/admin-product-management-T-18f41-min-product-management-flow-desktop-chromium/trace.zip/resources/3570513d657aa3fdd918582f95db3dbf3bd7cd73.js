import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/feedback/ToastRegion.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ToastRegion.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
function Toast({ item, dismiss }) {
	_s();
	const [paused, setPaused] = useState(false);
	useEffect(() => {
		if (paused) return;
		const timer = window.setTimeout(() => dismiss(item.id), 5e3);
		return () => window.clearTimeout(timer);
	}, [
		item.id,
		paused,
		dismiss
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "store-toast",
		onMouseEnter: () => setPaused(true),
		onMouseLeave: () => setPaused(false),
		onFocusCapture: () => setPaused(true),
		onBlurCapture: (event) => {
			if (!event.currentTarget.contains(event.relatedTarget)) setPaused(false);
		},
		children: [
			/* @__PURE__ */ _jsxDEV(Icon, {
				name: "check",
				className: "h-5 w-5 shrink-0"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: item.message }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this), item.action && /* @__PURE__ */ _jsxDEV(Link, {
					to: item.action.to,
					onClick: () => dismiss(item.id),
					className: "mt-1 inline-block font-semibold underline underline-offset-4",
					children: item.action.label
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => dismiss(item.id),
				"aria-label": "Dismiss notification",
				className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-sm",
				children: /* @__PURE__ */ _jsxDEV(Icon, {
					name: "close",
					className: "h-4 w-4"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_s(Toast, "YpqooJVnPWVCX63C3Sv2zKz9JC0=");
_c = Toast;
export function ToastRegion() {
	_s2();
	const [items, setItems] = useState([]);
	const dismiss = useCallback((id) => setItems((current) => current.filter((item) => item.id !== id)), []);
	useEffect(() => {
		const receive = (event) => {
			const message = event.detail;
			setItems((current) => [{
				...message,
				id: crypto.randomUUID()
			}, ...current].slice(0, 3));
		};
		window.addEventListener("store-toast", receive);
		return () => window.removeEventListener("store-toast", receive);
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "store-toast-region",
		"aria-live": "polite",
		"aria-relevant": "additions",
		children: items.map((item) => /* @__PURE__ */ _jsxDEV(Toast, {
			item,
			dismiss
		}, item.id, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 72,
		columnNumber: 5
	}, this);
}
_s2(ToastRegion, "xYfr7SFRUQeNSvj+VVpR2jvtqTs=");
_c2 = ToastRegion;
var _c, _c2;
$RefreshReg$(_c, "Toast");
$RefreshReg$(_c2, "ToastRegion");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/feedback/ToastRegion.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ToastRegion.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ToastRegion.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ToastRegion.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCO0FBQ2pELFNBQVMsWUFBWTtBQUVyQixTQUFTLFlBQVk7Ozs7QUFFckIsU0FBUyxNQUFNLEVBQ2IsTUFDQSxXQUlDOztDQUNELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLGdCQUFnQjtFQUNkLElBQUksUUFBUTtFQUNaLE1BQU0sUUFBUSxPQUFPLGlCQUFpQixRQUFRLEtBQUssRUFBRSxHQUFHLEdBQUk7RUFDNUQsYUFBYSxPQUFPLGFBQWEsS0FBSztDQUN4QyxHQUFHO0VBQUMsS0FBSztFQUFJO0VBQVE7Q0FBTyxDQUFDO0NBQzdCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVU7RUFDVixvQkFBb0IsVUFBVSxJQUFJO0VBQ2xDLG9CQUFvQixVQUFVLEtBQUs7RUFDbkMsc0JBQXNCLFVBQVUsSUFBSTtFQUNwQyxnQkFBZ0IsVUFBVTtHQUN4QixJQUFJLENBQUMsTUFBTSxjQUFjLFNBQVMsTUFBTSxhQUFhLEdBQ25ELFVBQVUsS0FBSztFQUNuQjtZQVJGO0dBVUUsd0JBQUMsTUFBRDtJQUFNLE1BQUs7SUFBUSxXQUFVO0dBQW9COzs7OztHQUNqRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRCxZQUFJLEtBQUssUUFBVzs7OztjQUNuQixLQUFLLFVBQ0osd0JBQUMsTUFBRDtLQUNFLElBQUksS0FBSyxPQUFPO0tBQ2hCLGVBQWUsUUFBUSxLQUFLLEVBQUU7S0FDOUIsV0FBVTtlQUVULEtBQUssT0FBTztJQUNUOzs7O1lBRUw7Ozs7OztHQUNMLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsZUFBZSxRQUFRLEtBQUssRUFBRTtJQUM5QixjQUFXO0lBQ1gsV0FBVTtjQUVWLHdCQUFDLE1BQUQ7S0FBTSxNQUFLO0tBQVEsV0FBVTtJQUFXOzs7OztHQUNsQzs7Ozs7RUFDTDs7Ozs7O0FBRVQ7OztBQUNBLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWlCLENBQUMsQ0FBQztDQUM3QyxNQUFNLFVBQVUsYUFDYixPQUNDLFVBQVUsWUFBWSxRQUFRLFFBQVEsU0FBUyxLQUFLLE9BQU8sRUFBRSxDQUFDLEdBQ2hFLENBQUMsQ0FDSDtDQUNBLGdCQUFnQjtFQUNkLE1BQU0sV0FBVyxVQUFpQjtHQUNoQyxNQUFNLFVBQVcsTUFBb0M7R0FDckQsVUFBVSxZQUNSLENBQUM7SUFBRSxHQUFHO0lBQVMsSUFBSSxPQUFPLFdBQVc7R0FBRSxHQUFHLEdBQUcsT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FDbEU7RUFDRjtFQUNBLE9BQU8saUJBQWlCLGVBQWUsT0FBTztFQUM5QyxhQUFhLE9BQU8sb0JBQW9CLGVBQWUsT0FBTztDQUNoRSxHQUFHLENBQUMsQ0FBQztDQUNMLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVU7RUFDVixhQUFVO0VBQ1YsaUJBQWM7WUFFYixNQUFNLEtBQUssU0FDVix3QkFBQyxPQUFEO0dBQTJCO0dBQWU7RUFBVSxHQUF4QyxLQUFLOzs7O1NBQW1DLENBQ3JEO0NBQ0U7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVG9hc3RSZWdpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB0eXBlIHsgVG9hc3RNZXNzYWdlIH0gZnJvbSAnLi4vLi4vdXRpbHMvdG9hc3QnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG50eXBlIEl0ZW0gPSBUb2FzdE1lc3NhZ2UgJiB7IGlkOiBzdHJpbmcgfTtcclxuZnVuY3Rpb24gVG9hc3Qoe1xyXG4gIGl0ZW0sXHJcbiAgZGlzbWlzcyxcclxufToge1xyXG4gIGl0ZW06IEl0ZW07XHJcbiAgZGlzbWlzczogKGlkOiBzdHJpbmcpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBjb25zdCBbcGF1c2VkLCBzZXRQYXVzZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocGF1c2VkKSByZXR1cm47XHJcbiAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IGRpc21pc3MoaXRlbS5pZCksIDUwMDApO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xyXG4gIH0sIFtpdGVtLmlkLCBwYXVzZWQsIGRpc21pc3NdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJzdG9yZS10b2FzdFwiXHJcbiAgICAgIG9uTW91c2VFbnRlcj17KCkgPT4gc2V0UGF1c2VkKHRydWUpfVxyXG4gICAgICBvbk1vdXNlTGVhdmU9eygpID0+IHNldFBhdXNlZChmYWxzZSl9XHJcbiAgICAgIG9uRm9jdXNDYXB0dXJlPXsoKSA9PiBzZXRQYXVzZWQodHJ1ZSl9XHJcbiAgICAgIG9uQmx1ckNhcHR1cmU9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGlmICghZXZlbnQuY3VycmVudFRhcmdldC5jb250YWlucyhldmVudC5yZWxhdGVkVGFyZ2V0KSlcclxuICAgICAgICAgIHNldFBhdXNlZChmYWxzZSk7XHJcbiAgICAgIH19XHJcbiAgICA+XHJcbiAgICAgIDxJY29uIG5hbWU9XCJjaGVja1wiIGNsYXNzTmFtZT1cImgtNSB3LTUgc2hyaW5rLTBcIiAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgPHA+e2l0ZW0ubWVzc2FnZX08L3A+XHJcbiAgICAgICAge2l0ZW0uYWN0aW9uICYmIChcclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtpdGVtLmFjdGlvbi50b31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGlzbWlzcyhpdGVtLmlkKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBpbmxpbmUtYmxvY2sgZm9udC1zZW1pYm9sZCB1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC00XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2l0ZW0uYWN0aW9uLmxhYmVsfVxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZGlzbWlzcyhpdGVtLmlkKX1cclxuICAgICAgICBhcmlhLWxhYmVsPVwiRGlzbWlzcyBub3RpZmljYXRpb25cIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXNtXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxJY29uIG5hbWU9XCJjbG9zZVwiIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFRvYXN0UmVnaW9uKCkge1xyXG4gIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8SXRlbVtdPihbXSk7XHJcbiAgY29uc3QgZGlzbWlzcyA9IHVzZUNhbGxiYWNrKFxyXG4gICAgKGlkOiBzdHJpbmcpID0+XHJcbiAgICAgIHNldEl0ZW1zKChjdXJyZW50KSA9PiBjdXJyZW50LmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gaWQpKSxcclxuICAgIFtdLFxyXG4gICk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHJlY2VpdmUgPSAoZXZlbnQ6IEV2ZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSAoZXZlbnQgYXMgQ3VzdG9tRXZlbnQ8VG9hc3RNZXNzYWdlPikuZGV0YWlsO1xyXG4gICAgICBzZXRJdGVtcygoY3VycmVudCkgPT5cclxuICAgICAgICBbeyAuLi5tZXNzYWdlLCBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSB9LCAuLi5jdXJyZW50XS5zbGljZSgwLCAzKSxcclxuICAgICAgKTtcclxuICAgIH07XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc3RvcmUtdG9hc3QnLCByZWNlaXZlKTtcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc3RvcmUtdG9hc3QnLCByZWNlaXZlKTtcclxuICB9LCBbXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPVwic3RvcmUtdG9hc3QtcmVnaW9uXCJcclxuICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcclxuICAgICAgYXJpYS1yZWxldmFudD1cImFkZGl0aW9uc1wiXHJcbiAgICA+XHJcbiAgICAgIHtpdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICA8VG9hc3Qga2V5PXtpdGVtLmlkfSBpdGVtPXtpdGVtfSBkaXNtaXNzPXtkaXNtaXNzfSAvPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19