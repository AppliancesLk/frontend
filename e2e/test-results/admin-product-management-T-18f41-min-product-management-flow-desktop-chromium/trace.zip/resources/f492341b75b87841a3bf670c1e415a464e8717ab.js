import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Inventory/index.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import { EmptyState } from "/src/components/ui/Feedback.tsx";
import { InventoryList } from "/src/pages/Admin/Inventory/components/InventoryList.tsx";
import { useInventoryPage } from "/src/pages/Admin/Inventory/hooks/useInventoryPage.ts";
import { translations } from "/src/utils/translations.ts";
import { LoadingState, ErrorState } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
function InventoryPage() {
	_s();
	const page = useInventoryPage();
	const { products, loading, loadError, saving, handleRefresh } = page;
	return /* @__PURE__ */ _jsxDEV("section", { children: /* @__PURE__ */ _jsxDEV("div", {
		className: "mx-auto max-w-5xl",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "mb-8 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: translations.admin.inventory
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-secondary",
					children: translations.admin.inventoryDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: handleRefresh,
					disabled: loading || Object.values(saving).some(Boolean),
					className: "ui-button ui-button-secondary rounded-sm bg-surface px-4 py-2 text-sm font-medium text-fg-secondary  transition hover:bg-subtle disabled:cursor-not-allowed ",
					children: translations.admin.refresh
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 9
			}, this),
			loading && /* @__PURE__ */ _jsxDEV(LoadingState, { label: translations.admin.inventoryLoading }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 11
			}, this),
			!loading && loadError && /* @__PURE__ */ _jsxDEV(ErrorState, {
				message: loadError,
				retry: handleRefresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 11
			}, this),
			!loading && !loadError && products.length === 0 && /* @__PURE__ */ _jsxDEV(EmptyState, {
				title: translations.admin.inventoryEmpty,
				icon: "bag"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this),
			!loading && !loadError && products.length > 0 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "mb-3 text-sm text-fg-muted",
				children: [
					products.length,
					" ",
					products.length === 1 ? translations.admin.productSingular : translations.admin.productPlural
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV(InventoryList, { page }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_s(InventoryPage, "KRjgRTdkS3kwmWwhhsgIJyGsqF4=", false, function() {
	return [useInventoryPage];
});
_c = InventoryPage;
export default InventoryPage;
var _c;
$RefreshReg$(_c, "InventoryPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Inventory/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjLGtCQUFrQjs7OztBQUN6QyxTQUFTLGdCQUFnQjs7Q0FDdkIsTUFBTSxPQUFPLGlCQUFpQjtDQUM5QixNQUFNLEVBQUUsVUFBVSxTQUFTLFdBQVcsUUFBUSxrQkFBa0I7Q0FDaEUsT0FDRSx3QkFBQyxXQUFELFlBQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsYUFBYSxNQUFNO0lBQ2xCOzs7O2NBRUosd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixhQUFhLE1BQU07SUFDbkI7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUztLQUNULFVBQVUsV0FBVyxPQUFPLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxPQUFPO0tBQ3ZELFdBQVU7ZUFFVCxhQUFhLE1BQU07SUFDZDs7OztZQUNGOzs7Ozs7R0FFUCxXQUNDLHdCQUFDLGNBQUQsRUFBYyxPQUFPLGFBQWEsTUFBTSxpQkFBbUI7Ozs7O0dBRzVELENBQUMsV0FBVyxhQUNYLHdCQUFDLFlBQUQ7SUFBWSxTQUFTO0lBQVcsT0FBTztHQUFnQjs7Ozs7R0FHeEQsQ0FBQyxXQUFXLENBQUMsYUFBYSxTQUFTLFdBQVcsS0FDN0Msd0JBQUMsWUFBRDtJQUFZLE9BQU8sYUFBYSxNQUFNO0lBQWdCLE1BQUs7R0FBTzs7Ozs7R0FHbkUsQ0FBQyxXQUFXLENBQUMsYUFBYSxTQUFTLFNBQVMsS0FDM0MsZ0RBQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYjtLQUNHLFNBQVM7S0FBUTtLQUNqQixTQUFTLFdBQVcsSUFDakIsYUFBYSxNQUFNLGtCQUNuQixhQUFhLE1BQU07SUFDdEI7Ozs7O2FBRUgsd0JBQUMsZUFBRCxFQUFxQixLQUFPOzs7O1dBQzVCOzs7OztFQUVEOzs7OztVQUNFOzs7OztBQUViOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgSW52ZW50b3J5TGlzdCB9IGZyb20gJy4vY29tcG9uZW50cy9JbnZlbnRvcnlMaXN0JztcclxuaW1wb3J0IHsgdXNlSW52ZW50b3J5UGFnZSB9IGZyb20gJy4vaG9va3MvdXNlSW52ZW50b3J5UGFnZSc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSwgRXJyb3JTdGF0ZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5mdW5jdGlvbiBJbnZlbnRvcnlQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VJbnZlbnRvcnlQYWdlKCk7XHJcbiAgY29uc3QgeyBwcm9kdWN0cywgbG9hZGluZywgbG9hZEVycm9yLCBzYXZpbmcsIGhhbmRsZVJlZnJlc2ggfSA9IHBhZ2U7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctNXhsXCI+XHJcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJtYi04IGZsZXggZmxleC1jb2wgZ2FwLTQgc206ZmxleC1yb3cgc206aXRlbXMtc3RhcnQgc206anVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5hZG1pbi5pbnZlbnRvcnl9XHJcbiAgICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmFkbWluLmludmVudG9yeURlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZWZyZXNofVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCBPYmplY3QudmFsdWVzKHNhdmluZykuc29tZShCb29sZWFuKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgcm91bmRlZC1zbSBiZy1zdXJmYWNlIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctc2Vjb25kYXJ5ICB0cmFuc2l0aW9uIGhvdmVyOmJnLXN1YnRsZSBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5hZG1pbi5yZWZyZXNofVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICAgIHtsb2FkaW5nICYmIChcclxuICAgICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9e3RyYW5zbGF0aW9ucy5hZG1pbi5pbnZlbnRvcnlMb2FkaW5nfSAvPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHshbG9hZGluZyAmJiBsb2FkRXJyb3IgJiYgKFxyXG4gICAgICAgICAgPEVycm9yU3RhdGUgbWVzc2FnZT17bG9hZEVycm9yfSByZXRyeT17aGFuZGxlUmVmcmVzaH0gLz5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7IWxvYWRpbmcgJiYgIWxvYWRFcnJvciAmJiBwcm9kdWN0cy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgPEVtcHR5U3RhdGUgdGl0bGU9e3RyYW5zbGF0aW9ucy5hZG1pbi5pbnZlbnRvcnlFbXB0eX0gaWNvbj1cImJhZ1wiIC8+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgeyFsb2FkaW5nICYmICFsb2FkRXJyb3IgJiYgcHJvZHVjdHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgIHtwcm9kdWN0cy5sZW5ndGh9eycgJ31cclxuICAgICAgICAgICAgICB7cHJvZHVjdHMubGVuZ3RoID09PSAxXHJcbiAgICAgICAgICAgICAgICA/IHRyYW5zbGF0aW9ucy5hZG1pbi5wcm9kdWN0U2luZ3VsYXJcclxuICAgICAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLmFkbWluLnByb2R1Y3RQbHVyYWx9XHJcbiAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgIDxJbnZlbnRvcnlMaXN0IHBhZ2U9e3BhZ2V9IC8+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbnZlbnRvcnlQYWdlO1xyXG4iXX0=