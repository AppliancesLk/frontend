import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Home/components/PromotionalBanner.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { bannerImageUrl } from "/src/services/bannerService.ts";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/PromotionalBanner.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.storefront;
export function PromotionalBanner({ section }) {
	_s();
	const [index, setIndex] = useState(0);
	const [paused, setPaused] = useState(false);
	const [interacting, setInteracting] = useState(false);
	const touchStart = useRef(null);
	const count = section?.slides.length ?? 0;
	const current = count ? index % count : 0;
	const isHero = section?.position === "top";
	useEffect(() => {
		if (count < 2 || paused || interacting || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const timer = window.setInterval(() => {
			if (!document.hidden) setIndex((value) => (value + 1) % count);
		}, isHero ? 3500 : 7e3);
		return () => window.clearInterval(timer);
	}, [
		count,
		paused,
		interacting,
		isHero
	]);
	if (!section?.visible || !count) return null;
	const slide = section.slides[current];
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-label": t.positions[section.position],
		"aria-roledescription": count > 1 ? "carousel" : undefined,
		className: `overflow-hidden rounded-lg border border-line bg-surface ${isHero ? "campaign-hero" : ""}`,
		onMouseEnter: () => setInteracting(true),
		onMouseLeave: () => setInteracting(false),
		onFocusCapture: () => setInteracting(true),
		onBlurCapture: (event) => {
			if (!event.currentTarget.contains(event.relatedTarget)) setInteracting(false);
		},
		onTouchStart: (event) => {
			touchStart.current = event.touches[0].clientX;
			if (isHero) setInteracting(true);
			else setPaused(true);
		},
		onTouchEnd: (event) => {
			const start = touchStart.current;
			const end = event.changedTouches[0].clientX;
			if (start !== null && Math.abs(end - start) > 50) setIndex((value) => (value + (end < start ? 1 : count - 1)) % count);
			touchStart.current = null;
			if (isHero) setInteracting(false);
		},
		onTouchCancel: () => {
			touchStart.current = null;
			if (isHero) setInteracting(false);
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: `campaign-slide motion-safe:animate-fade-in ${isHero ? "campaign-hero-slide" : ""}`,
			role: "group",
			"aria-roledescription": "slide",
			"aria-label": `${current + 1} of ${count}`,
			"aria-live": paused || interacting ? "polite" : "off",
			children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
				src: bannerImageUrl(slide.imageUrl),
				alt: slide.alt,
				eager: isHero,
				className: `campaign-art w-full ${isHero ? "campaign-hero-art object-cover! object-right" : "aspect-[16/5]"}`
			}, slide.imageUrl, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this), (slide.title || slide.description || slide.buttonText) && /* @__PURE__ */ _jsxDEV("div", {
				className: isHero ? "campaign-hero-copy flex flex-col gap-4" : "flex flex-col gap-4 border-t border-line-subtle p-5 sm:flex-row sm:items-center sm:justify-between sm:p-8",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [slide.title && /* @__PURE__ */ _jsxDEV("h2", {
					className: `text-2xl font-bold tracking-tight md:text-3xl ${isHero ? "text-white" : "text-fg"}`,
					children: slide.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 17
				}, this), slide.description && /* @__PURE__ */ _jsxDEV("p", {
					className: `mt-2 max-w-2xl text-sm leading-6 ${isHero ? "text-white/90" : "text-fg-secondary"}`,
					children: slide.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 13
				}, this), slide.buttonText && slide.href && (slide.href.startsWith("/") ? /* @__PURE__ */ _jsxDEV(Link, {
					className: "shrink-0 self-start rounded-sm bg-primary px-5 py-3 font-semibold text-primary-on hover:bg-primary-hover",
					to: slide.href,
					children: [slide.buttonText, " →"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 17
				}, this) : /* @__PURE__ */ _jsxDEV("a", {
					className: "shrink-0 self-start rounded-sm bg-primary px-5 py-3 font-semibold text-primary-on hover:bg-primary-hover",
					href: slide.href,
					children: [slide.buttonText, " →"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 17
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 11
			}, this)]
		}, current, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this), !isHero && count > 1 && /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-center gap-3 border-t border-line-subtle p-3",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					"aria-label": t.previous,
					className: "min-h-11 w-11 rounded-sm hover:bg-subtle",
					onClick: () => setIndex((current + count - 1) % count),
					children: "←"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 11
				}, this),
				section.slides.map((_, i) => /* @__PURE__ */ _jsxDEV("button", {
					"aria-label": `Slide ${i + 1}`,
					"aria-current": current === i ? "true" : undefined,
					onClick: () => setIndex(i),
					className: "flex min-h-11 w-7 items-center justify-center",
					children: /* @__PURE__ */ _jsxDEV("span", { className: `h-2 rounded-full ${current === i ? "w-6 bg-primary" : "w-2 bg-sunken"}` }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 15
					}, this)
				}, i, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 13
				}, this)),
				/* @__PURE__ */ _jsxDEV("button", {
					"aria-label": t.next,
					className: "min-h-11 w-11 rounded-sm hover:bg-subtle",
					onClick: () => setIndex((current + 1) % count),
					children: "→"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: "rounded-sm px-3 py-2 text-xs text-fg-secondary",
					onClick: () => setPaused((value) => !value),
					children: paused ? t.play : t.pause
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 121,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_s(PromotionalBanner, "Ll/GSakXIPUNxRmw+ATG7vDVMHk=");
_c = PromotionalBanner;
var _c;
$RefreshReg$(_c, "PromotionalBanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Home/components/PromotionalBanner.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/PromotionalBanner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/PromotionalBanner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/PromotionalBanner.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFVBQVUsY0FBYztBQUM1QyxTQUFTLFlBQVk7QUFFckIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7Ozs7QUFDN0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGtCQUFrQixFQUFFLFdBQXdDOztDQUMxRSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsQ0FBQztDQUNwQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sYUFBYSxPQUFzQixJQUFJO0NBQzdDLE1BQU0sUUFBUSxTQUFTLE9BQU8sVUFBVTtDQUN4QyxNQUFNLFVBQVUsUUFBUSxRQUFRLFFBQVE7Q0FDeEMsTUFBTSxTQUFTLFNBQVMsYUFBYTtDQUNyQyxnQkFBZ0I7RUFDZCxJQUNFLFFBQVEsS0FDUixVQUNBLGVBQ0EsT0FBTyxXQUFXLGtDQUFrQyxDQUFDLENBQUMsU0FFdEQ7RUFDRixNQUFNLFFBQVEsT0FBTyxrQkFBa0I7R0FDckMsSUFBSSxDQUFDLFNBQVMsUUFBUSxVQUFVLFdBQVcsUUFBUSxLQUFLLEtBQUs7RUFDL0QsR0FBRyxTQUFTLE9BQU8sR0FBSTtFQUN2QixhQUFhLE9BQU8sY0FBYyxLQUFLO0NBQ3pDLEdBQUc7RUFBQztFQUFPO0VBQVE7RUFBYTtDQUFNLENBQUM7Q0FDdkMsSUFBSSxDQUFDLFNBQVMsV0FBVyxDQUFDLE9BQU8sT0FBTztDQUN4QyxNQUFNLFFBQVEsUUFBUSxPQUFPO0NBQzdCLE9BQ0Usd0JBQUMsV0FBRDtFQUNFLGNBQVksRUFBRSxVQUFVLFFBQVE7RUFDaEMsd0JBQXNCLFFBQVEsSUFBSSxhQUFhO0VBQy9DLFdBQVcsNERBQTRELFNBQVMsa0JBQWtCO0VBQ2xHLG9CQUFvQixlQUFlLElBQUk7RUFDdkMsb0JBQW9CLGVBQWUsS0FBSztFQUN4QyxzQkFBc0IsZUFBZSxJQUFJO0VBQ3pDLGdCQUFnQixVQUFVO0dBQ3hCLElBQUksQ0FBQyxNQUFNLGNBQWMsU0FBUyxNQUFNLGFBQWEsR0FDbkQsZUFBZSxLQUFLO0VBQ3hCO0VBQ0EsZUFBZSxVQUFVO0dBQ3ZCLFdBQVcsVUFBVSxNQUFNLFFBQVEsRUFBRSxDQUFDO0dBQ3RDLElBQUksUUFBUSxlQUFlLElBQUk7UUFDMUIsVUFBVSxJQUFJO0VBQ3JCO0VBQ0EsYUFBYSxVQUFVO0dBQ3JCLE1BQU0sUUFBUSxXQUFXO0dBQ3pCLE1BQU0sTUFBTSxNQUFNLGVBQWUsRUFBRSxDQUFDO0dBQ3BDLElBQUksVUFBVSxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSSxJQUM1QyxVQUFVLFdBQVcsU0FBUyxNQUFNLFFBQVEsSUFBSSxRQUFRLE1BQU0sS0FBSztHQUNyRSxXQUFXLFVBQVU7R0FDckIsSUFBSSxRQUFRLGVBQWUsS0FBSztFQUNsQztFQUNBLHFCQUFxQjtHQUNuQixXQUFXLFVBQVU7R0FDckIsSUFBSSxRQUFRLGVBQWUsS0FBSztFQUNsQztZQTNCRixDQTZCRSx3QkFBQyxPQUFEO0dBRUUsV0FBVyw4Q0FBOEMsU0FBUyx3QkFBd0I7R0FDMUYsTUFBSztHQUNMLHdCQUFxQjtHQUNyQixjQUFZLEdBQUcsVUFBVSxFQUFFLE1BQU07R0FDakMsYUFBVyxVQUFVLGNBQWMsV0FBVzthQU5oRCxDQVFFLHdCQUFDLGNBQUQ7SUFFRSxLQUFLLGVBQWUsTUFBTSxRQUFRO0lBQ2xDLEtBQUssTUFBTTtJQUNYLE9BQU87SUFDUCxXQUFXLHVCQUF1QixTQUFTLGlEQUFpRDtHQUM3RixHQUxNLE1BQU07Ozs7VUFLWixJQUNDLE1BQU0sU0FBUyxNQUFNLGVBQWUsTUFBTSxlQUMxQyx3QkFBQyxPQUFEO0lBQ0UsV0FDRSxTQUNJLDJDQUNBO2NBSlIsQ0FPRSx3QkFBQyxPQUFELGFBQ0csTUFBTSxTQUNMLHdCQUFDLE1BQUQ7S0FDRSxXQUFXLGlEQUFpRCxTQUFTLGVBQWU7ZUFFbkYsTUFBTTtJQUNMOzs7O2NBRUwsTUFBTSxlQUNMLHdCQUFDLEtBQUQ7S0FDRSxXQUFXLG9DQUFvQyxTQUFTLGtCQUFrQjtlQUV6RSxNQUFNO0lBQ047Ozs7WUFFRjs7OztjQUNKLE1BQU0sY0FDTCxNQUFNLFNBQ0wsTUFBTSxLQUFLLFdBQVcsR0FBRyxJQUN4Qix3QkFBQyxNQUFEO0tBQ0UsV0FBVTtLQUNWLElBQUksTUFBTTtlQUZaLENBSUcsTUFBTSxZQUFXLElBQ2Q7Ozs7O2VBRU4sd0JBQUMsS0FBRDtLQUNFLFdBQVU7S0FDVixNQUFNLE1BQU07ZUFGZCxDQUlHLE1BQU0sWUFBVyxJQUNqQjs7Ozs7YUFFSjs7Ozs7V0FFSjtLQXpERTs7OztTQXlERixHQUNKLENBQUMsVUFBVSxRQUFRLEtBQ2xCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxVQUFEO0tBQ0UsY0FBWSxFQUFFO0tBQ2QsV0FBVTtLQUNWLGVBQWUsVUFBVSxVQUFVLFFBQVEsS0FBSyxLQUFLO2VBQ3REO0lBRU87Ozs7O0lBQ1AsUUFBUSxPQUFPLEtBQUssR0FBRyxNQUN0Qix3QkFBQyxVQUFEO0tBRUUsY0FBWSxTQUFTLElBQUk7S0FDekIsZ0JBQWMsWUFBWSxJQUFJLFNBQVM7S0FDdkMsZUFBZSxTQUFTLENBQUM7S0FDekIsV0FBVTtlQUVWLHdCQUFDLFFBQUQsRUFDRSxXQUFXLG9CQUFvQixZQUFZLElBQUksbUJBQW1CLGtCQUNuRTs7Ozs7SUFDSyxHQVREOzs7O1dBU0MsQ0FDVDtJQUNELHdCQUFDLFVBQUQ7S0FDRSxjQUFZLEVBQUU7S0FDZCxXQUFVO0tBQ1YsZUFBZSxVQUFVLFVBQVUsS0FBSyxLQUFLO2VBQzlDO0lBRU87Ozs7O0lBQ1Isd0JBQUMsVUFBRDtLQUNFLFdBQVU7S0FDVixlQUFlLFdBQVcsVUFBVSxDQUFDLEtBQUs7ZUFFekMsU0FBUyxFQUFFLE9BQU8sRUFBRTtJQUNmOzs7OztHQUNMOzs7OztVQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9tb3Rpb25hbEJhbm5lci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB0eXBlIHsgQmFubmVyU2VjdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL2Jhbm5lci50eXBlcyc7XHJcbmltcG9ydCB7IGJhbm5lckltYWdlVXJsIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2VydmljZXMvYmFubmVyU2VydmljZSc7XHJcbmltcG9ydCB7IFByb2R1Y3RJbWFnZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1Byb2R1Y3RJbWFnZSc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuc3RvcmVmcm9udDtcclxuZXhwb3J0IGZ1bmN0aW9uIFByb21vdGlvbmFsQmFubmVyKHsgc2VjdGlvbiB9OiB7IHNlY3Rpb24/OiBCYW5uZXJTZWN0aW9uIH0pIHtcclxuICBjb25zdCBbaW5kZXgsIHNldEluZGV4XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtwYXVzZWQsIHNldFBhdXNlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2ludGVyYWN0aW5nLCBzZXRJbnRlcmFjdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgdG91Y2hTdGFydCA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBjb3VudCA9IHNlY3Rpb24/LnNsaWRlcy5sZW5ndGggPz8gMDtcclxuICBjb25zdCBjdXJyZW50ID0gY291bnQgPyBpbmRleCAlIGNvdW50IDogMDtcclxuICBjb25zdCBpc0hlcm8gPSBzZWN0aW9uPy5wb3NpdGlvbiA9PT0gJ3RvcCc7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChcclxuICAgICAgY291bnQgPCAyIHx8XHJcbiAgICAgIHBhdXNlZCB8fFxyXG4gICAgICBpbnRlcmFjdGluZyB8fFxyXG4gICAgICB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzXHJcbiAgICApXHJcbiAgICAgIHJldHVybjtcclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgaWYgKCFkb2N1bWVudC5oaWRkZW4pIHNldEluZGV4KCh2YWx1ZSkgPT4gKHZhbHVlICsgMSkgJSBjb3VudCk7XHJcbiAgICB9LCBpc0hlcm8gPyAzNTAwIDogNzAwMCk7XHJcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwodGltZXIpO1xyXG4gIH0sIFtjb3VudCwgcGF1c2VkLCBpbnRlcmFjdGluZywgaXNIZXJvXSk7XHJcbiAgaWYgKCFzZWN0aW9uPy52aXNpYmxlIHx8ICFjb3VudCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3Qgc2xpZGUgPSBzZWN0aW9uLnNsaWRlc1tjdXJyZW50XTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb25cclxuICAgICAgYXJpYS1sYWJlbD17dC5wb3NpdGlvbnNbc2VjdGlvbi5wb3NpdGlvbl19XHJcbiAgICAgIGFyaWEtcm9sZWRlc2NyaXB0aW9uPXtjb3VudCA+IDEgPyAnY2Fyb3VzZWwnIDogdW5kZWZpbmVkfVxyXG4gICAgICBjbGFzc05hbWU9e2BvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSAke2lzSGVybyA/ICdjYW1wYWlnbi1oZXJvJyA6ICcnfWB9XHJcbiAgICAgIG9uTW91c2VFbnRlcj17KCkgPT4gc2V0SW50ZXJhY3RpbmcodHJ1ZSl9XHJcbiAgICAgIG9uTW91c2VMZWF2ZT17KCkgPT4gc2V0SW50ZXJhY3RpbmcoZmFsc2UpfVxyXG4gICAgICBvbkZvY3VzQ2FwdHVyZT17KCkgPT4gc2V0SW50ZXJhY3RpbmcodHJ1ZSl9XHJcbiAgICAgIG9uQmx1ckNhcHR1cmU9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGlmICghZXZlbnQuY3VycmVudFRhcmdldC5jb250YWlucyhldmVudC5yZWxhdGVkVGFyZ2V0KSlcclxuICAgICAgICAgIHNldEludGVyYWN0aW5nKGZhbHNlKTtcclxuICAgICAgfX1cclxuICAgICAgb25Ub3VjaFN0YXJ0PXsoZXZlbnQpID0+IHtcclxuICAgICAgICB0b3VjaFN0YXJ0LmN1cnJlbnQgPSBldmVudC50b3VjaGVzWzBdLmNsaWVudFg7XHJcbiAgICAgICAgaWYgKGlzSGVybykgc2V0SW50ZXJhY3RpbmcodHJ1ZSk7XHJcbiAgICAgICAgZWxzZSBzZXRQYXVzZWQodHJ1ZSk7XHJcbiAgICAgIH19XHJcbiAgICAgIG9uVG91Y2hFbmQ9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gdG91Y2hTdGFydC5jdXJyZW50O1xyXG4gICAgICAgIGNvbnN0IGVuZCA9IGV2ZW50LmNoYW5nZWRUb3VjaGVzWzBdLmNsaWVudFg7XHJcbiAgICAgICAgaWYgKHN0YXJ0ICE9PSBudWxsICYmIE1hdGguYWJzKGVuZCAtIHN0YXJ0KSA+IDUwKVxyXG4gICAgICAgICAgc2V0SW5kZXgoKHZhbHVlKSA9PiAodmFsdWUgKyAoZW5kIDwgc3RhcnQgPyAxIDogY291bnQgLSAxKSkgJSBjb3VudCk7XHJcbiAgICAgICAgdG91Y2hTdGFydC5jdXJyZW50ID0gbnVsbDtcclxuICAgICAgICBpZiAoaXNIZXJvKSBzZXRJbnRlcmFjdGluZyhmYWxzZSk7XHJcbiAgICAgIH19XHJcbiAgICAgIG9uVG91Y2hDYW5jZWw9eygpID0+IHtcclxuICAgICAgICB0b3VjaFN0YXJ0LmN1cnJlbnQgPSBudWxsO1xyXG4gICAgICAgIGlmIChpc0hlcm8pIHNldEludGVyYWN0aW5nKGZhbHNlKTtcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGtleT17Y3VycmVudH1cclxuICAgICAgICBjbGFzc05hbWU9e2BjYW1wYWlnbi1zbGlkZSBtb3Rpb24tc2FmZTphbmltYXRlLWZhZGUtaW4gJHtpc0hlcm8gPyAnY2FtcGFpZ24taGVyby1zbGlkZScgOiAnJ31gfVxyXG4gICAgICAgIHJvbGU9XCJncm91cFwiXHJcbiAgICAgICAgYXJpYS1yb2xlZGVzY3JpcHRpb249XCJzbGlkZVwiXHJcbiAgICAgICAgYXJpYS1sYWJlbD17YCR7Y3VycmVudCArIDF9IG9mICR7Y291bnR9YH1cclxuICAgICAgICBhcmlhLWxpdmU9e3BhdXNlZCB8fCBpbnRlcmFjdGluZyA/ICdwb2xpdGUnIDogJ29mZid9XHJcbiAgICAgID5cclxuICAgICAgICA8UHJvZHVjdEltYWdlXHJcbiAgICAgICAgICBrZXk9e3NsaWRlLmltYWdlVXJsfVxyXG4gICAgICAgICAgc3JjPXtiYW5uZXJJbWFnZVVybChzbGlkZS5pbWFnZVVybCl9XHJcbiAgICAgICAgICBhbHQ9e3NsaWRlLmFsdH1cclxuICAgICAgICAgIGVhZ2VyPXtpc0hlcm99XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BjYW1wYWlnbi1hcnQgdy1mdWxsICR7aXNIZXJvID8gJ2NhbXBhaWduLWhlcm8tYXJ0IG9iamVjdC1jb3ZlciEgb2JqZWN0LXJpZ2h0JyA6ICdhc3BlY3QtWzE2LzVdJ31gfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgeyhzbGlkZS50aXRsZSB8fCBzbGlkZS5kZXNjcmlwdGlvbiB8fCBzbGlkZS5idXR0b25UZXh0KSAmJiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgaXNIZXJvXHJcbiAgICAgICAgICAgICAgICA/ICdjYW1wYWlnbi1oZXJvLWNvcHkgZmxleCBmbGV4LWNvbCBnYXAtNCdcclxuICAgICAgICAgICAgICAgIDogJ2ZsZXggZmxleC1jb2wgZ2FwLTQgYm9yZGVyLXQgYm9yZGVyLWxpbmUtc3VidGxlIHAtNSBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIHNtOnAtOCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIHtzbGlkZS50aXRsZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8aDJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IG1kOnRleHQtM3hsICR7aXNIZXJvID8gJ3RleHQtd2hpdGUnIDogJ3RleHQtZmcnfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzbGlkZS50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7c2xpZGUuZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbXQtMiBtYXgtdy0yeGwgdGV4dC1zbSBsZWFkaW5nLTYgJHtpc0hlcm8gPyAndGV4dC13aGl0ZS85MCcgOiAndGV4dC1mZy1zZWNvbmRhcnknfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzbGlkZS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3NsaWRlLmJ1dHRvblRleHQgJiZcclxuICAgICAgICAgICAgICBzbGlkZS5ocmVmICYmXHJcbiAgICAgICAgICAgICAgKHNsaWRlLmhyZWYuc3RhcnRzV2l0aCgnLycpID8gKFxyXG4gICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2hyaW5rLTAgc2VsZi1zdGFydCByb3VuZGVkLXNtIGJnLXByaW1hcnkgcHgtNSBweS0zIGZvbnQtc2VtaWJvbGQgdGV4dC1wcmltYXJ5LW9uIGhvdmVyOmJnLXByaW1hcnktaG92ZXJcIlxyXG4gICAgICAgICAgICAgICAgICB0bz17c2xpZGUuaHJlZn1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3NsaWRlLmJ1dHRvblRleHR9IOKGklxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMCBzZWxmLXN0YXJ0IHJvdW5kZWQtc20gYmctcHJpbWFyeSBweC01IHB5LTMgZm9udC1zZW1pYm9sZCB0ZXh0LXByaW1hcnktb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlclwiXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9e3NsaWRlLmhyZWZ9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzbGlkZS5idXR0b25UZXh0fSDihpJcclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7IWlzSGVybyAmJiBjb3VudCA+IDEgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgYm9yZGVyLXQgYm9yZGVyLWxpbmUtc3VidGxlIHAtM1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPXt0LnByZXZpb3VzfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4taC0xMSB3LTExIHJvdW5kZWQtc20gaG92ZXI6Ymctc3VidGxlXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5kZXgoKGN1cnJlbnQgKyBjb3VudCAtIDEpICUgY291bnQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICDihpBcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAge3NlY3Rpb24uc2xpZGVzLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BTbGlkZSAke2kgKyAxfWB9XHJcbiAgICAgICAgICAgICAgYXJpYS1jdXJyZW50PXtjdXJyZW50ID09PSBpID8gJ3RydWUnIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEluZGV4KGkpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMTEgdy03IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC0yIHJvdW5kZWQtZnVsbCAke2N1cnJlbnQgPT09IGkgPyAndy02IGJnLXByaW1hcnknIDogJ3ctMiBiZy1zdW5rZW4nfWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17dC5uZXh0fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4taC0xMSB3LTExIHJvdW5kZWQtc20gaG92ZXI6Ymctc3VidGxlXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5kZXgoKGN1cnJlbnQgKyAxKSAlIGNvdW50KX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAg4oaSXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1zbSBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LWZnLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhdXNlZCgodmFsdWUpID0+ICF2YWx1ZSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtwYXVzZWQgPyB0LnBsYXkgOiB0LnBhdXNlfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=