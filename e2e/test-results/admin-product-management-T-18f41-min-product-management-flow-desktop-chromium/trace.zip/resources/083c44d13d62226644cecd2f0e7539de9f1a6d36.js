import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx");const useId = __vite__cjsImport0_react["useId"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { defaultSpecificationValue } from "/src/pages/Admin/Products/Edit/helpers/product-edit.helpers.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const t = translations.productEdit;
const kinds = [
	{
		value: "text",
		label: t.text
	},
	{
		value: "number",
		label: t.number
	},
	{
		value: "boolean",
		label: t.boolean
	},
	{
		value: "group",
		label: t.group
	},
	{
		value: "list",
		label: t.list
	},
	{
		value: "empty",
		label: t.empty
	}
];
function SpecificationValue({ draft, onChange }) {
	_s();
	const id = useId();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-w-0 space-y-3",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-3 sm:grid-cols-[140px_1fr]",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "auth-label",
						htmlFor: `${id}-type`,
						children: t.type
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: `${id}-type`,
						className: "ui-field auth-input",
						value: draft.kind,
						onChange: (event) => {
							const selected = kinds.find((kind) => kind.value === event.target.value);
							if (selected) onChange(defaultSpecificationValue(selected.value));
						},
						children: [draft.kind === "preserved" && /* @__PURE__ */ _jsxDEV("option", {
							value: "preserved",
							children: t.keepExisting
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 15
						}, this), kinds.map((kind) => /* @__PURE__ */ _jsxDEV("option", {
							value: kind.value,
							children: kind.label
						}, kind.value, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 9
					}, this),
					(draft.kind === "text" || draft.kind === "number") && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "auth-label",
						htmlFor: `${id}-value`,
						children: t.value
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: `${id}-value`,
						type: draft.kind === "number" ? "number" : "text",
						step: draft.kind === "number" ? "any" : undefined,
						required: draft.kind === "number",
						className: "ui-field auth-input",
						value: draft.text,
						onChange: (event) => onChange({
							...draft,
							text: event.target.value
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this),
					draft.kind === "boolean" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "auth-label",
						htmlFor: `${id}-value`,
						children: t.value
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: `${id}-value`,
						className: "ui-field auth-input",
						value: String(draft.value),
						onChange: (event) => onChange({
							kind: "boolean",
							value: event.target.value === "true"
						}),
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "true",
							children: translations.productDetails.yes
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("option", {
							value: "false",
							children: translations.productDetails.no
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this),
					draft.kind === "empty" && /* @__PURE__ */ _jsxDEV("p", {
						className: "self-end py-3 text-sm text-fg-muted",
						children: t.empty
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 11
					}, this),
					draft.kind === "preserved" && /* @__PURE__ */ _jsxDEV("p", {
						className: "self-end py-3 text-sm text-fg-muted",
						children: t.specificationDepth
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 7
			}, this),
			draft.kind === "group" && /* @__PURE__ */ _jsxDEV(SpecificationEntries, {
				entries: draft.entries,
				onChange: (entries) => onChange({
					kind: "group",
					entries
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 9
			}, this),
			draft.kind === "list" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3 border-l-2 border-line pl-3 sm:pl-5",
				children: [draft.items.map((item, index) => /* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-sm border border-line bg-surface p-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-medium text-fg-muted",
							children: [
								t.listItem,
								" ",
								index + 1
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "text-sm font-medium text-danger hover:text-danger",
							"aria-label": `${t.remove}: ${t.listItem} ${index + 1}`,
							onClick: () => onChange({
								...draft,
								items: draft.items.filter((_, itemIndex) => itemIndex !== index)
							}),
							children: t.remove
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(SpecificationValue, {
						draft: item,
						onChange: (value) => onChange({
							...draft,
							items: draft.items.map((current, itemIndex) => itemIndex === index ? value : current)
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 15
					}, this)]
				}, index, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 13
				}, this)), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "auth-secondary h-auto min-min-h-11 max-w-full whitespace-normal py-2 text-center",
					onClick: () => onChange({
						...draft,
						items: [...draft.items, {
							kind: "text",
							text: ""
						}]
					}),
					children: t.addItem
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_s(SpecificationValue, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=");
_c = SpecificationValue;
export function SpecificationEntries({ entries, onChange }) {
	_s2();
	const id = useId();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [entries.map((entry, index) => /* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-sm border border-line bg-page p-3 sm:p-4",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-4 flex items-end gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "auth-label",
						htmlFor: `${id}-${index}-name`,
						children: t.property
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: `${id}-${index}-name`,
						required: true,
						className: "ui-field auth-input",
						value: entry.name,
						onChange: (event) => onChange(entries.map((current, entryIndex) => entryIndex === index ? {
							...entry,
							name: event.target.value
						} : current))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 180,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "mb-2 text-sm font-medium text-danger hover:text-danger",
					"aria-label": `${t.remove}: ${entry.name || t.property}`,
					onClick: () => onChange(entries.filter((_, entryIndex) => entryIndex !== index)),
					children: t.remove
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV(SpecificationValue, {
				draft: entry.value,
				onChange: (value) => onChange(entries.map((current, entryIndex) => entryIndex === index ? {
					...entry,
					value
				} : current))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 11
			}, this)]
		}, index, true, {
			fileName: _jsxFileName,
			lineNumber: 175,
			columnNumber: 9
		}, this)), /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "auth-secondary h-auto min-min-h-11 max-w-full whitespace-normal py-2 text-center",
			onClick: () => onChange([...entries, {
				name: "",
				value: {
					kind: "text",
					text: ""
				}
			}]),
			children: t.addSpecification
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 225,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 173,
		columnNumber: 5
	}, this);
}
_s2(SpecificationEntries, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=");
_c2 = SpecificationEntries;
var _c, _c2;
$RefreshReg$(_c, "SpecificationValue");
$RefreshReg$(_c2, "SpecificationEntries");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBS3RCLFNBQVMsaUNBQWlDO0FBQzFDLFNBQVMsb0JBQW9COzs7O0FBQzdCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE1BQU0sUUFBZ0U7Q0FDcEU7RUFBRSxPQUFPO0VBQVEsT0FBTyxFQUFFO0NBQUs7Q0FDL0I7RUFBRSxPQUFPO0VBQVUsT0FBTyxFQUFFO0NBQU87Q0FDbkM7RUFBRSxPQUFPO0VBQVcsT0FBTyxFQUFFO0NBQVE7Q0FDckM7RUFBRSxPQUFPO0VBQVMsT0FBTyxFQUFFO0NBQU07Q0FDakM7RUFBRSxPQUFPO0VBQVEsT0FBTyxFQUFFO0NBQUs7Q0FDL0I7RUFBRSxPQUFPO0VBQVMsT0FBTyxFQUFFO0NBQU07QUFDbkM7QUFDQSxTQUFTLG1CQUFtQixFQUMxQixPQUNBLFlBSUM7O0NBQ0QsTUFBTSxLQUFLLE1BQU07Q0FDakIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtNQUFhLFNBQVMsR0FBRyxHQUFHO2dCQUMxQyxFQUFFO0tBQ0U7Ozs7ZUFDUCx3QkFBQyxVQUFEO01BQ0UsSUFBSSxHQUFHLEdBQUc7TUFDVixXQUFVO01BQ1YsT0FBTyxNQUFNO01BQ2IsV0FBVyxVQUFVO09BQ25CLE1BQU0sV0FBVyxNQUFNLE1BQ3BCLFNBQVMsS0FBSyxVQUFVLE1BQU0sT0FBTyxLQUN4QztPQUNBLElBQUksVUFBVSxTQUFTLDBCQUEwQixTQUFTLEtBQUssQ0FBQztNQUNsRTtnQkFURixDQVdHLE1BQU0sU0FBUyxlQUNkLHdCQUFDLFVBQUQ7T0FBUSxPQUFNO2lCQUFhLEVBQUU7TUFBcUI7Ozs7Z0JBRW5ELE1BQU0sS0FBSyxTQUNWLHdCQUFDLFVBQUQ7T0FBeUIsT0FBTyxLQUFLO2lCQUNsQyxLQUFLO01BQ0EsR0FGSyxLQUFLOzs7O2FBRVYsQ0FDVCxDQUNLOzs7OzthQUNMOzs7OztNQUNILE1BQU0sU0FBUyxVQUFVLE1BQU0sU0FBUyxhQUN4Qyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7TUFBYSxTQUFTLEdBQUcsR0FBRztnQkFDMUMsRUFBRTtLQUNFOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUNFLElBQUksR0FBRyxHQUFHO01BQ1YsTUFBTSxNQUFNLFNBQVMsV0FBVyxXQUFXO01BQzNDLE1BQU0sTUFBTSxTQUFTLFdBQVcsUUFBUTtNQUN4QyxVQUFVLE1BQU0sU0FBUztNQUN6QixXQUFVO01BQ1YsT0FBTyxNQUFNO01BQ2IsV0FBVyxVQUNULFNBQVM7T0FBRSxHQUFHO09BQU8sTUFBTSxNQUFNLE9BQU87TUFBTSxDQUFDO0tBRWxEOzs7O2FBQ0U7Ozs7O0tBRU4sTUFBTSxTQUFTLGFBQ2Qsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO01BQWEsU0FBUyxHQUFHLEdBQUc7Z0JBQzFDLEVBQUU7S0FDRTs7OztlQUNQLHdCQUFDLFVBQUQ7TUFDRSxJQUFJLEdBQUcsR0FBRztNQUNWLFdBQVU7TUFDVixPQUFPLE9BQU8sTUFBTSxLQUFLO01BQ3pCLFdBQVcsVUFDVCxTQUFTO09BQ1AsTUFBTTtPQUNOLE9BQU8sTUFBTSxPQUFPLFVBQVU7TUFDaEMsQ0FBQztnQkFSTCxDQVdFLHdCQUFDLFVBQUQ7T0FBUSxPQUFNO2lCQUFRLGFBQWEsZUFBZTtNQUFZOzs7O2dCQUM5RCx3QkFBQyxVQUFEO09BQVEsT0FBTTtpQkFBUyxhQUFhLGVBQWU7TUFBVzs7OztjQUN4RDs7Ozs7YUFDTDs7Ozs7S0FFTixNQUFNLFNBQVMsV0FDZCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBdUMsRUFBRTtLQUFTOzs7OztLQUVoRSxNQUFNLFNBQVMsZUFDZCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixFQUFFO0tBQ0Y7Ozs7O0lBRUY7Ozs7OztHQUNKLE1BQU0sU0FBUyxXQUNkLHdCQUFDLHNCQUFEO0lBQ0UsU0FBUyxNQUFNO0lBQ2YsV0FBVyxZQUFZLFNBQVM7S0FBRSxNQUFNO0tBQVM7SUFBUSxDQUFDO0dBQzNEOzs7OztHQUVGLE1BQU0sU0FBUyxVQUNkLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRyxNQUFNLE1BQU0sS0FBSyxNQUFNLFVBQ3RCLHdCQUFDLE9BQUQ7S0FFRSxXQUFVO2VBRlosQ0FJRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQjtRQUNHLEVBQUU7UUFBUztRQUFFLFFBQVE7T0FDbEI7Ozs7O2dCQUNOLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtPQUNWLGNBQVksR0FBRyxFQUFFLE9BQU8sSUFBSSxFQUFFLFNBQVMsR0FBRyxRQUFRO09BQ2xELGVBQ0UsU0FBUztRQUNQLEdBQUc7UUFDSCxPQUFPLE1BQU0sTUFBTSxRQUNoQixHQUFHLGNBQWMsY0FBYyxLQUNsQztPQUNGLENBQUM7aUJBR0YsRUFBRTtNQUNHOzs7O2NBQ0w7Ozs7O2VBQ0wsd0JBQUMsb0JBQUQ7TUFDRSxPQUFPO01BQ1AsV0FBVyxVQUNULFNBQVM7T0FDUCxHQUFHO09BQ0gsT0FBTyxNQUFNLE1BQU0sS0FBSyxTQUFTLGNBQy9CLGNBQWMsUUFBUSxRQUFRLE9BQ2hDO01BQ0YsQ0FBQztLQUVKOzs7O2FBQ0U7T0FsQ0U7Ozs7V0FrQ0YsQ0FDTixHQUNELHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtLQUNWLGVBQ0UsU0FBUztNQUNQLEdBQUc7TUFDSCxPQUFPLENBQUMsR0FBRyxNQUFNLE9BQU87T0FBRSxNQUFNO09BQVEsTUFBTTtNQUFHLENBQUM7S0FDcEQsQ0FBQztlQUdGLEVBQUU7SUFDRzs7OztZQUNMOzs7Ozs7RUFFSjs7Ozs7O0FBRVQ7OztBQUNBLE9BQU8sU0FBUyxxQkFBcUIsRUFDbkMsU0FDQSxZQUlDOztDQUNELE1BQU0sS0FBSyxNQUFNO0NBQ2pCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNHLFFBQVEsS0FBSyxPQUFPLFVBQ25CLHdCQUFDLE9BQUQ7R0FFRSxXQUFVO2FBRlosQ0FJRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO01BQWEsU0FBUyxHQUFHLEdBQUcsR0FBRyxNQUFNO2dCQUNuRCxFQUFFO0tBQ0U7Ozs7ZUFDUCx3QkFBQyxTQUFEO01BQ0UsSUFBSSxHQUFHLEdBQUcsR0FBRyxNQUFNO01BQ25CO01BQ0EsV0FBVTtNQUNWLE9BQU8sTUFBTTtNQUNiLFdBQVcsVUFDVCxTQUNFLFFBQVEsS0FBSyxTQUFTLGVBQ3BCLGVBQWUsUUFDWDtPQUFFLEdBQUc7T0FBTyxNQUFNLE1BQU0sT0FBTztNQUFNLElBQ3JDLE9BQ04sQ0FDRjtLQUVIOzs7O2FBQ0U7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsY0FBWSxHQUFHLEVBQUUsT0FBTyxJQUFJLE1BQU0sUUFBUSxFQUFFO0tBQzVDLGVBQ0UsU0FDRSxRQUFRLFFBQVEsR0FBRyxlQUFlLGVBQWUsS0FBSyxDQUN4RDtlQUdELEVBQUU7SUFDRzs7OztZQUNMOzs7OzthQUNMLHdCQUFDLG9CQUFEO0lBQ0UsT0FBTyxNQUFNO0lBQ2IsV0FBVyxVQUNULFNBQ0UsUUFBUSxLQUFLLFNBQVMsZUFDcEIsZUFBZSxRQUFRO0tBQUUsR0FBRztLQUFPO0lBQU0sSUFBSSxPQUMvQyxDQUNGO0dBRUg7Ozs7V0FDRTtLQS9DRTs7OztTQStDRixDQUNOLEdBQ0Qsd0JBQUMsVUFBRDtHQUNFLE1BQUs7R0FDTCxXQUFVO0dBQ1YsZUFDRSxTQUFTLENBQ1AsR0FBRyxTQUNIO0lBQUUsTUFBTTtJQUFJLE9BQU87S0FBRSxNQUFNO0tBQVEsTUFBTTtJQUFHO0dBQUUsQ0FDaEQsQ0FBQzthQUdGLEVBQUU7RUFDRzs7OztVQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTcGVjaWZpY2F0aW9uRWRpdG9yLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VJZCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHR5cGUge1xyXG4gIFNwZWNpZmljYXRpb25EcmFmdCxcclxuICBTcGVjaWZpY2F0aW9uRW50cnlEcmFmdCxcclxufSBmcm9tICcuLi90eXBlcy9wcm9kdWN0LWVkaXQudHlwZXMnO1xyXG5pbXBvcnQgeyBkZWZhdWx0U3BlY2lmaWNhdGlvblZhbHVlIH0gZnJvbSAnLi4vaGVscGVycy9wcm9kdWN0LWVkaXQuaGVscGVycyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMucHJvZHVjdEVkaXQ7XHJcbmNvbnN0IGtpbmRzOiB7IHZhbHVlOiBTcGVjaWZpY2F0aW9uRHJhZnRbJ2tpbmQnXTsgbGFiZWw6IHN0cmluZyB9W10gPSBbXHJcbiAgeyB2YWx1ZTogJ3RleHQnLCBsYWJlbDogdC50ZXh0IH0sXHJcbiAgeyB2YWx1ZTogJ251bWJlcicsIGxhYmVsOiB0Lm51bWJlciB9LFxyXG4gIHsgdmFsdWU6ICdib29sZWFuJywgbGFiZWw6IHQuYm9vbGVhbiB9LFxyXG4gIHsgdmFsdWU6ICdncm91cCcsIGxhYmVsOiB0Lmdyb3VwIH0sXHJcbiAgeyB2YWx1ZTogJ2xpc3QnLCBsYWJlbDogdC5saXN0IH0sXHJcbiAgeyB2YWx1ZTogJ2VtcHR5JywgbGFiZWw6IHQuZW1wdHkgfSxcclxuXTtcclxuZnVuY3Rpb24gU3BlY2lmaWNhdGlvblZhbHVlKHtcclxuICBkcmFmdCxcclxuICBvbkNoYW5nZSxcclxufToge1xyXG4gIGRyYWZ0OiBTcGVjaWZpY2F0aW9uRHJhZnQ7XHJcbiAgb25DaGFuZ2U6ICh2YWx1ZTogU3BlY2lmaWNhdGlvbkRyYWZ0KSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgaWQgPSB1c2VJZCgpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgc3BhY2UteS0zXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBzbTpncmlkLWNvbHMtWzE0MHB4XzFmcl1cIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIiBodG1sRm9yPXtgJHtpZH0tdHlwZWB9PlxyXG4gICAgICAgICAgICB7dC50eXBlfVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgaWQ9e2Ake2lkfS10eXBlYH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgYXV0aC1pbnB1dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtkcmFmdC5raW5kfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPSBraW5kcy5maW5kKFxyXG4gICAgICAgICAgICAgICAgKGtpbmQpID0+IGtpbmQudmFsdWUgPT09IGV2ZW50LnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIGlmIChzZWxlY3RlZCkgb25DaGFuZ2UoZGVmYXVsdFNwZWNpZmljYXRpb25WYWx1ZShzZWxlY3RlZC52YWx1ZSkpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7ZHJhZnQua2luZCA9PT0gJ3ByZXNlcnZlZCcgJiYgKFxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwcmVzZXJ2ZWRcIj57dC5rZWVwRXhpc3Rpbmd9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtraW5kcy5tYXAoKGtpbmQpID0+IChcclxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17a2luZC52YWx1ZX0gdmFsdWU9e2tpbmQudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAge2tpbmQubGFiZWx9XHJcbiAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgeyhkcmFmdC5raW5kID09PSAndGV4dCcgfHwgZHJhZnQua2luZCA9PT0gJ251bWJlcicpICYmIChcclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCIgaHRtbEZvcj17YCR7aWR9LXZhbHVlYH0+XHJcbiAgICAgICAgICAgICAge3QudmFsdWV9XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIGlkPXtgJHtpZH0tdmFsdWVgfVxyXG4gICAgICAgICAgICAgIHR5cGU9e2RyYWZ0LmtpbmQgPT09ICdudW1iZXInID8gJ251bWJlcicgOiAndGV4dCd9XHJcbiAgICAgICAgICAgICAgc3RlcD17ZHJhZnQua2luZCA9PT0gJ251bWJlcicgPyAnYW55JyA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICByZXF1aXJlZD17ZHJhZnQua2luZCA9PT0gJ251bWJlcid9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgYXV0aC1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0LnRleHR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlKHsgLi4uZHJhZnQsIHRleHQ6IGV2ZW50LnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2RyYWZ0LmtpbmQgPT09ICdib29sZWFuJyAmJiAoXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiIGh0bWxGb3I9e2Ake2lkfS12YWx1ZWB9PlxyXG4gICAgICAgICAgICAgIHt0LnZhbHVlfVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgaWQ9e2Ake2lkfS12YWx1ZWB9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgYXV0aC1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e1N0cmluZyhkcmFmdC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlKHtcclxuICAgICAgICAgICAgICAgICAga2luZDogJ2Jvb2xlYW4nLFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogZXZlbnQudGFyZ2V0LnZhbHVlID09PSAndHJ1ZScsXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0cnVlXCI+e3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy55ZXN9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImZhbHNlXCI+e3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5ub308L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtkcmFmdC5raW5kID09PSAnZW1wdHknICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlbGYtZW5kIHB5LTMgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3QuZW1wdHl9PC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2RyYWZ0LmtpbmQgPT09ICdwcmVzZXJ2ZWQnICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlbGYtZW5kIHB5LTMgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHt0LnNwZWNpZmljYXRpb25EZXB0aH1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge2RyYWZ0LmtpbmQgPT09ICdncm91cCcgJiYgKFxyXG4gICAgICAgIDxTcGVjaWZpY2F0aW9uRW50cmllc1xyXG4gICAgICAgICAgZW50cmllcz17ZHJhZnQuZW50cmllc31cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZW50cmllcykgPT4gb25DaGFuZ2UoeyBraW5kOiAnZ3JvdXAnLCBlbnRyaWVzIH0pfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHtkcmFmdC5raW5kID09PSAnbGlzdCcgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIGJvcmRlci1sLTIgYm9yZGVyLWxpbmUgcGwtMyBzbTpwbC01XCI+XHJcbiAgICAgICAgICB7ZHJhZnQuaXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtM1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAge3QubGlzdEl0ZW19IHtpbmRleCArIDF9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZGFuZ2VyIGhvdmVyOnRleHQtZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dC5yZW1vdmV9OiAke3QubGlzdEl0ZW19ICR7aW5kZXggKyAxfWB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4uZHJhZnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZHJhZnQuaXRlbXMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoXywgaXRlbUluZGV4KSA9PiBpdGVtSW5kZXggIT09IGluZGV4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt0LnJlbW92ZX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxTcGVjaWZpY2F0aW9uVmFsdWVcclxuICAgICAgICAgICAgICAgIGRyYWZ0PXtpdGVtfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLmRyYWZ0LFxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBkcmFmdC5pdGVtcy5tYXAoKGN1cnJlbnQsIGl0ZW1JbmRleCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGl0ZW1JbmRleCA9PT0gaW5kZXggPyB2YWx1ZSA6IGN1cnJlbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnkgaC1hdXRvIG1pbi1taW4taC0xMSBtYXgtdy1mdWxsIHdoaXRlc3BhY2Utbm9ybWFsIHB5LTIgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlKHtcclxuICAgICAgICAgICAgICAgIC4uLmRyYWZ0LFxyXG4gICAgICAgICAgICAgICAgaXRlbXM6IFsuLi5kcmFmdC5pdGVtcywgeyBraW5kOiAndGV4dCcsIHRleHQ6ICcnIH1dLFxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3QuYWRkSXRlbX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gU3BlY2lmaWNhdGlvbkVudHJpZXMoe1xyXG4gIGVudHJpZXMsXHJcbiAgb25DaGFuZ2UsXHJcbn06IHtcclxuICBlbnRyaWVzOiBTcGVjaWZpY2F0aW9uRW50cnlEcmFmdFtdO1xyXG4gIG9uQ2hhbmdlOiAoZW50cmllczogU3BlY2lmaWNhdGlvbkVudHJ5RHJhZnRbXSkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAge2VudHJpZXMubWFwKChlbnRyeSwgaW5kZXgpID0+IChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgYmctcGFnZSBwLTMgc206cC00XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgZmxleCBpdGVtcy1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCIgaHRtbEZvcj17YCR7aWR9LSR7aW5kZXh9LW5hbWVgfT5cclxuICAgICAgICAgICAgICAgIHt0LnByb3BlcnR5fVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD17YCR7aWR9LSR7aW5kZXh9LW5hbWVgfVxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2VudHJ5Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICBlbnRyaWVzLm1hcCgoY3VycmVudCwgZW50cnlJbmRleCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGVudHJ5SW5kZXggPT09IGluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5lbnRyeSwgbmFtZTogZXZlbnQudGFyZ2V0LnZhbHVlIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBjdXJyZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWRhbmdlciBob3Zlcjp0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dC5yZW1vdmV9OiAke2VudHJ5Lm5hbWUgfHwgdC5wcm9wZXJ0eX1gfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgZW50cmllcy5maWx0ZXIoKF8sIGVudHJ5SW5kZXgpID0+IGVudHJ5SW5kZXggIT09IGluZGV4KSxcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dC5yZW1vdmV9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8U3BlY2lmaWNhdGlvblZhbHVlXHJcbiAgICAgICAgICAgIGRyYWZ0PXtlbnRyeS52YWx1ZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICBvbkNoYW5nZShcclxuICAgICAgICAgICAgICAgIGVudHJpZXMubWFwKChjdXJyZW50LCBlbnRyeUluZGV4KSA9PlxyXG4gICAgICAgICAgICAgICAgICBlbnRyeUluZGV4ID09PSBpbmRleCA/IHsgLi4uZW50cnksIHZhbHVlIH0gOiBjdXJyZW50LFxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnkgaC1hdXRvIG1pbi1taW4taC0xMSBtYXgtdy1mdWxsIHdoaXRlc3BhY2Utbm9ybWFsIHB5LTIgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICBvbkNoYW5nZShbXHJcbiAgICAgICAgICAgIC4uLmVudHJpZXMsXHJcbiAgICAgICAgICAgIHsgbmFtZTogJycsIHZhbHVlOiB7IGtpbmQ6ICd0ZXh0JywgdGV4dDogJycgfSB9LFxyXG4gICAgICAgICAgXSlcclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICB7dC5hZGRTcGVjaWZpY2F0aW9ufVxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19