import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Cart/components/CartSummary.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/components/common/Icon.tsx";
import { CartBenefits } from "/src/pages/Customer/Cart/components/CartBenefits.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartSummary.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.cart;
export function CartSummary({ cart, busy }) {
	return /* @__PURE__ */ _jsxDEV("aside", {
		"aria-label": t.summary,
		"aria-busy": busy,
		className: "cart-summary rounded-lg border border-line bg-surface p-6 lg:sticky lg:top-24",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				id: "cart-summary",
				className: "flex items-center gap-3 text-xl font-semibold text-fg",
				children: [/* @__PURE__ */ _jsxDEV(Icon, {
					name: "bag",
					className: "h-7 w-7 text-fg-link"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this), t.orderSummary]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-muted",
				children: [
					cart.itemCount,
					" ",
					cart.itemCount === 1 ? t.product : t.products
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("dl", {
				className: "mt-6 border-y border-line py-5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ _jsxDEV("dt", {
						className: "font-medium text-fg-secondary",
						children: t.subtotal
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("dd", {
						className: "break-all text-lg font-semibold tracking-tight text-fg",
						children: formatCurrency(cart.subtotal)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex flex-wrap justify-between gap-2 text-sm",
					children: [/* @__PURE__ */ _jsxDEV("dt", {
						className: "text-fg-muted",
						children: t.delivery
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("dd", {
						className: "text-fg-secondary",
						children: t.deliveryHint
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-5 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-semibold text-fg",
					children: t.total
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "price text-2xl font-bold text-fg",
					children: formatCurrency(cart.subtotal)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 7
			}, this),
			cart.items.some((item) => !item.isAvailable) && /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-4 text-sm text-danger",
				children: "Remove unavailable items to continue."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cart-checkout-bar",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "cart-mobile-total",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs text-fg-muted",
						children: "Total"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "price text-sm font-semibold",
						children: formatCurrency(cart.subtotal)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this), busy || cart.items.some((item) => !item.isAvailable) ? /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled: true,
					className: "auth-primary mt-5 w-full cart-checkout-action",
					children: [translations.checkout.proceed, /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.checkout,
					className: "auth-primary mt-5 w-full cart-checkout-action",
					children: [translations.checkout.proceed, /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6",
				children: /* @__PURE__ */ _jsxDEV(CartBenefits, { compact: true }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-xs leading-5 text-fg-muted",
				children: t.stockNotice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_c = CartSummary;
var _c;
$RefreshReg$(_c, "CartSummary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Cart/components/CartSummary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartSummary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartSummary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartSummary.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGNBQWM7QUFFdkIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsWUFBWSxFQUFFLE1BQU0sUUFBdUM7Q0FDekUsT0FDRSx3QkFBQyxTQUFEO0VBQ0UsY0FBWSxFQUFFO0VBQ2QsYUFBVztFQUNYLFdBQVU7WUFIWjtHQUtFLHdCQUFDLE1BQUQ7SUFDRSxJQUFHO0lBQ0gsV0FBVTtjQUZaLENBSUUsd0JBQUMsTUFBRDtLQUFNLE1BQUs7S0FBTSxXQUFVO0lBQXdCOzs7O2NBQ2xELEVBQUUsWUFDRDs7Ozs7O0dBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYjtLQUNHLEtBQUs7S0FBVTtLQUFFLEtBQUssY0FBYyxJQUFJLEVBQUUsVUFBVSxFQUFFO0lBQ3REOzs7Ozs7R0FDSCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFkLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQyxFQUFFO0tBQWE7Ozs7ZUFDOUQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsZUFBZSxLQUFLLFFBQVE7S0FDM0I7Ozs7YUFDRDs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWlCLEVBQUU7S0FBYTs7OztlQUM5Qyx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBcUIsRUFBRTtLQUFpQjs7OzthQUNuRDs7Ozs7WUFDSDs7Ozs7O0dBQ0osd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXlCLEVBQUU7SUFBWTs7OztjQUN2RCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNiLGVBQWUsS0FBSyxRQUFRO0lBQ3pCOzs7O1lBQ0g7Ozs7OztHQUNKLEtBQUssTUFBTSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVcsS0FDMUMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBMkI7R0FFckM7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBd0I7S0FBVzs7OztlQUNuRCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFDYixlQUFlLEtBQUssUUFBUTtLQUN6Qjs7OzthQUNIOzs7OztjQUNKLFFBQVEsS0FBSyxNQUFNLE1BQU0sU0FBUyxDQUFDLEtBQUssV0FBVyxJQUNsRCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMO0tBQ0EsV0FBVTtlQUhaLENBS0csYUFBYSxTQUFTLFNBQ3ZCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7YUFDZDs7Ozs7ZUFFUix3QkFBQyxNQUFEO0tBQ0UsSUFBSSxPQUFPO0tBQ1gsV0FBVTtlQUZaLENBSUcsYUFBYSxTQUFTLFNBQ3ZCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7YUFDaEI7Ozs7O1lBRUw7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsY0FBRCxFQUFjLGNBQVM7Ozs7O0dBQ3BCOzs7OztHQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXdDLEVBQUU7R0FBZTs7Ozs7RUFDakU7Ozs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcnRTdW1tYXJ5LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IENhcnRCZW5lZml0cyB9IGZyb20gJy4vQ2FydEJlbmVmaXRzJztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHR5cGUgeyBDYXJ0IH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvY2FydC50eXBlcyc7XHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvY3VycmVuY3knO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmNhcnQ7XHJcbmV4cG9ydCBmdW5jdGlvbiBDYXJ0U3VtbWFyeSh7IGNhcnQsIGJ1c3kgfTogeyBjYXJ0OiBDYXJ0OyBidXN5OiBib29sZWFuIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGFzaWRlXHJcbiAgICAgIGFyaWEtbGFiZWw9e3Quc3VtbWFyeX1cclxuICAgICAgYXJpYS1idXN5PXtidXN5fVxyXG4gICAgICBjbGFzc05hbWU9XCJjYXJ0LXN1bW1hcnkgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTYgbGc6c3RpY2t5IGxnOnRvcC0yNFwiXHJcbiAgICA+XHJcbiAgICAgIDxoMlxyXG4gICAgICAgIGlkPVwiY2FydC1zdW1tYXJ5XCJcclxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiXHJcbiAgICAgID5cclxuICAgICAgICA8SWNvbiBuYW1lPVwiYmFnXCIgY2xhc3NOYW1lPVwiaC03IHctNyB0ZXh0LWZnLWxpbmtcIiAvPlxyXG4gICAgICAgIHt0Lm9yZGVyU3VtbWFyeX1cclxuICAgICAgPC9oMj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICB7Y2FydC5pdGVtQ291bnR9IHtjYXJ0Lml0ZW1Db3VudCA9PT0gMSA/IHQucHJvZHVjdCA6IHQucHJvZHVjdHN9XHJcbiAgICAgIDwvcD5cclxuICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTYgYm9yZGVyLXkgYm9yZGVyLWxpbmUgcHktNVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtYmFzZWxpbmUganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIj57dC5zdWJ0b3RhbH08L2R0PlxyXG4gICAgICAgICAgPGRkIGNsYXNzTmFtZT1cImJyZWFrLWFsbCB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koY2FydC5zdWJ0b3RhbCl9XHJcbiAgICAgICAgICA8L2RkPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtZmctbXV0ZWRcIj57dC5kZWxpdmVyeX08L2R0PlxyXG4gICAgICAgICAgPGRkIGNsYXNzTmFtZT1cInRleHQtZmctc2Vjb25kYXJ5XCI+e3QuZGVsaXZlcnlIaW50fTwvZGQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3QudG90YWx9PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByaWNlIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koY2FydC5zdWJ0b3RhbCl9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge2NhcnQuaXRlbXMuc29tZSgoaXRlbSkgPT4gIWl0ZW0uaXNBdmFpbGFibGUpICYmIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgIFJlbW92ZSB1bmF2YWlsYWJsZSBpdGVtcyB0byBjb250aW51ZS5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1jaGVja291dC1iYXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtbW9iaWxlLXRvdGFsXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5Ub3RhbDwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByaWNlIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koY2FydC5zdWJ0b3RhbCl9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2J1c3kgfHwgY2FydC5pdGVtcy5zb21lKChpdGVtKSA9PiAhaXRlbS5pc0F2YWlsYWJsZSkgPyAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnkgbXQtNSB3LWZ1bGwgY2FydC1jaGVja291dC1hY3Rpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dHJhbnNsYXRpb25zLmNoZWNrb3V0LnByb2NlZWR9XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5jaGVja291dH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IG10LTUgdy1mdWxsIGNhcnQtY2hlY2tvdXQtYWN0aW9uXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jaGVja291dC5wcm9jZWVkfVxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiYXJyb3dcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICA8Q2FydEJlbmVmaXRzIGNvbXBhY3QgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyBsZWFkaW5nLTUgdGV4dC1mZy1tdXRlZFwiPnt0LnN0b2NrTm90aWNlfTwvcD5cclxuICAgIDwvYXNpZGU+XHJcbiAgKTtcclxufVxyXG4iXX0=