import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/components/ProductForm.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { ProductFields } from "/src/pages/Admin/Products/components/ProductFields.tsx";
import { translations } from "/src/utils/translations.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductForm.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.admin;
export function ProductForm({ page }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "bg-surface",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "mb-5 text-xl font-semibold text-fg",
				children: t.addProduct
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			page.categories.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-fg-secondary",
				children: [
					t.categoryRequired,
					" ",
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.adminCategories,
						className: "font-medium text-fg-link",
						children: t.addCategory
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: page.submit,
				children: /* @__PURE__ */ _jsxDEV("fieldset", {
					disabled: page.busy,
					className: "grid gap-5 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ _jsxDEV(ProductFields, {
							onUploadState: page.setUploading,
							draft: page.draft,
							categories: page.categories,
							onChange: (field, value) => page.setDraft({
								...page.draft,
								[field]: value
							}),
							onPendingFilesChange: (files) => page.setDraft({
								...page.draft,
								pendingImages: files
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "stockQty",
							className: "auth-label",
							children: t.initialStock
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "stockQty",
							type: "number",
							min: 0,
							max: 2147483647,
							step: 1,
							required: true,
							className: "ui-field auth-input",
							value: page.draft.stockQty,
							onChange: (event) => page.setDraft({
								...page.draft,
								stockQty: event.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "specifications",
								className: "auth-label",
								children: t.specifications
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								id: "specifications",
								rows: 3,
								className: "ui-field auth-input h-auto py-2",
								value: page.draft.specifications,
								onChange: (event) => page.setDraft({
									...page.draft,
									specifications: event.target.value
								}),
								"aria-describedby": "spec-hint"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								id: "spec-hint",
								className: "mt-2 text-xs text-fg-muted",
								children: t.specificationsHint
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ _jsxDEV("button", {
								className: "auth-primary",
								type: "submit",
								children: [page.busy && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 31
								}, this), page.busy ? t.saving : t.addProduct]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this),
			page.formError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mt-4 text-sm text-danger",
				children: page.formError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this),
			page.success && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "mt-4 text-sm text-success",
				children: page.success
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = ProductForm;
var _c;
$RefreshReg$(_c, "ProductForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/components/ProductForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMscUJBQXFCO0FBRTlCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsY0FBYztBQUN2QixTQUFTLFlBQVk7OztBQUNyQixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsWUFBWSxFQUMxQixRQUdDO0NBQ0QsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXNDLEVBQUU7R0FBZTs7Ozs7R0FDcEUsS0FBSyxXQUFXLFdBQVcsSUFDMUIsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYjtLQUNHLEVBQUU7S0FBa0I7S0FDckIsd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTztNQUNYLFdBQVU7Z0JBRVQsRUFBRTtLQUNDOzs7OztJQUNMOzs7OztjQUVILHdCQUFDLFFBQUQ7SUFBTSxVQUFVLEtBQUs7Y0FDbkIsd0JBQUMsWUFBRDtLQUFVLFVBQVUsS0FBSztLQUFNLFdBQVU7ZUFBekM7TUFDRSx3QkFBQyxlQUFEO09BQ0UsZUFBZSxLQUFLO09BQ3BCLE9BQU8sS0FBSztPQUNaLFlBQVksS0FBSztPQUNqQixXQUFXLE9BQU8sVUFDaEIsS0FBSyxTQUFTO1FBQUUsR0FBRyxLQUFLO1NBQVEsUUFBUTtPQUFNLENBQUM7T0FFakQsdUJBQXVCLFVBQ3JCLEtBQUssU0FBUztRQUFFLEdBQUcsS0FBSztRQUFPLGVBQWU7T0FBTSxDQUFDO01BRXhEOzs7OztNQUNELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sU0FBUTtPQUFXLFdBQVU7aUJBQ2pDLEVBQUU7TUFDRTs7OztnQkFDUCx3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILE1BQUs7T0FDTCxLQUFLO09BQ0wsS0FBSztPQUNMLE1BQU07T0FDTjtPQUNBLFdBQVU7T0FDVixPQUFPLEtBQUssTUFBTTtPQUNsQixXQUFXLFVBQ1QsS0FBSyxTQUFTO1FBQUUsR0FBRyxLQUFLO1FBQU8sVUFBVSxNQUFNLE9BQU87T0FBTSxDQUFDO01BRWhFOzs7O2NBQ0U7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUNFLHdCQUFDLFNBQUQ7UUFBTyxTQUFRO1FBQWlCLFdBQVU7a0JBQ3ZDLEVBQUU7T0FDRTs7Ozs7T0FDUCx3QkFBQyxZQUFEO1FBQ0UsSUFBRztRQUNILE1BQU07UUFDTixXQUFVO1FBQ1YsT0FBTyxLQUFLLE1BQU07UUFDbEIsV0FBVyxVQUNULEtBQUssU0FBUztTQUNaLEdBQUcsS0FBSztTQUNSLGdCQUFnQixNQUFNLE9BQU87UUFDL0IsQ0FBQztRQUVILG9CQUFpQjtPQUNsQjs7Ozs7T0FDRCx3QkFBQyxLQUFEO1FBQUcsSUFBRztRQUFZLFdBQVU7a0JBQ3pCLEVBQUU7T0FDRjs7Ozs7TUFDQTs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUFlLE1BQUs7a0JBQXRDLENBQ0csS0FBSyxRQUFRLHdCQUFDLFNBQUQsRUFBUyxXQUFVLE9BQVE7Ozs7a0JBQ3hDLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUNwQjs7Ozs7O01BQ0w7Ozs7O0tBQ0c7Ozs7OztHQUNOOzs7OztHQUVQLEtBQUssYUFDSix3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFRLFdBQVU7Y0FDdkIsS0FBSztHQUNMOzs7OztHQUVKLEtBQUssV0FDSix3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFTLFdBQVU7Y0FDeEIsS0FBSztHQUNMOzs7OztFQUVFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBQcm9kdWN0RmllbGRzIH0gZnJvbSAnLi9Qcm9kdWN0RmllbGRzJztcclxuaW1wb3J0IHR5cGUgeyB1c2VQcm9kdWN0c1BhZ2UgfSBmcm9tICcuLi9ob29rcy91c2VQcm9kdWN0c1BhZ2UnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmFkbWluO1xyXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdEZvcm0oe1xyXG4gIHBhZ2UsXHJcbn06IHtcclxuICBwYWdlOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VQcm9kdWN0c1BhZ2U+O1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXN1cmZhY2VcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTUgdGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dC5hZGRQcm9kdWN0fTwvaDI+XHJcbiAgICAgIHtwYWdlLmNhdGVnb3JpZXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgIHt0LmNhdGVnb3J5UmVxdWlyZWR9eycgJ31cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuYWRtaW5DYXRlZ29yaWVzfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dC5hZGRDYXRlZ29yeX1cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3BhZ2Uuc3VibWl0fT5cclxuICAgICAgICAgIDxmaWVsZHNldCBkaXNhYmxlZD17cGFnZS5idXN5fSBjbGFzc05hbWU9XCJncmlkIGdhcC01IHNtOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICAgIDxQcm9kdWN0RmllbGRzXHJcbiAgICAgICAgICAgICAgb25VcGxvYWRTdGF0ZT17cGFnZS5zZXRVcGxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgZHJhZnQ9e3BhZ2UuZHJhZnR9XHJcbiAgICAgICAgICAgICAgY2F0ZWdvcmllcz17cGFnZS5jYXRlZ29yaWVzfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZmllbGQsIHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgcGFnZS5zZXREcmFmdCh7IC4uLnBhZ2UuZHJhZnQsIFtmaWVsZF06IHZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIG9uUGVuZGluZ0ZpbGVzQ2hhbmdlPXsoZmlsZXMpID0+XHJcbiAgICAgICAgICAgICAgICBwYWdlLnNldERyYWZ0KHsgLi4ucGFnZS5kcmFmdCwgcGVuZGluZ0ltYWdlczogZmlsZXMgfSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJzdG9ja1F0eVwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgIHt0LmluaXRpYWxTdG9ja31cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgaWQ9XCJzdG9ja1F0eVwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgIG1heD17MjE0NzQ4MzY0N31cclxuICAgICAgICAgICAgICAgIHN0ZXA9ezF9XHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgYXV0aC1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGFnZS5kcmFmdC5zdG9ja1F0eX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgIHBhZ2Uuc2V0RHJhZnQoeyAuLi5wYWdlLmRyYWZ0LCBzdG9ja1F0eTogZXZlbnQudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJzcGVjaWZpY2F0aW9uc1wiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgIHt0LnNwZWNpZmljYXRpb25zfVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICBpZD1cInNwZWNpZmljYXRpb25zXCJcclxuICAgICAgICAgICAgICAgIHJvd3M9ezN9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0IGgtYXV0byBweS0yXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYWdlLmRyYWZ0LnNwZWNpZmljYXRpb25zfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICAgICAgcGFnZS5zZXREcmFmdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4ucGFnZS5kcmFmdCxcclxuICAgICAgICAgICAgICAgICAgICBzcGVjaWZpY2F0aW9uczogZXZlbnQudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT1cInNwZWMtaGludFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8cCBpZD1cInNwZWMtaGludFwiIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICB7dC5zcGVjaWZpY2F0aW9uc0hpbnR9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnlcIiB0eXBlPVwic3VibWl0XCI+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5idXN5ICYmIDxTcGlubmVyIGNsYXNzTmFtZT1cIm1yLTJcIiAvPn1cclxuICAgICAgICAgICAgICAgIHtwYWdlLmJ1c3kgPyB0LnNhdmluZyA6IHQuYWRkUHJvZHVjdH1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgKX1cclxuICAgICAge3BhZ2UuZm9ybUVycm9yICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgIHtwYWdlLmZvcm1FcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLnN1Y2Nlc3MgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1zdWNjZXNzXCI+XHJcbiAgICAgICAgICB7cGFnZS5zdWNjZXNzfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==