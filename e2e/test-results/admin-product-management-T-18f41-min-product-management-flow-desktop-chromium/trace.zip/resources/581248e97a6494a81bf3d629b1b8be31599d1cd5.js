import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/forms/ImageUploader.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { deleteProductImage, uploadProductImage } from "/src/services/productService.ts";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/forms/ImageUploader.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.experience;
export function ImageUploader({ value, onChange, max = 10, onBusyChange, productID, onPendingFilesChange }) {
	_s();
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState("");
	const [pending, setPending] = useState([]);
	const previews = useMemo(() => pending.map((file) => ({
		file,
		src: URL.createObjectURL(file)
	})), [pending]);
	useEffect(() => () => previews.forEach(({ src }) => URL.revokeObjectURL(src)), [previews]);
	async function upload(files) {
		if (!files.length) return;
		setError("");
		if (files.length + value.length + pending.length > max || files.some((file) => file.size > 5 * 1024 * 1024 || ![
			"image/jpeg",
			"image/png",
			"image/webp"
		].includes(file.type))) {
			setError(t.uploadError);
			return;
		}
		if (!productID) {
			const next = [...pending, ...files];
			setPending(next);
			onPendingFilesChange?.(next);
			return;
		}
		setBusy(true);
		onBusyChange?.(true);
		const results = [...value];
		try {
			for (const file of files) results.push((await uploadProductImage(productID, file)).imageUrl);
			onChange(results);
		} catch {
			setError(t.uploadError);
		} finally {
			setBusy(false);
			onBusyChange?.(false);
		}
	}
	function remove(src, index) {
		if (!productID && index >= value.length) {
			const next = pending.filter((_file, i) => i !== index - value.length);
			setPending(next);
			onPendingFilesChange?.(next);
			return;
		}
		if (!productID) {
			onChange(value.filter((_item, i) => i !== index));
			return;
		}
		const imageID = src.split("/").pop();
		if (!imageID) return;
		setBusy(true);
		onBusyChange?.(true);
		void deleteProductImage(productID, imageID).then(() => onChange(value.filter((_item, i) => i !== index))).catch(() => setError(t.uploadError)).finally(() => {
			setBusy(false);
			onBusyChange?.(false);
		});
	}
	const items = [...value.map((src) => ({
		src,
		pending: false
	})), ...previews.map(({ src }) => ({
		src,
		pending: true
	}))];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				className: "block text-sm font-medium text-fg-secondary",
				children: [busy ? t.uploading : t.upload, /* @__PURE__ */ _jsxDEV("input", {
					disabled: busy || items.length >= max,
					type: "file",
					multiple: max > 1,
					accept: "image/png,image/jpeg,image/webp",
					onChange: (event) => {
						void upload(Array.from(event.target.files ?? []));
						event.target.value = "";
					},
					className: "mt-2 block w-full text-sm file:mr-3 file:rounded-sm file:border-0 file:bg-primary-subtle file:px-4 file:py-2 file:text-fg-link"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs leading-5 text-fg-muted",
				children: [
					t.imageHelp,
					" (",
					items.length,
					"/",
					max,
					")"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap gap-3",
				children: items.map(({ src }, index) => /* @__PURE__ */ _jsxDEV("div", {
					className: "w-24 rounded-sm border border-line bg-surface p-2",
					children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
						src,
						alt: `${translations.productDetails.image} ${index + 1}`,
						className: "aspect-square w-full"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 7
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: busy,
						"aria-label": `${t.removeImage} ${index + 1}`,
						onClick: () => remove(src, index),
						className: "px-1 py-2 text-danger",
						children: "×"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 7
					}, this)]
				}, `${src}:${index}`, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 74
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 5
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 15
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 10
	}, this);
}
_s(ImageUploader, "GwytCaRMYMF0bgJiW8EqIlB3KEs=");
_c = ImageUploader;
var _c;
$RefreshReg$(_c, "ImageUploader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/forms/ImageUploader.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/forms/ImageUploader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/forms/ImageUploader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/forms/ImageUploader.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzdDLFNBQVMsb0JBQW9CLDBCQUEwQjtBQUN2RCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjs7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUV2QixPQUFPLFNBQVMsY0FBYyxFQUFFLE9BQU8sVUFBVSxNQUFNLElBQUksY0FBYyxXQUFXLHdCQUlqRjs7Q0FDRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQWlCLENBQUMsQ0FBQztDQUNqRCxNQUFNLFdBQVcsY0FBYyxRQUFRLEtBQUssVUFBVTtFQUFFO0VBQU0sS0FBSyxJQUFJLGdCQUFnQixJQUFJO0NBQUUsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQzNHLHNCQUFzQixTQUFTLFNBQVMsRUFBRSxVQUFVLElBQUksZ0JBQWdCLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ3pGLGVBQWUsT0FBTyxPQUFlO0VBQ25DLElBQUksQ0FBQyxNQUFNLFFBQVE7RUFDbkIsU0FBUyxFQUFFO0VBQ1gsSUFBSSxNQUFNLFNBQVMsTUFBTSxTQUFTLFFBQVEsU0FBUyxPQUFPLE1BQU0sTUFBTSxTQUFTLEtBQUssT0FBTyxJQUFJLE9BQU8sUUFBUSxDQUFDO0dBQUM7R0FBYztHQUFhO0VBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxJQUFJLENBQUMsR0FBRztHQUM3SyxTQUFTLEVBQUUsV0FBVztHQUFHO0VBQzNCO0VBQ0EsSUFBSSxDQUFDLFdBQVc7R0FBRSxNQUFNLE9BQU8sQ0FBQyxHQUFHLFNBQVMsR0FBRyxLQUFLO0dBQUcsV0FBVyxJQUFJO0dBQUcsdUJBQXVCLElBQUk7R0FBRztFQUFRO0VBQy9HLFFBQVEsSUFBSTtFQUFHLGVBQWUsSUFBSTtFQUNsQyxNQUFNLFVBQVUsQ0FBQyxHQUFHLEtBQUs7RUFDekIsSUFBSTtHQUFFLEtBQUssTUFBTSxRQUFRLE9BQU8sUUFBUSxNQUFNLE1BQU0sbUJBQW1CLFdBQVcsSUFBSSxFQUFDLENBQUUsUUFBUTtHQUFHLFNBQVMsT0FBTztFQUFHLFFBQ2pIO0dBQUUsU0FBUyxFQUFFLFdBQVc7RUFBRyxVQUN6QjtHQUFFLFFBQVEsS0FBSztHQUFHLGVBQWUsS0FBSztFQUFHO0NBQ25EO0NBQ0EsU0FBUyxPQUFPLEtBQWEsT0FBZTtFQUMxQyxJQUFJLENBQUMsYUFBYSxTQUFTLE1BQU0sUUFBUTtHQUFFLE1BQU0sT0FBTyxRQUFRLFFBQVEsT0FBTyxNQUFNLE1BQU0sUUFBUSxNQUFNLE1BQU07R0FBRyxXQUFXLElBQUk7R0FBRyx1QkFBdUIsSUFBSTtHQUFHO0VBQVE7RUFDMUssSUFBSSxDQUFDLFdBQVc7R0FBRSxTQUFTLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUM7R0FBRztFQUFRO0VBQzdFLE1BQU0sVUFBVSxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSTtFQUFHLElBQUksQ0FBQyxTQUFTO0VBQ3BELFFBQVEsSUFBSTtFQUFHLGVBQWUsSUFBSTtFQUNsQyxLQUFLLG1CQUFtQixXQUFXLE9BQU8sQ0FBQyxDQUFDLFdBQVcsU0FBUyxNQUFNLFFBQVEsT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsY0FBYztHQUFFLFFBQVEsS0FBSztHQUFHLGVBQWUsS0FBSztFQUFHLENBQUM7Q0FDek07Q0FDQSxNQUFNLFFBQVEsQ0FBQyxHQUFHLE1BQU0sS0FBSyxTQUFTO0VBQUU7RUFBSyxTQUFTO0NBQU0sRUFBRSxHQUFHLEdBQUcsU0FBUyxLQUFLLEVBQUUsV0FBVztFQUFFO0VBQUssU0FBUztDQUFLLEVBQUUsQ0FBQztDQUN2SCxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDTCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUFnRSxPQUFPLEVBQUUsWUFBWSxFQUFFLFFBQ3JGLHdCQUFDLFNBQUQ7S0FBTyxVQUFVLFFBQVEsTUFBTSxVQUFVO0tBQUssTUFBSztLQUFPLFVBQVUsTUFBTTtLQUFHLFFBQU87S0FBa0MsV0FBVyxVQUFVO01BQUUsS0FBSyxPQUFPLE1BQU0sS0FBSyxNQUFNLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQztNQUFHLE1BQU0sT0FBTyxRQUFRO0tBQUk7S0FBRyxXQUFVO0lBQWtJOzs7O1lBQ25XOzs7Ozs7R0FDUCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQWdELEVBQUU7S0FBVTtLQUFHLE1BQU07S0FBTztLQUFFO0tBQUk7SUFBSTs7Ozs7O0dBQ3RGLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQXdCLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSx3QkFBQyxPQUFEO0tBQTZCLFdBQVU7ZUFBdkMsQ0FDbkUsd0JBQUMsY0FBRDtNQUFtQjtNQUFLLEtBQUssR0FBRyxhQUFhLGVBQWUsTUFBTSxHQUFHLFFBQVE7TUFBSyxXQUFVO0tBQXdCOzs7O2VBQ3BILHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsVUFBVTtNQUFNLGNBQVksR0FBRyxFQUFFLFlBQVksR0FBRyxRQUFRO01BQUssZUFBZSxPQUFPLEtBQUssS0FBSztNQUFHLFdBQVU7Z0JBQXdCO0tBQVM7Ozs7YUFDOUo7T0FIMEUsR0FBRyxJQUFJLEdBQUc7Ozs7V0FHcEYsQ0FBQztHQUFPOzs7OztHQUNaLFNBQVMsd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUSxXQUFVO2NBQXVCO0dBQVM7Ozs7O0VBQ2pFOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJJbWFnZVVwbG9hZGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZGVsZXRlUHJvZHVjdEltYWdlLCB1cGxvYWRQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9wcm9kdWN0U2VydmljZSc7XG5pbXBvcnQgeyBQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi9jb21tb24vUHJvZHVjdEltYWdlJztcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmV4cGVyaWVuY2U7XG5cbmV4cG9ydCBmdW5jdGlvbiBJbWFnZVVwbG9hZGVyKHsgdmFsdWUsIG9uQ2hhbmdlLCBtYXggPSAxMCwgb25CdXN5Q2hhbmdlLCBwcm9kdWN0SUQsIG9uUGVuZGluZ0ZpbGVzQ2hhbmdlIH06IHtcbiAgdmFsdWU6IHN0cmluZ1tdOyBvbkNoYW5nZTogKHZhbHVlOiBzdHJpbmdbXSkgPT4gdm9pZDsgbWF4PzogbnVtYmVyO1xuICBvbkJ1c3lDaGFuZ2U/OiAoYnVzeTogYm9vbGVhbikgPT4gdm9pZDsgcHJvZHVjdElEPzogc3RyaW5nO1xuICBvblBlbmRpbmdGaWxlc0NoYW5nZT86IChmaWxlczogRmlsZVtdKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGVuZGluZywgc2V0UGVuZGluZ10gPSB1c2VTdGF0ZTxGaWxlW10+KFtdKTtcbiAgY29uc3QgcHJldmlld3MgPSB1c2VNZW1vKCgpID0+IHBlbmRpbmcubWFwKChmaWxlKSA9PiAoeyBmaWxlLCBzcmM6IFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSkgfSkpLCBbcGVuZGluZ10pO1xuICB1c2VFZmZlY3QoKCkgPT4gKCkgPT4gcHJldmlld3MuZm9yRWFjaCgoeyBzcmMgfSkgPT4gVVJMLnJldm9rZU9iamVjdFVSTChzcmMpKSwgW3ByZXZpZXdzXSk7XG4gIGFzeW5jIGZ1bmN0aW9uIHVwbG9hZChmaWxlczogRmlsZVtdKSB7XG4gICAgaWYgKCFmaWxlcy5sZW5ndGgpIHJldHVybjtcbiAgICBzZXRFcnJvcignJyk7XG4gICAgaWYgKGZpbGVzLmxlbmd0aCArIHZhbHVlLmxlbmd0aCArIHBlbmRpbmcubGVuZ3RoID4gbWF4IHx8IGZpbGVzLnNvbWUoKGZpbGUpID0+IGZpbGUuc2l6ZSA+IDUgKiAxMDI0ICogMTAyNCB8fCAhWydpbWFnZS9qcGVnJywgJ2ltYWdlL3BuZycsICdpbWFnZS93ZWJwJ10uaW5jbHVkZXMoZmlsZS50eXBlKSkpIHtcbiAgICAgIHNldEVycm9yKHQudXBsb2FkRXJyb3IpOyByZXR1cm47XG4gICAgfVxuICAgIGlmICghcHJvZHVjdElEKSB7IGNvbnN0IG5leHQgPSBbLi4ucGVuZGluZywgLi4uZmlsZXNdOyBzZXRQZW5kaW5nKG5leHQpOyBvblBlbmRpbmdGaWxlc0NoYW5nZT8uKG5leHQpOyByZXR1cm47IH1cbiAgICBzZXRCdXN5KHRydWUpOyBvbkJ1c3lDaGFuZ2U/Lih0cnVlKTtcbiAgICBjb25zdCByZXN1bHRzID0gWy4uLnZhbHVlXTtcbiAgICB0cnkgeyBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHJlc3VsdHMucHVzaCgoYXdhaXQgdXBsb2FkUHJvZHVjdEltYWdlKHByb2R1Y3RJRCwgZmlsZSkpLmltYWdlVXJsKTsgb25DaGFuZ2UocmVzdWx0cyk7IH1cbiAgICBjYXRjaCB7IHNldEVycm9yKHQudXBsb2FkRXJyb3IpOyB9XG4gICAgZmluYWxseSB7IHNldEJ1c3koZmFsc2UpOyBvbkJ1c3lDaGFuZ2U/LihmYWxzZSk7IH1cbiAgfVxuICBmdW5jdGlvbiByZW1vdmUoc3JjOiBzdHJpbmcsIGluZGV4OiBudW1iZXIpIHtcbiAgICBpZiAoIXByb2R1Y3RJRCAmJiBpbmRleCA+PSB2YWx1ZS5sZW5ndGgpIHsgY29uc3QgbmV4dCA9IHBlbmRpbmcuZmlsdGVyKChfZmlsZSwgaSkgPT4gaSAhPT0gaW5kZXggLSB2YWx1ZS5sZW5ndGgpOyBzZXRQZW5kaW5nKG5leHQpOyBvblBlbmRpbmdGaWxlc0NoYW5nZT8uKG5leHQpOyByZXR1cm47IH1cbiAgICBpZiAoIXByb2R1Y3RJRCkgeyBvbkNoYW5nZSh2YWx1ZS5maWx0ZXIoKF9pdGVtLCBpKSA9PiBpICE9PSBpbmRleCkpOyByZXR1cm47IH1cbiAgICBjb25zdCBpbWFnZUlEID0gc3JjLnNwbGl0KCcvJykucG9wKCk7IGlmICghaW1hZ2VJRCkgcmV0dXJuO1xuICAgIHNldEJ1c3kodHJ1ZSk7IG9uQnVzeUNoYW5nZT8uKHRydWUpO1xuICAgIHZvaWQgZGVsZXRlUHJvZHVjdEltYWdlKHByb2R1Y3RJRCwgaW1hZ2VJRCkudGhlbigoKSA9PiBvbkNoYW5nZSh2YWx1ZS5maWx0ZXIoKF9pdGVtLCBpKSA9PiBpICE9PSBpbmRleCkpKS5jYXRjaCgoKSA9PiBzZXRFcnJvcih0LnVwbG9hZEVycm9yKSkuZmluYWxseSgoKSA9PiB7IHNldEJ1c3koZmFsc2UpOyBvbkJ1c3lDaGFuZ2U/LihmYWxzZSk7IH0pO1xuICB9XG4gIGNvbnN0IGl0ZW1zID0gWy4uLnZhbHVlLm1hcCgoc3JjKSA9PiAoeyBzcmMsIHBlbmRpbmc6IGZhbHNlIH0pKSwgLi4ucHJldmlld3MubWFwKCh7IHNyYyB9KSA9PiAoeyBzcmMsIHBlbmRpbmc6IHRydWUgfSkpXTtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIj57YnVzeSA/IHQudXBsb2FkaW5nIDogdC51cGxvYWR9XG4gICAgICA8aW5wdXQgZGlzYWJsZWQ9e2J1c3kgfHwgaXRlbXMubGVuZ3RoID49IG1heH0gdHlwZT1cImZpbGVcIiBtdWx0aXBsZT17bWF4ID4gMX0gYWNjZXB0PVwiaW1hZ2UvcG5nLGltYWdlL2pwZWcsaW1hZ2Uvd2VicFwiIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHsgdm9pZCB1cGxvYWQoQXJyYXkuZnJvbShldmVudC50YXJnZXQuZmlsZXMgPz8gW10pKTsgZXZlbnQudGFyZ2V0LnZhbHVlID0gJyc7IH19IGNsYXNzTmFtZT1cIm10LTIgYmxvY2sgdy1mdWxsIHRleHQtc20gZmlsZTptci0zIGZpbGU6cm91bmRlZC1zbSBmaWxlOmJvcmRlci0wIGZpbGU6YmctcHJpbWFyeS1zdWJ0bGUgZmlsZTpweC00IGZpbGU6cHktMiBmaWxlOnRleHQtZmctbGlua1wiIC8+XG4gICAgPC9sYWJlbD5cbiAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+e3QuaW1hZ2VIZWxwfSAoe2l0ZW1zLmxlbmd0aH0ve21heH0pPC9wPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj57aXRlbXMubWFwKCh7IHNyYyB9LCBpbmRleCkgPT4gPGRpdiBrZXk9e2Ake3NyY306JHtpbmRleH1gfSBjbGFzc05hbWU9XCJ3LTI0IHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC0yXCI+XG4gICAgICA8UHJvZHVjdEltYWdlIHNyYz17c3JjfSBhbHQ9e2Ake3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5pbWFnZX0gJHtpbmRleCArIDF9YH0gY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGxcIiAvPlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e2J1c3l9IGFyaWEtbGFiZWw9e2Ake3QucmVtb3ZlSW1hZ2V9ICR7aW5kZXggKyAxfWB9IG9uQ2xpY2s9eygpID0+IHJlbW92ZShzcmMsIGluZGV4KX0gY2xhc3NOYW1lPVwicHgtMSBweS0yIHRleHQtZGFuZ2VyXCI+w5c8L2J1dHRvbj5cbiAgICA8L2Rpdj4pfTwvZGl2PlxuICAgIHtlcnJvciAmJiA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+e2Vycm9yfTwvcD59XG4gIDwvZGl2Pjtcbn1cbiJdfQ==