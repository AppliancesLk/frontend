import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Categories/index.tsx");const useState = __vite__cjsImport6_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import { CategoryTable } from "/src/pages/Admin/Categories/components/CategoryTable.tsx";
import { CategoryForm } from "/src/pages/Admin/Categories/components/CategoryForm.tsx";
import { useCategoriesPage } from "/src/pages/Admin/Categories/hooks/useCategoriesPage.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { translations } from "/src/utils/translations.ts";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/index.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.admin;
export default function CategoriesPage() {
	_s();
	const page = useCategoriesPage();
	const [drawerOpen, setDrawerOpen] = useState(false);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.categories
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 14
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.categoriesDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 71
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "auth-primary",
					onClick: () => setDrawerOpen(true),
					children: t.addCategory
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this),
			!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV(CategoryTable, { page }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: drawerOpen || Boolean(page.editing),
				onClose: () => {
					setDrawerOpen(false);
					page.cancelEdit();
				},
				title: page.editing ? translations.experience.editCategory : t.addCategory,
				drawer: true,
				busy: page.busy,
				children: /* @__PURE__ */ _jsxDEV(CategoryForm, { page }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s(CategoriesPage, "wx9bB+XC55gRgr/TpRL0vELG+U4=", false, function() {
	return [useCategoriesPage];
});
_c = CategoriesPage;
var _c;
$RefreshReg$(_c, "CategoriesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Categories/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZ0JBQWdCOzs7O0FBQ3pCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLGVBQWUsU0FBUyxpQkFBaUI7O0NBQ3ZDLE1BQU0sT0FBTyxrQkFBa0I7Q0FDL0IsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFlOzs7O2NBQUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEIsRUFBRTtJQUF5Qjs7OztZQUFNOzs7O2NBQzFJLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsV0FBVTtLQUFlLGVBQWUsY0FBYyxJQUFJO2VBQUksRUFBRTtJQUFvQjs7OztZQUNwRzs7Ozs7O0dBQ1Isd0JBQUMsaUJBQUQ7SUFDRSxTQUFTLEtBQUs7SUFDZCxPQUFPLEtBQUs7SUFDWixPQUFPLEtBQUs7R0FDYjs7Ozs7R0FDQSxDQUFDLEtBQUssV0FBVyxDQUFDLEtBQUssU0FDdEIsK0NBQ0Usd0JBQUMsZUFBRCxFQUFxQixLQUFPOzs7O1lBQzVCOzs7OztHQUVKLHdCQUFDLFFBQUQ7SUFBUSxNQUFNLGNBQWMsUUFBUSxLQUFLLE9BQU87SUFBRyxlQUFlO0tBQUUsY0FBYyxLQUFLO0tBQUcsS0FBSyxXQUFXO0lBQUc7SUFBRyxPQUFPLEtBQUssVUFBVSxhQUFhLFdBQVcsZUFBZSxFQUFFO0lBQWE7SUFBTyxNQUFNLEtBQUs7Y0FDNU0sd0JBQUMsY0FBRCxFQUFvQixLQUFPOzs7OztHQUNyQjs7Ozs7RUFDRDs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENhdGVnb3J5VGFibGUgfSBmcm9tICcuL2NvbXBvbmVudHMvQ2F0ZWdvcnlUYWJsZSc7XHJcbmltcG9ydCB7IENhdGVnb3J5Rm9ybSB9IGZyb20gJy4vY29tcG9uZW50cy9DYXRlZ29yeUZvcm0nO1xyXG5pbXBvcnQgeyB1c2VDYXRlZ29yaWVzUGFnZSB9IGZyb20gJy4vaG9va3MvdXNlQ2F0ZWdvcmllc1BhZ2UnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IERpYWxvZyB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuYWRtaW47XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhdGVnb3JpZXNQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VDYXRlZ29yaWVzUGFnZSgpO1xyXG4gIGNvbnN0IFtkcmF3ZXJPcGVuLCBzZXREcmF3ZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdj48aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+e3QuY2F0ZWdvcmllc308L2gxPjxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3QuY2F0ZWdvcmllc0Rlc2NyaXB0aW9ufTwvcD48L2Rpdj5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXREcmF3ZXJPcGVuKHRydWUpfT57dC5hZGRDYXRlZ29yeX08L2J1dHRvbj5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICAgIDxDYXRhbG9nRmVlZGJhY2tcclxuICAgICAgICBsb2FkaW5nPXtwYWdlLmxvYWRpbmd9XHJcbiAgICAgICAgZXJyb3I9e3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgcmV0cnk9e3BhZ2UucmVmcmVzaH1cclxuICAgICAgLz5cclxuICAgICAgeyFwYWdlLmxvYWRpbmcgJiYgIXBhZ2UuZXJyb3IgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8Q2F0ZWdvcnlUYWJsZSBwYWdlPXtwYWdlfSAvPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgICA8RGlhbG9nIG9wZW49e2RyYXdlck9wZW4gfHwgQm9vbGVhbihwYWdlLmVkaXRpbmcpfSBvbkNsb3NlPXsoKSA9PiB7IHNldERyYXdlck9wZW4oZmFsc2UpOyBwYWdlLmNhbmNlbEVkaXQoKTsgfX0gdGl0bGU9e3BhZ2UuZWRpdGluZyA/IHRyYW5zbGF0aW9ucy5leHBlcmllbmNlLmVkaXRDYXRlZ29yeSA6IHQuYWRkQ2F0ZWdvcnl9IGRyYXdlciBidXN5PXtwYWdlLmJ1c3l9PlxyXG4gICAgICAgIDxDYXRlZ29yeUZvcm0gcGFnZT17cGFnZX0gLz5cclxuICAgICAgPC9EaWFsb2c+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=