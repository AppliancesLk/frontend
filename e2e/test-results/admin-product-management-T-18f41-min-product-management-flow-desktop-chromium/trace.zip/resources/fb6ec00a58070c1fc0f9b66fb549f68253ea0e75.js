import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Categories/components/CategoryForm.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { translations } from "/src/utils/translations.ts";
import { ImageUploader } from "/src/components/forms/ImageUploader.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryForm.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.admin;
export function CategoryForm({ page }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "rounded-md border border-line bg-surface p-5  sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "mb-5 text-xl font-semibold text-fg",
				children: page.editing ? translations.experience.editCategory : t.addCategory
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: page.submit,
				children: /* @__PURE__ */ _jsxDEV("fieldset", {
					disabled: page.busy,
					className: "grid items-end gap-5 md:grid-cols-[1fr_1fr_auto]",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "auth-label",
							htmlFor: "category-name",
							children: t.categoryName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							required: true,
							minLength: 2,
							id: "category-name",
							className: "ui-field auth-input",
							value: page.name,
							onChange: (event) => page.setName(event.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "auth-label",
							htmlFor: "parent-category",
							children: t.parentCategory
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							id: "parent-category",
							className: "ui-field auth-input",
							value: page.parentID,
							onChange: (event) => page.setParentID(event.target.value),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: t.noParent
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 15
							}, this), page.categories.filter((category) => category.isActive && category.categoryID !== page.editing).map((category) => /* @__PURE__ */ _jsxDEV("option", {
								value: category.categoryID,
								children: category.name
							}, category.categoryID, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 19
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "auth-primary",
							children: [page.busy && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 27
							}, this), page.busy ? t.saving : page.editing ? translations.experience.save : t.addCategory]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "md:col-span-3",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "mb-3 text-sm font-medium text-fg-secondary",
								children: translations.experience.categoryImage
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(ImageUploader, {
								max: 1,
								value: page.imageUrl ? [page.imageUrl] : [],
								onChange: (images) => page.setImageUrl(images[0] ?? ""),
								onBusyChange: page.setUploading
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 11
						}, this),
						page.editing && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "auth-secondary",
							onClick: page.cancelEdit,
							children: translations.experience.cancel
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			page.formError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mt-4 text-sm text-danger",
				children: page.formError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 9
			}, this),
			page.success && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "mt-4 text-sm text-success",
				children: page.success
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = CategoryForm;
var _c;
$RefreshReg$(_c, "CategoryForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Categories/components/CategoryForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBRXhCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMscUJBQXFCOzs7QUFDOUIsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGFBQWEsRUFDM0IsUUFHQztDQUNELE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLEtBQUssVUFBVSxhQUFhLFdBQVcsZUFBZSxFQUFFO0dBQ3ZEOzs7OztHQUNKLHdCQUFDLFFBQUQ7SUFBTSxVQUFVLEtBQUs7Y0FDbkIsd0JBQUMsWUFBRDtLQUNFLFVBQVUsS0FBSztLQUNmLFdBQVU7ZUFGWjtNQUlFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFhLFNBQVE7aUJBQ25DLEVBQUU7TUFDRTs7OztnQkFDUCx3QkFBQyxTQUFEO09BQ0U7T0FDQSxXQUFXO09BQ1gsSUFBRztPQUNILFdBQVU7T0FDVixPQUFPLEtBQUs7T0FDWixXQUFXLFVBQVUsS0FBSyxRQUFRLE1BQU0sT0FBTyxLQUFLO01BQ3JEOzs7O2NBQ0U7Ozs7O01BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO09BQWEsU0FBUTtpQkFDbkMsRUFBRTtNQUNFOzs7O2dCQUNQLHdCQUFDLFVBQUQ7T0FDRSxJQUFHO09BQ0gsV0FBVTtPQUNWLE9BQU8sS0FBSztPQUNaLFdBQVcsVUFBVSxLQUFLLFlBQVksTUFBTSxPQUFPLEtBQUs7aUJBSjFELENBTUUsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQUksRUFBRTtPQUFpQjs7OztpQkFDcEMsS0FBSyxXQUNILFFBQ0UsYUFDQyxTQUFTLFlBQVksU0FBUyxlQUFlLEtBQUssT0FDdEQsQ0FBQyxDQUNBLEtBQUssYUFDSix3QkFBQyxVQUFEO1FBQVEsT0FBTyxTQUFTO2tCQUNyQixTQUFTO09BQ0osR0FGaUMsU0FBUzs7OztjQUUxQyxDQUNULENBQ0c7Ozs7O2NBQ0w7Ozs7O01BQ0wsd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFVO2lCQUFoQyxDQUNHLEtBQUssUUFBUSx3QkFBQyxTQUFELEVBQVMsV0FBVSxPQUFROzs7O2lCQUN4QyxLQUFLLE9BQ0YsRUFBRSxTQUNGLEtBQUssVUFDSCxhQUFhLFdBQVcsT0FDeEIsRUFBRSxXQUNGOzs7Ozs7TUFDUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLGFBQWEsV0FBVztPQUN4Qjs7OztpQkFDSCx3QkFBQyxlQUFEO1FBQ0UsS0FBSztRQUNMLE9BQU8sS0FBSyxXQUFXLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQztRQUMxQyxXQUFXLFdBQVcsS0FBSyxZQUFZLE9BQU8sTUFBTSxFQUFFO1FBQ3RELGNBQWMsS0FBSztPQUNwQjs7OztlQUNFOzs7Ozs7TUFDSixLQUFLLFdBQ0osd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxXQUFVO09BQ1YsU0FBUyxLQUFLO2lCQUViLGFBQWEsV0FBVztNQUNuQjs7Ozs7S0FFRjs7Ozs7O0dBQ047Ozs7O0dBQ0wsS0FBSyxhQUNKLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVEsV0FBVTtjQUN2QixLQUFLO0dBQ0w7Ozs7O0dBRUosS0FBSyxXQUNKLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVMsV0FBVTtjQUN4QixLQUFLO0dBQ0w7Ozs7O0VBRUU7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhdGVnb3J5Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgdHlwZSB7IHVzZUNhdGVnb3JpZXNQYWdlIH0gZnJvbSAnLi4vaG9va3MvdXNlQ2F0ZWdvcmllc1BhZ2UnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBJbWFnZVVwbG9hZGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9mb3Jtcy9JbWFnZVVwbG9hZGVyJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pbjtcclxuZXhwb3J0IGZ1bmN0aW9uIENhdGVnb3J5Rm9ybSh7XHJcbiAgcGFnZSxcclxufToge1xyXG4gIHBhZ2U6IFJldHVyblR5cGU8dHlwZW9mIHVzZUNhdGVnb3JpZXNQYWdlPjtcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNSAgc206cC02XCI+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi01IHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAge3BhZ2UuZWRpdGluZyA/IHRyYW5zbGF0aW9ucy5leHBlcmllbmNlLmVkaXRDYXRlZ29yeSA6IHQuYWRkQ2F0ZWdvcnl9XHJcbiAgICAgIDwvaDI+XHJcbiAgICAgIDxmb3JtIG9uU3VibWl0PXtwYWdlLnN1Ym1pdH0+XHJcbiAgICAgICAgPGZpZWxkc2V0XHJcbiAgICAgICAgICBkaXNhYmxlZD17cGFnZS5idXN5fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1lbmQgZ2FwLTUgbWQ6Z3JpZC1jb2xzLVsxZnJfMWZyX2F1dG9dXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiIGh0bWxGb3I9XCJjYXRlZ29yeS1uYW1lXCI+XHJcbiAgICAgICAgICAgICAge3QuY2F0ZWdvcnlOYW1lfVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgIG1pbkxlbmd0aD17Mn1cclxuICAgICAgICAgICAgICBpZD1cImNhdGVnb3J5LW5hbWVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwYWdlLm5hbWV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gcGFnZS5zZXROYW1lKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCIgaHRtbEZvcj1cInBhcmVudC1jYXRlZ29yeVwiPlxyXG4gICAgICAgICAgICAgIHt0LnBhcmVudENhdGVnb3J5fVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgaWQ9XCJwYXJlbnQtY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwYWdlLnBhcmVudElEfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHBhZ2Uuc2V0UGFyZW50SUQoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj57dC5ub1BhcmVudH08L29wdGlvbj5cclxuICAgICAgICAgICAgICB7cGFnZS5jYXRlZ29yaWVzXHJcbiAgICAgICAgICAgICAgICAuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAoY2F0ZWdvcnkpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnkuaXNBY3RpdmUgJiYgY2F0ZWdvcnkuY2F0ZWdvcnlJRCAhPT0gcGFnZS5lZGl0aW5nLFxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17Y2F0ZWdvcnkuY2F0ZWdvcnlJRH0ga2V5PXtjYXRlZ29yeS5jYXRlZ29yeUlEfT5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImF1dGgtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICB7cGFnZS5idXN5ICYmIDxTcGlubmVyIGNsYXNzTmFtZT1cIm1yLTJcIiAvPn1cclxuICAgICAgICAgICAge3BhZ2UuYnVzeVxyXG4gICAgICAgICAgICAgID8gdC5zYXZpbmdcclxuICAgICAgICAgICAgICA6IHBhZ2UuZWRpdGluZ1xyXG4gICAgICAgICAgICAgICAgPyB0cmFuc2xhdGlvbnMuZXhwZXJpZW5jZS5zYXZlXHJcbiAgICAgICAgICAgICAgICA6IHQuYWRkQ2F0ZWdvcnl9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tM1wiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmV4cGVyaWVuY2UuY2F0ZWdvcnlJbWFnZX1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8SW1hZ2VVcGxvYWRlclxyXG4gICAgICAgICAgICAgIG1heD17MX1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGFnZS5pbWFnZVVybCA/IFtwYWdlLmltYWdlVXJsXSA6IFtdfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoaW1hZ2VzKSA9PiBwYWdlLnNldEltYWdlVXJsKGltYWdlc1swXSA/PyAnJyl9XHJcbiAgICAgICAgICAgICAgb25CdXN5Q2hhbmdlPXtwYWdlLnNldFVwbG9hZGluZ31cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge3BhZ2UuZWRpdGluZyAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17cGFnZS5jYW5jZWxFZGl0fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5leHBlcmllbmNlLmNhbmNlbH1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZmllbGRzZXQ+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAge3BhZ2UuZm9ybUVycm9yICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgIHtwYWdlLmZvcm1FcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLnN1Y2Nlc3MgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1zdWNjZXNzXCI+XHJcbiAgICAgICAgICB7cGFnZS5zdWNjZXNzfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==