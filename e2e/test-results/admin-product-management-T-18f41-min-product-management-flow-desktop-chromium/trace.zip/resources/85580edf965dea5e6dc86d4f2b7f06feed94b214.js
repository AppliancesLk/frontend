import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Repairs/Request/index.tsx");const useEffect = __vite__cjsImport2_react["useEffect"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import { RatingPlate } from "/src/components/common/RatingPlate.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { useRepairRequest } from "/src/pages/Customer/Repairs/Request/hooks/useRepairRequest.ts";
import { RepairRequestForm } from "/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx";
import { RepairSuccess } from "/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/index.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const t = translations.repairs;
export default function RepairRequestPage() {
	_s();
	const { user } = useAuth();
	return user ? /* @__PURE__ */ _jsxDEV(RepairRequestContent, {}, user.id, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 17
	}, this) : null;
}
_s(RepairRequestPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = RepairRequestPage;
function RepairRequestContent() {
	_s2();
	const page = useRepairRequest();
	useEffect(() => {
		const previous = document.title;
		document.title = `${t.requestTitle} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-[1200px] space-y-8",
			children: [
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": translations.productDetails.breadcrumb,
					className: "text-sm",
					children: /* @__PURE__ */ _jsxDEV("ol", {
						className: "flex items-center gap-2 text-fg-muted",
						children: [
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.products,
								className: "font-medium text-fg-link hover:text-fg-link",
								children: translations.productDetails.products
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 39,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 38,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-hidden": "true",
								children: "/"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.repairs,
								className: "font-medium text-fg-link hover:text-fg-link",
								children: t.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-hidden": "true",
								children: "/"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-current": "page",
								children: t.requestTitle
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.requestTitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.requestDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				page.createdTicket ? /* @__PURE__ */ _jsxDEV(RepairSuccess, { ticket: page.createdTicket }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "grid items-start gap-8 xl:grid-cols-[minmax(0,760px)_minmax(0,320px)]",
					children: [/* @__PURE__ */ _jsxDEV(RepairRequestForm, { page }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("aside", {
						className: "space-y-6 xl:sticky xl:top-24",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-md border border-line bg-surface p-5",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-semibold",
									children: "Find your device details"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 72,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "mt-3 text-sm leading-6 text-fg-secondary",
									children: "Look for a small rating plate on the back, base or inside the door of your appliance. On a phone, look in Settings → About phone."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mt-5",
									children: /* @__PURE__ */ _jsxDEV(RatingPlate, {
										title: "Your device",
										rows: [{
											label: "Model",
											value: "Look for “Model” or “Mod.”"
										}, {
											label: "Serial number",
											value: "Look for “S/N” or “Serial”"
										}],
										footer: "An example of the information to look for."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 81,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 80,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-md border border-line bg-surface p-5",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-semibold",
								children: "What happens next"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("ul", {
								className: "mt-5 space-y-5 text-sm text-fg-secondary",
								children: [
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Icon, {
											name: "orders",
											className: "h-5 w-5 shrink-0 text-fg-link"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 98,
											columnNumber: 21
										}, this), "Our team reviews your request."]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Icon, {
											name: "repair",
											className: "h-5 w-5 shrink-0 text-fg-link"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 105,
											columnNumber: 21
										}, this), "We update you as the repair progresses."]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Icon, {
											name: "check",
											className: "h-5 w-5 shrink-0 text-fg-link"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 112,
											columnNumber: 21
										}, this), "Track everything in Your repairs."]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 111,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_s2(RepairRequestContent, "h6tVO1AU6617OmbtN/XKZY/Kad0=", false, function() {
	return [useRepairRequest];
});
_c2 = RepairRequestContent;
var _c, _c2;
$RefreshReg$(_c, "RepairRequestPage");
$RefreshReg$(_c2, "RepairRequestContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Repairs/Request/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMscUJBQXFCOzs7O0FBRTlCLE1BQU0sSUFBSSxhQUFhO0FBRXZCLGVBQWUsU0FBUyxvQkFBb0I7O0NBQzFDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FBTyxPQUFPLHdCQUFDLHNCQUFELENBQXFDLEdBQVYsS0FBSzs7OztRQUFLLElBQUk7QUFDekQ7Ozs7O0FBRUEsU0FBUyx1QkFBdUI7O0NBQzlCLE1BQU0sT0FBTyxpQkFBaUI7Q0FFOUIsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLFNBQVM7RUFDMUIsU0FBUyxRQUFRLEdBQUcsRUFBRSxhQUFhLEtBQUssYUFBYSxPQUFPO0VBQzVELGFBQWE7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUNFLGNBQVksYUFBYSxlQUFlO0tBQ3hDLFdBQVU7ZUFFVix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPO1FBQ1gsV0FBVTtrQkFFVCxhQUFhLGVBQWU7T0FDekI7Ozs7Z0JBQ0o7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLGVBQVk7a0JBQU87T0FBSzs7Ozs7T0FDNUIsd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFDRSxJQUFJLE9BQU87UUFDWCxXQUFVO2tCQUVULEVBQUU7T0FDQzs7OztnQkFDSjs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksZUFBWTtrQkFBTztPQUFLOzs7OztPQUM1Qix3QkFBQyxNQUFEO1FBQUksZ0JBQWE7a0JBQVEsRUFBRTtPQUFpQjs7Ozs7TUFDMUM7Ozs7OztJQUNEOzs7OztJQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF5QixFQUFFO0lBQWlCOzs7O2NBQzFELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCLEVBQUU7SUFBc0I7Ozs7WUFDaEU7Ozs7O0lBRUosS0FBSyxnQkFDSix3QkFBQyxlQUFELEVBQWUsUUFBUSxLQUFLLGNBQWdCOzs7O2VBRTVDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxtQkFBRCxFQUF5QixLQUFPOzs7O2VBQ2hDLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXdCO1FBRWxDOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQztRQUlyRDs7Ozs7UUFDSCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxhQUFEO1VBQ0UsT0FBTTtVQUNOLE1BQU0sQ0FDSjtXQUFFLE9BQU87V0FBUyxPQUFPO1VBQTZCLEdBQ3REO1dBQ0UsT0FBTztXQUNQLE9BQU87VUFDVCxDQUNGO1VBQ0EsUUFBTztTQUNSOzs7OztRQUNFOzs7OztPQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF3QjtPQUFxQjs7OztpQkFDM0Qsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLE1BQUQ7V0FDRSxNQUFLO1dBQ0wsV0FBVTtVQUNYOzs7O29CQUFDLGdDQUVBOzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLE1BQUQ7V0FDRSxNQUFLO1dBQ0wsV0FBVTtVQUNYOzs7O29CQUFDLHlDQUVBOzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLE1BQUQ7V0FDRSxNQUFLO1dBQ0wsV0FBVTtVQUNYOzs7O29CQUFDLG1DQUVBOzs7Ozs7UUFDRjs7Ozs7ZUFDRDs7Ozs7Y0FDQTs7Ozs7YUFDSjs7Ozs7O0dBRUo7Ozs7OztDQUNEOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSYXRpbmdQbGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JhdGluZ1BsYXRlJztcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgdXNlUmVwYWlyUmVxdWVzdCB9IGZyb20gJy4vaG9va3MvdXNlUmVwYWlyUmVxdWVzdCc7XHJcbmltcG9ydCB7IFJlcGFpclJlcXVlc3RGb3JtIH0gZnJvbSAnLi9jb21wb25lbnRzL1JlcGFpclJlcXVlc3RGb3JtJztcclxuaW1wb3J0IHsgUmVwYWlyU3VjY2VzcyB9IGZyb20gJy4vY29tcG9uZW50cy9SZXBhaXJTdWNjZXNzJztcclxuXHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMucmVwYWlycztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlcGFpclJlcXVlc3RQYWdlKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIHJldHVybiB1c2VyID8gPFJlcGFpclJlcXVlc3RDb250ZW50IGtleT17dXNlci5pZH0gLz4gOiBudWxsO1xyXG59XHJcblxyXG5mdW5jdGlvbiBSZXBhaXJSZXF1ZXN0Q29udGVudCgpIHtcclxuICBjb25zdCBwYWdlID0gdXNlUmVwYWlyUmVxdWVzdCgpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgcHJldmlvdXMgPSBkb2N1bWVudC50aXRsZTtcclxuICAgIGRvY3VtZW50LnRpdGxlID0gYCR7dC5yZXF1ZXN0VGl0bGV9IHwgJHt0cmFuc2xhdGlvbnMuY29tbW9uLnN0b3JlTmFtZX1gO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYmctcGFnZSBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LVsxMjAwcHhdIHNwYWNlLXktOFwiPlxyXG4gICAgICAgIDxuYXZcclxuICAgICAgICAgIGFyaWEtbGFiZWw9e3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5icmVhZGNydW1ifVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPG9sIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLnByb2R1Y3RzfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5wcm9kdWN0c31cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBhcmlhLWhpZGRlbj1cInRydWVcIj4vPC9saT5cclxuICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLnJlcGFpcnN9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmsgaG92ZXI6dGV4dC1mZy1saW5rXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dC50aXRsZX1cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBhcmlhLWhpZGRlbj1cInRydWVcIj4vPC9saT5cclxuICAgICAgICAgICAgPGxpIGFyaWEtY3VycmVudD1cInBhZ2VcIj57dC5yZXF1ZXN0VGl0bGV9PC9saT5cclxuICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgPC9uYXY+XHJcblxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+e3QucmVxdWVzdFRpdGxlfTwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPnt0LnJlcXVlc3REZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtwYWdlLmNyZWF0ZWRUaWNrZXQgPyAoXHJcbiAgICAgICAgICA8UmVwYWlyU3VjY2VzcyB0aWNrZXQ9e3BhZ2UuY3JlYXRlZFRpY2tldH0gLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGl0ZW1zLXN0YXJ0IGdhcC04IHhsOmdyaWQtY29scy1bbWlubWF4KDAsNzYwcHgpX21pbm1heCgwLDMyMHB4KV1cIj5cclxuICAgICAgICAgICAgPFJlcGFpclJlcXVlc3RGb3JtIHBhZ2U9e3BhZ2V9IC8+XHJcbiAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzcGFjZS15LTYgeGw6c3RpY2t5IHhsOnRvcC0yNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTVcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgRmluZCB5b3VyIGRldmljZSBkZXRhaWxzXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICBMb29rIGZvciBhIHNtYWxsIHJhdGluZyBwbGF0ZSBvbiB0aGUgYmFjaywgYmFzZSBvciBpbnNpZGUgdGhlXHJcbiAgICAgICAgICAgICAgICAgIGRvb3Igb2YgeW91ciBhcHBsaWFuY2UuIE9uIGEgcGhvbmUsIGxvb2sgaW4gU2V0dGluZ3Mg4oaSIEFib3V0XHJcbiAgICAgICAgICAgICAgICAgIHBob25lLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxSYXRpbmdQbGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiWW91ciBkZXZpY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdNb2RlbCcsIHZhbHVlOiAnTG9vayBmb3Ig4oCcTW9kZWzigJ0gb3Ig4oCcTW9kLuKAnScgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdTZXJpYWwgbnVtYmVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICdMb29rIGZvciDigJxTL07igJ0gb3Ig4oCcU2VyaWFs4oCdJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICBmb290ZXI9XCJBbiBleGFtcGxlIG9mIHRoZSBpbmZvcm1hdGlvbiB0byBsb29rIGZvci5cIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNVwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPldoYXQgaGFwcGVucyBuZXh0PC9oMj5cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC01IHNwYWNlLXktNSB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb25cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJvcmRlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC01IHctNSBzaHJpbmstMCB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgT3VyIHRlYW0gcmV2aWV3cyB5b3VyIHJlcXVlc3QuXHJcbiAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb25cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZXBhaXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC01IHctNSBzaHJpbmstMCB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgV2UgdXBkYXRlIHlvdSBhcyB0aGUgcmVwYWlyIHByb2dyZXNzZXMuXHJcbiAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb25cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVja1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTUgdy01IHNocmluay0wIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICBUcmFjayBldmVyeXRoaW5nIGluIFlvdXIgcmVwYWlycy5cclxuICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==