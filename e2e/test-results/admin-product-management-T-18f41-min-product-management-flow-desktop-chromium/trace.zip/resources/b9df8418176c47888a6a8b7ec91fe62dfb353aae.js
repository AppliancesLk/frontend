import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductContent.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import { translations } from "/src/utils/translations.ts";
import { ProductSpecifications } from "/src/pages/Customer/ProductDetails/components/ProductSpecifications.tsx";
import { formatSpecificationValue, getSpecificationEntries, formatSpecificationLabel } from "/src/pages/Customer/ProductDetails/helpers/product-details.helpers.ts";
import { ProductReviews } from "/src/components/reviews/ProductReviews.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductContent.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.experience;
const tabs = [
	"overview",
	"specifications",
	"boxContents",
	"reviews"
];
export function ProductContent({ product, active, setActive, onSummary }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "product-content",
		className: "scroll-mt-36 rounded-md border border-line bg-surface p-4 sm:p-6",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			role: "tablist",
			"aria-label": translations.productDetails.details,
			className: "mb-6 flex gap-2 overflow-x-auto border-b border-line",
			children: tabs.map((tab, index) => /* @__PURE__ */ _jsxDEV("button", {
				id: `tab-${tab}`,
				role: "tab",
				"aria-selected": active === tab,
				"aria-controls": `panel-${tab}`,
				tabIndex: active === tab ? 0 : -1,
				onClick: () => setActive(tab),
				onKeyDown: (event) => {
					if ([
						"ArrowLeft",
						"ArrowRight",
						"Home",
						"End"
					].includes(event.key)) {
						event.preventDefault();
						const next = event.key === "Home" ? 0 : event.key === "End" ? tabs.length - 1 : (index + (event.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length;
						setActive(tabs[next]);
						document.getElementById(`tab-${tabs[next]}`)?.focus();
					}
				},
				className: `shrink-0 border-b-2 px-3 py-3 text-sm font-medium ${active === tab ? "border-primary text-fg-link" : "border-transparent text-fg-muted hover:text-fg"}`,
				children: [t[tab], tab === "reviews" ? ` (${product.ratingCount ?? 0})` : ""]
			}, tab, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this), tabs.map((tab) => /* @__PURE__ */ _jsxDEV("div", {
			role: "tabpanel",
			id: `panel-${tab}`,
			"aria-labelledby": `tab-${tab}`,
			hidden: active !== tab,
			tabIndex: 0,
			children: [
				tab === "overview" && /* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-6 xl:grid-cols-[1fr_1fr_1.1fr]",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "mb-3 font-semibold text-fg",
							children: t.description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "whitespace-pre-line text-sm leading-7 text-fg-secondary",
							children: product.description || t.noDescription
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "mb-3 font-semibold text-fg",
							children: t.features
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 17
						}, this), product.features?.length ? /* @__PURE__ */ _jsxDEV("ul", {
							className: "space-y-2 text-sm leading-6 text-fg-secondary",
							children: product.features.map((feature, index) => /* @__PURE__ */ _jsxDEV("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": "true",
									className: "font-bold text-fg-link",
									children: "✓"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: feature }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 25
								}, this)]
							}, index, true, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 23
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-fg-muted",
							children: t.noFeatures
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-md bg-primary-subtle p-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3 flex flex-wrap justify-between gap-2",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-sm font-semibold text-fg",
									children: t.keySpecifications
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActive("specifications"),
									className: "text-xs font-medium text-fg-link",
									children: [t.fullSpecifications, " →"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dl", {
								className: "divide-y divide-line-subtle",
								children: getSpecificationEntries(product.specifications).slice(0, 8).map(([label, value]) => /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3 py-2 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("dt", {
										className: "break-words text-fg-muted",
										children: formatSpecificationLabel(label)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("dd", {
										className: "break-words text-fg-secondary",
										children: formatSpecificationValue(value)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 25
									}, this)]
								}, label, true, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 23
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 13
				}, this),
				tab === "specifications" && /* @__PURE__ */ _jsxDEV(ProductSpecifications, { specifications: product.specifications }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 13
				}, this),
				tab === "boxContents" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "mb-4 text-lg font-semibold text-fg",
					children: t.boxContents
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 15
				}, this), product.boxContents?.length ? /* @__PURE__ */ _jsxDEV("ul", {
					className: "list-inside list-disc space-y-3 text-sm text-fg-secondary",
					children: product.boxContents.map((item, index) => /* @__PURE__ */ _jsxDEV("li", { children: item }, index, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 21
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 17
				}, this) : /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-fg-muted",
					children: t.noBox
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 13
				}, this),
				tab === "reviews" && /* @__PURE__ */ _jsxDEV(ProductReviews, {
					productId: product.productID,
					onSummary
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 13
				}, this)
			]
		}, tab, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 9
		}, this))]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_c = ProductContent;
var _c;
$RefreshReg$(_c, "ProductContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductContent.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductContent.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductContent.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductContent.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyw2QkFBNkI7QUFDdEMsU0FDRSwwQkFDQSx5QkFDQSxnQ0FDSztBQUNQLFNBQVMsc0JBQXNCOzs7QUFDL0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsTUFBTSxPQUFPO0NBQUM7Q0FBWTtDQUFrQjtDQUFlO0FBQVM7QUFFcEUsT0FBTyxTQUFTLGVBQWUsRUFDN0IsU0FDQSxRQUNBLFdBQ0EsYUFNQztDQUNELE9BQ0Usd0JBQUMsV0FBRDtFQUNFLElBQUc7RUFDSCxXQUFVO1lBRlosQ0FJRSx3QkFBQyxPQUFEO0dBQ0UsTUFBSztHQUNMLGNBQVksYUFBYSxlQUFlO0dBQ3hDLFdBQVU7YUFFVCxLQUFLLEtBQUssS0FBSyxVQUNkLHdCQUFDLFVBQUQ7SUFFRSxJQUFJLE9BQU87SUFDWCxNQUFLO0lBQ0wsaUJBQWUsV0FBVztJQUMxQixpQkFBZSxTQUFTO0lBQ3hCLFVBQVUsV0FBVyxNQUFNLElBQUksQ0FBQztJQUNoQyxlQUFlLFVBQVUsR0FBRztJQUM1QixZQUFZLFVBQVU7S0FDcEIsSUFDRTtNQUFDO01BQWE7TUFBYztNQUFRO0tBQUssQ0FBQyxDQUFDLFNBQVMsTUFBTSxHQUFHLEdBQzdEO01BQ0EsTUFBTSxlQUFlO01BQ3JCLE1BQU0sT0FDSixNQUFNLFFBQVEsU0FDVixJQUNBLE1BQU0sUUFBUSxRQUNaLEtBQUssU0FBUyxLQUNiLFNBQ0UsTUFBTSxRQUFRLGVBQWUsSUFBSSxLQUFLLFNBQVMsTUFDbEQsS0FBSztNQUNiLFVBQVUsS0FBSyxLQUFLO01BQ3BCLFNBQVMsZUFBZSxPQUFPLEtBQUssT0FBTyxDQUFDLEVBQUUsTUFBTTtLQUN0RDtJQUNGO0lBQ0EsV0FBVyxxREFBcUQsV0FBVyxNQUFNLGdDQUFnQztjQXpCbkgsQ0EyQkcsRUFBRSxNQUNGLFFBQVEsWUFBWSxLQUFLLFFBQVEsZUFBZSxFQUFFLEtBQUssRUFDbEQ7TUE1QkQ7Ozs7VUE0QkMsQ0FDVDtFQUNFOzs7O1lBQ0osS0FBSyxLQUFLLFFBQ1Qsd0JBQUMsT0FBRDtHQUVFLE1BQUs7R0FDTCxJQUFJLFNBQVM7R0FDYixtQkFBaUIsT0FBTztHQUN4QixRQUFRLFdBQVc7R0FDbkIsVUFBVTthQU5aO0lBUUcsUUFBUSxjQUNQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQThCLEVBQUU7TUFBZ0I7Ozs7Z0JBQzlELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLFFBQVEsZUFBZSxFQUFFO01BQ3pCOzs7O2NBQ0E7Ozs7O01BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUE4QixFQUFFO01BQWE7Ozs7Z0JBQzFELFFBQVEsVUFBVSxTQUNqQix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxRQUFRLFNBQVMsS0FBSyxTQUFTLFVBQzlCLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsUUFBRDtTQUNFLGVBQVk7U0FDWixXQUFVO21CQUNYO1FBRUs7Ozs7a0JBQ04sd0JBQUMsUUFBRCxZQUFPLFFBQWM7Ozs7Z0JBQ25CO1VBUjRCOzs7O2NBUTVCLENBQ0w7TUFDQzs7OztpQkFFSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUIsRUFBRTtNQUFjOzs7O2NBRXJEOzs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxFQUFFO1FBQ0Q7Ozs7a0JBQ0osd0JBQUMsVUFBRDtTQUNFLGVBQWUsVUFBVSxnQkFBZ0I7U0FDekMsV0FBVTttQkFGWixDQUlHLEVBQUUsb0JBQW1CLElBQ2hCOzs7OztnQkFDTDs7Ozs7aUJBQ0wsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsd0JBQXdCLFFBQVEsY0FBYyxDQUFDLENBQzdDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FDWCxLQUFLLENBQUMsT0FBTyxXQUNaLHdCQUFDLE9BQUQ7U0FFRSxXQUFVO21CQUZaLENBSUUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gseUJBQXlCLEtBQUs7U0FDN0I7Ozs7bUJBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gseUJBQXlCLEtBQUs7U0FDN0I7Ozs7aUJBQ0Q7V0FURTs7OztlQVNGLENBQ047T0FDRDs7OztlQUNEOzs7Ozs7S0FDRjs7Ozs7O0lBRU4sUUFBUSxvQkFDUCx3QkFBQyx1QkFBRCxFQUF1QixnQkFBZ0IsUUFBUSxlQUFpQjs7Ozs7SUFFakUsUUFBUSxpQkFDUCxnREFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLEVBQUU7SUFDRDs7OztjQUNILFFBQVEsYUFBYSxTQUNwQix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLFFBQVEsWUFBWSxLQUFLLE1BQU0sVUFDOUIsd0JBQUMsTUFBRCxZQUFpQixLQUFTLEdBQWpCOzs7O1lBQWlCLENBQzNCO0lBQ0M7Ozs7ZUFFSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF5QixFQUFFO0lBQVM7Ozs7WUFFbkQ7Ozs7O0lBRUgsUUFBUSxhQUNQLHdCQUFDLGdCQUFEO0tBQ0UsV0FBVyxRQUFRO0tBQ1I7SUFDWjs7Ozs7R0FFQTtLQTVGRTs7OztTQTRGRixDQUNOLENBQ007Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2R1Y3RDb250ZW50LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9wcm9kdWN0LnR5cGVzJztcclxuaW1wb3J0IHR5cGUgeyBSZXZpZXdTdW1tYXJ5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvcmV2aWV3LnR5cGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgUHJvZHVjdFNwZWNpZmljYXRpb25zIH0gZnJvbSAnLi9Qcm9kdWN0U3BlY2lmaWNhdGlvbnMnO1xyXG5pbXBvcnQge1xyXG4gIGZvcm1hdFNwZWNpZmljYXRpb25WYWx1ZSxcclxuICBnZXRTcGVjaWZpY2F0aW9uRW50cmllcyxcclxuICBmb3JtYXRTcGVjaWZpY2F0aW9uTGFiZWwsXHJcbn0gZnJvbSAnLi4vaGVscGVycy9wcm9kdWN0LWRldGFpbHMuaGVscGVycyc7XHJcbmltcG9ydCB7IFByb2R1Y3RSZXZpZXdzIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9yZXZpZXdzL1Byb2R1Y3RSZXZpZXdzJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5leHBlcmllbmNlO1xyXG5jb25zdCB0YWJzID0gWydvdmVydmlldycsICdzcGVjaWZpY2F0aW9ucycsICdib3hDb250ZW50cycsICdyZXZpZXdzJ10gYXMgY29uc3Q7XHJcbmV4cG9ydCB0eXBlIFByb2R1Y3RUYWIgPSAodHlwZW9mIHRhYnMpW251bWJlcl07XHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0Q29udGVudCh7XHJcbiAgcHJvZHVjdCxcclxuICBhY3RpdmUsXHJcbiAgc2V0QWN0aXZlLFxyXG4gIG9uU3VtbWFyeSxcclxufToge1xyXG4gIHByb2R1Y3Q6IFByb2R1Y3Q7XHJcbiAgYWN0aXZlOiBQcm9kdWN0VGFiO1xyXG4gIHNldEFjdGl2ZTogKHRhYjogUHJvZHVjdFRhYikgPT4gdm9pZDtcclxuICBvblN1bW1hcnk6IChzdW1tYXJ5OiBSZXZpZXdTdW1tYXJ5KSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uXHJcbiAgICAgIGlkPVwicHJvZHVjdC1jb250ZW50XCJcclxuICAgICAgY2xhc3NOYW1lPVwic2Nyb2xsLW10LTM2IHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC00IHNtOnAtNlwiXHJcbiAgICA+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICByb2xlPVwidGFibGlzdFwiXHJcbiAgICAgICAgYXJpYS1sYWJlbD17dHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLmRldGFpbHN9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibWItNiBmbGV4IGdhcC0yIG92ZXJmbG93LXgtYXV0byBib3JkZXItYiBib3JkZXItbGluZVwiXHJcbiAgICAgID5cclxuICAgICAgICB7dGFicy5tYXAoKHRhYiwgaW5kZXgpID0+IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PXt0YWJ9XHJcbiAgICAgICAgICAgIGlkPXtgdGFiLSR7dGFifWB9XHJcbiAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxyXG4gICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXthY3RpdmUgPT09IHRhYn1cclxuICAgICAgICAgICAgYXJpYS1jb250cm9scz17YHBhbmVsLSR7dGFifWB9XHJcbiAgICAgICAgICAgIHRhYkluZGV4PXthY3RpdmUgPT09IHRhYiA/IDAgOiAtMX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlKHRhYil9XHJcbiAgICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgWydBcnJvd0xlZnQnLCAnQXJyb3dSaWdodCcsICdIb21lJywgJ0VuZCddLmluY2x1ZGVzKGV2ZW50LmtleSlcclxuICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0ID1cclxuICAgICAgICAgICAgICAgICAgZXZlbnQua2V5ID09PSAnSG9tZSdcclxuICAgICAgICAgICAgICAgICAgICA/IDBcclxuICAgICAgICAgICAgICAgICAgICA6IGV2ZW50LmtleSA9PT0gJ0VuZCdcclxuICAgICAgICAgICAgICAgICAgICAgID8gdGFicy5sZW5ndGggLSAxXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IChpbmRleCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGV2ZW50LmtleSA9PT0gJ0Fycm93UmlnaHQnID8gMSA6IHRhYnMubGVuZ3RoIC0gMSkpICVcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFicy5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmUodGFic1tuZXh0XSk7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgdGFiLSR7dGFic1tuZXh0XX1gKT8uZm9jdXMoKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHNocmluay0wIGJvcmRlci1iLTIgcHgtMyBweS0zIHRleHQtc20gZm9udC1tZWRpdW0gJHthY3RpdmUgPT09IHRhYiA/ICdib3JkZXItcHJpbWFyeSB0ZXh0LWZnLWxpbmsnIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWZnLW11dGVkIGhvdmVyOnRleHQtZmcnfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0W3RhYl19XHJcbiAgICAgICAgICAgIHt0YWIgPT09ICdyZXZpZXdzJyA/IGAgKCR7cHJvZHVjdC5yYXRpbmdDb3VudCA/PyAwfSlgIDogJyd9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHt0YWJzLm1hcCgodGFiKSA9PiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAga2V5PXt0YWJ9XHJcbiAgICAgICAgICByb2xlPVwidGFicGFuZWxcIlxyXG4gICAgICAgICAgaWQ9e2BwYW5lbC0ke3RhYn1gfVxyXG4gICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PXtgdGFiLSR7dGFifWB9XHJcbiAgICAgICAgICBoaWRkZW49e2FjdGl2ZSAhPT0gdGFifVxyXG4gICAgICAgICAgdGFiSW5kZXg9ezB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3RhYiA9PT0gJ292ZXJ2aWV3JyAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiB4bDpncmlkLWNvbHMtWzFmcl8xZnJfMS4xZnJdXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi0zIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt0LmRlc2NyaXB0aW9ufTwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLXByZS1saW5lIHRleHQtc20gbGVhZGluZy03IHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwcm9kdWN0LmRlc2NyaXB0aW9uIHx8IHQubm9EZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3QuZmVhdHVyZXN9PC9oMj5cclxuICAgICAgICAgICAgICAgIHtwcm9kdWN0LmZlYXR1cmVzPy5sZW5ndGggPyAoXHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdC5mZWF0dXJlcy5tYXAoKGZlYXR1cmUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDinJNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZmVhdHVyZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3Qubm9GZWF0dXJlc308L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBiZy1wcmltYXJ5LXN1YnRsZSBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Qua2V5U3BlY2lmaWNhdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmUoJ3NwZWNpZmljYXRpb25zJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3QuZnVsbFNwZWNpZmljYXRpb25zfSDihpJcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtbGluZS1zdWJ0bGVcIj5cclxuICAgICAgICAgICAgICAgICAge2dldFNwZWNpZmljYXRpb25FbnRyaWVzKHByb2R1Y3Quc3BlY2lmaWNhdGlvbnMpXHJcbiAgICAgICAgICAgICAgICAgICAgLnNsaWNlKDAsIDgpXHJcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgoW2xhYmVsLCB2YWx1ZV0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBweS0yIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiYnJlYWstd29yZHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRTcGVjaWZpY2F0aW9uTGFiZWwobGFiZWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiYnJlYWstd29yZHMgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0U3BlY2lmaWNhdGlvblZhbHVlKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge3RhYiA9PT0gJ3NwZWNpZmljYXRpb25zJyAmJiAoXHJcbiAgICAgICAgICAgIDxQcm9kdWN0U3BlY2lmaWNhdGlvbnMgc3BlY2lmaWNhdGlvbnM9e3Byb2R1Y3Quc3BlY2lmaWNhdGlvbnN9IC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge3RhYiA9PT0gJ2JveENvbnRlbnRzJyAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgIHt0LmJveENvbnRlbnRzfVxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAge3Byb2R1Y3QuYm94Q29udGVudHM/Lmxlbmd0aCA/IChcclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWluc2lkZSBsaXN0LWRpc2Mgc3BhY2UteS0zIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAge3Byb2R1Y3QuYm94Q29udGVudHMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2luZGV4fT57aXRlbX08L2xpPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1mZy1tdXRlZFwiPnt0Lm5vQm94fTwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICB7dGFiID09PSAncmV2aWV3cycgJiYgKFxyXG4gICAgICAgICAgICA8UHJvZHVjdFJldmlld3NcclxuICAgICAgICAgICAgICBwcm9kdWN0SWQ9e3Byb2R1Y3QucHJvZHVjdElEfVxyXG4gICAgICAgICAgICAgIG9uU3VtbWFyeT17b25TdW1tYXJ5fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=