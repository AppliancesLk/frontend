import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import "/src/App.css";
import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { AuthProvider } from "/src/context/AuthProvider.tsx";
import { ToastRegion } from "/src/components/feedback/ToastRegion.tsx";
import { SeasonalThemeProvider } from "/src/context/SeasonalThemeProvider.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/App.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
function App() {
	return /* @__PURE__ */ _jsxDEV(SeasonalThemeProvider, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: [/* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 9
	}, this), /* @__PURE__ */ _jsxDEV(ToastRegion, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLDZCQUE2Qjs7O0FBQ3RDLFNBQVMsTUFBTTtDQUNiLE9BQ0Usd0JBQUMsdUJBQUQsWUFDRSx3QkFBQyxjQUFELGFBQ0Usd0JBQUMsUUFBRCxDQUFTOzs7O1dBQ1Qsd0JBQUMsYUFBRCxDQUFjOzs7O1NBQ0Y7Ozs7VUFDTzs7Ozs7QUFFM0I7O0FBQ0EsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi9BcHAuY3NzJztcclxuaW1wb3J0IHsgT3V0bGV0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEF1dGhQcm92aWRlciB9IGZyb20gJy4vY29udGV4dC9BdXRoUHJvdmlkZXInO1xyXG5pbXBvcnQgeyBUb2FzdFJlZ2lvbiB9IGZyb20gJy4vY29tcG9uZW50cy9mZWVkYmFjay9Ub2FzdFJlZ2lvbic7XHJcbmltcG9ydCB7IFNlYXNvbmFsVGhlbWVQcm92aWRlciB9IGZyb20gJy4vY29udGV4dC9TZWFzb25hbFRoZW1lUHJvdmlkZXInO1xyXG5mdW5jdGlvbiBBcHAoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxTZWFzb25hbFRoZW1lUHJvdmlkZXI+XHJcbiAgICAgIDxBdXRoUHJvdmlkZXI+XHJcbiAgICAgICAgPE91dGxldCAvPlxyXG4gICAgICAgIDxUb2FzdFJlZ2lvbiAvPlxyXG4gICAgICA8L0F1dGhQcm92aWRlcj5cclxuICAgIDwvU2Vhc29uYWxUaGVtZVByb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgQXBwO1xyXG4iXX0=