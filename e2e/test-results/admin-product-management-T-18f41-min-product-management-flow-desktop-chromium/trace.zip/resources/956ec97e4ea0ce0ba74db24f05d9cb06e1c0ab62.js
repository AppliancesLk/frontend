import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/index.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];const useState = __vite__cjsImport6_react["useState"];import { ProductTable } from "/src/pages/Admin/Products/components/ProductTable.tsx";
import { ProductForm } from "/src/pages/Admin/Products/components/ProductForm.tsx";
import { useProductsPage } from "/src/pages/Admin/Products/hooks/useProductsPage.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { translations } from "/src/utils/translations.ts";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/index.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.admin;
export default function AdminProductsPage() {
	_s();
	const page = useProductsPage();
	const [drawerOpen, setDrawerOpen] = useState(false);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.products
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 14
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.productsDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 69
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "auth-primary",
					onClick: () => setDrawerOpen(true),
					children: t.addProduct
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this),
			!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV(ProductTable, { page }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: drawerOpen,
				onClose: () => setDrawerOpen(false),
				title: t.addProduct,
				drawer: true,
				busy: page.busy,
				children: /* @__PURE__ */ _jsxDEV(ProductForm, { page }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s(AdminProductsPage, "WOdFmZUYJ3hepECTYJNUu8bjDCM=", false, function() {
	return [useProductsPage];
});
_c = AdminProductsPage;
var _c;
$RefreshReg$(_c, "AdminProductsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZ0JBQWdCOzs7O0FBQ3pCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLGVBQWUsU0FBUyxvQkFBb0I7O0NBQzFDLE1BQU0sT0FBTyxnQkFBZ0I7Q0FDN0IsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFhOzs7O2NBQUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEIsRUFBRTtJQUF1Qjs7OztZQUFNOzs7O2NBQ3RJLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsV0FBVTtLQUFlLGVBQWUsY0FBYyxJQUFJO2VBQUksRUFBRTtJQUFtQjs7OztZQUNuRzs7Ozs7O0dBQ1Isd0JBQUMsaUJBQUQ7SUFDRSxTQUFTLEtBQUs7SUFDZCxPQUFPLEtBQUs7SUFDWixPQUFPLEtBQUs7R0FDYjs7Ozs7R0FDQSxDQUFDLEtBQUssV0FBVyxDQUFDLEtBQUssU0FDdEIsK0NBQ0Usd0JBQUMsY0FBRCxFQUFvQixLQUFPOzs7O1lBQzNCOzs7OztHQUVKLHdCQUFDLFFBQUQ7SUFBUSxNQUFNO0lBQVksZUFBZSxjQUFjLEtBQUs7SUFBRyxPQUFPLEVBQUU7SUFBWTtJQUFPLE1BQU0sS0FBSztjQUNwRyx3QkFBQyxhQUFELEVBQW1CLEtBQU87Ozs7O0dBQ3BCOzs7OztFQUNEOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUHJvZHVjdFRhYmxlIH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RUYWJsZSc7XHJcbmltcG9ydCB7IFByb2R1Y3RGb3JtIH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RGb3JtJztcclxuaW1wb3J0IHsgdXNlUHJvZHVjdHNQYWdlIH0gZnJvbSAnLi9ob29rcy91c2VQcm9kdWN0c1BhZ2UnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IERpYWxvZyB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuYWRtaW47XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFkbWluUHJvZHVjdHNQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VQcm9kdWN0c1BhZ2UoKTtcclxuICBjb25zdCBbZHJhd2VyT3Blbiwgc2V0RHJhd2VyT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+PGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGUgdGV4dC1mZ1wiPnt0LnByb2R1Y3RzfTwvaDE+PHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5wcm9kdWN0c0Rlc2NyaXB0aW9ufTwvcD48L2Rpdj5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXREcmF3ZXJPcGVuKHRydWUpfT57dC5hZGRQcm9kdWN0fTwvYnV0dG9uPlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAgPENhdGFsb2dGZWVkYmFja1xyXG4gICAgICAgIGxvYWRpbmc9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICBlcnJvcj17cGFnZS5lcnJvcn1cclxuICAgICAgICByZXRyeT17cGFnZS5yZWZyZXNofVxyXG4gICAgICAvPlxyXG4gICAgICB7IXBhZ2UubG9hZGluZyAmJiAhcGFnZS5lcnJvciAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxQcm9kdWN0VGFibGUgcGFnZT17cGFnZX0gLz5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAgPERpYWxvZyBvcGVuPXtkcmF3ZXJPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXREcmF3ZXJPcGVuKGZhbHNlKX0gdGl0bGU9e3QuYWRkUHJvZHVjdH0gZHJhd2VyIGJ1c3k9e3BhZ2UuYnVzeX0+XHJcbiAgICAgICAgPFByb2R1Y3RGb3JtIHBhZ2U9e3BhZ2V9IC8+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19