import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Orders/components/OrderList.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { CopyReference } from "/src/components/common/CopyReference.tsx";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { EmptyState } from "/src/components/ui/Feedback.tsx";
import { Link, generatePath } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { formatDate } from "/src/utils/date.ts";
import { OrderStatusBadge } from "/src/pages/Customer/Orders/components/OrderStatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderList.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.orders;
export function OrderList({ orders }) {
	_s();
	const [filter, setFilter] = useState("All");
	const [query, setQuery] = useState("");
	const visible = orders.filter((order) => order.id.toLowerCase().includes(query.toLowerCase()) && (filter === "All" || (filter === "Delivered" ? order.status === "DELIVERED" : filter === "Cancelled" ? order.status === "CANCELLED" : !["DELIVERED", "CANCELLED"].includes(order.status))));
	if (!orders.length) return /* @__PURE__ */ _jsxDEV(EmptyState, {
		title: t.empty,
		description: t.emptyDescription,
		action: /* @__PURE__ */ _jsxDEV(Link, {
			to: ROUTES.products,
			className: "auth-primary mt-6",
			children: translations.common.continueShopping
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 11
		}, this),
		icon: "orders"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 7
	}, this);
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-label": t.title,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex max-w-full gap-5 overflow-x-auto border-b border-line",
						role: "group",
						"aria-label": "Filter orders",
						children: [
							"All",
							"In progress",
							"Delivered",
							"Cancelled"
						].map((item) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setFilter(item),
							"aria-pressed": filter === item,
							className: `min-h-11 shrink-0 border-b-2 text-sm ${filter === item ? "border-primary text-fg" : "border-transparent text-fg-muted"}`,
							children: item
						}, item, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "sr-only",
						htmlFor: "order-search",
						children: "Search by order number"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						className: "ui-field w-full sm:w-64",
						id: "order-search",
						placeholder: "Search by order number?",
						value: query,
						onChange: (event) => setQuery(event.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 7
			}, this),
			visible.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "py-12 text-center text-sm text-fg-muted",
				children: "No orders match your search."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "space-y-4",
				children: visible.map((order) => /* @__PURE__ */ _jsxDEV("li", {
					className: "rounded-md border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "font-sans text-base font-semibold",
									children: ["Order #", order.id.slice(0, 8).toUpperCase()]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 82,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(CopyReference, { value: order.id }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 85,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(OrderStatusBadge, { status: order.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 flex gap-2",
							children: [order.items.slice(0, 4).map((item) => /* @__PURE__ */ _jsxDEV(ProductImage, {
								src: item.images[0],
								alt: item.name,
								className: "h-14 w-14 rounded-sm bg-well p-1"
							}, item.id, false, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 17
							}, this)), order.items.length > 4 && /* @__PURE__ */ _jsxDEV("span", {
								className: "flex h-14 w-14 items-center justify-center rounded-sm bg-subtle text-sm text-fg-muted",
								children: ["+", order.items.length - 4]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-5 flex flex-wrap items-end justify-between gap-4",
							children: [/* @__PURE__ */ _jsxDEV("dl", {
								className: "flex flex-wrap gap-x-12 gap-y-4 text-sm",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-fg-muted",
									children: t.date
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 text-fg",
									children: /* @__PURE__ */ _jsxDEV("time", {
										dateTime: order.createdAt,
										children: formatDate(order.createdAt)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 109,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-fg-muted",
									children: t.total
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 font-semibold text-fg",
									children: formatCurrency(order.total)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: generatePath(ROUTES.orderDetail, { id: order.id }),
								className: "auth-secondary",
								"aria-label": `${t.view} ${order.id}`,
								children: t.view
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 13
						}, this)
					]
				}, order.id, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 5
	}, this);
}
_s(OrderList, "LSAa0ZrsHX5DqQ7b6+pRXrZDjxk=");
_c = OrderList;
var _c;
$RefreshReg$(_c, "OrderList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Orders/components/OrderList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxNQUFNLG9CQUFvQjtBQUVuQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyx3QkFBd0I7Ozs7QUFDakMsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLFVBQVUsRUFBRSxVQUErQjs7Q0FDekQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxVQUFVLE9BQU8sUUFDcEIsVUFDQyxNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUMsU0FBUyxNQUFNLFlBQVksQ0FBQyxNQUNsRCxXQUFXLFVBQ1QsV0FBVyxjQUNSLE1BQU0sV0FBVyxjQUNqQixXQUFXLGNBQ1QsTUFBTSxXQUFXLGNBQ2pCLENBQUMsQ0FBQyxhQUFhLFdBQVcsQ0FBQyxDQUFDLFNBQVMsTUFBTSxNQUFNLEdBQzdEO0NBQ0EsSUFBSSxDQUFDLE9BQU8sUUFDVixPQUNFLHdCQUFDLFlBQUQ7RUFDRSxPQUFPLEVBQUU7RUFDVCxhQUFhLEVBQUU7RUFDZixRQUNFLHdCQUFDLE1BQUQ7R0FBTSxJQUFJLE9BQU87R0FBVSxXQUFVO2FBQ2xDLGFBQWEsT0FBTztFQUNqQjs7Ozs7RUFFUixNQUFLO0NBQ047Ozs7O0NBRUwsT0FDRSx3QkFBQyxXQUFEO0VBQVMsY0FBWSxFQUFFO0VBQU8sV0FBVTtZQUF4QztHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLE1BQUs7TUFDTCxjQUFXO2dCQUVWO09BQUM7T0FBTztPQUFlO09BQWE7TUFBVyxDQUFDLENBQUMsS0FBSyxTQUNyRCx3QkFBQyxVQUFEO09BRUUsZUFBZSxVQUFVLElBQUk7T0FDN0IsZ0JBQWMsV0FBVztPQUN6QixXQUFXLHdDQUF3QyxXQUFXLE9BQU8sMkJBQTJCO2lCQUUvRjtNQUNLLEdBTkQ7Ozs7YUFNQyxDQUNUO0tBQ0U7Ozs7O0tBQ0wsd0JBQUMsU0FBRDtNQUFPLFdBQVU7TUFBVSxTQUFRO2dCQUFlO0tBRTNDOzs7OztLQUNQLHdCQUFDLFNBQUQ7TUFDRSxXQUFVO01BQ1YsSUFBRztNQUNILGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVyxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7S0FDakQ7Ozs7O0lBQ0U7Ozs7OztHQUNKLFFBQVEsV0FBVyxLQUNsQix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUEwQztHQUVwRDs7Ozs7R0FFTCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLFFBQVEsS0FBSyxVQUNaLHdCQUFDLE1BQUQ7S0FFRSxXQUFVO2VBRlo7TUFJRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FBa0QsV0FDeEMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQ3ZDOzs7OztrQkFDSix3QkFBQyxlQUFELEVBQWUsT0FBTyxNQUFNLEdBQUs7Ozs7Z0JBQzlCOzs7OztpQkFDTCx3QkFBQyxrQkFBRCxFQUFrQixRQUFRLE1BQU0sT0FBUzs7OztlQUN0Qzs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRyxNQUFNLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FDNUIsd0JBQUMsY0FBRDtRQUVFLEtBQUssS0FBSyxPQUFPO1FBQ2pCLEtBQUssS0FBSztRQUNWLFdBQVU7T0FDWCxHQUpNLEtBQUs7Ozs7Y0FJWCxDQUNGLEdBQ0EsTUFBTSxNQUFNLFNBQVMsS0FDcEIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQXdHLEtBQ3BHLE1BQU0sTUFBTSxTQUFTLENBQ25COzs7OztlQUVMOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFpQixFQUFFO1FBQVM7Ozs7a0JBQzFDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQ7VUFBTSxVQUFVLE1BQU07b0JBQ25CLFdBQVcsTUFBTSxTQUFTO1NBQ3ZCOzs7OztRQUNKOzs7O2dCQUNEOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBaUIsRUFBRTtRQUFVOzs7O2tCQUMzQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxlQUFlLE1BQU0sS0FBSztRQUN6Qjs7OztnQkFDRDs7OztnQkFDSDs7Ozs7aUJBQ0osd0JBQUMsTUFBRDtRQUNFLElBQUksYUFBYSxPQUFPLGFBQWEsRUFBRSxJQUFJLE1BQU0sR0FBRyxDQUFDO1FBQ3JELFdBQVU7UUFDVixjQUFZLEdBQUcsRUFBRSxLQUFLLEdBQUcsTUFBTTtrQkFFOUIsRUFBRTtPQUNDOzs7O2VBQ0g7Ozs7OztLQUNIO09BcERHLE1BQU07Ozs7V0FvRFQsQ0FDTDtHQUNDOzs7OztFQUNHOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPcmRlckxpc3QudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDb3B5UmVmZXJlbmNlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vQ29weVJlZmVyZW5jZSc7XHJcbmltcG9ydCB7IFByb2R1Y3RJbWFnZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1Byb2R1Y3RJbWFnZSc7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgTGluaywgZ2VuZXJhdGVQYXRoIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB0eXBlIHsgT3JkZXIgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9vcmRlci50eXBlcyc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGUnO1xyXG5pbXBvcnQgeyBPcmRlclN0YXR1c0JhZGdlIH0gZnJvbSAnLi9PcmRlclN0YXR1c0JhZGdlJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5vcmRlcnM7XHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlckxpc3QoeyBvcmRlcnMgfTogeyBvcmRlcnM6IE9yZGVyW10gfSkge1xyXG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZSgnQWxsJyk7XHJcbiAgY29uc3QgW3F1ZXJ5LCBzZXRRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgdmlzaWJsZSA9IG9yZGVycy5maWx0ZXIoXHJcbiAgICAob3JkZXIpID0+XHJcbiAgICAgIG9yZGVyLmlkLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkudG9Mb3dlckNhc2UoKSkgJiZcclxuICAgICAgKGZpbHRlciA9PT0gJ0FsbCcgfHxcclxuICAgICAgICAoZmlsdGVyID09PSAnRGVsaXZlcmVkJ1xyXG4gICAgICAgICAgPyBvcmRlci5zdGF0dXMgPT09ICdERUxJVkVSRUQnXHJcbiAgICAgICAgICA6IGZpbHRlciA9PT0gJ0NhbmNlbGxlZCdcclxuICAgICAgICAgICAgPyBvcmRlci5zdGF0dXMgPT09ICdDQU5DRUxMRUQnXHJcbiAgICAgICAgICAgIDogIVsnREVMSVZFUkVEJywgJ0NBTkNFTExFRCddLmluY2x1ZGVzKG9yZGVyLnN0YXR1cykpKSxcclxuICApO1xyXG4gIGlmICghb3JkZXJzLmxlbmd0aClcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgdGl0bGU9e3QuZW1wdHl9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3QuZW1wdHlEZXNjcmlwdGlvbn1cclxuICAgICAgICBhY3Rpb249e1xyXG4gICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5wcm9kdWN0c30gY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IG10LTZcIj5cclxuICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jb21tb24uY29udGludWVTaG9wcGluZ31cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICB9XHJcbiAgICAgICAgaWNvbj1cIm9yZGVyc1wiXHJcbiAgICAgIC8+XHJcbiAgICApO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPXt0LnRpdGxlfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtYXgtdy1mdWxsIGdhcC01IG92ZXJmbG93LXgtYXV0byBib3JkZXItYiBib3JkZXItbGluZVwiXHJcbiAgICAgICAgICByb2xlPVwiZ3JvdXBcIlxyXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkZpbHRlciBvcmRlcnNcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtbJ0FsbCcsICdJbiBwcm9ncmVzcycsICdEZWxpdmVyZWQnLCAnQ2FuY2VsbGVkJ10ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBrZXk9e2l0ZW19XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKGl0ZW0pfVxyXG4gICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17ZmlsdGVyID09PSBpdGVtfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1pbi1oLTExIHNocmluay0wIGJvcmRlci1iLTIgdGV4dC1zbSAke2ZpbHRlciA9PT0gaXRlbSA/ICdib3JkZXItcHJpbWFyeSB0ZXh0LWZnJyA6ICdib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1mZy1tdXRlZCd9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtpdGVtfVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzci1vbmx5XCIgaHRtbEZvcj1cIm9yZGVyLXNlYXJjaFwiPlxyXG4gICAgICAgICAgU2VhcmNoIGJ5IG9yZGVyIG51bWJlclxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCB3LWZ1bGwgc206dy02NFwiXHJcbiAgICAgICAgICBpZD1cIm9yZGVyLXNlYXJjaFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBvcmRlciBudW1iZXI/XCJcclxuICAgICAgICAgIHZhbHVlPXtxdWVyeX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFF1ZXJ5KGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHt2aXNpYmxlLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicHktMTIgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICBObyBvcmRlcnMgbWF0Y2ggeW91ciBzZWFyY2guXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAge3Zpc2libGUubWFwKChvcmRlcikgPT4gKFxyXG4gICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgIGtleT17b3JkZXIuaWR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2FucyB0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICBPcmRlciAje29yZGVyLmlkLnNsaWNlKDAsIDgpLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgPENvcHlSZWZlcmVuY2UgdmFsdWU9e29yZGVyLmlkfSAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxPcmRlclN0YXR1c0JhZGdlIHN0YXR1cz17b3JkZXIuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICB7b3JkZXIuaXRlbXMuc2xpY2UoMCwgNCkubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8UHJvZHVjdEltYWdlXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgc3JjPXtpdGVtLmltYWdlc1swXX1cclxuICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgdy0xNCByb3VuZGVkLXNtIGJnLXdlbGwgcC0xXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAge29yZGVyLml0ZW1zLmxlbmd0aCA+IDQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBoLTE0IHctMTQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtc20gYmctc3VidGxlIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAre29yZGVyLml0ZW1zLmxlbmd0aCAtIDR9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC14LTEyIGdhcC15LTQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtZmctbXV0ZWRcIj57dC5kYXRlfTwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGltZSBkYXRlVGltZT17b3JkZXIuY3JlYXRlZEF0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKG9yZGVyLmNyZWF0ZWRBdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90aW1lPlxyXG4gICAgICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPnt0LnRvdGFsfTwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShvcmRlci50b3RhbCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2RsPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICB0bz17Z2VuZXJhdGVQYXRoKFJPVVRFUy5vcmRlckRldGFpbCwgeyBpZDogb3JkZXIuaWQgfSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHt0LnZpZXd9ICR7b3JkZXIuaWR9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dC52aWV3fVxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L3VsPlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19