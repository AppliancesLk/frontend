import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Orders/index.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { translations } from "/src/utils/translations.ts";
import { AdminOrdersTable } from "/src/pages/Admin/Orders/components/AdminOrdersTable.tsx";
import { useAdminOrdersPage } from "/src/pages/Admin/Orders/hooks/useAdminOrdersPage.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/index.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.adminOrders;
export default function AdminOrdersPage() {
	_s();
	const page = useAdminOrdersPage();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: page.refresh,
					disabled: page.loading,
					className: "auth-secondary ",
					children: t.refresh
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(AdminOrdersTable, { orders: page.orders }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_s(AdminOrdersPage, "swiaj9akQBluzULbLC42r0gox44=", false, function() {
	return [useAdminOrdersPage];
});
_c = AdminOrdersPage;
var _c;
$RefreshReg$(_c, "AdminOrdersPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Orders/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx3QkFBd0I7QUFDakMsU0FBUywwQkFBMEI7Ozs7QUFFbkMsTUFBTSxJQUFJLGFBQWE7QUFDdkIsZUFBZSxTQUFTLGtCQUFrQjs7Q0FDeEMsTUFBTSxPQUFPLG1CQUFtQjtDQUNoQyxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFVOzs7O2NBQ25ELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCLEVBQUU7SUFBZTs7OztZQUN6RDs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUyxLQUFLO0tBQ2QsVUFBVSxLQUFLO0tBQ2YsV0FBVTtlQUVULEVBQUU7SUFDRzs7OztZQUNGOzs7Ozs7R0FDUix3QkFBQyxpQkFBRDtJQUNFLFNBQVMsS0FBSztJQUNkLE9BQU8sS0FBSztJQUNaLE9BQU8sS0FBSztHQUNiOzs7OztHQUNBLENBQUMsS0FBSyxXQUFXLENBQUMsS0FBSyxTQUN0Qix3QkFBQyxrQkFBRCxFQUFrQixRQUFRLEtBQUssT0FBUzs7Ozs7RUFFbkM7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IEFkbWluT3JkZXJzVGFibGUgfSBmcm9tICcuL2NvbXBvbmVudHMvQWRtaW5PcmRlcnNUYWJsZSc7XHJcbmltcG9ydCB7IHVzZUFkbWluT3JkZXJzUGFnZSB9IGZyb20gJy4vaG9va3MvdXNlQWRtaW5PcmRlcnNQYWdlJztcclxuXHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuYWRtaW5PcmRlcnM7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFkbWluT3JkZXJzUGFnZSgpIHtcclxuICBjb25zdCBwYWdlID0gdXNlQWRtaW5PcmRlcnNQYWdlKCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+e3QudGl0bGV9PC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3QuZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17cGFnZS5yZWZyZXNofVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5IFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3QucmVmcmVzaH1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICAgIDxDYXRhbG9nRmVlZGJhY2tcclxuICAgICAgICBsb2FkaW5nPXtwYWdlLmxvYWRpbmd9XHJcbiAgICAgICAgZXJyb3I9e3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgcmV0cnk9e3BhZ2UucmVmcmVzaH1cclxuICAgICAgLz5cclxuICAgICAgeyFwYWdlLmxvYWRpbmcgJiYgIXBhZ2UuZXJyb3IgJiYgKFxyXG4gICAgICAgIDxBZG1pbk9yZGVyc1RhYmxlIG9yZGVycz17cGFnZS5vcmRlcnN9IC8+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=