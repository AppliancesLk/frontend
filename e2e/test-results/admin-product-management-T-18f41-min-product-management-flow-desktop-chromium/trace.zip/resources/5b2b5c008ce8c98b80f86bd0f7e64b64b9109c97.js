import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/SiteHeader.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport16_react_jsxDevRuntime["Fragment"];import { formatCategoryName } from "/src/utils/category.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link, NavLink, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { USER_ROLES } from "/src/constants/roles.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { useAuth } from "/src/hooks/useAuth.ts";
import { getCart } from "/src/services/cartService.ts";
import { getCategories } from "/src/services/categoryService.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { BrandLogo } from "/src/components/common/BrandLogo.tsx";
import { ThemeToggle } from "/src/components/common/ThemeToggle.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { StoreSearch } from "/src/components/layout/StoreSearch.tsx";
import { OfflineBanner } from "/src/components/feedback/OfflineBanner.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteHeader.tsx";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function SiteHeader() {
	_s();
	const { user, loading, signOut } = useAuth();
	const navigate = useNavigate();
	const location = useLocation();
	const [searchOpen, setSearchOpen] = useState(false);
	const [categories, setCategories] = useState([]);
	const [collapsed, setCollapsed] = useState(false);
	const [noticeHeight, setNoticeHeight] = useState(0);
	const notices = useRef(null);
	const navigation = useRef(null);
	const [cart, setCart] = useState(null);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState("");
	useEffect(() => {
		if (!user || user.role !== USER_ROLES.CUSTOMER) return;
		let active = true;
		let revision = 0;
		const refresh = () => {
			const current = ++revision;
			void getCart().then((result) => {
				if (active && current === revision) setCart({
					userId: user.id,
					count: result.itemCount
				});
			}).catch(() => {
				if (active && current === revision) setCart(null);
			});
		};
		refresh();
		window.addEventListener("cart-updated", refresh);
		return () => {
			active = false;
			window.removeEventListener("cart-updated", refresh);
		};
	}, [user, location.pathname]);
	async function logout() {
		setBusy(true);
		setError("");
		try {
			await signOut();
			navigate(ROUTES.home);
		} catch {
			setError(translations.auth.logoutError);
		} finally {
			setBusy(false);
		}
	}
	const customer = !user || user.role === USER_ROLES.CUSTOMER;
	const checkout = location.pathname === ROUTES.checkout;
	const home = location.pathname === ROUTES.home;
	const repairRoute = user?.role === "ADMIN" ? ROUTES.adminRepairs : user?.role === "REPAIRER" ? ROUTES.repairerRepairs : ROUTES.repairRequest;
	const supportRoute = user?.role === "ADMIN" ? ROUTES.adminChat : user?.role === "REPAIRER" ? ROUTES.repairerRepairs : ROUTES.liveChat;
	const count = user && cart?.userId === user.id ? cart.count : 0;
	useEffect(() => {
		let active = true;
		void getCategories().then((items) => {
			if (active) setCategories(items.filter((item) => item.isActive && !item.parent));
		}).catch(() => {});
		return () => {
			active = false;
		};
	}, []);
	useEffect(() => {
		const scrollPosition = () => Math.max(0, Math.min(window.scrollY, document.documentElement.scrollHeight - window.innerHeight));
		let previous = scrollPosition();
		let turnPosition = previous;
		let direction = 0;
		let hidden = false;
		let frame = 0;
		const show = (hide) => {
			if (hidden === hide) return;
			hidden = hide;
			setCollapsed(hide);
		};
		const update = () => {
			frame = 0;
			const next = scrollPosition();
			const delta = next - previous;
			// Ignore tiny reversals and overscroll bounce. Keep keyboard navigation visible.
			if (next <= 72 || !window.matchMedia("(min-width: 768px)").matches || navigation.current?.contains(document.activeElement) && document.activeElement?.matches(":focus-visible")) {
				show(false);
				turnPosition = previous = next;
				direction = 0;
				return;
			}
			if (delta === 0) return;
			const nextDirection = delta > 0 ? 1 : -1;
			if (nextDirection !== direction) {
				turnPosition = previous;
				direction = nextDirection;
			}
			previous = next;
			if (direction === 1 && next > 120 && next - turnPosition >= 32) show(true);
			else if (direction === -1 && turnPosition - next >= 16) show(false);
		};
		const scroll = () => {
			if (!frame) frame = window.requestAnimationFrame(update);
		};
		const resize = () => {
			show(false);
			turnPosition = previous = scrollPosition();
			direction = 0;
		};
		window.addEventListener("scroll", scroll, { passive: true });
		window.addEventListener("resize", resize);
		return () => {
			window.removeEventListener("scroll", scroll);
			window.removeEventListener("resize", resize);
			window.cancelAnimationFrame(frame);
		};
	}, []);
	useEffect(() => {
		if (!notices.current) return;
		const observer = new ResizeObserver(([entry]) => setNoticeHeight(entry.contentRect.height));
		observer.observe(notices.current);
		return () => observer.disconnect();
	}, []);
	useEffect(() => {
		const close = (event) => {
			document.querySelectorAll(".header-menu[open]").forEach((menu) => {
				if (!menu.contains(event.target)) menu.open = false;
			});
		};
		document.addEventListener("pointerdown", close);
		return () => document.removeEventListener("pointerdown", close);
	}, []);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("a", {
			href: "#main-content",
			className: "ui-skip",
			children: "Skip to main content"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 179,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: `site-header-slot ${checkout ? "is-checkout" : ""} ${home ? "is-home" : ""}`,
			style: { paddingBottom: noticeHeight },
			children: /* @__PURE__ */ _jsxDEV("header", {
				className: `site-header ${collapsed ? "is-collapsed" : ""} ${checkout ? "checkout-header" : ""}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "header-main shell-wide",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.home,
							"aria-label": "Appliances.lk home",
							className: "shrink-0",
							children: /* @__PURE__ */ _jsxDEV(BrandLogo, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this), checkout ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "ml-auto flex items-center gap-2 text-sm text-fg-secondary",
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "lock" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 19
							}, this), "Secure checkout"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.cart,
							className: "hidden text-sm text-fg-link sm:block",
							children: "Back to cart"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "desktop-search",
							children: /* @__PURE__ */ _jsxDEV(StoreSearch, {}, location.search, false, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "header-actions",
							children: [
								/* @__PURE__ */ _jsxDEV(Link, {
									to: supportRoute,
									className: "header-help",
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "chat" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 217,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Help" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									className: "ui-icon-button md:hidden",
									"aria-label": "Open search",
									onClick: () => setSearchOpen(true),
									children: /* @__PURE__ */ _jsxDEV(Icon, { name: "search" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 220,
									columnNumber: 19
								}, this),
								!user && !loading && /* @__PURE__ */ _jsxDEV("div", {
									className: "hidden items-center gap-3 md:flex",
									children: [/* @__PURE__ */ _jsxDEV(Link, {
										to: ROUTES.login,
										className: "ui-button ui-button-secondary min-h-10 whitespace-nowrap",
										children: "Sign in"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 229,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV(Link, {
										to: ROUTES.register,
										className: "hidden min-h-10 items-center whitespace-nowrap text-sm text-fg-link xl:inline-flex",
										children: "Create account"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 228,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("details", {
									className: `header-menu account-menu ${!user ? "hidden" : ""}`,
									onKeyDown: (event) => {
										if (event.key === "Escape") event.currentTarget.open = false;
									},
									children: [/* @__PURE__ */ _jsxDEV("summary", {
										className: "account-trigger",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "account-avatar",
												children: user ? user.username.slice(0, 1).toUpperCase() : /* @__PURE__ */ _jsxDEV(Icon, {
													name: "user",
													className: "h-4 w-4"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 256,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 252,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "hidden max-w-28 truncate lg:block",
												children: loading ? "Loading…" : user?.username ?? "Sign in"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 259,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "hidden text-xs lg:block",
												children: "⌄"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 262,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 251,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "header-popover",
										children: [
											user ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "border-b border-line-subtle px-3 py-3 text-sm font-semibold",
													children: user.username
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 267,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.account,
													children: "Your account"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 270,
													columnNumber: 27
												}, this),
												customer && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
													/* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.orders,
														children: "Your orders"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 273,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.repairs,
														children: "Your repairs"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 274,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.liveChat,
														children: "Live support"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 275,
														columnNumber: 31
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 272,
													columnNumber: 29
												}, this),
												user.role === "ADMIN" && /* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.admin,
													children: "Admin workspace"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 279,
													columnNumber: 29
												}, this),
												user.role === "REPAIRER" && /* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.repairer,
													children: "Repair workspace"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 282,
													columnNumber: 29
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 266,
												columnNumber: 25
											}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Link, {
												to: ROUTES.login,
												children: "Sign in"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 287,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV(Link, {
												to: ROUTES.register,
												children: "Create account"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 288,
												columnNumber: 27
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 286,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "border-t border-line-subtle px-2 py-3",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "mb-2 px-1 text-xs text-fg-muted",
													children: "Appearance"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 292,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV(ThemeToggle, {}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 295,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 291,
												columnNumber: 23
											}, this),
											user && /* @__PURE__ */ _jsxDEV("button", {
												disabled: busy,
												onClick: () => void logout(),
												className: "w-full text-danger",
												children: [busy && /* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 303,
													columnNumber: 36
												}, this), busy ? "Signing out…" : "Sign out"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 298,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 21
									}, this)]
								}, location.pathname, true, {
									fileName: _jsxFileName,
									lineNumber: 243,
									columnNumber: 19
								}, this),
								customer && /* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.cart,
									"aria-label": `Cart${count ? `, ${count} items` : ""}`,
									className: "header-cart",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "relative",
											children: [/* @__PURE__ */ _jsxDEV(Icon, {
												name: "cart",
												className: "h-6 w-6"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 316,
												columnNumber: 25
											}, this), count > 0 && /* @__PURE__ */ _jsxDEV("span", {
												className: "cart-count",
												children: count > 99 ? "99+" : count
											}, count, false, {
												fileName: _jsxFileName,
												lineNumber: 318,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "hidden text-sm lg:inline",
											children: "Cart"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 323,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "sr-only",
											"aria-live": "polite",
											children: [count, " items in cart"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 324,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 310,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this),
					!checkout && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [home && /* @__PURE__ */ _jsxDEV("div", {
						className: "home-mobile-search shell-wide",
						children: /* @__PURE__ */ _jsxDEV(StoreSearch, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 337,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 336,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("nav", {
						ref: navigation,
						inert: collapsed,
						"aria-label": translations.auth.mainNavigation,
						className: "header-navigation",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "shell-wide flex items-center gap-7",
							children: [
								/* @__PURE__ */ _jsxDEV("details", {
									className: "header-menu category-menu",
									onKeyDown: (event) => {
										if (event.key === "Escape") event.currentTarget.open = false;
									},
									children: [/* @__PURE__ */ _jsxDEV("summary", {
										className: "shop-all",
										children: [
											/* @__PURE__ */ _jsxDEV(Icon, {
												name: "grid",
												className: "h-4 w-4"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 355,
												columnNumber: 23
											}, this),
											"Shop all",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "ml-2 text-xs",
												children: "⌄"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 356,
												columnNumber: 31
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 354,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "header-popover category-popover",
										children: [/* @__PURE__ */ _jsxDEV(Link, {
											to: ROUTES.products,
											children: "All products"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 359,
											columnNumber: 23
										}, this), categories.map((category) => /* @__PURE__ */ _jsxDEV(Link, {
											to: `${ROUTES.products}?category=${encodeURIComponent(category.categoryID)}`,
											onClick: (event) => {
												const menu = event.currentTarget.closest("details");
												if (menu) menu.open = false;
											},
											children: formatCategoryName(category.name)
										}, category.categoryID, false, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 25
										}, this))]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 358,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "category-nav-links",
									children: categories.slice(0, 5).map((category) => /* @__PURE__ */ _jsxDEV(Link, {
										to: `${ROUTES.products}?category=${encodeURIComponent(category.categoryID)}`,
										children: formatCategoryName(category.name)
									}, category.categoryID, false, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 374,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "service-nav-links",
									children: [/* @__PURE__ */ _jsxDEV(NavLink, {
										to: repairRoute,
										children: [/* @__PURE__ */ _jsxDEV(Icon, {
											name: "repair",
											className: "h-4 w-4"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 386,
											columnNumber: 23
										}, this), customer ? "Repair a device" : "Repairs"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 385,
										columnNumber: 21
									}, this), customer && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(NavLink, {
										to: ROUTES.orders,
										children: "Your orders"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV(NavLink, {
										to: ROUTES.liveChat,
										children: "Live support"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 392,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 390,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 384,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 340,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 334,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						ref: notices,
						children: [error && /* @__PURE__ */ _jsxDEV("p", {
							role: "alert",
							className: "bg-danger-bg px-4 py-2 text-sm text-danger",
							children: error
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 402,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(OfflineBanner, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 409,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 400,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 186,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 182,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Dialog, {
			open: searchOpen,
			onClose: () => setSearchOpen(false),
			title: "Search products",
			children: /* @__PURE__ */ _jsxDEV(StoreSearch, {
				autoFocus: true,
				onSearch: () => setSearchOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 418,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 413,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 178,
		columnNumber: 5
	}, this);
}
_s(SiteHeader, "QEdNut6U8eQPttmktKPS4Zciu+I=", false, function() {
	return [
		useAuth,
		useNavigate,
		useLocation
	];
});
_c = SiteHeader;
var _c;
$RefreshReg$(_c, "SiteHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/SiteHeader.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteHeader.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsTUFBTSxTQUFTLGFBQWEsbUJBQW1CO0FBQ3hELFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMscUJBQXFCO0FBRTlCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMscUJBQXFCOzs7O0FBRTlCLE9BQU8sU0FBUyxhQUFhOztDQUMzQixNQUFNLEVBQUUsTUFBTSxTQUFTLFlBQVksUUFBUTtDQUMzQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFxQixDQUFDLENBQUM7Q0FDM0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxDQUFDO0NBQ2xELE1BQU0sVUFBVSxPQUF1QixJQUFJO0NBQzNDLE1BQU0sYUFBYSxPQUFvQixJQUFJO0NBQzNDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FDdEIsSUFDRjtDQUNBLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBQ3RDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRLEtBQUssU0FBUyxXQUFXLFVBQVU7RUFDaEQsSUFBSSxTQUFTO0VBQ2IsSUFBSSxXQUFXO0VBQ2YsTUFBTSxnQkFBZ0I7R0FDcEIsTUFBTSxVQUFVLEVBQUU7R0FDbEIsS0FBSyxRQUFRLENBQUMsQ0FDWCxNQUFNLFdBQVc7SUFDaEIsSUFBSSxVQUFVLFlBQVksVUFDeEIsUUFBUTtLQUFFLFFBQVEsS0FBSztLQUFJLE9BQU8sT0FBTztJQUFVLENBQUM7R0FDeEQsQ0FBQyxDQUFDLENBQ0QsWUFBWTtJQUNYLElBQUksVUFBVSxZQUFZLFVBQVUsUUFBUSxJQUFJO0dBQ2xELENBQUM7RUFDTDtFQUNBLFFBQVE7RUFDUixPQUFPLGlCQUFpQixnQkFBZ0IsT0FBTztFQUMvQyxhQUFhO0dBQ1gsU0FBUztHQUNULE9BQU8sb0JBQW9CLGdCQUFnQixPQUFPO0VBQ3BEO0NBQ0YsR0FBRyxDQUFDLE1BQU0sU0FBUyxRQUFRLENBQUM7Q0FDNUIsZUFBZSxTQUFTO0VBQ3RCLFFBQVEsSUFBSTtFQUNaLFNBQVMsRUFBRTtFQUNYLElBQUk7R0FDRixNQUFNLFFBQVE7R0FDZCxTQUFTLE9BQU8sSUFBSTtFQUN0QixRQUFRO0dBQ04sU0FBUyxhQUFhLEtBQUssV0FBVztFQUN4QyxVQUFVO0dBQ1IsUUFBUSxLQUFLO0VBQ2Y7Q0FDRjtDQUNBLE1BQU0sV0FBVyxDQUFDLFFBQVEsS0FBSyxTQUFTLFdBQVc7Q0FDbkQsTUFBTSxXQUFXLFNBQVMsYUFBYSxPQUFPO0NBQzlDLE1BQU0sT0FBTyxTQUFTLGFBQWEsT0FBTztDQUMxQyxNQUFNLGNBQ0osTUFBTSxTQUFTLFVBQ1gsT0FBTyxlQUNQLE1BQU0sU0FBUyxhQUNiLE9BQU8sa0JBQ1AsT0FBTztDQUNmLE1BQU0sZUFDSixNQUFNLFNBQVMsVUFDWCxPQUFPLFlBQ1AsTUFBTSxTQUFTLGFBQ2IsT0FBTyxrQkFDUCxPQUFPO0NBQ2YsTUFBTSxRQUFRLFFBQVEsTUFBTSxXQUFXLEtBQUssS0FBSyxLQUFLLFFBQVE7Q0FDOUQsZ0JBQWdCO0VBQ2QsSUFBSSxTQUFTO0VBQ2IsS0FBSyxjQUFjLENBQUMsQ0FDakIsTUFBTSxVQUFVO0dBQ2YsSUFBSSxRQUNGLGNBQWMsTUFBTSxRQUFRLFNBQVMsS0FBSyxZQUFZLENBQUMsS0FBSyxNQUFNLENBQUM7RUFDdkUsQ0FBQyxDQUFDLENBQ0QsWUFBWSxDQUFDLENBQUM7RUFDakIsYUFBYTtHQUNYLFNBQVM7RUFDWDtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsZ0JBQWdCO0VBQ2QsTUFBTSx1QkFDSixLQUFLLElBQ0gsR0FDQSxLQUFLLElBQ0gsT0FBTyxTQUNQLFNBQVMsZ0JBQWdCLGVBQWUsT0FBTyxXQUNqRCxDQUNGO0VBQ0YsSUFBSSxXQUFXLGVBQWU7RUFDOUIsSUFBSSxlQUFlO0VBQ25CLElBQUksWUFBWTtFQUNoQixJQUFJLFNBQVM7RUFDYixJQUFJLFFBQVE7RUFDWixNQUFNLFFBQVEsU0FBa0I7R0FDOUIsSUFBSSxXQUFXLE1BQU07R0FDckIsU0FBUztHQUNULGFBQWEsSUFBSTtFQUNuQjtFQUNBLE1BQU0sZUFBZTtHQUNuQixRQUFRO0dBQ1IsTUFBTSxPQUFPLGVBQWU7R0FDNUIsTUFBTSxRQUFRLE9BQU87O0dBRXJCLElBQ0UsUUFBUSxNQUNSLENBQUMsT0FBTyxXQUFXLG9CQUFvQixDQUFDLENBQUMsV0FDeEMsV0FBVyxTQUFTLFNBQVMsU0FBUyxhQUFhLEtBQ2xELFNBQVMsZUFBZSxRQUFRLGdCQUFnQixHQUNsRDtJQUNBLEtBQUssS0FBSztJQUNWLGVBQWUsV0FBVztJQUMxQixZQUFZO0lBQ1o7R0FDRjtHQUNBLElBQUksVUFBVSxHQUFHO0dBQ2pCLE1BQU0sZ0JBQWdCLFFBQVEsSUFBSSxJQUFJLENBQUM7R0FDdkMsSUFBSSxrQkFBa0IsV0FBVztJQUMvQixlQUFlO0lBQ2YsWUFBWTtHQUNkO0dBQ0EsV0FBVztHQUNYLElBQUksY0FBYyxLQUFLLE9BQU8sT0FBTyxPQUFPLGdCQUFnQixJQUMxRCxLQUFLLElBQUk7UUFDTixJQUFJLGNBQWMsQ0FBQyxLQUFLLGVBQWUsUUFBUSxJQUFJLEtBQUssS0FBSztFQUNwRTtFQUNBLE1BQU0sZUFBZTtHQUNuQixJQUFJLENBQUMsT0FBTyxRQUFRLE9BQU8sc0JBQXNCLE1BQU07RUFDekQ7RUFDQSxNQUFNLGVBQWU7R0FDbkIsS0FBSyxLQUFLO0dBQ1YsZUFBZSxXQUFXLGVBQWU7R0FDekMsWUFBWTtFQUNkO0VBQ0EsT0FBTyxpQkFBaUIsVUFBVSxRQUFRLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDM0QsT0FBTyxpQkFBaUIsVUFBVSxNQUFNO0VBQ3hDLGFBQWE7R0FDWCxPQUFPLG9CQUFvQixVQUFVLE1BQU07R0FDM0MsT0FBTyxvQkFBb0IsVUFBVSxNQUFNO0dBQzNDLE9BQU8scUJBQXFCLEtBQUs7RUFDbkM7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUNMLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRLFNBQVM7RUFDdEIsTUFBTSxXQUFXLElBQUksZ0JBQWdCLENBQUMsV0FDcEMsZ0JBQWdCLE1BQU0sWUFBWSxNQUFNLENBQzFDO0VBQ0EsU0FBUyxRQUFRLFFBQVEsT0FBTztFQUNoQyxhQUFhLFNBQVMsV0FBVztDQUNuQyxHQUFHLENBQUMsQ0FBQztDQUNMLGdCQUFnQjtFQUNkLE1BQU0sU0FBUyxVQUF3QjtHQUNyQyxTQUNHLGlCQUFxQyxvQkFBb0IsQ0FBQyxDQUMxRCxTQUFTLFNBQVM7SUFDakIsSUFBSSxDQUFDLEtBQUssU0FBUyxNQUFNLE1BQWMsR0FBRyxLQUFLLE9BQU87R0FDeEQsQ0FBQztFQUNMO0VBQ0EsU0FBUyxpQkFBaUIsZUFBZSxLQUFLO0VBQzlDLGFBQWEsU0FBUyxvQkFBb0IsZUFBZSxLQUFLO0NBQ2hFLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsT0FDRTtFQUNFLHdCQUFDLEtBQUQ7R0FBRyxNQUFLO0dBQWdCLFdBQVU7YUFBVTtFQUV6Qzs7Ozs7RUFDSCx3QkFBQyxPQUFEO0dBQ0UsV0FBVyxvQkFBb0IsV0FBVyxnQkFBZ0IsR0FBRyxHQUFHLE9BQU8sWUFBWTtHQUNuRixPQUFPLEVBQUUsZUFBZSxhQUFhO2FBRXJDLHdCQUFDLFVBQUQ7SUFDRSxXQUFXLGVBQWUsWUFBWSxpQkFBaUIsR0FBRyxHQUFHLFdBQVcsb0JBQW9CO2NBRDlGO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPO09BQ1gsY0FBVztPQUNYLFdBQVU7aUJBRVYsd0JBQUMsV0FBRCxDQUFZOzs7OztNQUNSOzs7O2dCQUNMLFdBQ0MsZ0RBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztpQkFBQyxpQkFFaEI7Ozs7O2dCQUNOLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLE9BQU87T0FDWCxXQUFVO2lCQUNYO01BRUs7Ozs7Y0FDTjs7OztpQkFFRixnREFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxhQUFELENBQW9DLEdBQWxCLFNBQVM7Ozs7Y0FBUztNQUNqQzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE1BQUQ7U0FBTSxJQUFJO1NBQWMsV0FBVTttQkFBbEMsQ0FDRSx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7O21CQUNuQix3QkFBQyxRQUFELFlBQU0sT0FBVTs7OztpQkFDWjs7Ozs7O1FBQ04sd0JBQUMsVUFBRDtTQUNFLFdBQVU7U0FDVixjQUFXO1NBQ1gsZUFBZSxjQUFjLElBQUk7bUJBRWpDLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFNBQVU7Ozs7O1FBQ2Y7Ozs7O1FBQ1AsQ0FBQyxRQUFRLENBQUMsV0FDVCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFDRSxJQUFJLE9BQU87VUFDWCxXQUFVO29CQUNYO1NBRUs7Ozs7bUJBQ04sd0JBQUMsTUFBRDtVQUNFLElBQUksT0FBTztVQUNYLFdBQVU7b0JBQ1g7U0FFSzs7OztpQkFDSDs7Ozs7O1FBRVAsd0JBQUMsV0FBRDtTQUVFLFdBQVcsNEJBQTRCLENBQUMsT0FBTyxXQUFXO1NBQzFELFlBQVksVUFBVTtVQUNwQixJQUFJLE1BQU0sUUFBUSxVQUNoQixNQUFNLGNBQWMsT0FBTztTQUMvQjttQkFORixDQVFFLHdCQUFDLFdBQUQ7VUFBUyxXQUFVO29CQUFuQjtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNiLE9BQ0MsS0FBSyxTQUFTLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLElBRXRDLHdCQUFDLE1BQUQ7YUFBTSxNQUFLO2FBQU8sV0FBVTtZQUFXOzs7OztXQUVyQzs7Ozs7V0FDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixVQUFVLGFBQWMsTUFBTSxZQUFZO1dBQ3ZDOzs7OztXQUNOLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUEwQjtXQUFPOzs7OztVQUMxQzs7Ozs7bUJBQ1Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRyxPQUNDO1lBQ0Usd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQ1YsS0FBSztZQUNMOzs7OztZQUNILHdCQUFDLE1BQUQ7YUFBTSxJQUFJLE9BQU87dUJBQVM7WUFBa0I7Ozs7O1lBQzNDLFlBQ0M7YUFDRSx3QkFBQyxNQUFEO2NBQU0sSUFBSSxPQUFPO3dCQUFRO2FBQWlCOzs7OzthQUMxQyx3QkFBQyxNQUFEO2NBQU0sSUFBSSxPQUFPO3dCQUFTO2FBQWtCOzs7OzthQUM1Qyx3QkFBQyxNQUFEO2NBQU0sSUFBSSxPQUFPO3dCQUFVO2FBQWtCOzs7OztZQUM3Qzs7Ozs7WUFFSCxLQUFLLFNBQVMsV0FDYix3QkFBQyxNQUFEO2FBQU0sSUFBSSxPQUFPO3VCQUFPO1lBQXFCOzs7OztZQUU5QyxLQUFLLFNBQVMsY0FDYix3QkFBQyxNQUFEO2FBQU0sSUFBSSxPQUFPO3VCQUFVO1lBQXNCOzs7OztXQUVuRDs7OztzQkFFRixnREFDRSx3QkFBQyxNQUFEO1lBQU0sSUFBSSxPQUFPO3NCQUFPO1dBQWE7Ozs7cUJBQ3JDLHdCQUFDLE1BQUQ7WUFBTSxJQUFJLE9BQU87c0JBQVU7V0FBb0I7Ozs7bUJBQy9DOzs7OztXQUVKLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWtDO1lBRTVDOzs7O3NCQUNILHdCQUFDLGFBQUQsQ0FBYzs7OztvQkFDWDs7Ozs7O1dBQ0osUUFDQyx3QkFBQyxVQUFEO1lBQ0UsVUFBVTtZQUNWLGVBQWUsS0FBSyxPQUFPO1lBQzNCLFdBQVU7c0JBSFosQ0FLRyxRQUFRLHdCQUFDLFNBQUQsQ0FBVTs7OztzQkFDbEIsT0FBTyxpQkFBaUIsVUFDbkI7Ozs7OztVQUVQOzs7OztpQkFDRTtXQWhFRixTQUFTOzs7O2VBZ0VQO1FBQ1IsWUFDQyx3QkFBQyxNQUFEO1NBQ0UsSUFBSSxPQUFPO1NBQ1gsY0FBWSxPQUFPLFFBQVEsS0FBSyxNQUFNLFVBQVU7U0FDaEQsV0FBVTttQkFIWjtVQUtFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNFLHdCQUFDLE1BQUQ7WUFBTSxNQUFLO1lBQU8sV0FBVTtXQUFXOzs7O3FCQUN0QyxRQUFRLEtBQ1Asd0JBQUMsUUFBRDtZQUFrQixXQUFVO3NCQUN6QixRQUFRLEtBQUssUUFBUTtXQUNsQixHQUZLOzs7O2tCQUVMLENBRUo7Ozs7OztVQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUEyQjtVQUFVOzs7OztVQUNyRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtXQUFVLGFBQVU7cUJBQXBDLENBQ0csT0FBTSxnQkFDSDs7Ozs7O1NBQ0Y7Ozs7OztPQUVMOzs7OztjQUNMOzs7O2NBRUQ7Ozs7OztLQUNKLENBQUMsWUFDQSxnREFDRyxRQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7S0FDWDs7OztlQUVQLHdCQUFDLE9BQUQ7TUFDRSxLQUFLO01BQ0wsT0FBTztNQUNQLGNBQVksYUFBYSxLQUFLO01BQzlCLFdBQVU7Z0JBRVYsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxXQUFEO1NBQ0UsV0FBVTtTQUNWLFlBQVksVUFBVTtVQUNwQixJQUFJLE1BQU0sUUFBUSxVQUNoQixNQUFNLGNBQWMsT0FBTztTQUMvQjttQkFMRixDQU9FLHdCQUFDLFdBQUQ7VUFBUyxXQUFVO29CQUFuQjtXQUNFLHdCQUFDLE1BQUQ7WUFBTSxNQUFLO1lBQU8sV0FBVTtXQUFXOzs7OztXQUFDO1dBQ2hDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFlO1dBQU87Ozs7O1VBQ3ZDOzs7OzttQkFDVCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE1BQUQ7V0FBTSxJQUFJLE9BQU87cUJBQVU7VUFBa0I7Ozs7b0JBQzVDLFdBQVcsS0FBSyxhQUNmLHdCQUFDLE1BQUQ7V0FFRSxJQUFJLEdBQUcsT0FBTyxTQUFTLFlBQVksbUJBQW1CLFNBQVMsVUFBVTtXQUN6RSxVQUFVLFVBQVU7WUFDbEIsTUFBTSxPQUFPLE1BQU0sY0FBYyxRQUFRLFNBQVM7WUFDbEQsSUFBSSxNQUFNLEtBQUssT0FBTztXQUN4QjtxQkFFQyxtQkFBbUIsU0FBUyxJQUFJO1VBQzdCLEdBUkMsU0FBUzs7OztpQkFRVixDQUNQLENBQ0U7Ozs7O2lCQUNFOzs7Ozs7UUFDVCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixXQUFXLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLGFBQzNCLHdCQUFDLE1BQUQ7VUFFRSxJQUFJLEdBQUcsT0FBTyxTQUFTLFlBQVksbUJBQW1CLFNBQVMsVUFBVTtvQkFFeEUsbUJBQW1CLFNBQVMsSUFBSTtTQUM3QixHQUpDLFNBQVM7Ozs7Z0JBSVYsQ0FDUDtRQUNFOzs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFTLElBQUk7b0JBQWIsQ0FDRSx3QkFBQyxNQUFEO1dBQU0sTUFBSztXQUFTLFdBQVU7VUFBVzs7OztvQkFDeEMsV0FBVyxvQkFBb0IsU0FDekI7Ozs7O21CQUNSLFlBQ0MsZ0RBQ0Usd0JBQUMsU0FBRDtVQUFTLElBQUksT0FBTztvQkFBUTtTQUFvQjs7OzttQkFDaEQsd0JBQUMsU0FBRDtVQUFTLElBQUksT0FBTztvQkFBVTtTQUFxQjs7OztpQkFDbkQ7Ozs7aUJBRUQ7Ozs7OztPQUNGOzs7Ozs7S0FDRjs7OzthQUNMOzs7OztLQUVKLHdCQUFDLE9BQUQ7TUFBSyxLQUFLO2dCQUFWLENBQ0csU0FDQyx3QkFBQyxLQUFEO09BQ0UsTUFBSztPQUNMLFdBQVU7aUJBRVQ7TUFDQTs7OztnQkFFTCx3QkFBQyxlQUFELENBQWdCOzs7O2NBQ2I7Ozs7OztJQUNDOzs7Ozs7RUFDTDs7Ozs7RUFDTCx3QkFBQyxRQUFEO0dBQ0UsTUFBTTtHQUNOLGVBQWUsY0FBYyxLQUFLO0dBQ2xDLE9BQU07YUFFTix3QkFBQyxhQUFEO0lBQWE7SUFBVSxnQkFBZ0IsY0FBYyxLQUFLO0dBQUk7Ozs7O0VBQ3hEOzs7OztDQUNSOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpdGVIZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGZvcm1hdENhdGVnb3J5TmFtZSB9IGZyb20gJy4uLy4uL3V0aWxzL2NhdGVnb3J5JztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rLCBOYXZMaW5rLCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgVVNFUl9ST0xFUyB9IGZyb20gJy4uLy4uL2NvbnN0YW50cy9yb2xlcyc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IGdldENhcnQgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9jYXJ0U2VydmljZSc7XHJcbmltcG9ydCB7IGdldENhdGVnb3JpZXMgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9jYXRlZ29yeVNlcnZpY2UnO1xyXG5pbXBvcnQgdHlwZSB7IENhdGVnb3J5IH0gZnJvbSAnLi4vLi4vdHlwZXMvY2F0ZWdvcnkudHlwZXMnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBCcmFuZExvZ28gfSBmcm9tICcuLi9jb21tb24vQnJhbmRMb2dvJztcclxuaW1wb3J0IHsgVGhlbWVUb2dnbGUgfSBmcm9tICcuLi9jb21tb24vVGhlbWVUb2dnbGUnO1xyXG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnLi4vdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBEaWFsb2cgfSBmcm9tICcuLi91aS9EaWFsb2cnO1xyXG5pbXBvcnQgeyBTdG9yZVNlYXJjaCB9IGZyb20gJy4vU3RvcmVTZWFyY2gnO1xyXG5pbXBvcnQgeyBPZmZsaW5lQmFubmVyIH0gZnJvbSAnLi4vZmVlZGJhY2svT2ZmbGluZUJhbm5lcic7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2l0ZUhlYWRlcigpIHtcclxuICBjb25zdCB7IHVzZXIsIGxvYWRpbmcsIHNpZ25PdXQgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWFyY2hPcGVuLCBzZXRTZWFyY2hPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY2F0ZWdvcmllcywgc2V0Q2F0ZWdvcmllc10gPSB1c2VTdGF0ZTxDYXRlZ29yeVtdPihbXSk7XHJcbiAgY29uc3QgW2NvbGxhcHNlZCwgc2V0Q29sbGFwc2VkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbm90aWNlSGVpZ2h0LCBzZXROb3RpY2VIZWlnaHRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3Qgbm90aWNlcyA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgbmF2aWdhdGlvbiA9IHVzZVJlZjxIVE1MRWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgW2NhcnQsIHNldENhcnRdID0gdXNlU3RhdGU8eyB1c2VySWQ6IHN0cmluZzsgY291bnQ6IG51bWJlciB9IHwgbnVsbD4oXHJcbiAgICBudWxsLFxyXG4gICk7XHJcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIXVzZXIgfHwgdXNlci5yb2xlICE9PSBVU0VSX1JPTEVTLkNVU1RPTUVSKSByZXR1cm47XHJcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZTtcclxuICAgIGxldCByZXZpc2lvbiA9IDA7XHJcbiAgICBjb25zdCByZWZyZXNoID0gKCkgPT4ge1xyXG4gICAgICBjb25zdCBjdXJyZW50ID0gKytyZXZpc2lvbjtcclxuICAgICAgdm9pZCBnZXRDYXJ0KClcclxuICAgICAgICAudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICBpZiAoYWN0aXZlICYmIGN1cnJlbnQgPT09IHJldmlzaW9uKVxyXG4gICAgICAgICAgICBzZXRDYXJ0KHsgdXNlcklkOiB1c2VyLmlkLCBjb3VudDogcmVzdWx0Lml0ZW1Db3VudCB9KTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XHJcbiAgICAgICAgICBpZiAoYWN0aXZlICYmIGN1cnJlbnQgPT09IHJldmlzaW9uKSBzZXRDYXJ0KG51bGwpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIHJlZnJlc2goKTtcclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdjYXJ0LXVwZGF0ZWQnLCByZWZyZXNoKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2FydC11cGRhdGVkJywgcmVmcmVzaCk7XHJcbiAgICB9O1xyXG4gIH0sIFt1c2VyLCBsb2NhdGlvbi5wYXRobmFtZV0pO1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvZ291dCgpIHtcclxuICAgIHNldEJ1c3kodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcignJyk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBzaWduT3V0KCk7XHJcbiAgICAgIG5hdmlnYXRlKFJPVVRFUy5ob21lKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBzZXRFcnJvcih0cmFuc2xhdGlvbnMuYXV0aC5sb2dvdXRFcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRCdXN5KGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcbiAgY29uc3QgY3VzdG9tZXIgPSAhdXNlciB8fCB1c2VyLnJvbGUgPT09IFVTRVJfUk9MRVMuQ1VTVE9NRVI7XHJcbiAgY29uc3QgY2hlY2tvdXQgPSBsb2NhdGlvbi5wYXRobmFtZSA9PT0gUk9VVEVTLmNoZWNrb3V0O1xyXG4gIGNvbnN0IGhvbWUgPSBsb2NhdGlvbi5wYXRobmFtZSA9PT0gUk9VVEVTLmhvbWU7XHJcbiAgY29uc3QgcmVwYWlyUm91dGUgPVxyXG4gICAgdXNlcj8ucm9sZSA9PT0gJ0FETUlOJ1xyXG4gICAgICA/IFJPVVRFUy5hZG1pblJlcGFpcnNcclxuICAgICAgOiB1c2VyPy5yb2xlID09PSAnUkVQQUlSRVInXHJcbiAgICAgICAgPyBST1VURVMucmVwYWlyZXJSZXBhaXJzXHJcbiAgICAgICAgOiBST1VURVMucmVwYWlyUmVxdWVzdDtcclxuICBjb25zdCBzdXBwb3J0Um91dGUgPVxyXG4gICAgdXNlcj8ucm9sZSA9PT0gJ0FETUlOJ1xyXG4gICAgICA/IFJPVVRFUy5hZG1pbkNoYXRcclxuICAgICAgOiB1c2VyPy5yb2xlID09PSAnUkVQQUlSRVInXHJcbiAgICAgICAgPyBST1VURVMucmVwYWlyZXJSZXBhaXJzXHJcbiAgICAgICAgOiBST1VURVMubGl2ZUNoYXQ7XHJcbiAgY29uc3QgY291bnQgPSB1c2VyICYmIGNhcnQ/LnVzZXJJZCA9PT0gdXNlci5pZCA/IGNhcnQuY291bnQgOiAwO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZTtcclxuICAgIHZvaWQgZ2V0Q2F0ZWdvcmllcygpXHJcbiAgICAgIC50aGVuKChpdGVtcykgPT4ge1xyXG4gICAgICAgIGlmIChhY3RpdmUpXHJcbiAgICAgICAgICBzZXRDYXRlZ29yaWVzKGl0ZW1zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pc0FjdGl2ZSAmJiAhaXRlbS5wYXJlbnQpKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHNjcm9sbFBvc2l0aW9uID0gKCkgPT5cclxuICAgICAgTWF0aC5tYXgoXHJcbiAgICAgICAgMCxcclxuICAgICAgICBNYXRoLm1pbihcclxuICAgICAgICAgIHdpbmRvdy5zY3JvbGxZLFxyXG4gICAgICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbEhlaWdodCAtIHdpbmRvdy5pbm5lckhlaWdodCxcclxuICAgICAgICApLFxyXG4gICAgICApO1xyXG4gICAgbGV0IHByZXZpb3VzID0gc2Nyb2xsUG9zaXRpb24oKTtcclxuICAgIGxldCB0dXJuUG9zaXRpb24gPSBwcmV2aW91cztcclxuICAgIGxldCBkaXJlY3Rpb24gPSAwO1xyXG4gICAgbGV0IGhpZGRlbiA9IGZhbHNlO1xyXG4gICAgbGV0IGZyYW1lID0gMDtcclxuICAgIGNvbnN0IHNob3cgPSAoaGlkZTogYm9vbGVhbikgPT4ge1xyXG4gICAgICBpZiAoaGlkZGVuID09PSBoaWRlKSByZXR1cm47XHJcbiAgICAgIGhpZGRlbiA9IGhpZGU7XHJcbiAgICAgIHNldENvbGxhcHNlZChoaWRlKTtcclxuICAgIH07XHJcbiAgICBjb25zdCB1cGRhdGUgPSAoKSA9PiB7XHJcbiAgICAgIGZyYW1lID0gMDtcclxuICAgICAgY29uc3QgbmV4dCA9IHNjcm9sbFBvc2l0aW9uKCk7XHJcbiAgICAgIGNvbnN0IGRlbHRhID0gbmV4dCAtIHByZXZpb3VzO1xyXG4gICAgICAvLyBJZ25vcmUgdGlueSByZXZlcnNhbHMgYW5kIG92ZXJzY3JvbGwgYm91bmNlLiBLZWVwIGtleWJvYXJkIG5hdmlnYXRpb24gdmlzaWJsZS5cclxuICAgICAgaWYgKFxyXG4gICAgICAgIG5leHQgPD0gNzIgfHxcclxuICAgICAgICAhd2luZG93Lm1hdGNoTWVkaWEoJyhtaW4td2lkdGg6IDc2OHB4KScpLm1hdGNoZXMgfHxcclxuICAgICAgICAobmF2aWdhdGlvbi5jdXJyZW50Py5jb250YWlucyhkb2N1bWVudC5hY3RpdmVFbGVtZW50KSAmJlxyXG4gICAgICAgICAgZG9jdW1lbnQuYWN0aXZlRWxlbWVudD8ubWF0Y2hlcygnOmZvY3VzLXZpc2libGUnKSlcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2hvdyhmYWxzZSk7XHJcbiAgICAgICAgdHVyblBvc2l0aW9uID0gcHJldmlvdXMgPSBuZXh0O1xyXG4gICAgICAgIGRpcmVjdGlvbiA9IDA7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChkZWx0YSA9PT0gMCkgcmV0dXJuO1xyXG4gICAgICBjb25zdCBuZXh0RGlyZWN0aW9uID0gZGVsdGEgPiAwID8gMSA6IC0xO1xyXG4gICAgICBpZiAobmV4dERpcmVjdGlvbiAhPT0gZGlyZWN0aW9uKSB7XHJcbiAgICAgICAgdHVyblBvc2l0aW9uID0gcHJldmlvdXM7XHJcbiAgICAgICAgZGlyZWN0aW9uID0gbmV4dERpcmVjdGlvbjtcclxuICAgICAgfVxyXG4gICAgICBwcmV2aW91cyA9IG5leHQ7XHJcbiAgICAgIGlmIChkaXJlY3Rpb24gPT09IDEgJiYgbmV4dCA+IDEyMCAmJiBuZXh0IC0gdHVyblBvc2l0aW9uID49IDMyKVxyXG4gICAgICAgIHNob3codHJ1ZSk7XHJcbiAgICAgIGVsc2UgaWYgKGRpcmVjdGlvbiA9PT0gLTEgJiYgdHVyblBvc2l0aW9uIC0gbmV4dCA+PSAxNikgc2hvdyhmYWxzZSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3Qgc2Nyb2xsID0gKCkgPT4ge1xyXG4gICAgICBpZiAoIWZyYW1lKSBmcmFtZSA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUodXBkYXRlKTtcclxuICAgIH07XHJcbiAgICBjb25zdCByZXNpemUgPSAoKSA9PiB7XHJcbiAgICAgIHNob3coZmFsc2UpO1xyXG4gICAgICB0dXJuUG9zaXRpb24gPSBwcmV2aW91cyA9IHNjcm9sbFBvc2l0aW9uKCk7XHJcbiAgICAgIGRpcmVjdGlvbiA9IDA7XHJcbiAgICB9O1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIHNjcm9sbCwgeyBwYXNzaXZlOiB0cnVlIH0pO1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZSk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgc2Nyb2xsKTtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZSk7XHJcbiAgICAgIHdpbmRvdy5jYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZSk7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFub3RpY2VzLmN1cnJlbnQpIHJldHVybjtcclxuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKChbZW50cnldKSA9PlxyXG4gICAgICBzZXROb3RpY2VIZWlnaHQoZW50cnkuY29udGVudFJlY3QuaGVpZ2h0KSxcclxuICAgICk7XHJcbiAgICBvYnNlcnZlci5vYnNlcnZlKG5vdGljZXMuY3VycmVudCk7XHJcbiAgICByZXR1cm4gKCkgPT4gb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgY2xvc2UgPSAoZXZlbnQ6IFBvaW50ZXJFdmVudCkgPT4ge1xyXG4gICAgICBkb2N1bWVudFxyXG4gICAgICAgIC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxEZXRhaWxzRWxlbWVudD4oJy5oZWFkZXItbWVudVtvcGVuXScpXHJcbiAgICAgICAgLmZvckVhY2goKG1lbnUpID0+IHtcclxuICAgICAgICAgIGlmICghbWVudS5jb250YWlucyhldmVudC50YXJnZXQgYXMgTm9kZSkpIG1lbnUub3BlbiA9IGZhbHNlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJkb3duJywgY2xvc2UpO1xyXG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJkb3duJywgY2xvc2UpO1xyXG4gIH0sIFtdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGEgaHJlZj1cIiNtYWluLWNvbnRlbnRcIiBjbGFzc05hbWU9XCJ1aS1za2lwXCI+XHJcbiAgICAgICAgU2tpcCB0byBtYWluIGNvbnRlbnRcclxuICAgICAgPC9hPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgc2l0ZS1oZWFkZXItc2xvdCAke2NoZWNrb3V0ID8gJ2lzLWNoZWNrb3V0JyA6ICcnfSAke2hvbWUgPyAnaXMtaG9tZScgOiAnJ31gfVxyXG4gICAgICAgIHN0eWxlPXt7IHBhZGRpbmdCb3R0b206IG5vdGljZUhlaWdodCB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGhlYWRlclxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgc2l0ZS1oZWFkZXIgJHtjb2xsYXBzZWQgPyAnaXMtY29sbGFwc2VkJyA6ICcnfSAke2NoZWNrb3V0ID8gJ2NoZWNrb3V0LWhlYWRlcicgOiAnJ31gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLW1haW4gc2hlbGwtd2lkZVwiPlxyXG4gICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgIHRvPXtST1VURVMuaG9tZX1cclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQXBwbGlhbmNlcy5sayBob21lXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QnJhbmRMb2dvIC8+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAge2NoZWNrb3V0ID8gKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImxvY2tcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBTZWN1cmUgY2hlY2tvdXRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuY2FydH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuIHRleHQtc20gdGV4dC1mZy1saW5rIHNtOmJsb2NrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQmFjayB0byBjYXJ0XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVza3RvcC1zZWFyY2hcIj5cclxuICAgICAgICAgICAgICAgICAgPFN0b3JlU2VhcmNoIGtleT17bG9jYXRpb24uc2VhcmNofSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlci1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtzdXBwb3J0Um91dGV9IGNsYXNzTmFtZT1cImhlYWRlci1oZWxwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImNoYXRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkhlbHA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWljb24tYnV0dG9uIG1kOmhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk9wZW4gc2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWFyY2hPcGVuKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cInNlYXJjaFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICB7IXVzZXIgJiYgIWxvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGl0ZW1zLWNlbnRlciBnYXAtMyBtZDpmbGV4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLmxvZ2lufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXNlY29uZGFyeSBtaW4taC0xMCB3aGl0ZXNwYWNlLW5vd3JhcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNpZ24gaW5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMucmVnaXN0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlbiBtaW4taC0xMCBpdGVtcy1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LWZnLWxpbmsgeGw6aW5saW5lLWZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDcmVhdGUgYWNjb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIGtleT17bG9jYXRpb24ucGF0aG5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaGVhZGVyLW1lbnUgYWNjb3VudC1tZW51ICR7IXVzZXIgPyAnaGlkZGVuJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFc2NhcGUnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudC5jdXJyZW50VGFyZ2V0Lm9wZW4gPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN1bW1hcnkgY2xhc3NOYW1lPVwiYWNjb3VudC10cmlnZ2VyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhY2NvdW50LWF2YXRhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlciA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyLnVzZXJuYW1lLnNsaWNlKDAsIDEpLnRvVXBwZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwidXNlclwiIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIG1heC13LTI4IHRydW5jYXRlIGxnOmJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gJ0xvYWRpbmfigKYnIDogKHVzZXI/LnVzZXJuYW1lID8/ICdTaWduIGluJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gdGV4dC14cyBsZzpibG9ja1wiPuKMhDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3N1bW1hcnk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXItcG9wb3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWxpbmUtc3VidGxlIHB4LTMgcHktMyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnVzZXJuYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLmFjY291bnR9PllvdXIgYWNjb3VudDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5vcmRlcnN9PllvdXIgb3JkZXJzPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLnJlcGFpcnN9PllvdXIgcmVwYWlyczwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5saXZlQ2hhdH0+TGl2ZSBzdXBwb3J0PC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5yb2xlID09PSAnQURNSU4nICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtST1VURVMuYWRtaW59PkFkbWluIHdvcmtzcGFjZTwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnJvbGUgPT09ICdSRVBBSVJFUicgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5yZXBhaXJlcn0+UmVwYWlyIHdvcmtzcGFjZTwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5sb2dpbn0+U2lnbiBpbjwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLnJlZ2lzdGVyfT5DcmVhdGUgYWNjb3VudDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItbGluZS1zdWJ0bGUgcHgtMiBweS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTIgcHgtMSB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBcHBlYXJhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRoZW1lVG9nZ2xlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgbG9nb3V0KCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtidXN5ICYmIDxTcGlubmVyIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtidXN5ID8gJ1NpZ25pbmcgb3V04oCmJyA6ICdTaWduIG91dCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kZXRhaWxzPlxyXG4gICAgICAgICAgICAgICAgICB7Y3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLmNhcnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQ2FydCR7Y291bnQgPyBgLCAke2NvdW50fSBpdGVtc2AgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGVhZGVyLWNhcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjYXJ0XCIgY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17Y291bnR9IGNsYXNzTmFtZT1cImNhcnQtY291bnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb3VudCA+IDk5ID8gJzk5KycgOiBjb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gdGV4dC1zbSBsZzppbmxpbmVcIj5DYXJ0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y291bnR9IGl0ZW1zIGluIGNhcnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgeyFjaGVja291dCAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAge2hvbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJob21lLW1vYmlsZS1zZWFyY2ggc2hlbGwtd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8U3RvcmVTZWFyY2ggLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPG5hdlxyXG4gICAgICAgICAgICAgICAgcmVmPXtuYXZpZ2F0aW9ufVxyXG4gICAgICAgICAgICAgICAgaW5lcnQ9e2NvbGxhcHNlZH1cclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e3RyYW5zbGF0aW9ucy5hdXRoLm1haW5OYXZpZ2F0aW9ufVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGVhZGVyLW5hdmlnYXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hlbGwtd2lkZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtN1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhlYWRlci1tZW51IGNhdGVnb3J5LW1lbnVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQuY3VycmVudFRhcmdldC5vcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdW1tYXJ5IGNsYXNzTmFtZT1cInNob3AtYWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiZ3JpZFwiIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2hvcCBhbGw8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQteHNcIj7ijIQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zdW1tYXJ5PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLXBvcG92ZXIgY2F0ZWdvcnktcG9wb3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5wcm9kdWN0c30+QWxsIHByb2R1Y3RzPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Y2F0ZWdvcnkuY2F0ZWdvcnlJRH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YCR7Uk9VVEVTLnByb2R1Y3RzfT9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeS5jYXRlZ29yeUlEKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVudSA9IGV2ZW50LmN1cnJlbnRUYXJnZXQuY2xvc2VzdCgnZGV0YWlscycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1lbnUpIG1lbnUub3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q2F0ZWdvcnlOYW1lKGNhdGVnb3J5Lm5hbWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kZXRhaWxzPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGVnb3J5LW5hdi1saW5rc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yaWVzLnNsaWNlKDAsIDUpLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Y2F0ZWdvcnkuY2F0ZWdvcnlJRH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdG89e2Ake1JPVVRFUy5wcm9kdWN0c30/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkuY2F0ZWdvcnlJRCl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdENhdGVnb3J5TmFtZShjYXRlZ29yeS5uYW1lKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VydmljZS1uYXYtbGlua3NcIj5cclxuICAgICAgICAgICAgICAgICAgICA8TmF2TGluayB0bz17cmVwYWlyUm91dGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cInJlcGFpclwiIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyID8gJ1JlcGFpciBhIGRldmljZScgOiAnUmVwYWlycyd9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TmF2TGluayB0bz17Uk9VVEVTLm9yZGVyc30+WW91ciBvcmRlcnM8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIHRvPXtST1VURVMubGl2ZUNoYXR9PkxpdmUgc3VwcG9ydDwvTmF2TGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxkaXYgcmVmPXtub3RpY2VzfT5cclxuICAgICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWRhbmdlci1iZyBweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPE9mZmxpbmVCYW5uZXIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPERpYWxvZ1xyXG4gICAgICAgIG9wZW49e3NlYXJjaE9wZW59XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2VhcmNoT3BlbihmYWxzZSl9XHJcbiAgICAgICAgdGl0bGU9XCJTZWFyY2ggcHJvZHVjdHNcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPFN0b3JlU2VhcmNoIGF1dG9Gb2N1cyBvblNlYXJjaD17KCkgPT4gc2V0U2VhcmNoT3BlbihmYWxzZSl9IC8+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXX0=