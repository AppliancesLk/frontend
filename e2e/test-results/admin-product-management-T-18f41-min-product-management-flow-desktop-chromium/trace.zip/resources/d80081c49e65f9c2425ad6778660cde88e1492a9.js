import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Products/components/CatalogPagination.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { paginationPages } from "/src/pages/Products/helpers/catalog.helpers.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogPagination.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.catalog;
export function CatalogPagination({ page, totalPages, onChange }) {
	if (totalPages <= 1) return null;
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": t.pagination,
		className: "mt-8 flex flex-wrap items-center justify-center gap-2",
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				disabled: page <= 1,
				onClick: () => onChange(page - 1),
				"aria-label": t.previous,
				className: "min-h-11 w-11 rounded-sm border border-line bg-surface text-fg-secondary disabled:text-fg-disabled",
				children: "←"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 7
			}, this),
			paginationPages(page, totalPages).map((value, index) => value === "ellipsis" ? /* @__PURE__ */ _jsxDEV("span", {
				className: "px-1 text-fg-muted",
				children: "…"
			}, `gap-${index}`, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("button", {
				"aria-label": `${t.page} ${value}`,
				"aria-current": value === page ? "page" : undefined,
				onClick: () => onChange(value),
				className: `h-10 min-w-10 rounded-sm border px-2 text-sm font-medium ${value === page ? "border-primary bg-primary text-primary-on" : "border-line bg-surface text-fg-secondary hover:border-primary"}`,
				children: value
			}, value, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 11
			}, this)),
			/* @__PURE__ */ _jsxDEV("button", {
				disabled: page >= totalPages,
				onClick: () => onChange(page + 1),
				"aria-label": t.next,
				className: "min-h-11 w-11 rounded-sm border border-line bg-surface text-fg-secondary disabled:text-fg-disabled",
				children: "→"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_c = CatalogPagination;
var _c;
$RefreshReg$(_c, "CatalogPagination");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Products/components/CatalogPagination.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogPagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogPagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogPagination.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsa0JBQWtCLEVBQ2hDLE1BQ0EsWUFDQSxZQUtDO0NBQ0QsSUFBSSxjQUFjLEdBQUcsT0FBTztDQUM1QixPQUNFLHdCQUFDLE9BQUQ7RUFDRSxjQUFZLEVBQUU7RUFDZCxXQUFVO1lBRlo7R0FJRSx3QkFBQyxVQUFEO0lBQ0UsVUFBVSxRQUFRO0lBQ2xCLGVBQWUsU0FBUyxPQUFPLENBQUM7SUFDaEMsY0FBWSxFQUFFO0lBQ2QsV0FBVTtjQUNYO0dBRU87Ozs7O0dBQ1AsZ0JBQWdCLE1BQU0sVUFBVSxDQUFDLENBQUMsS0FBSyxPQUFPLFVBQzdDLFVBQVUsYUFDUix3QkFBQyxRQUFEO0lBQTJCLFdBQVU7Y0FBcUI7R0FFcEQsR0FGSyxPQUFPOzs7O1VBRVosSUFFTix3QkFBQyxVQUFEO0lBRUUsY0FBWSxHQUFHLEVBQUUsS0FBSyxHQUFHO0lBQ3pCLGdCQUFjLFVBQVUsT0FBTyxTQUFTO0lBQ3hDLGVBQWUsU0FBUyxLQUFLO0lBQzdCLFdBQVcsNERBQTRELFVBQVUsT0FBTyw4Q0FBOEM7Y0FFckk7R0FDSyxHQVBEOzs7O1VBT0MsQ0FFWjtHQUNBLHdCQUFDLFVBQUQ7SUFDRSxVQUFVLFFBQVE7SUFDbEIsZUFBZSxTQUFTLE9BQU8sQ0FBQztJQUNoQyxjQUFZLEVBQUU7SUFDZCxXQUFVO2NBQ1g7R0FFTzs7Ozs7RUFDTDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2F0YWxvZ1BhZ2luYXRpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHBhZ2luYXRpb25QYWdlcyB9IGZyb20gJy4uL2hlbHBlcnMvY2F0YWxvZy5oZWxwZXJzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5jYXRhbG9nO1xyXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1BhZ2luYXRpb24oe1xyXG4gIHBhZ2UsXHJcbiAgdG90YWxQYWdlcyxcclxuICBvbkNoYW5nZSxcclxufToge1xyXG4gIHBhZ2U6IG51bWJlcjtcclxuICB0b3RhbFBhZ2VzOiBudW1iZXI7XHJcbiAgb25DaGFuZ2U6IChwYWdlOiBudW1iZXIpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBpZiAodG90YWxQYWdlcyA8PSAxKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gKFxyXG4gICAgPG5hdlxyXG4gICAgICBhcmlhLWxhYmVsPXt0LnBhZ2luYXRpb259XHJcbiAgICAgIGNsYXNzTmFtZT1cIm10LTggZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcclxuICAgID5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIGRpc2FibGVkPXtwYWdlIDw9IDF9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gb25DaGFuZ2UocGFnZSAtIDEpfVxyXG4gICAgICAgIGFyaWEtbGFiZWw9e3QucHJldmlvdXN9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibWluLWgtMTEgdy0xMSByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHRleHQtZmctc2Vjb25kYXJ5IGRpc2FibGVkOnRleHQtZmctZGlzYWJsZWRcIlxyXG4gICAgICA+XHJcbiAgICAgICAg4oaQXHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgICB7cGFnaW5hdGlvblBhZ2VzKHBhZ2UsIHRvdGFsUGFnZXMpLm1hcCgodmFsdWUsIGluZGV4KSA9PlxyXG4gICAgICAgIHZhbHVlID09PSAnZWxsaXBzaXMnID8gKFxyXG4gICAgICAgICAgPHNwYW4ga2V5PXtgZ2FwLSR7aW5kZXh9YH0gY2xhc3NOYW1lPVwicHgtMSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIOKAplxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGtleT17dmFsdWV9XHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2Ake3QucGFnZX0gJHt2YWx1ZX1gfVxyXG4gICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e3ZhbHVlID09PSBwYWdlID8gJ3BhZ2UnIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZSh2YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtMTAgbWluLXctMTAgcm91bmRlZC1zbSBib3JkZXIgcHgtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtICR7dmFsdWUgPT09IHBhZ2UgPyAnYm9yZGVyLXByaW1hcnkgYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktb24nIDogJ2JvcmRlci1saW5lIGJnLXN1cmZhY2UgdGV4dC1mZy1zZWNvbmRhcnkgaG92ZXI6Ym9yZGVyLXByaW1hcnknfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt2YWx1ZX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICksXHJcbiAgICAgICl9XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBkaXNhYmxlZD17cGFnZSA+PSB0b3RhbFBhZ2VzfVxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHBhZ2UgKyAxKX1cclxuICAgICAgICBhcmlhLWxhYmVsPXt0Lm5leHR9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibWluLWgtMTEgdy0xMSByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHRleHQtZmctc2Vjb25kYXJ5IGRpc2FibGVkOnRleHQtZmctZGlzYWJsZWRcIlxyXG4gICAgICA+XHJcbiAgICAgICAg4oaSXHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9uYXY+XHJcbiAgKTtcclxufVxyXG4iXX0=