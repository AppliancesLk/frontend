import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/chat/ChatSessionList.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
import { chatText as t } from "/src/utils/chatText.ts";
import { formatDate } from "/src/utils/date.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatSessionList.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function ChatSessionList({ sessions, selectedId, role, select }) {
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": t.sessions,
		className: "max-h-[32rem] space-y-2 overflow-y-auto p-3",
		children: [sessions.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
			className: "p-4 text-sm text-fg-muted",
			children: t.empty
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 9
		}, this), sessions.map((session) => {
			const unread = role === "ADMIN" ? session.adminUnreadCount : session.customerUnreadCount;
			return /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-pressed": selectedId === session.id,
				onClick: () => select(session.id),
				className: `w-full rounded-md border p-4 text-left transition-colors focus-visible:outline-2 focus-visible:outline-primary ${selectedId === session.id ? "border-primary bg-primary-subtle" : "border-line bg-surface hover:bg-page"}`,
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "min-w-0 truncate font-semibold text-fg",
							children: role === "ADMIN" ? session.customer?.username ?? t.customer : `${t.newConversation} · ${session.id.slice(0, 8)}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(StatusBadge, {
							status: session.status,
							children: session.status === "OPEN" ? t.open : t.closed
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 13
					}, this),
					role === "ADMIN" && /* @__PURE__ */ _jsxDEV("span", {
						className: "mt-1 block truncate text-xs text-fg-muted",
						children: session.customer?.email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "mt-3 block truncate text-sm text-fg-secondary",
						children: session.lastMessagePreview || t.noMessages
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-fg-muted",
						children: [/* @__PURE__ */ _jsxDEV("time", {
							dateTime: session.lastMessageAt,
							children: formatDate(session.lastMessageAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [session.messageCount, "/100"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this),
					unread > 0 && /* @__PURE__ */ _jsxDEV("span", {
						className: "mt-2 inline-block rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-on",
						children: [
							unread,
							" ",
							t.unread
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 15
					}, this)
				]
			}, session.id, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 11
			}, this);
		})]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_c = ChatSessionList;
var _c;
$RefreshReg$(_c, "ChatSessionList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/chat/ChatSessionList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatSessionList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatSessionList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatSessionList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFFNUIsU0FBUyxZQUFZLFNBQVM7QUFDOUIsU0FBUyxrQkFBa0I7OztBQUMzQixPQUFPLFNBQVMsZ0JBQWdCLEVBQzlCLFVBQ0EsWUFDQSxNQUNBLFVBTUM7Q0FDRCxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxjQUFZLEVBQUU7RUFDZCxXQUFVO1lBRlosQ0FJRyxTQUFTLFdBQVcsS0FDbkIsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBNkIsRUFBRTtFQUFTOzs7O1lBRXRELFNBQVMsS0FBSyxZQUFZO0dBQ3pCLE1BQU0sU0FDSixTQUFTLFVBQ0wsUUFBUSxtQkFDUixRQUFRO0dBQ2QsT0FDRSx3QkFBQyxVQUFEO0lBRUUsTUFBSztJQUNMLGdCQUFjLGVBQWUsUUFBUTtJQUNyQyxlQUFlLE9BQU8sUUFBUSxFQUFFO0lBQ2hDLFdBQVcsa0hBQWtILGVBQWUsUUFBUSxLQUFLLHFDQUFxQztjQUxoTTtLQU9FLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLFNBQVMsVUFDTCxRQUFRLFVBQVUsWUFBWSxFQUFFLFdBQ2pDLEdBQUcsRUFBRSxnQkFBZ0IsS0FBSyxRQUFRLEdBQUcsTUFBTSxHQUFHLENBQUM7TUFDL0M7Ozs7Z0JBQ04sd0JBQUMsYUFBRDtPQUFhLFFBQVEsUUFBUTtpQkFDMUIsUUFBUSxXQUFXLFNBQVMsRUFBRSxPQUFPLEVBQUU7TUFDN0I7Ozs7Y0FDVDs7Ozs7O0tBQ0wsU0FBUyxXQUNSLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLFFBQVEsVUFBVTtLQUNmOzs7OztLQUVSLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLFFBQVEsc0JBQXNCLEVBQUU7S0FDN0I7Ozs7O0tBQ04sd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFVBQVUsUUFBUTtpQkFDckIsV0FBVyxRQUFRLGFBQWE7TUFDN0I7Ozs7Z0JBQ04sd0JBQUMsUUFBRCxhQUFPLFFBQVEsY0FBYSxNQUFVOzs7O2NBQ2xDOzs7Ozs7S0FDTCxTQUFTLEtBQ1Isd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQ0c7T0FBTztPQUFFLEVBQUU7TUFDUjs7Ozs7O0lBRUY7TUFuQ0QsUUFBUTs7OztVQW1DUDtFQUVaLENBQUMsQ0FDRTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hhdFNlc3Npb25MaXN0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdGF0dXNCYWRnZSB9IGZyb20gJy4uL3VpL1N0YXR1c0JhZGdlJztcclxuaW1wb3J0IHR5cGUgeyBDaGF0Um9sZSwgQ2hhdFNlc3Npb24gfSBmcm9tICcuLi8uLi90eXBlcy9jaGF0LnR5cGVzJztcclxuaW1wb3J0IHsgY2hhdFRleHQgYXMgdCB9IGZyb20gJy4uLy4uL3V0aWxzL2NoYXRUZXh0JztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uL3V0aWxzL2RhdGUnO1xyXG5leHBvcnQgZnVuY3Rpb24gQ2hhdFNlc3Npb25MaXN0KHtcclxuICBzZXNzaW9ucyxcclxuICBzZWxlY3RlZElkLFxyXG4gIHJvbGUsXHJcbiAgc2VsZWN0LFxyXG59OiB7XHJcbiAgc2Vzc2lvbnM6IENoYXRTZXNzaW9uW107XHJcbiAgc2VsZWN0ZWRJZDogc3RyaW5nIHwgbnVsbDtcclxuICByb2xlOiBDaGF0Um9sZTtcclxuICBzZWxlY3Q6IChpZDogc3RyaW5nKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxuYXZcclxuICAgICAgYXJpYS1sYWJlbD17dC5zZXNzaW9uc31cclxuICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzMycmVtXSBzcGFjZS15LTIgb3ZlcmZsb3cteS1hdXRvIHAtM1wiXHJcbiAgICA+XHJcbiAgICAgIHtzZXNzaW9ucy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5lbXB0eX08L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIHtzZXNzaW9ucy5tYXAoKHNlc3Npb24pID0+IHtcclxuICAgICAgICBjb25zdCB1bnJlYWQgPVxyXG4gICAgICAgICAgcm9sZSA9PT0gJ0FETUlOJ1xyXG4gICAgICAgICAgICA/IHNlc3Npb24uYWRtaW5VbnJlYWRDb3VudFxyXG4gICAgICAgICAgICA6IHNlc3Npb24uY3VzdG9tZXJVbnJlYWRDb3VudDtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9e3Nlc3Npb24uaWR9XHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBhcmlhLXByZXNzZWQ9e3NlbGVjdGVkSWQgPT09IHNlc3Npb24uaWR9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNlbGVjdChzZXNzaW9uLmlkKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIHAtNCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLXByaW1hcnkgJHtzZWxlY3RlZElkID09PSBzZXNzaW9uLmlkID8gJ2JvcmRlci1wcmltYXJ5IGJnLXByaW1hcnktc3VidGxlJyA6ICdib3JkZXItbGluZSBiZy1zdXJmYWNlIGhvdmVyOmJnLXBhZ2UnfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCB0cnVuY2F0ZSBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgIHtyb2xlID09PSAnQURNSU4nXHJcbiAgICAgICAgICAgICAgICAgID8gKHNlc3Npb24uY3VzdG9tZXI/LnVzZXJuYW1lID8/IHQuY3VzdG9tZXIpXHJcbiAgICAgICAgICAgICAgICAgIDogYCR7dC5uZXdDb252ZXJzYXRpb259IMK3ICR7c2Vzc2lvbi5pZC5zbGljZSgwLCA4KX1gfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2Ugc3RhdHVzPXtzZXNzaW9uLnN0YXR1c30+XHJcbiAgICAgICAgICAgICAgICB7c2Vzc2lvbi5zdGF0dXMgPT09ICdPUEVOJyA/IHQub3BlbiA6IHQuY2xvc2VkfVxyXG4gICAgICAgICAgICAgIDwvU3RhdHVzQmFkZ2U+XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAge3JvbGUgPT09ICdBRE1JTicgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdHJ1bmNhdGUgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICB7c2Vzc2lvbi5jdXN0b21lcj8uZW1haWx9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0zIGJsb2NrIHRydW5jYXRlIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICB7c2Vzc2lvbi5sYXN0TWVzc2FnZVByZXZpZXcgfHwgdC5ub01lc3NhZ2VzfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICA8dGltZSBkYXRlVGltZT17c2Vzc2lvbi5sYXN0TWVzc2FnZUF0fT5cclxuICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKHNlc3Npb24ubGFzdE1lc3NhZ2VBdCl9XHJcbiAgICAgICAgICAgICAgPC90aW1lPlxyXG4gICAgICAgICAgICAgIDxzcGFuPntzZXNzaW9uLm1lc3NhZ2VDb3VudH0vMTAwPC9zcGFuPlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIHt1bnJlYWQgPiAwICYmIChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0yIGlubGluZS1ibG9jayByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeSBweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcHJpbWFyeS1vblwiPlxyXG4gICAgICAgICAgICAgICAge3VucmVhZH0ge3QudW5yZWFkfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICk7XHJcbiAgICAgIH0pfVxyXG4gICAgPC9uYXY+XHJcbiAgKTtcclxufVxyXG4iXX0=