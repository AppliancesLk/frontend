import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ProductFields } from "/src/pages/Admin/Products/components/ProductFields.tsx";
import { SpecificationEntries } from "/src/pages/Admin/Products/Edit/components/SpecificationEditor.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.productEdit;
export function ProductEditForm({ page }) {
	const editor = page.editor;
	if (!editor) return null;
	const { draft, categories, product } = editor;
	const options = categories.some((category) => category.categoryID === draft.categoryID) ? categories : [...categories, product.category];
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: page.submit,
		className: "space-y-6",
		children: [
			editor.restored && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "rounded-sm border border-primary bg-primary-subtle p-4 text-sm text-fg-link",
				children: t.restored
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 9
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "rounded-sm border border-danger/25 bg-danger-bg p-4 text-sm text-danger",
				children: page.error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this),
			page.success && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "rounded-sm border border-success/25 bg-success-bg p-4 text-sm text-success",
				children: page.success
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				disabled: page.busy,
				className: "rounded-md border border-line bg-surface p-5  sm:p-6",
				children: [
					/* @__PURE__ */ _jsxDEV("legend", {
						className: "sr-only",
						children: t.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: /* @__PURE__ */ _jsxDEV(ProductFields, {
							onUploadState: page.setUploading,
							editing: true,
							productID: product.productID,
							draft,
							categories: options,
							onChange: (field, value) => page.changeDraft({
								...draft,
								[field]: value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-6 border-t border-line pt-5",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-3 text-sm font-medium text-fg",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								className: "h-4 w-4 accent-primary",
								checked: draft.isActive,
								onChange: (event) => page.changeDraft({
									...draft,
									isActive: event.target.checked
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 13
							}, this), t.availability]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-xs leading-5 text-fg-muted",
							children: t.availabilityHint
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				disabled: page.busy,
				className: "rounded-md border border-line bg-surface p-5  sm:p-6",
				children: [
					/* @__PURE__ */ _jsxDEV("legend", {
						className: "sr-only",
						children: translations.admin.specifications
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-5 flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-semibold text-fg",
							children: translations.admin.specifications
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm text-fg-muted",
							children: t.specificationsHint
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "text-sm font-medium text-danger hover:text-danger",
							onClick: () => page.changeDraft({
								...draft,
								specifications: [],
								specificationsMode: "clear"
							}),
							children: t.clearSpecifications
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 9
					}, this),
					draft.specifications.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
						className: "mb-4 text-sm text-fg-muted",
						children: draft.specificationsMode === "clear" ? t.clearedSpecifications : t.emptySpecifications
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(SpecificationEntries, {
						entries: draft.specifications,
						onChange: (entries) => page.changeDraft({
							...draft,
							specifications: entries,
							specificationsMode: "replace"
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-5  sm:p-6",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-fg-secondary",
					children: [
						t.inventoryHint,
						" ",
						/* @__PURE__ */ _jsxDEV("span", {
							className: "font-medium",
							children: [
								translations.admin.currentStock,
								" ",
								product.stockQty.toLocaleString()
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.adminInventory,
					className: "mt-3 inline-block text-sm font-medium text-fg-link hover:text-fg-link",
					children: t.inventoryLink
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "auth-primary disabled:cursor-not-allowed",
						disabled: page.busy || !page.dirty,
						children: [page.busy && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 25
						}, this), page.busy ? translations.admin.saving : t.save]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						className: "auth-secondary",
						to: ROUTES.adminProducts,
						children: t.cancel
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 9
					}, this),
					page.dirty && /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs text-warning",
						children: t.unsaved
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
}
_c = ProductEditForm;
var _c;
$RefreshReg$(_c, "ProductEditForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsWUFBWTtBQUVyQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsZ0JBQWdCLEVBQzlCLFFBR0M7Q0FDRCxNQUFNLFNBQVMsS0FBSztDQUNwQixJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLE1BQU0sRUFBRSxPQUFPLFlBQVksWUFBWTtDQUN2QyxNQUFNLFVBQVUsV0FBVyxNQUN4QixhQUFhLFNBQVMsZUFBZSxNQUFNLFVBQzlDLElBQ0ksYUFDQSxDQUFDLEdBQUcsWUFBWSxRQUFRLFFBQVE7Q0FDcEMsT0FDRSx3QkFBQyxRQUFEO0VBQU0sVUFBVSxLQUFLO0VBQVEsV0FBVTtZQUF2QztHQUNHLE9BQU8sWUFDTix3QkFBQyxLQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FFVCxFQUFFO0dBQ0Y7Ozs7O0dBRUosS0FBSyxTQUNKLHdCQUFDLEtBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtjQUVULEtBQUs7R0FDTDs7Ozs7R0FFSixLQUFLLFdBQ0osd0JBQUMsS0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRVQsS0FBSztHQUNMOzs7OztHQUVMLHdCQUFDLFlBQUQ7SUFDRSxVQUFVLEtBQUs7SUFDZixXQUFVO2NBRlo7S0FJRSx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFBVyxFQUFFO0tBQWM7Ozs7O0tBQzdDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGVBQUQ7T0FDRSxlQUFlLEtBQUs7T0FDcEI7T0FDRSxXQUFXLFFBQVE7T0FDZDtPQUNQLFlBQVk7T0FDWixXQUFXLE9BQU8sVUFDaEIsS0FBSyxZQUFZO1FBQUUsR0FBRztTQUFRLFFBQVE7T0FBTSxDQUFDO01BRWhEOzs7OztLQUNFOzs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO1FBQ1YsU0FBUyxNQUFNO1FBQ2YsV0FBVyxVQUNULEtBQUssWUFBWTtTQUFFLEdBQUc7U0FBTyxVQUFVLE1BQU0sT0FBTztRQUFRLENBQUM7T0FFaEU7Ozs7aUJBQ0EsRUFBRSxZQUNFOzs7OztnQkFDUCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixFQUFFO01BQ0Y7Ozs7Y0FDQTs7Ozs7O0lBQ0c7Ozs7OztHQUNWLHdCQUFDLFlBQUQ7SUFDRSxVQUFVLEtBQUs7SUFDZixXQUFVO2NBRlo7S0FJRSx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFBVyxhQUFhLE1BQU07S0FBdUI7Ozs7O0tBQ3ZFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLGFBQWEsTUFBTTtNQUNsQjs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBOEIsRUFBRTtNQUFzQjs7OztjQUNoRTs7OztnQkFDTCx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFdBQVU7T0FDVixlQUNFLEtBQUssWUFBWTtRQUNmLEdBQUc7UUFDSCxnQkFBZ0IsQ0FBQztRQUNqQixvQkFBb0I7T0FDdEIsQ0FBQztpQkFHRixFQUFFO01BQ0c7Ozs7Y0FDTDs7Ozs7O0tBQ0osTUFBTSxlQUFlLFdBQVcsS0FDL0Isd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsTUFBTSx1QkFBdUIsVUFDMUIsRUFBRSx3QkFDRixFQUFFO0tBQ0w7Ozs7O0tBRUwsd0JBQUMsc0JBQUQ7TUFDRSxTQUFTLE1BQU07TUFDZixXQUFXLFlBQ1QsS0FBSyxZQUFZO09BQ2YsR0FBRztPQUNILGdCQUFnQjtPQUNoQixvQkFBb0I7TUFDdEIsQ0FBQztLQUVKOzs7OztJQUNPOzs7Ozs7R0FDVix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYjtNQUNHLEVBQUU7TUFBZTtNQUNsQix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEI7UUFDRyxhQUFhLE1BQU07UUFBYztRQUNqQyxRQUFRLFNBQVMsZUFBZTtPQUM3Qjs7Ozs7O0tBQ0w7Ozs7O2NBQ0gsd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTztLQUNYLFdBQVU7ZUFFVCxFQUFFO0lBQ0M7Ozs7WUFDSDs7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtNQUNWLFVBQVUsS0FBSyxRQUFRLENBQUMsS0FBSztnQkFIL0IsQ0FLRyxLQUFLLFFBQVEsd0JBQUMsU0FBRCxFQUFTLFdBQVUsT0FBUTs7OztnQkFDeEMsS0FBSyxPQUFPLGFBQWEsTUFBTSxTQUFTLEVBQUUsSUFDckM7Ozs7OztLQUNSLHdCQUFDLE1BQUQ7TUFBTSxXQUFVO01BQWlCLElBQUksT0FBTztnQkFDekMsRUFBRTtLQUNDOzs7OztLQUNMLEtBQUssU0FDSix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBd0IsRUFBRTtLQUFjOzs7OztJQUV2RDs7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2R1Y3RFZGl0Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB0eXBlIHsgdXNlUHJvZHVjdEVkaXQgfSBmcm9tICcuLi9ob29rcy91c2VQcm9kdWN0RWRpdCc7XHJcbmltcG9ydCB7IFByb2R1Y3RGaWVsZHMgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL1Byb2R1Y3RGaWVsZHMnO1xyXG5pbXBvcnQgeyBTcGVjaWZpY2F0aW9uRW50cmllcyB9IGZyb20gJy4vU3BlY2lmaWNhdGlvbkVkaXRvcic7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLnByb2R1Y3RFZGl0O1xyXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdEVkaXRGb3JtKHtcclxuICBwYWdlLFxyXG59OiB7XHJcbiAgcGFnZTogUmV0dXJuVHlwZTx0eXBlb2YgdXNlUHJvZHVjdEVkaXQ+O1xyXG59KSB7XHJcbiAgY29uc3QgZWRpdG9yID0gcGFnZS5lZGl0b3I7XHJcbiAgaWYgKCFlZGl0b3IpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHsgZHJhZnQsIGNhdGVnb3JpZXMsIHByb2R1Y3QgfSA9IGVkaXRvcjtcclxuICBjb25zdCBvcHRpb25zID0gY2F0ZWdvcmllcy5zb21lKFxyXG4gICAgKGNhdGVnb3J5KSA9PiBjYXRlZ29yeS5jYXRlZ29yeUlEID09PSBkcmFmdC5jYXRlZ29yeUlELFxyXG4gIClcclxuICAgID8gY2F0ZWdvcmllc1xyXG4gICAgOiBbLi4uY2F0ZWdvcmllcywgcHJvZHVjdC5jYXRlZ29yeV07XHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtIG9uU3VibWl0PXtwYWdlLnN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHtlZGl0b3IucmVzdG9yZWQgJiYgKFxyXG4gICAgICAgIDxwXHJcbiAgICAgICAgICByb2xlPVwic3RhdHVzXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1wcmltYXJ5IGJnLXByaW1hcnktc3VidGxlIHAtNCB0ZXh0LXNtIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3QucmVzdG9yZWR9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICB7cGFnZS5lcnJvciAmJiAoXHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIGJvcmRlciBib3JkZXItZGFuZ2VyLzI1IGJnLWRhbmdlci1iZyBwLTQgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICB7cGFnZS5zdWNjZXNzICYmIChcclxuICAgICAgICA8cFxyXG4gICAgICAgICAgcm9sZT1cInN0YXR1c1wiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIGJvcmRlciBib3JkZXItc3VjY2Vzcy8yNSBiZy1zdWNjZXNzLWJnIHAtNCB0ZXh0LXNtIHRleHQtc3VjY2Vzc1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3BhZ2Uuc3VjY2Vzc31cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIDxmaWVsZHNldFxyXG4gICAgICAgIGRpc2FibGVkPXtwYWdlLmJ1c3l9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTUgIHNtOnAtNlwiXHJcbiAgICAgID5cclxuICAgICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57dC50aXRsZX08L2xlZ2VuZD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTUgc206Z3JpZC1jb2xzLTJcIj5cclxuICAgICAgICAgIDxQcm9kdWN0RmllbGRzXHJcbiAgICAgICAgICAgIG9uVXBsb2FkU3RhdGU9e3BhZ2Uuc2V0VXBsb2FkaW5nfVxyXG4gICAgICAgICAgICBlZGl0aW5nXHJcbiAgICAgICAgICAgICAgcHJvZHVjdElEPXtwcm9kdWN0LnByb2R1Y3RJRH1cclxuICAgICAgICAgICAgZHJhZnQ9e2RyYWZ0fVxyXG4gICAgICAgICAgICBjYXRlZ29yaWVzPXtvcHRpb25zfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGZpZWxkLCB2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICBwYWdlLmNoYW5nZURyYWZ0KHsgLi4uZHJhZnQsIFtmaWVsZF06IHZhbHVlIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJvcmRlci10IGJvcmRlci1saW5lIHB0LTVcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IGFjY2VudC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICBjaGVja2VkPXtkcmFmdC5pc0FjdGl2ZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PlxyXG4gICAgICAgICAgICAgICAgcGFnZS5jaGFuZ2VEcmFmdCh7IC4uLmRyYWZ0LCBpc0FjdGl2ZTogZXZlbnQudGFyZ2V0LmNoZWNrZWQgfSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHt0LmF2YWlsYWJpbGl0eX1cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAge3QuYXZhaWxhYmlsaXR5SGludH1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9maWVsZHNldD5cclxuICAgICAgPGZpZWxkc2V0XHJcbiAgICAgICAgZGlzYWJsZWQ9e3BhZ2UuYnVzeX1cclxuICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNSAgc206cC02XCJcclxuICAgICAgPlxyXG4gICAgICAgIDxsZWdlbmQgY2xhc3NOYW1lPVwic3Itb25seVwiPnt0cmFuc2xhdGlvbnMuYWRtaW4uc3BlY2lmaWNhdGlvbnN9PC9sZWdlbmQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYWRtaW4uc3BlY2lmaWNhdGlvbnN9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3Quc3BlY2lmaWNhdGlvbnNIaW50fTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWRhbmdlciBob3Zlcjp0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgcGFnZS5jaGFuZ2VEcmFmdCh7XHJcbiAgICAgICAgICAgICAgICAuLi5kcmFmdCxcclxuICAgICAgICAgICAgICAgIHNwZWNpZmljYXRpb25zOiBbXSxcclxuICAgICAgICAgICAgICAgIHNwZWNpZmljYXRpb25zTW9kZTogJ2NsZWFyJyxcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LmNsZWFyU3BlY2lmaWNhdGlvbnN9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7ZHJhZnQuc3BlY2lmaWNhdGlvbnMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHtkcmFmdC5zcGVjaWZpY2F0aW9uc01vZGUgPT09ICdjbGVhcidcclxuICAgICAgICAgICAgICA/IHQuY2xlYXJlZFNwZWNpZmljYXRpb25zXHJcbiAgICAgICAgICAgICAgOiB0LmVtcHR5U3BlY2lmaWNhdGlvbnN9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8U3BlY2lmaWNhdGlvbkVudHJpZXNcclxuICAgICAgICAgIGVudHJpZXM9e2RyYWZ0LnNwZWNpZmljYXRpb25zfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlbnRyaWVzKSA9PlxyXG4gICAgICAgICAgICBwYWdlLmNoYW5nZURyYWZ0KHtcclxuICAgICAgICAgICAgICAuLi5kcmFmdCxcclxuICAgICAgICAgICAgICBzcGVjaWZpY2F0aW9uczogZW50cmllcyxcclxuICAgICAgICAgICAgICBzcGVjaWZpY2F0aW9uc01vZGU6ICdyZXBsYWNlJyxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01ICBzbTpwLTZcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICB7dC5pbnZlbnRvcnlIaW50fXsnICd9XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICB7dHJhbnNsYXRpb25zLmFkbWluLmN1cnJlbnRTdG9ja317JyAnfVxyXG4gICAgICAgICAgICB7cHJvZHVjdC5zdG9ja1F0eS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5hZG1pbkludmVudG9yeX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTMgaW5saW5lLWJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3QuaW52ZW50b3J5TGlua31cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICBkaXNhYmxlZD17cGFnZS5idXN5IHx8ICFwYWdlLmRpcnR5fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtwYWdlLmJ1c3kgJiYgPFNwaW5uZXIgY2xhc3NOYW1lPVwibXItMlwiIC8+fVxyXG4gICAgICAgICAge3BhZ2UuYnVzeSA/IHRyYW5zbGF0aW9ucy5hZG1pbi5zYXZpbmcgOiB0LnNhdmV9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnlcIiB0bz17Uk9VVEVTLmFkbWluUHJvZHVjdHN9PlxyXG4gICAgICAgICAge3QuY2FuY2VsfVxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICB7cGFnZS5kaXJ0eSAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2FybmluZ1wiPnt0LnVuc2F2ZWR9PC9zcGFuPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn1cclxuIl19