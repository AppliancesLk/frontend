import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/components/ProductPicker.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { getProductCatalog } from "/src/services/productService.ts";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { promotionText as t } from "/src/utils/promotionText.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { Button } from "/src/components/ui/Button.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/ProductPicker.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function ProductPicker({ draft, onChange, selectedProducts, onProducts }) {
	_s();
	const [search, setSearch] = useState(""), [page, setPage] = useState(1), [result, setResult] = useState(null), [loading, setLoading] = useState(true), [error, setError] = useState(""), [revision, setRevision] = useState(0);
	useEffect(() => {
		const controller = new AbortController();
		const timer = window.setTimeout(async () => {
			setLoading(true);
			setError("");
			try {
				const next = await getProductCatalog({
					q: search,
					page,
					limit: 8,
					sort: "name"
				}, controller.signal);
				if (!controller.signal.aborted) setResult(next);
			} catch (err) {
				if (!controller.signal.aborted) setError(getApiError(err, "Unable to load products. Please try again."));
			} finally {
				if (!controller.signal.aborted) setLoading(false);
			}
		}, 300);
		return () => {
			controller.abort();
			window.clearTimeout(timer);
		};
	}, [
		search,
		page,
		revision
	]);
	function toggle(product) {
		const has = draft.productIds.includes(product.productID);
		onChange({
			...draft,
			productIds: has ? draft.productIds.filter((id) => id !== product.productID) : [...draft.productIds, product.productID]
		});
		if (!has && !selectedProducts.some((item) => item.productID === product.productID)) onProducts([...selectedProducts, product]);
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "ui-panel p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-semibold",
				children: t.products
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-xs leading-5 text-fg-muted",
				children: t.productHint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-xs font-semibold",
				children: [
					draft.productIds.length,
					" / 12 ",
					t.selectedCount
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this),
			draft.productIds.length > 0 && /* @__PURE__ */ _jsxDEV("ul", {
				className: "mt-3 space-y-2",
				children: draft.productIds.map((id) => {
					const product = selectedProducts.find((item) => item.productID === id);
					return /* @__PURE__ */ _jsxDEV("li", {
						className: "flex items-center justify-between gap-3 rounded-md bg-subtle p-3 text-xs",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "min-w-0 break-words",
							children: [product?.name ?? "Unavailable product", product && !product.isActive ? " (inactive)" : ""]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-label": `Remove ${product?.name ?? "product"}`,
							className: "shrink-0 p-1 underline",
							onClick: () => onChange({
								...draft,
								productIds: draft.productIds.filter((value) => value !== id)
							}),
							children: "Remove"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 17
						}, this)]
					}, id, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				className: "auth-label mt-4",
				htmlFor: "promotion-product-search",
				children: t.productSearch
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "promotion-product-search",
				className: "ui-field",
				type: "search",
				maxLength: 100,
				value: search,
				onChange: (e) => {
					setSearch(e.target.value);
					setPage(1);
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mt-3 text-sm text-danger",
				children: [
					error,
					" ",
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "underline",
						onClick: () => setRevision((n) => n + 1),
						children: "Retry"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 127,
				columnNumber: 9
			}, this),
			loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { compact: true }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-3 max-h-80 overflow-y-auto rounded-md border border-line",
				children: result?.items.length ? result.items.map((product) => /* @__PURE__ */ _jsxDEV("label", {
					className: "flex cursor-pointer items-center gap-3 border-b border-line p-3 last:border-0 hover:bg-subtle",
					children: [
						/* @__PURE__ */ _jsxDEV("input", {
							type: "checkbox",
							"aria-label": `Select product ${product.name}`,
							checked: draft.productIds.includes(product.productID),
							disabled: draft.productIds.length >= 12 && !draft.productIds.includes(product.productID),
							onChange: () => toggle(product),
							className: "h-4 w-4 shrink-0 accent-primary"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "h-12 w-12 shrink-0 overflow-hidden rounded-md bg-subtle",
							children: /* @__PURE__ */ _jsxDEV(ProductImage, {
								src: product.images[0],
								alt: product.name,
								className: "h-full w-full object-contain"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "min-w-0 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "block font-medium",
								children: product.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "mt-1 block text-fg-muted",
								children: formatCurrency(product.price)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 17
						}, this)
					]
				}, product.productID, true, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 15
				}, this)) : /* @__PURE__ */ _jsxDEV("p", {
					className: "p-4 text-sm text-fg-muted",
					children: "No matching products."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-3 flex items-center justify-between gap-2 text-xs",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: [result?.total ?? 0, " products"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 180,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "ghost",
						disabled: page <= 1 || loading,
						onClick: () => setPage(page - 1),
						children: "Previous"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "ghost",
						disabled: loading || !result || page >= result.totalPages,
						onClick: () => setPage(page + 1),
						children: "Next"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 71,
		columnNumber: 5
	}, this);
}
_s(ProductPicker, "SVUU6XVF9Rna+UUg5YSNLnn7Hvg=");
_c = ProductPicker;
var _c;
$RefreshReg$(_c, "ProductPicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/components/ProductPicker.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/ProductPicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/ProductPicker.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/ProductPicker.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHlCQUF5QjtBQU1sQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGlCQUFpQixTQUFTO0FBQ25DLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjs7OztBQUM3QixPQUFPLFNBQVMsY0FBYyxFQUM1QixPQUNBLFVBQ0Esa0JBQ0EsY0FNQzs7Q0FDRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRSxHQUNyQyxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUMsR0FDNUIsQ0FBQyxRQUFRLGFBQWEsU0FBK0IsSUFBSSxHQUN6RCxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUksR0FDckMsQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFLEdBQy9CLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUN0QyxnQkFBZ0I7RUFDZCxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFDdkMsTUFBTSxRQUFRLE9BQU8sV0FBVyxZQUFZO0dBQzFDLFdBQVcsSUFBSTtHQUNmLFNBQVMsRUFBRTtHQUNYLElBQUk7SUFDRixNQUFNLE9BQU8sTUFBTSxrQkFDakI7S0FBRSxHQUFHO0tBQVE7S0FBTSxPQUFPO0tBQUcsTUFBTTtJQUFPLEdBQzFDLFdBQVcsTUFDYjtJQUNBLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUyxVQUFVLElBQUk7R0FDaEQsU0FBUyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUNyQixTQUNFLFlBQVksS0FBSyw0Q0FBNEMsQ0FDL0Q7R0FDSixVQUFVO0lBQ1IsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztHQUNsRDtFQUNGLEdBQUcsR0FBRztFQUNOLGFBQWE7R0FDWCxXQUFXLE1BQU07R0FDakIsT0FBTyxhQUFhLEtBQUs7RUFDM0I7Q0FDRixHQUFHO0VBQUM7RUFBUTtFQUFNO0NBQVEsQ0FBQztDQUMzQixTQUFTLE9BQU8sU0FBMkI7RUFDekMsTUFBTSxNQUFNLE1BQU0sV0FBVyxTQUFTLFFBQVEsU0FBUztFQUN2RCxTQUFTO0dBQ1AsR0FBRztHQUNILFlBQVksTUFDUixNQUFNLFdBQVcsUUFBUSxPQUFPLE9BQU8sUUFBUSxTQUFTLElBQ3hELENBQUMsR0FBRyxNQUFNLFlBQVksUUFBUSxTQUFTO0VBQzdDLENBQUM7RUFDRCxJQUNFLENBQUMsT0FDRCxDQUFDLGlCQUFpQixNQUFNLFNBQVMsS0FBSyxjQUFjLFFBQVEsU0FBUyxHQUVyRSxXQUFXLENBQUMsR0FBRyxrQkFBa0IsT0FBTyxDQUFDO0NBQzdDO0NBQ0EsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXlCLEVBQUU7R0FBYTs7Ozs7R0FDdEQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBd0MsRUFBRTtHQUFlOzs7OztHQUN0RSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQ0csTUFBTSxXQUFXO0tBQU87S0FBTyxFQUFFO0lBQ2pDOzs7Ozs7R0FDRixNQUFNLFdBQVcsU0FBUyxLQUN6Qix3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLE1BQU0sV0FBVyxLQUFLLE9BQU87S0FDNUIsTUFBTSxVQUFVLGlCQUFpQixNQUM5QixTQUFTLEtBQUssY0FBYyxFQUMvQjtLQUNBLE9BQ0Usd0JBQUMsTUFBRDtNQUVFLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDRyxTQUFTLFFBQVEsdUJBQ2pCLFdBQVcsQ0FBQyxRQUFRLFdBQVcsZ0JBQWdCLEVBQzVDOzs7OztnQkFDTix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGNBQVksVUFBVSxTQUFTLFFBQVE7T0FDdkMsV0FBVTtPQUNWLGVBQ0UsU0FBUztRQUNQLEdBQUc7UUFDSCxZQUFZLE1BQU0sV0FBVyxRQUMxQixVQUFVLFVBQVUsRUFDdkI7T0FDRixDQUFDO2lCQUVKO01BRU87Ozs7Y0FDTjtRQXRCRzs7OztZQXNCSDtJQUVSLENBQUM7R0FDQzs7Ozs7R0FFTix3QkFBQyxTQUFEO0lBQU8sV0FBVTtJQUFrQixTQUFRO2NBQ3hDLEVBQUU7R0FDRTs7Ozs7R0FDUCx3QkFBQyxTQUFEO0lBQ0UsSUFBRztJQUNILFdBQVU7SUFDVixNQUFLO0lBQ0wsV0FBVztJQUNYLE9BQU87SUFDUCxXQUFXLE1BQU07S0FDZixVQUFVLEVBQUUsT0FBTyxLQUFLO0tBQ3hCLFFBQVEsQ0FBQztJQUNYO0dBQ0Q7Ozs7O0dBQ0EsU0FDQyx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFRLFdBQVU7Y0FBMUI7S0FDRztLQUFPO0tBQ1Isd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFBZSxhQUFhLE1BQU0sSUFBSSxDQUFDO2dCQUN4QztLQUVPOzs7OztJQUNQOzs7Ozs7R0FFSixVQUNDLHdCQUFDLGNBQUQsRUFBYyxjQUFTOzs7O2NBRXZCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osUUFBUSxNQUFNLFNBQ2IsT0FBTyxNQUFNLEtBQUssWUFDaEIsd0JBQUMsU0FBRDtLQUVFLFdBQVU7ZUFGWjtNQUlFLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsY0FBWSxrQkFBa0IsUUFBUTtPQUN0QyxTQUFTLE1BQU0sV0FBVyxTQUFTLFFBQVEsU0FBUztPQUNwRCxVQUNFLE1BQU0sV0FBVyxVQUFVLE1BQzNCLENBQUMsTUFBTSxXQUFXLFNBQVMsUUFBUSxTQUFTO09BRTlDLGdCQUFnQixPQUFPLE9BQU87T0FDOUIsV0FBVTtNQUNYOzs7OztNQUNELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLGNBQUQ7UUFDRSxLQUFLLFFBQVEsT0FBTztRQUNwQixLQUFLLFFBQVE7UUFDYixXQUFVO09BQ1g7Ozs7O01BQ0U7Ozs7O01BQ0wsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXFCLFFBQVE7T0FBVzs7OztpQkFDeEQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsZUFBZSxRQUFRLEtBQUs7T0FDekI7Ozs7ZUFDRjs7Ozs7O0tBQ0Q7T0EzQkEsUUFBUTs7OztXQTJCUixDQUNSLElBRUQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNEI7SUFBd0I7Ozs7O0dBRWhFOzs7OztHQUVQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxLQUFELGFBQUksUUFBUSxTQUFTLEdBQUUsV0FBWTs7OztjQUNuQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixVQUFVLFFBQVEsS0FBSztNQUN2QixlQUFlLFFBQVEsT0FBTyxDQUFDO2dCQUNoQztLQUVPOzs7O2VBQ1Isd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixVQUFVLFdBQVcsQ0FBQyxVQUFVLFFBQVEsT0FBTztNQUMvQyxlQUFlLFFBQVEsT0FBTyxDQUFDO2dCQUNoQztLQUVPOzs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7OztFQUNFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0UGlja2VyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBnZXRQcm9kdWN0Q2F0YWxvZyB9IGZyb20gJy4uLy4uLy4uLy4uL3NlcnZpY2VzL3Byb2R1Y3RTZXJ2aWNlJztcclxuaW1wb3J0IHR5cGUgeyBDYXRhbG9nUmVzdWx0IH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvY2F0YWxvZy50eXBlcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBQcm9tb3Rpb25Db250ZW50LFxyXG4gIFByb21vdGlvblByb2R1Y3QsXHJcbn0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvcHJvbW90aW9uLnR5cGVzJztcclxuaW1wb3J0IHsgUHJvZHVjdEltYWdlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJvZHVjdEltYWdlJztcclxuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9jdXJyZW5jeSc7XHJcbmltcG9ydCB7IHByb21vdGlvblRleHQgYXMgdCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3Byb21vdGlvblRleHQnO1xyXG5pbXBvcnQgeyBnZXRBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2FwaUVycm9ycyc7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0UGlja2VyKHtcclxuICBkcmFmdCxcclxuICBvbkNoYW5nZSxcclxuICBzZWxlY3RlZFByb2R1Y3RzLFxyXG4gIG9uUHJvZHVjdHMsXHJcbn06IHtcclxuICBkcmFmdDogUHJvbW90aW9uQ29udGVudDtcclxuICBvbkNoYW5nZTogKHZhbHVlOiBQcm9tb3Rpb25Db250ZW50KSA9PiB2b2lkO1xyXG4gIHNlbGVjdGVkUHJvZHVjdHM6IFByb21vdGlvblByb2R1Y3RbXTtcclxuICBvblByb2R1Y3RzOiAodmFsdWU6IFByb21vdGlvblByb2R1Y3RbXSkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyksXHJcbiAgICBbcGFnZSwgc2V0UGFnZV0gPSB1c2VTdGF0ZSgxKSxcclxuICAgIFtyZXN1bHQsIHNldFJlc3VsdF0gPSB1c2VTdGF0ZTxDYXRhbG9nUmVzdWx0IHwgbnVsbD4obnVsbCksXHJcbiAgICBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKSxcclxuICAgIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpLFxyXG4gICAgW3JldmlzaW9uLCBzZXRSZXZpc2lvbl0gPSB1c2VTdGF0ZSgwKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgbmV4dCA9IGF3YWl0IGdldFByb2R1Y3RDYXRhbG9nKFxyXG4gICAgICAgICAgeyBxOiBzZWFyY2gsIHBhZ2UsIGxpbWl0OiA4LCBzb3J0OiAnbmFtZScgfSxcclxuICAgICAgICAgIGNvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSBzZXRSZXN1bHQobmV4dCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZClcclxuICAgICAgICAgIHNldEVycm9yKFxyXG4gICAgICAgICAgICBnZXRBcGlFcnJvcihlcnIsICdVbmFibGUgdG8gbG9hZCBwcm9kdWN0cy4gUGxlYXNlIHRyeSBhZ2Fpbi4nKSxcclxuICAgICAgICAgICk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSwgMzAwKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoKTtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9O1xyXG4gIH0sIFtzZWFyY2gsIHBhZ2UsIHJldmlzaW9uXSk7XHJcbiAgZnVuY3Rpb24gdG9nZ2xlKHByb2R1Y3Q6IFByb21vdGlvblByb2R1Y3QpIHtcclxuICAgIGNvbnN0IGhhcyA9IGRyYWZ0LnByb2R1Y3RJZHMuaW5jbHVkZXMocHJvZHVjdC5wcm9kdWN0SUQpO1xyXG4gICAgb25DaGFuZ2Uoe1xyXG4gICAgICAuLi5kcmFmdCxcclxuICAgICAgcHJvZHVjdElkczogaGFzXHJcbiAgICAgICAgPyBkcmFmdC5wcm9kdWN0SWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSBwcm9kdWN0LnByb2R1Y3RJRClcclxuICAgICAgICA6IFsuLi5kcmFmdC5wcm9kdWN0SWRzLCBwcm9kdWN0LnByb2R1Y3RJRF0sXHJcbiAgICB9KTtcclxuICAgIGlmIChcclxuICAgICAgIWhhcyAmJlxyXG4gICAgICAhc2VsZWN0ZWRQcm9kdWN0cy5zb21lKChpdGVtKSA9PiBpdGVtLnByb2R1Y3RJRCA9PT0gcHJvZHVjdC5wcm9kdWN0SUQpXHJcbiAgICApXHJcbiAgICAgIG9uUHJvZHVjdHMoWy4uLnNlbGVjdGVkUHJvZHVjdHMsIHByb2R1Y3RdKTtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInVpLXBhbmVsIHAtNSBzbTpwLTZcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPnt0LnByb2R1Y3RzfTwvaDI+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBsZWFkaW5nLTUgdGV4dC1mZy1tdXRlZFwiPnt0LnByb2R1Y3RIaW50fTwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICB7ZHJhZnQucHJvZHVjdElkcy5sZW5ndGh9IC8gMTIge3Quc2VsZWN0ZWRDb3VudH1cclxuICAgICAgPC9wPlxyXG4gICAgICB7ZHJhZnQucHJvZHVjdElkcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwibXQtMyBzcGFjZS15LTJcIj5cclxuICAgICAgICAgIHtkcmFmdC5wcm9kdWN0SWRzLm1hcCgoaWQpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgcHJvZHVjdCA9IHNlbGVjdGVkUHJvZHVjdHMuZmluZChcclxuICAgICAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5wcm9kdWN0SUQgPT09IGlkLFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAga2V5PXtpZH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyByb3VuZGVkLW1kIGJnLXN1YnRsZSBwLTMgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCBicmVhay13b3Jkc1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cHJvZHVjdD8ubmFtZSA/PyAnVW5hdmFpbGFibGUgcHJvZHVjdCd9XHJcbiAgICAgICAgICAgICAgICAgIHtwcm9kdWN0ICYmICFwcm9kdWN0LmlzQWN0aXZlID8gJyAoaW5hY3RpdmUpJyA6ICcnfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFJlbW92ZSAke3Byb2R1Y3Q/Lm5hbWUgPz8gJ3Byb2R1Y3QnfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHAtMSB1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLmRyYWZ0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdElkczogZHJhZnQucHJvZHVjdElkcy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICh2YWx1ZSkgPT4gdmFsdWUgIT09IGlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvdWw+XHJcbiAgICAgICl9XHJcbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdXRoLWxhYmVsIG10LTRcIiBodG1sRm9yPVwicHJvbW90aW9uLXByb2R1Y3Qtc2VhcmNoXCI+XHJcbiAgICAgICAge3QucHJvZHVjdFNlYXJjaH1cclxuICAgICAgPC9sYWJlbD5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgaWQ9XCJwcm9tb3Rpb24tcHJvZHVjdC1zZWFyY2hcIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkXCJcclxuICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICBtYXhMZW5ndGg9ezEwMH1cclxuICAgICAgICB2YWx1ZT17c2VhcmNofVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgIHNldFBhZ2UoMSk7XHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgIHtlcnJvcn17JyAnfVxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmV2aXNpb24oKG4pID0+IG4gKyAxKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmV0cnlcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgPExvYWRpbmdTdGF0ZSBjb21wYWN0IC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIG1heC1oLTgwIG92ZXJmbG93LXktYXV0byByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZVwiPlxyXG4gICAgICAgICAge3Jlc3VsdD8uaXRlbXMubGVuZ3RoID8gKFxyXG4gICAgICAgICAgICByZXN1bHQuaXRlbXMubWFwKChwcm9kdWN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICBrZXk9e3Byb2R1Y3QucHJvZHVjdElEfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcC0zIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc3VidGxlXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFNlbGVjdCBwcm9kdWN0ICR7cHJvZHVjdC5uYW1lfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2RyYWZ0LnByb2R1Y3RJZHMuaW5jbHVkZXMocHJvZHVjdC5wcm9kdWN0SUQpfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgZHJhZnQucHJvZHVjdElkcy5sZW5ndGggPj0gMTIgJiZcclxuICAgICAgICAgICAgICAgICAgICAhZHJhZnQucHJvZHVjdElkcy5pbmNsdWRlcyhwcm9kdWN0LnByb2R1Y3RJRClcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gdG9nZ2xlKHByb2R1Y3QpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIGFjY2VudC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTIgdy0xMiBzaHJpbmstMCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1tZCBiZy1zdWJ0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgPFByb2R1Y3RJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgIHNyYz17cHJvZHVjdC5pbWFnZXNbMF19XHJcbiAgICAgICAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY29udGFpblwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bVwiPntwcm9kdWN0Lm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICApKVxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicC00IHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPk5vIG1hdGNoaW5nIHByb2R1Y3RzLjwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC14c1wiPlxyXG4gICAgICAgIDxwPntyZXN1bHQ/LnRvdGFsID8/IDB9IHByb2R1Y3RzPC9wPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17cGFnZSA8PSAxIHx8IGxvYWRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhZ2UocGFnZSAtIDEpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBQcmV2aW91c1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8ICFyZXN1bHQgfHwgcGFnZSA+PSByZXN1bHQudG90YWxQYWdlc31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnZShwYWdlICsgMSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIE5leHRcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==