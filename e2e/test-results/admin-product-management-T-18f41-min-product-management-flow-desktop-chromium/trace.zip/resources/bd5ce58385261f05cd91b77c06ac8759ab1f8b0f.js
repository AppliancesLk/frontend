import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Orders/components/AdminOrderBadges.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderBadges.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function AdminOrderStatusBadge({ status }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status,
		children: translations.orders.statuses[status]
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = AdminOrderStatusBadge;
export function PaymentBadge({ status }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status,
		children: translations.adminOrders.paymentStatuses[status]
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_c2 = PaymentBadge;
var _c, _c2;
$RefreshReg$(_c, "AdminOrderStatusBadge");
$RefreshReg$(_c2, "PaymentBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Orders/components/AdminOrderBadges.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderBadges.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderBadges.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrderBadges.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7OztBQUM1QixPQUFPLFNBQVMsc0JBQXNCLEVBQUUsVUFBbUM7Q0FDekUsT0FDRSx3QkFBQyxhQUFEO0VBQXFCO1lBQ2xCLGFBQWEsT0FBTyxTQUFTO0NBQ25COzs7OztBQUVqQjs7QUFDQSxPQUFPLFNBQVMsYUFBYSxFQUMzQixVQUdDO0NBQ0QsT0FDRSx3QkFBQyxhQUFEO0VBQXFCO1lBQ2xCLGFBQWEsWUFBWSxnQkFBZ0I7Q0FDL0I7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFkbWluT3JkZXJCYWRnZXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgT3JkZXJTdGF0dXMgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9vcmRlci50eXBlcyc7XG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL1N0YXR1c0JhZGdlJztcbmV4cG9ydCBmdW5jdGlvbiBBZG1pbk9yZGVyU3RhdHVzQmFkZ2UoeyBzdGF0dXMgfTogeyBzdGF0dXM6IE9yZGVyU3RhdHVzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8U3RhdHVzQmFkZ2Ugc3RhdHVzPXtzdGF0dXN9PlxuICAgICAge3RyYW5zbGF0aW9ucy5vcmRlcnMuc3RhdHVzZXNbc3RhdHVzXX1cbiAgICA8L1N0YXR1c0JhZGdlPlxuICApO1xufVxuZXhwb3J0IGZ1bmN0aW9uIFBheW1lbnRCYWRnZSh7XG4gIHN0YXR1cyxcbn06IHtcbiAgc3RhdHVzOiAnUEVORElORycgfCAnU1VDQ0VTUycgfCAnRkFJTEVEJyB8ICdDQU5DRUxMRUQnO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e3N0YXR1c30+XG4gICAgICB7dHJhbnNsYXRpb25zLmFkbWluT3JkZXJzLnBheW1lbnRTdGF0dXNlc1tzdGF0dXNdfVxuICAgIDwvU3RhdHVzQmFkZ2U+XG4gICk7XG59XG4iXX0=