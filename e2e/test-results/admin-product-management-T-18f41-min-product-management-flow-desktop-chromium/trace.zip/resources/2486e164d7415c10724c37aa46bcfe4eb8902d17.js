import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/chat/ChatConversation.tsx");const useEffect = __vite__cjsImport6_react["useEffect"]; const useRef = __vite__cjsImport6_react["useRef"]; const useState = __vite__cjsImport6_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
import { uiText } from "/src/utils/uiText.ts";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { chatText as t } from "/src/utils/chatText.ts";
import { formatDate } from "/src/utils/date.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConversation.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function ChatConversation({ chat, admin = false }) {
	_s();
	const [confirmClose, setConfirmClose] = useState(false);
	const end = useRef(null);
	const view = chat.conversation;
	useEffect(() => {
		end.current?.scrollIntoView({ block: "nearest" });
	}, [chat.selectedId, view?.messages.length]);
	if (!chat.selectedId) return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-80 items-center justify-center p-8 text-center text-sm text-fg-muted",
		children: t.select
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 7
	}, this);
	if (chat.historyError) return /* @__PURE__ */ _jsxDEV("div", {
		role: "alert",
		className: "p-6 text-sm text-danger",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: chat.historyError }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			onClick: chat.retryHistory,
			className: "ui-button ui-button-secondary mt-3 rounded-sm border border-line px-4 py-2 text-fg-secondary",
			children: t.retry
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 7
	}, this);
	if (!view) return /* @__PURE__ */ _jsxDEV(LoadingState, {
		label: t.historyLoading,
		compact: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 21
	}, this);
	const { session, messages } = view;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "chat-conversation",
		children: [
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: confirmClose,
				onClose: () => setConfirmClose(false),
				title: uiText.closeChat,
				description: uiText.closeChatDescription,
				busy: chat.closing,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap justify-end gap-3",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: chat.closing,
						onClick: () => setConfirmClose(false),
						children: uiText.cancel
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "danger",
						busy: chat.closing,
						onClick: async () => {
							await chat.close();
							setConfirmClose(false);
						},
						children: t.close
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-3 border-b border-line p-4 sm:p-5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "break-words font-semibold text-fg",
							children: admin ? session.customer?.username ?? t.customer : t.support
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 11
						}, this),
						admin && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 break-all text-sm text-fg-muted",
							children: session.customer?.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-xs text-fg-muted",
							children: [
								/* @__PURE__ */ _jsxDEV(StatusBadge, {
									status: session.status,
									children: session.status === "OPEN" ? t.open : t.closed
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 13
								}, this),
								" · ",
								session.messageCount,
								"/100 · ",
								formatDate(session.createdAt)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this), admin && session.status === "OPEN" && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setConfirmClose(true),
					disabled: chat.closing,
					className: "ui-button ui-button-secondary min-h-11 rounded-sm border border-line px-4 text-sm font-medium text-fg-secondary hover:bg-page ",
					children: [chat.closing && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 30
					}, this), chat.closing ? t.closing : t.close]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				role: "log",
				"aria-label": t.conversation,
				"aria-live": "polite",
				"aria-relevant": "additions",
				tabIndex: 0,
				className: "chat-message-log flex-1 space-y-4 overflow-y-auto overscroll-contain bg-page p-4 focus-visible:outline-2 focus-visible:outline-primary sm:p-5",
				children: [
					messages.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
						className: "py-8 text-center text-sm text-fg-muted",
						children: t.noMessages
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this),
					messages.map((message) => /* @__PURE__ */ _jsxDEV("article", {
						className: `max-w-[90%] rounded-md px-4 py-3 sm:max-w-[80%] ${message.senderRole === chat.role ? "ml-auto bg-primary text-primary-on" : "mr-auto border border-line bg-surface text-fg"}`,
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: `mb-1 text-xs font-semibold ${message.senderRole === chat.role ? "text-primary-on" : "text-fg-muted"}`,
								children: message.senderUserId === chat.userId ? t.you : message.senderRole === "ADMIN" ? t.support : t.customer
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "whitespace-pre-wrap break-words text-sm leading-6",
								children: message.content
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("time", {
								dateTime: message.createdAt,
								className: `mt-2 block text-xs ${message.senderRole === chat.role ? "text-primary-on" : "text-fg-muted"}`,
								children: formatDate(message.createdAt)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 13
							}, this)
						]
					}, message.id, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 11
					}, this)),
					/* @__PURE__ */ _jsxDEV("div", { ref: end }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 7
			}, this),
			session.messageCount >= 100 ? /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "border-t border-warning/25 bg-warning-bg p-4 text-sm text-warning",
				children: admin ? t.adminLimit : t.limit
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 9
			}, this) : session.status === "CLOSED" ? /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "border-t border-line bg-subtle p-4 text-sm text-fg-secondary",
				children: t.closedNotice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 153,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(ChatComposer, {
				value: chat.draft,
				setValue: (value) => chat.setDraft(session.id, value),
				disabled: chat.sending || chat.connection !== "connected" || !!chat.sendError,
				sending: chat.sending,
				send: chat.submit
			}, session.id, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 9
			}, this),
			chat.sendError && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "border-t border-danger/25 bg-danger-bg p-4 text-sm text-danger",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: chat.sendError }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 176,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled: chat.sending || chat.connection !== "connected",
					onClick: chat.retrySend,
					className: "mt-2 rounded font-medium underline ",
					children: t.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
}
_s(ChatConversation, "K1wJZh/UWNkkfLwLuTtPqlD3pDk=");
_c = ChatConversation;
function ChatComposer({ value, setValue, disabled, sending, send }) {
	_s2();
	const inFlight = useRef(false);
	async function submit() {
		if (disabled || inFlight.current || !value.trim()) return;
		inFlight.current = true;
		try {
			if (await send(value)) setValue("");
		} finally {
			inFlight.current = false;
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: (event) => {
			event.preventDefault();
			void submit();
		},
		className: "sticky bottom-0 space-y-2 border-t border-line bg-surface p-4 pb-[max(1rem,env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "support-message",
				className: "block text-sm font-medium text-fg-secondary",
				children: t.label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 221,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("textarea", {
				id: "support-message",
				rows: 2,
				maxLength: 2e3,
				value,
				disabled,
				onChange: (event) => setValue(event.target.value),
				placeholder: t.placeholder,
				onKeyDown: (event) => {
					if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
						event.preventDefault();
						void submit();
					}
				},
				className: "ui-field w-full resize-none rounded-sm border border-line px-3 py-2 text-sm text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:bg-subtle"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 227,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-fg-muted",
					children: [
						t.textOnly,
						" · ",
						value.length,
						"/2000"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 248,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: disabled || !value.trim(),
					className: "ui-button ui-button-primary min-h-11 rounded-sm bg-primary px-5 text-sm font-medium text-primary-on hover:bg-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary ",
					children: [sending && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 23
					}, this), sending ? t.sending : t.send]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 251,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 247,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 214,
		columnNumber: 5
	}, this);
}
_s2(ChatComposer, "amn6iGzR0kxIhMmeDYuIuqCuZ5M=");
_c2 = ChatComposer;
var _c, _c2;
$RefreshReg$(_c, "ChatConversation");
$RefreshReg$(_c2, "ChatComposer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/chat/ChatConversation.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConversation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConversation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConversation.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsV0FBVyxRQUFRLGdCQUFnQjtBQUU1QyxTQUFTLFlBQVksU0FBUztBQUM5QixTQUFTLGtCQUFrQjs7OztBQUUzQixPQUFPLFNBQVMsaUJBQWlCLEVBQy9CLE1BQ0EsUUFBUSxTQUlQOztDQUNELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxNQUFNLE9BQXVCLElBQUk7Q0FDdkMsTUFBTSxPQUFPLEtBQUs7Q0FDbEIsZ0JBQWdCO0VBQ2QsSUFBSSxTQUFTLGVBQWUsRUFBRSxPQUFPLFVBQVUsQ0FBQztDQUNsRCxHQUFHLENBQUMsS0FBSyxZQUFZLE1BQU0sU0FBUyxNQUFNLENBQUM7Q0FDM0MsSUFBSSxDQUFDLEtBQUssWUFDUixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1osRUFBRTtDQUNBOzs7OztDQUVULElBQUksS0FBSyxjQUNQLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLE1BQUs7RUFBUSxXQUFVO1lBQTVCLENBQ0Usd0JBQUMsS0FBRCxZQUFJLEtBQUssYUFBZ0I7Ozs7WUFDekIsd0JBQUMsVUFBRDtHQUNFLE1BQUs7R0FDTCxTQUFTLEtBQUs7R0FDZCxXQUFVO2FBRVQsRUFBRTtFQUNHOzs7O1VBQ0w7Ozs7OztDQUVULElBQUksQ0FBQyxNQUFNLE9BQU8sd0JBQUMsY0FBRDtFQUFjLE9BQU8sRUFBRTtFQUFnQixTQUFTO0NBQU87Ozs7O0NBQ3pFLE1BQU0sRUFBRSxTQUFTLGFBQWE7Q0FDOUIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsUUFBRDtJQUNFLE1BQU07SUFDTixlQUFlLGdCQUFnQixLQUFLO0lBQ3BDLE9BQU8sT0FBTztJQUNkLGFBQWEsT0FBTztJQUNwQixNQUFNLEtBQUs7Y0FFWCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixVQUFVLEtBQUs7TUFDZixlQUFlLGdCQUFnQixLQUFLO2dCQUVuQyxPQUFPO0tBQ0Y7Ozs7ZUFDUix3QkFBQyxRQUFEO01BQ0UsU0FBUTtNQUNSLE1BQU0sS0FBSztNQUNYLFNBQVMsWUFBWTtPQUNuQixNQUFNLEtBQUssTUFBTTtPQUNqQixnQkFBZ0IsS0FBSztNQUN2QjtnQkFFQyxFQUFFO0tBQ0c7Ozs7YUFDTDs7Ozs7O0dBQ0M7Ozs7O0dBQ1Isd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsUUFBUyxRQUFRLFVBQVUsWUFBWSxFQUFFLFdBQVksRUFBRTtNQUN0RDs7Ozs7TUFDSCxTQUNDLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLFFBQVEsVUFBVTtNQUNsQjs7Ozs7TUFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUNFLHdCQUFDLGFBQUQ7U0FBYSxRQUFRLFFBQVE7bUJBQzFCLFFBQVEsV0FBVyxTQUFTLEVBQUUsT0FBTyxFQUFFO1FBQzdCOzs7OztRQUNaO1FBQ0EsUUFBUTtRQUFhO1FBQVEsV0FBVyxRQUFRLFNBQVM7T0FDekQ7Ozs7OztLQUNBOzs7OztjQUNKLFNBQVMsUUFBUSxXQUFXLFVBQzNCLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxnQkFBZ0IsSUFBSTtLQUNuQyxVQUFVLEtBQUs7S0FDZixXQUFVO2VBSlosQ0FNRyxLQUFLLFdBQVcsd0JBQUMsU0FBRCxFQUFTLFdBQVUsT0FBUTs7OztlQUMzQyxLQUFLLFVBQVUsRUFBRSxVQUFVLEVBQUUsS0FDeEI7Ozs7O1lBRUo7Ozs7OztHQUNSLHdCQUFDLE9BQUQ7SUFDRSxNQUFLO0lBQ0wsY0FBWSxFQUFFO0lBQ2QsYUFBVTtJQUNWLGlCQUFjO0lBQ2QsVUFBVTtJQUNWLFdBQVU7Y0FOWjtLQVFHLFNBQVMsV0FBVyxLQUNuQix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixFQUFFO0tBQ0Y7Ozs7O0tBRUosU0FBUyxLQUFLLFlBQ2Isd0JBQUMsV0FBRDtNQUVFLFdBQVcsbURBQW1ELFFBQVEsZUFBZSxLQUFLLE9BQU8sdUNBQXVDO2dCQUYxSTtPQUlFLHdCQUFDLEtBQUQ7UUFDRSxXQUFXLDhCQUE4QixRQUFRLGVBQWUsS0FBSyxPQUFPLG9CQUFvQjtrQkFFL0YsUUFBUSxpQkFBaUIsS0FBSyxTQUMzQixFQUFFLE1BQ0YsUUFBUSxlQUFlLFVBQ3JCLEVBQUUsVUFDRixFQUFFO09BQ1A7Ozs7O09BQ0gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsUUFBUTtPQUNSOzs7OztPQUNILHdCQUFDLFFBQUQ7UUFDRSxVQUFVLFFBQVE7UUFDbEIsV0FBVyxzQkFBc0IsUUFBUSxlQUFlLEtBQUssT0FBTyxvQkFBb0I7a0JBRXZGLFdBQVcsUUFBUSxTQUFTO09BQ3pCOzs7OztNQUNDO1FBckJGLFFBQVE7Ozs7WUFxQk4sQ0FDVjtLQUNELHdCQUFDLE9BQUQsRUFBSyxLQUFLLElBQU07Ozs7O0lBQ2I7Ozs7OztHQUNKLFFBQVEsZ0JBQWdCLE1BQ3ZCLHdCQUFDLEtBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtjQUVULFFBQVEsRUFBRSxhQUFhLEVBQUU7R0FDekI7Ozs7Y0FDRCxRQUFRLFdBQVcsV0FDckIsd0JBQUMsS0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRVQsRUFBRTtHQUNGOzs7O2NBRUgsd0JBQUMsY0FBRDtJQUVFLE9BQU8sS0FBSztJQUNaLFdBQVcsVUFBVSxLQUFLLFNBQVMsUUFBUSxJQUFJLEtBQUs7SUFDcEQsVUFDRSxLQUFLLFdBQVcsS0FBSyxlQUFlLGVBQWUsQ0FBQyxDQUFDLEtBQUs7SUFFNUQsU0FBUyxLQUFLO0lBQ2QsTUFBTSxLQUFLO0dBQ1osR0FSTSxRQUFROzs7O1VBUWQ7R0FFRixLQUFLLGFBQ0osd0JBQUMsT0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRlosQ0FJRSx3QkFBQyxLQUFELFlBQUksS0FBSyxVQUFhOzs7O2NBQ3RCLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsVUFBVSxLQUFLLFdBQVcsS0FBSyxlQUFlO0tBQzlDLFNBQVMsS0FBSztLQUNkLFdBQVU7ZUFFVCxFQUFFO0lBQ0c7Ozs7WUFDTDs7Ozs7O0VBRUo7Ozs7OztBQUVUOzs7QUFDQSxTQUFTLGFBQWEsRUFDcEIsT0FDQSxVQUNBLFVBQ0EsU0FDQSxRQU9DOztDQUNELE1BQU0sV0FBVyxPQUFPLEtBQUs7Q0FDN0IsZUFBZSxTQUFTO0VBQ3RCLElBQUksWUFBWSxTQUFTLFdBQVcsQ0FBQyxNQUFNLEtBQUssR0FBRztFQUNuRCxTQUFTLFVBQVU7RUFDbkIsSUFBSTtHQUNGLElBQUksTUFBTSxLQUFLLEtBQUssR0FBRyxTQUFTLEVBQUU7RUFDcEMsVUFBVTtHQUNSLFNBQVMsVUFBVTtFQUNyQjtDQUNGO0NBQ0EsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyxVQUFVO0dBQ25CLE1BQU0sZUFBZTtHQUNyQixLQUFLLE9BQU87RUFDZDtFQUNBLFdBQVU7WUFMWjtHQU9FLHdCQUFDLFNBQUQ7SUFDRSxTQUFRO0lBQ1IsV0FBVTtjQUVULEVBQUU7R0FDRTs7Ozs7R0FDUCx3QkFBQyxZQUFEO0lBQ0UsSUFBRztJQUNILE1BQU07SUFDTixXQUFXO0lBQ0o7SUFDRztJQUNWLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO0lBQ2hELGFBQWEsRUFBRTtJQUNmLFlBQVksVUFBVTtLQUNwQixJQUNFLE1BQU0sUUFBUSxXQUNkLENBQUMsTUFBTSxZQUNQLENBQUMsTUFBTSxZQUFZLGFBQ25CO01BQ0EsTUFBTSxlQUFlO01BQ3JCLEtBQUssT0FBTztLQUNkO0lBQ0Y7SUFDQSxXQUFVO0dBQ1g7Ozs7O0dBQ0Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BQ0csRUFBRTtNQUFTO01BQUksTUFBTTtNQUFPO0tBQ3pCOzs7OztjQUNOLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsVUFBVSxZQUFZLENBQUMsTUFBTSxLQUFLO0tBQ2xDLFdBQVU7ZUFIWixDQUtHLFdBQVcsd0JBQUMsU0FBRCxFQUFTLFdBQVUsT0FBUTs7OztlQUN0QyxVQUFVLEVBQUUsVUFBVSxFQUFFLElBQ25COzs7OztZQUNMOzs7Ozs7RUFDRDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hhdENvbnZlcnNhdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgRGlhbG9nIH0gZnJvbSAnLi4vdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi91aS9TdGF0dXNCYWRnZSc7XHJcbmltcG9ydCB7IHVpVGV4dCB9IGZyb20gJy4uLy4uL3V0aWxzL3VpVGV4dCc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgdHlwZSB7IHVzZVN1cHBvcnRDaGF0IH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlU3VwcG9ydENoYXQnO1xyXG5pbXBvcnQgeyBjaGF0VGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vdXRpbHMvY2hhdFRleHQnO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vdXRpbHMvZGF0ZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ2hhdENvbnZlcnNhdGlvbih7XHJcbiAgY2hhdCxcclxuICBhZG1pbiA9IGZhbHNlLFxyXG59OiB7XHJcbiAgY2hhdDogUmV0dXJuVHlwZTx0eXBlb2YgdXNlU3VwcG9ydENoYXQ+O1xyXG4gIGFkbWluPzogYm9vbGVhbjtcclxufSkge1xyXG4gIGNvbnN0IFtjb25maXJtQ2xvc2UsIHNldENvbmZpcm1DbG9zZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgZW5kID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuICBjb25zdCB2aWV3ID0gY2hhdC5jb252ZXJzYXRpb247XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGVuZC5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJsb2NrOiAnbmVhcmVzdCcgfSk7XHJcbiAgfSwgW2NoYXQuc2VsZWN0ZWRJZCwgdmlldz8ubWVzc2FnZXMubGVuZ3RoXSk7XHJcbiAgaWYgKCFjaGF0LnNlbGVjdGVkSWQpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtODAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICB7dC5zZWxlY3R9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICBpZiAoY2hhdC5oaXN0b3J5RXJyb3IpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInAtNiB0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+XHJcbiAgICAgICAgPHA+e2NoYXQuaGlzdG9yeUVycm9yfTwvcD5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIG9uQ2xpY2s9e2NoYXQucmV0cnlIaXN0b3J5fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgbXQtMyByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBweC00IHB5LTIgdGV4dC1mZy1zZWNvbmRhcnlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0LnJldHJ5fVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgaWYgKCF2aWV3KSByZXR1cm4gPExvYWRpbmdTdGF0ZSBsYWJlbD17dC5oaXN0b3J5TG9hZGluZ30gY29tcGFjdD17dHJ1ZX0gLz47XHJcbiAgY29uc3QgeyBzZXNzaW9uLCBtZXNzYWdlcyB9ID0gdmlldztcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjaGF0LWNvbnZlcnNhdGlvblwiPlxyXG4gICAgICA8RGlhbG9nXHJcbiAgICAgICAgb3Blbj17Y29uZmlybUNsb3NlfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldENvbmZpcm1DbG9zZShmYWxzZSl9XHJcbiAgICAgICAgdGl0bGU9e3VpVGV4dC5jbG9zZUNoYXR9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3VpVGV4dC5jbG9zZUNoYXREZXNjcmlwdGlvbn1cclxuICAgICAgICBidXN5PXtjaGF0LmNsb3Npbmd9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17Y2hhdC5jbG9zaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtQ2xvc2UoZmFsc2UpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dWlUZXh0LmNhbmNlbH1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgYnVzeT17Y2hhdC5jbG9zaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2hhdC5jbG9zZSgpO1xyXG4gICAgICAgICAgICAgIHNldENvbmZpcm1DbG9zZShmYWxzZSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LmNsb3NlfVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyBib3JkZXItYiBib3JkZXItbGluZSBwLTQgc206cC01XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiYnJlYWstd29yZHMgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgIHthZG1pbiA/IChzZXNzaW9uLmN1c3RvbWVyPy51c2VybmFtZSA/PyB0LmN1c3RvbWVyKSA6IHQuc3VwcG9ydH1cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICB7YWRtaW4gJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIGJyZWFrLWFsbCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICB7c2Vzc2lvbi5jdXN0b21lcj8uZW1haWx9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICA8U3RhdHVzQmFkZ2Ugc3RhdHVzPXtzZXNzaW9uLnN0YXR1c30+XHJcbiAgICAgICAgICAgICAge3Nlc3Npb24uc3RhdHVzID09PSAnT1BFTicgPyB0Lm9wZW4gOiB0LmNsb3NlZH1cclxuICAgICAgICAgICAgPC9TdGF0dXNCYWRnZT5cclxuICAgICAgICAgICAgeycgwrcgJ31cclxuICAgICAgICAgICAge3Nlc3Npb24ubWVzc2FnZUNvdW50fS8xMDAgwrcge2Zvcm1hdERhdGUoc2Vzc2lvbi5jcmVhdGVkQXQpfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHthZG1pbiAmJiBzZXNzaW9uLnN0YXR1cyA9PT0gJ09QRU4nICYmIChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1DbG9zZSh0cnVlKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2NoYXQuY2xvc2luZ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgbWluLWgtMTEgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctc2Vjb25kYXJ5IGhvdmVyOmJnLXBhZ2UgXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2NoYXQuY2xvc2luZyAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICAgIHtjaGF0LmNsb3NpbmcgPyB0LmNsb3NpbmcgOiB0LmNsb3NlfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICByb2xlPVwibG9nXCJcclxuICAgICAgICBhcmlhLWxhYmVsPXt0LmNvbnZlcnNhdGlvbn1cclxuICAgICAgICBhcmlhLWxpdmU9XCJwb2xpdGVcIlxyXG4gICAgICAgIGFyaWEtcmVsZXZhbnQ9XCJhZGRpdGlvbnNcIlxyXG4gICAgICAgIHRhYkluZGV4PXswfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cImNoYXQtbWVzc2FnZS1sb2cgZmxleC0xIHNwYWNlLXktNCBvdmVyZmxvdy15LWF1dG8gb3ZlcnNjcm9sbC1jb250YWluIGJnLXBhZ2UgcC00IGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1wcmltYXJ5IHNtOnAtNVwiXHJcbiAgICAgID5cclxuICAgICAgICB7bWVzc2FnZXMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHt0Lm5vTWVzc2FnZXN9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7bWVzc2FnZXMubWFwKChtZXNzYWdlKSA9PiAoXHJcbiAgICAgICAgICA8YXJ0aWNsZVxyXG4gICAgICAgICAgICBrZXk9e21lc3NhZ2UuaWR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YG1heC13LVs5MCVdIHJvdW5kZWQtbWQgcHgtNCBweS0zIHNtOm1heC13LVs4MCVdICR7bWVzc2FnZS5zZW5kZXJSb2xlID09PSBjaGF0LnJvbGUgPyAnbWwtYXV0byBiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1vbicgOiAnbXItYXV0byBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSB0ZXh0LWZnJ31gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1iLTEgdGV4dC14cyBmb250LXNlbWlib2xkICR7bWVzc2FnZS5zZW5kZXJSb2xlID09PSBjaGF0LnJvbGUgPyAndGV4dC1wcmltYXJ5LW9uJyA6ICd0ZXh0LWZnLW11dGVkJ31gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge21lc3NhZ2Uuc2VuZGVyVXNlcklkID09PSBjaGF0LnVzZXJJZFxyXG4gICAgICAgICAgICAgICAgPyB0LnlvdVxyXG4gICAgICAgICAgICAgICAgOiBtZXNzYWdlLnNlbmRlclJvbGUgPT09ICdBRE1JTidcclxuICAgICAgICAgICAgICAgICAgPyB0LnN1cHBvcnRcclxuICAgICAgICAgICAgICAgICAgOiB0LmN1c3RvbWVyfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndoaXRlc3BhY2UtcHJlLXdyYXAgYnJlYWstd29yZHMgdGV4dC1zbSBsZWFkaW5nLTZcIj5cclxuICAgICAgICAgICAgICB7bWVzc2FnZS5jb250ZW50fVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDx0aW1lXHJcbiAgICAgICAgICAgICAgZGF0ZVRpbWU9e21lc3NhZ2UuY3JlYXRlZEF0fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YG10LTIgYmxvY2sgdGV4dC14cyAke21lc3NhZ2Uuc2VuZGVyUm9sZSA9PT0gY2hhdC5yb2xlID8gJ3RleHQtcHJpbWFyeS1vbicgOiAndGV4dC1mZy1tdXRlZCd9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtmb3JtYXREYXRlKG1lc3NhZ2UuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgPC90aW1lPlxyXG4gICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIDxkaXYgcmVmPXtlbmR9IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7c2Vzc2lvbi5tZXNzYWdlQ291bnQgPj0gMTAwID8gKFxyXG4gICAgICAgIDxwXHJcbiAgICAgICAgICByb2xlPVwic3RhdHVzXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci13YXJuaW5nLzI1IGJnLXdhcm5pbmctYmcgcC00IHRleHQtc20gdGV4dC13YXJuaW5nXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7YWRtaW4gPyB0LmFkbWluTGltaXQgOiB0LmxpbWl0fVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKSA6IHNlc3Npb24uc3RhdHVzID09PSAnQ0xPU0VEJyA/IChcclxuICAgICAgICA8cFxyXG4gICAgICAgICAgcm9sZT1cInN0YXR1c1wiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItbGluZSBiZy1zdWJ0bGUgcC00IHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0LmNsb3NlZE5vdGljZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPENoYXRDb21wb3NlclxyXG4gICAgICAgICAga2V5PXtzZXNzaW9uLmlkfVxyXG4gICAgICAgICAgdmFsdWU9e2NoYXQuZHJhZnR9XHJcbiAgICAgICAgICBzZXRWYWx1ZT17KHZhbHVlKSA9PiBjaGF0LnNldERyYWZ0KHNlc3Npb24uaWQsIHZhbHVlKX1cclxuICAgICAgICAgIGRpc2FibGVkPXtcclxuICAgICAgICAgICAgY2hhdC5zZW5kaW5nIHx8IGNoYXQuY29ubmVjdGlvbiAhPT0gJ2Nvbm5lY3RlZCcgfHwgISFjaGF0LnNlbmRFcnJvclxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc2VuZGluZz17Y2hhdC5zZW5kaW5nfVxyXG4gICAgICAgICAgc2VuZD17Y2hhdC5zdWJtaXR9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgICAge2NoYXQuc2VuZEVycm9yICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWRhbmdlci8yNSBiZy1kYW5nZXItYmcgcC00IHRleHQtc20gdGV4dC1kYW5nZXJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwPntjaGF0LnNlbmRFcnJvcn08L3A+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17Y2hhdC5zZW5kaW5nIHx8IGNoYXQuY29ubmVjdGlvbiAhPT0gJ2Nvbm5lY3RlZCd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2NoYXQucmV0cnlTZW5kfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHJvdW5kZWQgZm9udC1tZWRpdW0gdW5kZXJsaW5lIFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LnJldHJ5fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbmZ1bmN0aW9uIENoYXRDb21wb3Nlcih7XHJcbiAgdmFsdWUsXHJcbiAgc2V0VmFsdWUsXHJcbiAgZGlzYWJsZWQsXHJcbiAgc2VuZGluZyxcclxuICBzZW5kLFxyXG59OiB7XHJcbiAgdmFsdWU6IHN0cmluZztcclxuICBzZXRWYWx1ZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgZGlzYWJsZWQ6IGJvb2xlYW47XHJcbiAgc2VuZGluZzogYm9vbGVhbjtcclxuICBzZW5kOiAodGV4dDogc3RyaW5nKSA9PiBQcm9taXNlPGJvb2xlYW4+O1xyXG59KSB7XHJcbiAgY29uc3QgaW5GbGlnaHQgPSB1c2VSZWYoZmFsc2UpO1xyXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdCgpIHtcclxuICAgIGlmIChkaXNhYmxlZCB8fCBpbkZsaWdodC5jdXJyZW50IHx8ICF2YWx1ZS50cmltKCkpIHJldHVybjtcclxuICAgIGluRmxpZ2h0LmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGF3YWl0IHNlbmQodmFsdWUpKSBzZXRWYWx1ZSgnJyk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpbkZsaWdodC5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybVxyXG4gICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICB2b2lkIHN1Ym1pdCgpO1xyXG4gICAgICB9fVxyXG4gICAgICBjbGFzc05hbWU9XCJzdGlja3kgYm90dG9tLTAgc3BhY2UteS0yIGJvcmRlci10IGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC00IHBiLVttYXgoMXJlbSxlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSkpXVwiXHJcbiAgICA+XHJcbiAgICAgIDxsYWJlbFxyXG4gICAgICAgIGh0bWxGb3I9XCJzdXBwb3J0LW1lc3NhZ2VcIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIlxyXG4gICAgICA+XHJcbiAgICAgICAge3QubGFiZWx9XHJcbiAgICAgIDwvbGFiZWw+XHJcbiAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgIGlkPVwic3VwcG9ydC1tZXNzYWdlXCJcclxuICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgIG1heExlbmd0aD17MjAwMH1cclxuICAgICAgICB2YWx1ZT17dmFsdWV9XHJcbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFZhbHVlKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgcGxhY2Vob2xkZXI9e3QucGxhY2Vob2xkZXJ9XHJcbiAgICAgICAgb25LZXlEb3duPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgZXZlbnQua2V5ID09PSAnRW50ZXInICYmXHJcbiAgICAgICAgICAgICFldmVudC5zaGlmdEtleSAmJlxyXG4gICAgICAgICAgICAhZXZlbnQubmF0aXZlRXZlbnQuaXNDb21wb3NpbmdcclxuICAgICAgICAgICkge1xyXG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICB2b2lkIHN1Ym1pdCgpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH19XHJcbiAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgdy1mdWxsIHJlc2l6ZS1ub25lIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZmcgZm9jdXM6Ym9yZGVyLXByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjAgZGlzYWJsZWQ6Ymctc3VidGxlXCJcclxuICAgICAgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICB7dC50ZXh0T25seX0gwrcge3ZhbHVlLmxlbmd0aH0vMjAwMFxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZCB8fCAhdmFsdWUudHJpbSgpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1wcmltYXJ5IG1pbi1oLTExIHJvdW5kZWQtc20gYmctcHJpbWFyeSBweC01IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LW9uIGhvdmVyOmJnLXByaW1hcnktaG92ZXIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW9mZnNldC0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1wcmltYXJ5IFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3NlbmRpbmcgJiYgPFNwaW5uZXIgY2xhc3NOYW1lPVwibXItMlwiIC8+fVxyXG4gICAgICAgICAge3NlbmRpbmcgPyB0LnNlbmRpbmcgOiB0LnNlbmR9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn1cclxuIl19