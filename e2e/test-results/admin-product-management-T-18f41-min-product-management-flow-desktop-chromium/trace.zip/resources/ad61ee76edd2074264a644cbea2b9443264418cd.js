import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { aiText } from "/src/utils/aiText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function AiChatInput({ disabled, send }) {
	_s();
	const [value, setValue] = useState("");
	function submit() {
		if (disabled || !value.trim()) return;
		send(value);
		setValue("");
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "space-y-2 border-t border-line p-4",
		onSubmit: (event) => {
			event.preventDefault();
			submit();
		},
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "product-ai-question",
				className: "block text-sm font-medium text-fg-secondary",
				children: aiText.label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("textarea", {
				id: "product-ai-question",
				rows: 2,
				maxLength: 2e3,
				value,
				disabled,
				onChange: (event) => setValue(event.target.value),
				placeholder: aiText.placeholder,
				onKeyDown: (event) => {
					if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
						event.preventDefault();
						submit();
					}
				},
				className: "ui-field w-full resize-none rounded-sm border border-line px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:bg-subtle"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-fg-muted",
					children: [value.length, "/2000"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: disabled || !value.trim(),
					className: "ui-button ui-button-primary min-h-11 rounded-sm bg-primary px-4 text-sm font-medium text-primary-on hover:bg-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:cursor-not-allowed ",
					children: aiText.send
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_s(AiChatInput, "A2PXPeq8TepW328gUMM4+o8Xryo=");
_c = AiChatInput;
var _c;
$RefreshReg$(_c, "AiChatInput");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxjQUFjOzs7O0FBRXZCLE9BQU8sU0FBUyxZQUFZLEVBQzFCLFVBQ0EsUUFJQzs7Q0FDRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxTQUFTLFNBQVM7RUFDaEIsSUFBSSxZQUFZLENBQUMsTUFBTSxLQUFLLEdBQUc7RUFDL0IsS0FBSyxLQUFLO0VBQ1YsU0FBUyxFQUFFO0NBQ2I7Q0FDQSxPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFVO0VBQ1YsV0FBVyxVQUFVO0dBQ25CLE1BQU0sZUFBZTtHQUNyQixPQUFPO0VBQ1Q7WUFMRjtHQU9FLHdCQUFDLFNBQUQ7SUFDRSxTQUFRO0lBQ1IsV0FBVTtjQUVULE9BQU87R0FDSDs7Ozs7R0FDUCx3QkFBQyxZQUFEO0lBQ0UsSUFBRztJQUNILE1BQU07SUFDTixXQUFXO0lBQ0o7SUFDRztJQUNWLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO0lBQ2hELGFBQWEsT0FBTztJQUNwQixZQUFZLFVBQVU7S0FDcEIsSUFDRSxNQUFNLFFBQVEsV0FDZCxDQUFDLE1BQU0sWUFDUCxDQUFDLE1BQU0sWUFBWSxhQUNuQjtNQUNBLE1BQU0sZUFBZTtNQUNyQixPQUFPO0tBQ1Q7SUFDRjtJQUNBLFdBQVU7R0FDWDs7Ozs7R0FDRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FBeUMsTUFBTSxRQUFPLE9BQVc7Ozs7O2NBQ2pFLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsVUFBVSxZQUFZLENBQUMsTUFBTSxLQUFLO0tBQ2xDLFdBQVU7ZUFFVCxPQUFPO0lBQ0Y7Ozs7WUFDTDs7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFpQ2hhdElucHV0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgYWlUZXh0IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvYWlUZXh0JztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBaUNoYXRJbnB1dCh7XHJcbiAgZGlzYWJsZWQsXHJcbiAgc2VuZCxcclxufToge1xyXG4gIGRpc2FibGVkOiBib29sZWFuO1xyXG4gIHNlbmQ6ICh2YWx1ZTogc3RyaW5nKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgZnVuY3Rpb24gc3VibWl0KCkge1xyXG4gICAgaWYgKGRpc2FibGVkIHx8ICF2YWx1ZS50cmltKCkpIHJldHVybjtcclxuICAgIHNlbmQodmFsdWUpO1xyXG4gICAgc2V0VmFsdWUoJycpO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm1cclxuICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS0yIGJvcmRlci10IGJvcmRlci1saW5lIHAtNFwiXHJcbiAgICAgIG9uU3VibWl0PXsoZXZlbnQpID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIHN1Ym1pdCgpO1xyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICA8bGFiZWxcclxuICAgICAgICBodG1sRm9yPVwicHJvZHVjdC1haS1xdWVzdGlvblwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLXNlY29uZGFyeVwiXHJcbiAgICAgID5cclxuICAgICAgICB7YWlUZXh0LmxhYmVsfVxyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgICA8dGV4dGFyZWFcclxuICAgICAgICBpZD1cInByb2R1Y3QtYWktcXVlc3Rpb25cIlxyXG4gICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgbWF4TGVuZ3RoPXsyMDAwfVxyXG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XHJcbiAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VmFsdWUoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICBwbGFjZWhvbGRlcj17YWlUZXh0LnBsYWNlaG9sZGVyfVxyXG4gICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGV2ZW50LmtleSA9PT0gJ0VudGVyJyAmJlxyXG4gICAgICAgICAgICAhZXZlbnQuc2hpZnRLZXkgJiZcclxuICAgICAgICAgICAgIWV2ZW50Lm5hdGl2ZUV2ZW50LmlzQ29tcG9zaW5nXHJcbiAgICAgICAgICApIHtcclxuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgc3VibWl0KCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfX1cclxuICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCB3LWZ1bGwgcmVzaXplLW5vbmUgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgcHgtMyBweS0yIHRleHQtc20gZm9jdXM6Ym9yZGVyLXByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjAgZGlzYWJsZWQ6Ymctc3VidGxlXCJcclxuICAgICAgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj57dmFsdWUubGVuZ3RofS8yMDAwPC9zcGFuPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8ICF2YWx1ZS50cmltKCl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgbWluLWgtMTEgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtb2Zmc2V0LTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLXByaW1hcnkgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2FpVGV4dC5zZW5kfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZm9ybT5cclxuICApO1xyXG59XHJcbiJdfQ==