import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Auth/AccountAction/index.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { BrandLogo } from "/src/components/common/BrandLogo.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { accountText as t } from "/src/utils/accountText.ts";
import { useAccountAction } from "/src/pages/Auth/AccountAction/hooks/useAccountAction.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/AccountAction/index.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export default function AccountActionPage({ mode }) {
	_s();
	const location = useLocation();
	return /* @__PURE__ */ _jsxDEV(AccountActionContent, { mode }, `${mode}:${location.key}`, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 10
	}, this);
}
_s(AccountActionPage, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
	return [useLocation];
});
_c = AccountActionPage;
function AccountActionContent({ mode }) {
	_s2();
	const page = useAccountAction(mode);
	const title = mode === "verify" ? t.verifyTitle : mode === "forgot" ? t.forgotTitle : t.resetTitle;
	const description = mode === "verify" ? t.verifyDescription : mode === "forgot" ? t.forgotDescription : t.resetDescription;
	const validToken = /^[a-f0-9]{64}$/.test(page.token);
	const resetMissing = mode === "reset" && !validToken && !page.completed;
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto max-w-lg px-4 py-12 sm:py-16",
		children: [/* @__PURE__ */ _jsxDEV(Link, {
			to: ROUTES.home,
			children: /* @__PURE__ */ _jsxDEV(BrandLogo, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			className: "mt-8 rounded-lg border border-line bg-surface p-6 sm:p-8",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-3 text-sm leading-6 text-fg-secondary",
					children: description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this),
				page.message && /* @__PURE__ */ _jsxDEV("p", {
					role: "status",
					className: `ui-alert mt-6 ${page.completed ? "ui-tone-success" : "ui-tone-info"}`,
					children: page.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this),
				page.error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "ui-alert ui-tone-danger mt-6",
					children: page.error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this),
				resetMissing && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "ui-alert ui-tone-warning mt-6",
					children: t.invalid
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 11
				}, this),
				!page.completed && !resetMissing && /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: page.submit,
					className: "mt-6 space-y-5",
					"aria-busy": page.busy,
					children: [
						(mode === "forgot" || mode === "verify" && !validToken) && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "action-email",
							className: "auth-label",
							children: t.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "action-email",
							name: "email",
							type: "email",
							autoComplete: "email",
							required: true,
							maxLength: 254,
							className: "ui-field",
							value: page.email,
							onChange: (e) => page.setEmail(e.target.value),
							disabled: page.busy
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 15
						}, this),
						mode === "reset" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "new-password",
							className: "auth-label",
							children: t.newPassword
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "new-password",
							type: "password",
							autoComplete: "new-password",
							required: true,
							minLength: 8,
							maxLength: 72,
							className: "ui-field",
							value: page.password,
							onChange: (e) => page.setPassword(e.target.value),
							disabled: page.busy
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "confirm-password",
							className: "auth-label",
							children: t.confirmPassword
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							id: "confirm-password",
							type: "password",
							autoComplete: "new-password",
							required: true,
							minLength: 8,
							maxLength: 72,
							className: "ui-field",
							value: page.confirm,
							onChange: (e) => page.setConfirm(e.target.value),
							disabled: page.busy
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							type: "submit",
							busy: page.busy,
							className: "w-full",
							children: page.busy ? t.busy : mode === "verify" ? validToken ? t.verifyAction : t.resend : mode === "forgot" ? t.sendReset : t.resetAction
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-6 flex flex-wrap gap-4 text-sm font-semibold text-fg-link",
					children: [
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.login,
							children: t.signIn
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 11
						}, this),
						mode === "reset" && /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.forgotPassword,
							children: t.sendReset
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 13
						}, this),
						mode === "verify" && page.token && !page.completed && /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.verifyEmail,
							reloadDocument: true,
							children: t.resend
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this);
}
_s2(AccountActionContent, "tgBKMv8EG4Nl7KQtb19fuoLpuV4=", false, function() {
	return [useAccountAction];
});
_c2 = AccountActionContent;
var _c, _c2;
$RefreshReg$(_c, "AccountActionPage");
$RefreshReg$(_c2, "AccountActionContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Auth/AccountAction/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/AccountAction/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/AccountAction/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/AccountAction/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGNBQWM7QUFDdkIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZSxTQUFTO0FBQ2pDLFNBQ0Usd0JBRUs7Ozs7QUFFUCxlQUFlLFNBQVMsa0JBQWtCLEVBQ3hDLFFBR0M7O0NBQ0QsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsT0FBTyx3QkFBQyxzQkFBRCxFQUE0RCxLQUFPLEdBQXhDLEdBQUcsS0FBSyxHQUFHLFNBQVM7Ozs7UUFBb0I7QUFDNUU7Ozs7O0FBQ0EsU0FBUyxxQkFBcUIsRUFBRSxRQUFxQzs7Q0FDbkUsTUFBTSxPQUFPLGlCQUFpQixJQUFJO0NBQ2xDLE1BQU0sUUFDSixTQUFTLFdBQ0wsRUFBRSxjQUNGLFNBQVMsV0FDUCxFQUFFLGNBQ0YsRUFBRTtDQUNWLE1BQU0sY0FDSixTQUFTLFdBQ0wsRUFBRSxvQkFDRixTQUFTLFdBQ1AsRUFBRSxvQkFDRixFQUFFO0NBQ1YsTUFBTSxhQUFhLGlCQUFpQixLQUFLLEtBQUssS0FBSztDQUNuRCxNQUFNLGVBQWUsU0FBUyxXQUFXLENBQUMsY0FBYyxDQUFDLEtBQUs7Q0FDOUQsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQixDQUNFLHdCQUFDLE1BQUQ7R0FBTSxJQUFJLE9BQU87YUFDZix3QkFBQyxXQUFELENBQVk7Ozs7O0VBQ1I7Ozs7WUFDTix3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWlCO0lBQVU7Ozs7O0lBQ3pDLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1Y7SUFDQTs7Ozs7SUFDRixLQUFLLFdBQ0osd0JBQUMsS0FBRDtLQUNFLE1BQUs7S0FDTCxXQUFXLGlCQUFpQixLQUFLLFlBQVksb0JBQW9CO2VBRWhFLEtBQUs7SUFDTDs7Ozs7SUFFSixLQUFLLFNBQ0osd0JBQUMsS0FBRDtLQUFHLE1BQUs7S0FBUSxXQUFVO2VBQ3ZCLEtBQUs7SUFDTDs7Ozs7SUFFSixnQkFDQyx3QkFBQyxLQUFEO0tBQUcsTUFBSztLQUFRLFdBQVU7ZUFDdkIsRUFBRTtJQUNGOzs7OztJQUVKLENBQUMsS0FBSyxhQUFhLENBQUMsZ0JBQ25CLHdCQUFDLFFBQUQ7S0FDRSxVQUFVLEtBQUs7S0FDZixXQUFVO0tBQ1YsYUFBVyxLQUFLO2VBSGxCO09BS0ksU0FBUyxZQUFhLFNBQVMsWUFBWSxDQUFDLGVBQzVDLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sU0FBUTtPQUFlLFdBQVU7aUJBQ3JDLEVBQUU7TUFDRTs7OztnQkFDUCx3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILE1BQUs7T0FDTCxNQUFLO09BQ0wsY0FBYTtPQUNiO09BQ0EsV0FBVztPQUNYLFdBQVU7T0FDVixPQUFPLEtBQUs7T0FDWixXQUFXLE1BQU0sS0FBSyxTQUFTLEVBQUUsT0FBTyxLQUFLO09BQzdDLFVBQVUsS0FBSztNQUNoQjs7OztjQUNFOzs7OztNQUVOLFNBQVMsV0FDUixnREFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFNBQVE7T0FBZSxXQUFVO2lCQUNyQyxFQUFFO01BQ0U7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUNFLElBQUc7T0FDSCxNQUFLO09BQ0wsY0FBYTtPQUNiO09BQ0EsV0FBVztPQUNYLFdBQVc7T0FDWCxXQUFVO09BQ1YsT0FBTyxLQUFLO09BQ1osV0FBVyxNQUFNLEtBQUssWUFBWSxFQUFFLE9BQU8sS0FBSztPQUNoRCxVQUFVLEtBQUs7TUFDaEI7Ozs7Y0FDRTs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFNBQVE7T0FBbUIsV0FBVTtpQkFDekMsRUFBRTtNQUNFOzs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FDRSxJQUFHO09BQ0gsTUFBSztPQUNMLGNBQWE7T0FDYjtPQUNBLFdBQVc7T0FDWCxXQUFXO09BQ1gsV0FBVTtPQUNWLE9BQU8sS0FBSztPQUNaLFdBQVcsTUFBTSxLQUFLLFdBQVcsRUFBRSxPQUFPLEtBQUs7T0FDL0MsVUFBVSxLQUFLO01BQ2hCOzs7O2NBQ0U7Ozs7Y0FDTDs7Ozs7TUFFSix3QkFBQyxRQUFEO09BQVEsTUFBSztPQUFTLE1BQU0sS0FBSztPQUFNLFdBQVU7aUJBQzlDLEtBQUssT0FDRixFQUFFLE9BQ0YsU0FBUyxXQUNQLGFBQ0UsRUFBRSxlQUNGLEVBQUUsU0FDSixTQUFTLFdBQ1AsRUFBRSxZQUNGLEVBQUU7TUFDSjs7Ozs7S0FDSjs7Ozs7O0lBRVIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FBTSxJQUFJLE9BQU87aUJBQVEsRUFBRTtNQUFhOzs7OztNQUN2QyxTQUFTLFdBQ1Isd0JBQUMsTUFBRDtPQUFNLElBQUksT0FBTztpQkFBaUIsRUFBRTtNQUFnQjs7Ozs7TUFFckQsU0FBUyxZQUFZLEtBQUssU0FBUyxDQUFDLEtBQUssYUFDeEMsd0JBQUMsTUFBRDtPQUFNLElBQUksT0FBTztPQUFhO2lCQUMzQixFQUFFO01BQ0M7Ozs7O0tBRUw7Ozs7OztHQUNFOzs7OztVQUNMOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgQnJhbmRMb2dvIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vQnJhbmRMb2dvJztcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9CdXR0b24nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgYWNjb3VudFRleHQgYXMgdCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2FjY291bnRUZXh0JztcclxuaW1wb3J0IHtcclxuICB1c2VBY2NvdW50QWN0aW9uLFxyXG4gIHR5cGUgQWNjb3VudEFjdGlvbk1vZGUsXHJcbn0gZnJvbSAnLi9ob29rcy91c2VBY2NvdW50QWN0aW9uJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFjY291bnRBY3Rpb25QYWdlKHtcclxuICBtb2RlLFxyXG59OiB7XHJcbiAgbW9kZTogQWNjb3VudEFjdGlvbk1vZGU7XHJcbn0pIHtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgcmV0dXJuIDxBY2NvdW50QWN0aW9uQ29udGVudCBrZXk9e2Ake21vZGV9OiR7bG9jYXRpb24ua2V5fWB9IG1vZGU9e21vZGV9IC8+O1xyXG59XHJcbmZ1bmN0aW9uIEFjY291bnRBY3Rpb25Db250ZW50KHsgbW9kZSB9OiB7IG1vZGU6IEFjY291bnRBY3Rpb25Nb2RlIH0pIHtcclxuICBjb25zdCBwYWdlID0gdXNlQWNjb3VudEFjdGlvbihtb2RlKTtcclxuICBjb25zdCB0aXRsZSA9XHJcbiAgICBtb2RlID09PSAndmVyaWZ5J1xyXG4gICAgICA/IHQudmVyaWZ5VGl0bGVcclxuICAgICAgOiBtb2RlID09PSAnZm9yZ290J1xyXG4gICAgICAgID8gdC5mb3Jnb3RUaXRsZVxyXG4gICAgICAgIDogdC5yZXNldFRpdGxlO1xyXG4gIGNvbnN0IGRlc2NyaXB0aW9uID1cclxuICAgIG1vZGUgPT09ICd2ZXJpZnknXHJcbiAgICAgID8gdC52ZXJpZnlEZXNjcmlwdGlvblxyXG4gICAgICA6IG1vZGUgPT09ICdmb3Jnb3QnXHJcbiAgICAgICAgPyB0LmZvcmdvdERlc2NyaXB0aW9uXHJcbiAgICAgICAgOiB0LnJlc2V0RGVzY3JpcHRpb247XHJcbiAgY29uc3QgdmFsaWRUb2tlbiA9IC9eW2EtZjAtOV17NjR9JC8udGVzdChwYWdlLnRva2VuKTtcclxuICBjb25zdCByZXNldE1pc3NpbmcgPSBtb2RlID09PSAncmVzZXQnICYmICF2YWxpZFRva2VuICYmICFwYWdlLmNvbXBsZXRlZDtcclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1sZyBweC00IHB5LTEyIHNtOnB5LTE2XCI+XHJcbiAgICAgIDxMaW5rIHRvPXtST1VURVMuaG9tZX0+XHJcbiAgICAgICAgPEJyYW5kTG9nbyAvPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm10LTggcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTYgc206cC04XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGVcIj57dGl0bGV9PC9oMT5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICB7ZGVzY3JpcHRpb259XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIHtwYWdlLm1lc3NhZ2UgJiYgKFxyXG4gICAgICAgICAgPHBcclxuICAgICAgICAgICAgcm9sZT1cInN0YXR1c1wiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHVpLWFsZXJ0IG10LTYgJHtwYWdlLmNvbXBsZXRlZCA/ICd1aS10b25lLXN1Y2Nlc3MnIDogJ3VpLXRvbmUtaW5mbyd9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3BhZ2UubWVzc2FnZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtwYWdlLmVycm9yICYmIChcclxuICAgICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtZGFuZ2VyIG10LTZcIj5cclxuICAgICAgICAgICAge3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7cmVzZXRNaXNzaW5nICYmIChcclxuICAgICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtd2FybmluZyBtdC02XCI+XHJcbiAgICAgICAgICAgIHt0LmludmFsaWR9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7IXBhZ2UuY29tcGxldGVkICYmICFyZXNldE1pc3NpbmcgJiYgKFxyXG4gICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgb25TdWJtaXQ9e3BhZ2Uuc3VibWl0fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC02IHNwYWNlLXktNVwiXHJcbiAgICAgICAgICAgIGFyaWEtYnVzeT17cGFnZS5idXN5fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7KG1vZGUgPT09ICdmb3Jnb3QnIHx8IChtb2RlID09PSAndmVyaWZ5JyAmJiAhdmFsaWRUb2tlbikpICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJhY3Rpb24tZW1haWxcIiBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt0LmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cImFjdGlvbi1lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsyNTR9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhZ2UuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gcGFnZS5zZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLmJ1c3l9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7bW9kZSA9PT0gJ3Jlc2V0JyAmJiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmV3LXBhc3N3b3JkXCIgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0Lm5ld1Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm5ldy1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoPXs4fVxyXG4gICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NzJ9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYWdlLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gcGFnZS5zZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UuYnVzeX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjb25maXJtLXBhc3N3b3JkXCIgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0LmNvbmZpcm1QYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb25maXJtLXBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBtaW5MZW5ndGg9ezh9XHJcbiAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs3Mn1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhZ2UuY29uZmlybX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHBhZ2Uuc2V0Q29uZmlybShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UuYnVzeX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBidXN5PXtwYWdlLmJ1c3l9IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgIHtwYWdlLmJ1c3lcclxuICAgICAgICAgICAgICAgID8gdC5idXN5XHJcbiAgICAgICAgICAgICAgICA6IG1vZGUgPT09ICd2ZXJpZnknXHJcbiAgICAgICAgICAgICAgICAgID8gdmFsaWRUb2tlblxyXG4gICAgICAgICAgICAgICAgICAgID8gdC52ZXJpZnlBY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICA6IHQucmVzZW5kXHJcbiAgICAgICAgICAgICAgICAgIDogbW9kZSA9PT0gJ2ZvcmdvdCdcclxuICAgICAgICAgICAgICAgICAgICA/IHQuc2VuZFJlc2V0XHJcbiAgICAgICAgICAgICAgICAgICAgOiB0LnJlc2V0QWN0aW9ufVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGZsZXgtd3JhcCBnYXAtNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZy1saW5rXCI+XHJcbiAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLmxvZ2lufT57dC5zaWduSW59PC9MaW5rPlxyXG4gICAgICAgICAge21vZGUgPT09ICdyZXNldCcgJiYgKFxyXG4gICAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLmZvcmdvdFBhc3N3b3JkfT57dC5zZW5kUmVzZXR9PC9MaW5rPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIHttb2RlID09PSAndmVyaWZ5JyAmJiBwYWdlLnRva2VuICYmICFwYWdlLmNvbXBsZXRlZCAmJiAoXHJcbiAgICAgICAgICAgIDxMaW5rIHRvPXtST1VURVMudmVyaWZ5RW1haWx9IHJlbG9hZERvY3VtZW50PlxyXG4gICAgICAgICAgICAgIHt0LnJlc2VuZH1cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl19