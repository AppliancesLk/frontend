import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Repairs/index.tsx");const useEffect = __vite__cjsImport1_react["useEffect"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import { EmptyState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { useCustomerRepairsPage } from "/src/pages/Customer/Repairs/hooks/useCustomerRepairsPage.ts";
import { CustomerRepairsTable } from "/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/index.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const t = translations.repairs;
export default function RepairsPage() {
	_s();
	const { user } = useAuth();
	return user ? /* @__PURE__ */ _jsxDEV(RepairsContent, {}, user.id, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 17
	}, this) : null;
}
_s(RepairsPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = RepairsPage;
function RepairsContent() {
	_s2();
	const page = useCustomerRepairsPage();
	useEffect(() => {
		const previous = document.title;
		document.title = `${t.title} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-7xl space-y-6",
			children: [
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": translations.productDetails.breadcrumb,
					className: "text-sm",
					children: /* @__PURE__ */ _jsxDEV("ol", {
						className: "flex items-center gap-2 text-fg-muted",
						children: [
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.products,
								className: "font-medium text-fg-link hover:text-fg-link",
								children: translations.productDetails.products
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 38,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-hidden": "true",
								children: "/"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-current": "page",
								children: t.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title text-fg",
						children: t.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: t.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => void page.refresh(),
							disabled: page.loading,
							className: "auth-secondary",
							children: "Refresh"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.repairRequest,
							className: "auth-primary",
							children: t.requestTitle
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
					loading: page.loading,
					error: page.error,
					retry: page.refresh
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this),
				!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: page.repairs.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyState, {
					title: "No repair tickets found",
					description: "You haven't submitted any repair requests yet.",
					action: /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.repairRequest,
						className: "mt-4 inline-block text-sm font-medium text-fg-link hover:text-fg-link",
						children: t.requestTitle
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 19
					}, this),
					icon: "repair"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV(CustomerRepairsTable, { repairs: page.repairs }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_s2(RepairsContent, "3zQT7d4jcrtaKQ4umNI6kuOqopo=", false, function() {
	return [useCustomerRepairsPage];
});
_c2 = RepairsContent;
var _c, _c2;
$RefreshReg$(_c, "RepairsPage");
$RefreshReg$(_c2, "RepairsContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Repairs/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZTtBQUN4QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyw4QkFBOEI7QUFDdkMsU0FBUyw0QkFBNEI7Ozs7QUFFckMsTUFBTSxJQUFJLGFBQWE7QUFFdkIsZUFBZSxTQUFTLGNBQWM7O0NBQ3BDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FBTyxPQUFPLHdCQUFDLGdCQUFELENBQStCLEdBQVYsS0FBSzs7OztRQUFLLElBQUk7QUFDbkQ7Ozs7O0FBRUEsU0FBUyxpQkFBaUI7O0NBQ3hCLE1BQU0sT0FBTyx1QkFBdUI7Q0FFcEMsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLFNBQVM7RUFDMUIsU0FBUyxRQUFRLEdBQUcsRUFBRSxNQUFNLEtBQUssYUFBYSxPQUFPO0VBQ3JELGFBQWE7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUNFLGNBQVksYUFBYSxlQUFlO0tBQ3hDLFdBQVU7ZUFFVix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPO1FBQ1gsV0FBVTtrQkFFVCxhQUFhLGVBQWU7T0FDekI7Ozs7Z0JBQ0o7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLGVBQVk7a0JBQU87T0FBSzs7Ozs7T0FDNUIsd0JBQUMsTUFBRDtRQUFJLGdCQUFhO2tCQUFRLEVBQUU7T0FBVTs7Ozs7TUFDbkM7Ozs7OztJQUNEOzs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCLEVBQUU7S0FBVTs7OztlQUNuRCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBOEIsRUFBRTtLQUFlOzs7O2FBQ3pEOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsS0FBSyxLQUFLLFFBQVE7T0FDakMsVUFBVSxLQUFLO09BQ2YsV0FBVTtpQkFDWDtNQUVPOzs7O2dCQUNSLHdCQUFDLE1BQUQ7T0FBTSxJQUFJLE9BQU87T0FBZSxXQUFVO2lCQUN2QyxFQUFFO01BQ0M7Ozs7Y0FDSDs7Ozs7YUFDRjs7Ozs7O0lBRUwsd0JBQUMsaUJBQUQ7S0FDRSxTQUFTLEtBQUs7S0FDZCxPQUFPLEtBQUs7S0FDWixPQUFPLEtBQUs7SUFDYjs7Ozs7SUFFQSxDQUFDLEtBQUssV0FBVyxDQUFDLEtBQUssU0FDdEIsK0NBQ0csS0FBSyxRQUFRLFdBQVcsSUFDdkIsd0JBQUMsWUFBRDtLQUNFLE9BQU87S0FDUCxhQUFhO0tBQ2IsUUFDRSx3QkFBQyxNQUFEO01BQ0UsSUFBSSxPQUFPO01BQ1gsV0FBVTtnQkFFVCxFQUFFO0tBQ0M7Ozs7O0tBRVIsTUFBSztJQUNOOzs7O2VBRUQsd0JBQUMsc0JBQUQsRUFBc0IsU0FBUyxLQUFLLFFBQVU7Ozs7YUFFaEQ7Ozs7O0dBRUQ7Ozs7OztDQUNEOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZUN1c3RvbWVyUmVwYWlyc1BhZ2UgfSBmcm9tICcuL2hvb2tzL3VzZUN1c3RvbWVyUmVwYWlyc1BhZ2UnO1xyXG5pbXBvcnQgeyBDdXN0b21lclJlcGFpcnNUYWJsZSB9IGZyb20gJy4vY29tcG9uZW50cy9DdXN0b21lclJlcGFpcnNUYWJsZSc7XHJcblxyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLnJlcGFpcnM7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBhaXJzUGFnZSgpIHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICByZXR1cm4gdXNlciA/IDxSZXBhaXJzQ29udGVudCBrZXk9e3VzZXIuaWR9IC8+IDogbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gUmVwYWlyc0NvbnRlbnQoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZUN1c3RvbWVyUmVwYWlyc1BhZ2UoKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHByZXZpb3VzID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICBkb2N1bWVudC50aXRsZSA9IGAke3QudGl0bGV9IHwgJHt0cmFuc2xhdGlvbnMuY29tbW9uLnN0b3JlTmFtZX1gO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYmctcGFnZSBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bCBzcGFjZS15LTZcIj5cclxuICAgICAgICA8bmF2XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXt0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMuYnJlYWRjcnVtYn1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc21cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89e1JPVVRFUy5wcm9kdWN0c31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMucHJvZHVjdHN9XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICA8bGkgYXJpYS1oaWRkZW49XCJ0cnVlXCI+LzwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBhcmlhLWN1cnJlbnQ9XCJwYWdlXCI+e3QudGl0bGV9PC9saT5cclxuICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgPC9uYXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+e3QudGl0bGV9PC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwYWdlLnJlZnJlc2goKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5sb2FkaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlZnJlc2hcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxMaW5rIHRvPXtST1VURVMucmVwYWlyUmVxdWVzdH0gY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAge3QucmVxdWVzdFRpdGxlfVxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPENhdGFsb2dGZWVkYmFja1xyXG4gICAgICAgICAgbG9hZGluZz17cGFnZS5sb2FkaW5nfVxyXG4gICAgICAgICAgZXJyb3I9e3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgICByZXRyeT17cGFnZS5yZWZyZXNofVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIHshcGFnZS5sb2FkaW5nICYmICFwYWdlLmVycm9yICYmIChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIHtwYWdlLnJlcGFpcnMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgICB0aXRsZT17J05vIHJlcGFpciB0aWNrZXRzIGZvdW5kJ31cclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPXtcIllvdSBoYXZlbid0IHN1Ym1pdHRlZCBhbnkgcmVwYWlyIHJlcXVlc3RzIHlldC5cIn1cclxuICAgICAgICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgdG89e1JPVVRFUy5yZXBhaXJSZXF1ZXN0fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTQgaW5saW5lLWJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dC5yZXF1ZXN0VGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGljb249XCJyZXBhaXJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPEN1c3RvbWVyUmVwYWlyc1RhYmxlIHJlcGFpcnM9e3BhZ2UucmVwYWlyc30gLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl19