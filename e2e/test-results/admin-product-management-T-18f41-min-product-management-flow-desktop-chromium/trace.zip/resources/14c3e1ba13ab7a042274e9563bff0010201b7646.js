import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/Edit/index.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { useProductEdit } from "/src/pages/Admin/Products/Edit/hooks/useProductEdit.ts";
import { ProductEditForm } from "/src/pages/Admin/Products/Edit/components/ProductEditForm.tsx";
import { UnsavedChangesDialog } from "/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx";
import { ProductReviews } from "/src/components/reviews/ProductReviews.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.productEdit;
export default function ProductEditPage() {
	_s();
	const { id } = useParams();
	const page = useProductEdit(id);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "mx-auto max-w-4xl space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", { children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.adminProducts,
					className: "mb-4 inline-block text-sm font-medium text-fg-link hover:text-fg-link",
					children: translations.productDetails.backToProducts
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: page.editor?.product.name ?? t.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 9
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			page.status === "ready" && id && /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-5",
				children: /* @__PURE__ */ _jsxDEV(ProductReviews, { productId: id }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this),
			page.status === "loading" && /* @__PURE__ */ _jsxDEV(LoadingState, {
				label: t.loading,
				compact: false
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this),
			page.status === "not-found" && /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-8",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-semibold text-fg",
						children: t.notFound
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm text-fg-muted",
						children: t.notFoundDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.adminProducts,
						className: "auth-secondary mt-5",
						children: translations.productDetails.backToProducts
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this),
			page.status === "forbidden" && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-line bg-surface p-8",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-semibold text-fg",
						children: translations.auth.accessRestricted
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm text-fg-muted",
						children: translations.auth.accessDenied
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.products,
						className: "auth-secondary mt-5",
						children: translations.common.continueShopping
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this),
			page.status === "error" && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-danger/25 bg-danger-bg p-6",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-danger",
					children: t.loadError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: page.retry,
					className: "auth-secondary mt-4",
					children: translations.common.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this),
			page.editor && /* @__PURE__ */ _jsxDEV(ProductEditForm, { page }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 23
			}, this),
			/* @__PURE__ */ _jsxDEV(UnsavedChangesDialog, { page }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_s(ProductEditPage, "d1i0DUqQ62M638t3qPaR530tJ5w=", false, function() {
	return [useParams, useProductEdit];
});
_c = ProductEditPage;
var _c;
$RefreshReg$(_c, "ProductEditPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/Edit/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxNQUFNLGlCQUFpQjtBQUNoQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyw0QkFBNEI7QUFDckMsU0FBUyxzQkFBc0I7Ozs7QUFDL0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsZUFBZSxTQUFTLGtCQUFrQjs7Q0FDeEMsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixNQUFNLE9BQU8sZUFBZSxFQUFFO0NBQzlCLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxVQUFEO0lBQ0Usd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTztLQUNYLFdBQVU7ZUFFVCxhQUFhLGVBQWU7SUFDekI7Ozs7O0lBQ04sd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFVOzs7OztJQUNuRCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUNWLEtBQUssUUFBUSxRQUFRLFFBQVEsRUFBRTtJQUMvQjs7Ozs7R0FDRzs7Ozs7R0FDUCxLQUFLLFdBQVcsV0FBVyxNQUMxQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLGdCQUFELEVBQWdCLFdBQVcsR0FBSzs7Ozs7R0FDN0I7Ozs7O0dBRU4sS0FBSyxXQUFXLGFBQ2Ysd0JBQUMsY0FBRDtJQUFjLE9BQU8sRUFBRTtJQUFTLFNBQVM7R0FBUTs7Ozs7R0FFbEQsS0FBSyxXQUFXLGVBQ2Ysd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQyxFQUFFO0tBQWE7Ozs7O0tBQzlELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE4QixFQUFFO0tBQXVCOzs7OztLQUNwRSx3QkFBQyxNQUFEO01BQU0sSUFBSSxPQUFPO01BQWUsV0FBVTtnQkFDdkMsYUFBYSxlQUFlO0tBQ3pCOzs7OztJQUNIOzs7Ozs7R0FFTixLQUFLLFdBQVcsZUFDZix3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FGWjtLQUlFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYLGFBQWEsS0FBSztLQUNqQjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixhQUFhLEtBQUs7S0FDbEI7Ozs7O0tBQ0gsd0JBQUMsTUFBRDtNQUFNLElBQUksT0FBTztNQUFVLFdBQVU7Z0JBQ2xDLGFBQWEsT0FBTztLQUNqQjs7Ozs7SUFDSDs7Ozs7O0dBRU4sS0FBSyxXQUFXLFdBQ2Ysd0JBQUMsT0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRlosQ0FJRSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF1QixFQUFFO0lBQWE7Ozs7Y0FDbkQsd0JBQUMsVUFBRDtLQUFRLFNBQVMsS0FBSztLQUFPLFdBQVU7ZUFDcEMsYUFBYSxPQUFPO0lBQ2Y7Ozs7WUFDTDs7Ozs7O0dBRU4sS0FBSyxVQUFVLHdCQUFDLGlCQUFELEVBQXVCLEtBQU87Ozs7O0dBQzlDLHdCQUFDLHNCQUFELEVBQTRCLEtBQU87Ozs7O0VBQzVCOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IExpbmssIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgdXNlUHJvZHVjdEVkaXQgfSBmcm9tICcuL2hvb2tzL3VzZVByb2R1Y3RFZGl0JztcclxuaW1wb3J0IHsgUHJvZHVjdEVkaXRGb3JtIH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RFZGl0Rm9ybSc7XHJcbmltcG9ydCB7IFVuc2F2ZWRDaGFuZ2VzRGlhbG9nIH0gZnJvbSAnLi9jb21wb25lbnRzL1Vuc2F2ZWRDaGFuZ2VzRGlhbG9nJztcclxuaW1wb3J0IHsgUHJvZHVjdFJldmlld3MgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3Jldmlld3MvUHJvZHVjdFJldmlld3MnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLnByb2R1Y3RFZGl0O1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9kdWN0RWRpdFBhZ2UoKSB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgY29uc3QgcGFnZSA9IHVzZVByb2R1Y3RFZGl0KGlkKTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy00eGwgc3BhY2UteS02XCI+XHJcbiAgICAgIDxoZWFkZXI+XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMuYWRtaW5Qcm9kdWN0c31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTQgaW5saW5lLWJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5iYWNrVG9Qcm9kdWN0c31cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGUgdGV4dC1mZ1wiPnt0LnRpdGxlfTwvaDE+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHtwYWdlLmVkaXRvcj8ucHJvZHVjdC5uYW1lID8/IHQuZGVzY3JpcHRpb259XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAge3BhZ2Uuc3RhdHVzID09PSAncmVhZHknICYmIGlkICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01XCI+XHJcbiAgICAgICAgICA8UHJvZHVjdFJldmlld3MgcHJvZHVjdElkPXtpZH0gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAge3BhZ2Uuc3RhdHVzID09PSAnbG9hZGluZycgJiYgKFxyXG4gICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9e3QubG9hZGluZ30gY29tcGFjdD17ZmFsc2V9IC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLnN0YXR1cyA9PT0gJ25vdC1mb3VuZCcgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLThcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt0Lm5vdEZvdW5kfTwvaDI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPnt0Lm5vdEZvdW5kRGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5hZG1pblByb2R1Y3RzfSBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeSBtdC01XCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMuYmFja1RvUHJvZHVjdHN9XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLnN0YXR1cyA9PT0gJ2ZvcmJpZGRlbicgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtOFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYXV0aC5hY2Nlc3NSZXN0cmljdGVkfVxyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYXV0aC5hY2Nlc3NEZW5pZWR9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLnByb2R1Y3RzfSBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeSBtdC01XCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLmNvbnRpbnVlU2hvcHBpbmd9XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLnN0YXR1cyA9PT0gJ2Vycm9yJyAmJiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1kYW5nZXIvMjUgYmctZGFuZ2VyLWJnIHAtNlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWRhbmdlclwiPnt0LmxvYWRFcnJvcn08L3A+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3BhZ2UucmV0cnl9IGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5IG10LTRcIj5cclxuICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jb21tb24ucmV0cnl9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAge3BhZ2UuZWRpdG9yICYmIDxQcm9kdWN0RWRpdEZvcm0gcGFnZT17cGFnZX0gLz59XHJcbiAgICAgIDxVbnNhdmVkQ2hhbmdlc0RpYWxvZyBwYWdlPXtwYWdlfSAvPlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19