import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/components/MessageFields.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { promotionText as t } from "/src/utils/promotionText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/MessageFields.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const fields = [
	[
		"subject",
		t.subject,
		150
	],
	[
		"headline",
		t.headline,
		120
	],
	[
		"preheader",
		t.preheader,
		180
	],
	[
		"body",
		t.body,
		6e3
	],
	[
		"buttonText",
		t.button,
		40
	],
	[
		"buttonUrl",
		t.buttonUrl,
		1e3
	],
	[
		"footerNote",
		t.footer,
		240
	]
];
export function MessageFields({ draft, onChange }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "ui-panel p-5 sm:p-6",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-lg font-semibold",
			children: "Write your email"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "mt-5 space-y-5",
			children: fields.map(([key, label, max]) => /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `promotion-${key}`,
					className: "auth-label",
					children: label
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 13
				}, this),
				key === "body" || key === "footerNote" ? /* @__PURE__ */ _jsxDEV("textarea", {
					id: `promotion-${key}`,
					rows: key === "body" ? 9 : 3,
					className: `ui-field py-3 ${key === "body" ? "min-h-64" : "min-h-24"}`,
					maxLength: max,
					value: draft[key],
					onChange: (e) => onChange({
						...draft,
						[key]: e.target.value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV("input", {
					id: `promotion-${key}`,
					type: key === "buttonUrl" ? "url" : "text",
					className: "ui-field",
					maxLength: max,
					value: draft[key],
					onChange: (e) => onChange({
						...draft,
						[key]: e.target.value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 15
				}, this),
				key === "body" && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs leading-5 text-fg-muted",
					children: t.bodyHint
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 15
				}, this),
				key === "buttonUrl" && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs text-fg-muted",
					children: t.buttonHint
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-right text-xs text-fg-muted",
					children: [
						draft[key].length,
						" / ",
						max
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 13
				}, this)
			] }, key, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_c = MessageFields;
var _c;
$RefreshReg$(_c, "MessageFields");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/components/MessageFields.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/MessageFields.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/MessageFields.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/MessageFields.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxpQkFBaUIsU0FBUzs7O0FBQ25DLE1BQU0sU0FBUztDQUNiO0VBQUM7RUFBVyxFQUFFO0VBQVM7Q0FBRztDQUMxQjtFQUFDO0VBQVksRUFBRTtFQUFVO0NBQUc7Q0FDNUI7RUFBQztFQUFhLEVBQUU7RUFBVztDQUFHO0NBQzlCO0VBQUM7RUFBUSxFQUFFO0VBQU07Q0FBSTtDQUNyQjtFQUFDO0VBQWMsRUFBRTtFQUFRO0NBQUU7Q0FDM0I7RUFBQztFQUFhLEVBQUU7RUFBVztDQUFJO0NBQy9CO0VBQUM7RUFBYyxFQUFFO0VBQVE7Q0FBRztBQUM5QjtBQUNBLE9BQU8sU0FBUyxjQUFjLEVBQzVCLE9BQ0EsWUFJQztDQUNELE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkIsQ0FDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUF3QjtFQUFvQjs7OztZQUMxRCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLE9BQU8sS0FBSyxDQUFDLEtBQUssT0FBTyxTQUN4Qix3QkFBQyxPQUFEO0lBQ0Usd0JBQUMsU0FBRDtLQUFPLFNBQVMsYUFBYTtLQUFPLFdBQVU7ZUFDM0M7SUFDSTs7Ozs7SUFDTixRQUFRLFVBQVUsUUFBUSxlQUN6Qix3QkFBQyxZQUFEO0tBQ0UsSUFBSSxhQUFhO0tBQ2pCLE1BQU0sUUFBUSxTQUFTLElBQUk7S0FDM0IsV0FBVyxpQkFBaUIsUUFBUSxTQUFTLGFBQWE7S0FDMUQsV0FBVztLQUNYLE9BQU8sTUFBTTtLQUNiLFdBQVcsTUFBTSxTQUFTO01BQUUsR0FBRztPQUFRLE1BQU0sRUFBRSxPQUFPO0tBQU0sQ0FBQztJQUM5RDs7OztlQUVELHdCQUFDLFNBQUQ7S0FDRSxJQUFJLGFBQWE7S0FDakIsTUFBTSxRQUFRLGNBQWMsUUFBUTtLQUNwQyxXQUFVO0tBQ1YsV0FBVztLQUNYLE9BQU8sTUFBTTtLQUNiLFdBQVcsTUFBTSxTQUFTO01BQUUsR0FBRztPQUFRLE1BQU0sRUFBRSxPQUFPO0tBQU0sQ0FBQztJQUM5RDs7Ozs7SUFFRixRQUFRLFVBQ1Asd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixFQUFFO0lBQ0Y7Ozs7O0lBRUosUUFBUSxlQUNQLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCLEVBQUU7SUFBYzs7Ozs7SUFFN0Qsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYjtNQUNHLE1BQU0sSUFBSSxDQUFDO01BQU87TUFBSTtLQUN0Qjs7Ozs7O0dBQ0EsS0FsQ0s7Ozs7VUFrQ0wsQ0FDTjtFQUNFOzs7O1VBQ0U7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1lc3NhZ2VGaWVsZHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUHJvbW90aW9uQ29udGVudCB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3Byb21vdGlvbi50eXBlcyc7XHJcbmltcG9ydCB7IHByb21vdGlvblRleHQgYXMgdCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3Byb21vdGlvblRleHQnO1xyXG5jb25zdCBmaWVsZHMgPSBbXHJcbiAgWydzdWJqZWN0JywgdC5zdWJqZWN0LCAxNTBdLFxyXG4gIFsnaGVhZGxpbmUnLCB0LmhlYWRsaW5lLCAxMjBdLFxyXG4gIFsncHJlaGVhZGVyJywgdC5wcmVoZWFkZXIsIDE4MF0sXHJcbiAgWydib2R5JywgdC5ib2R5LCA2MDAwXSxcclxuICBbJ2J1dHRvblRleHQnLCB0LmJ1dHRvbiwgNDBdLFxyXG4gIFsnYnV0dG9uVXJsJywgdC5idXR0b25VcmwsIDEwMDBdLFxyXG4gIFsnZm9vdGVyTm90ZScsIHQuZm9vdGVyLCAyNDBdLFxyXG5dIGFzIGNvbnN0O1xyXG5leHBvcnQgZnVuY3Rpb24gTWVzc2FnZUZpZWxkcyh7XHJcbiAgZHJhZnQsXHJcbiAgb25DaGFuZ2UsXHJcbn06IHtcclxuICBkcmFmdDogUHJvbW90aW9uQ29udGVudDtcclxuICBvbkNoYW5nZTogKHZhbHVlOiBQcm9tb3Rpb25Db250ZW50KSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInVpLXBhbmVsIHAtNSBzbTpwLTZcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPldyaXRlIHlvdXIgZW1haWw8L2gyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgc3BhY2UteS01XCI+XHJcbiAgICAgICAge2ZpZWxkcy5tYXAoKFtrZXksIGxhYmVsLCBtYXhdKSA9PiAoXHJcbiAgICAgICAgICA8ZGl2IGtleT17a2V5fT5cclxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2Bwcm9tb3Rpb24tJHtrZXl9YH0gY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAge2tleSA9PT0gJ2JvZHknIHx8IGtleSA9PT0gJ2Zvb3Rlck5vdGUnID8gKFxyXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgaWQ9e2Bwcm9tb3Rpb24tJHtrZXl9YH1cclxuICAgICAgICAgICAgICAgIHJvd3M9e2tleSA9PT0gJ2JvZHknID8gOSA6IDN9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B1aS1maWVsZCBweS0zICR7a2V5ID09PSAnYm9keScgPyAnbWluLWgtNjQnIDogJ21pbi1oLTI0J31gfVxyXG4gICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXttYXh9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZHJhZnRba2V5XX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoeyAuLi5kcmFmdCwgW2tleV06IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD17YHByb21vdGlvbi0ke2tleX1gfVxyXG4gICAgICAgICAgICAgICAgdHlwZT17a2V5ID09PSAnYnV0dG9uVXJsJyA/ICd1cmwnIDogJ3RleHQnfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXttYXh9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZHJhZnRba2V5XX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoeyAuLi5kcmFmdCwgW2tleV06IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtrZXkgPT09ICdib2R5JyAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICB7dC5ib2R5SGludH1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtrZXkgPT09ICdidXR0b25VcmwnICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPnt0LmJ1dHRvbkhpbnR9PC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtcmlnaHQgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAge2RyYWZ0W2tleV0ubGVuZ3RofSAvIHttYXh9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==