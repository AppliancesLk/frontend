import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Checkout/components/PreparedCheckout.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PreparedCheckout.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.checkout;
export function PreparedCheckout({ summary }) {
	const delivery = summary.delivery;
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "prepared-delivery",
		className: "rounded-md border border-line bg-surface p-5  sm:p-6",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			id: "prepared-delivery",
			className: "text-lg font-semibold text-fg",
			children: t.confirmedDelivery
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("address", {
			className: "mt-4 space-y-1 break-words text-sm not-italic leading-6 text-fg-secondary",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "font-medium text-fg",
					children: [
						delivery.firstName,
						" ",
						delivery.lastName
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: delivery.addressLine1 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this),
				delivery.addressLine2 && /* @__PURE__ */ _jsxDEV("p", { children: delivery.addressLine2 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 35
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: [
					delivery.city,
					", ",
					delivery.postalCode,
					", ",
					delivery.countryCode
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "break-all",
					children: delivery.email
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: delivery.phone }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = PreparedCheckout;
var _c;
$RefreshReg$(_c, "PreparedCheckout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Checkout/components/PreparedCheckout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PreparedCheckout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PreparedCheckout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PreparedCheckout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsaUJBQWlCLEVBQUUsV0FBeUM7Q0FDMUUsTUFBTSxXQUFXLFFBQVE7Q0FDekIsT0FDRSx3QkFBQyxXQUFEO0VBQ0UsbUJBQWdCO0VBQ2hCLFdBQVU7WUFGWixDQUlFLHdCQUFDLE1BQUQ7R0FBSSxJQUFHO0dBQW9CLFdBQVU7YUFDbEMsRUFBRTtFQUNEOzs7O1lBQ0osd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkI7SUFDRSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQ0csU0FBUztNQUFVO01BQUUsU0FBUztLQUM5Qjs7Ozs7O0lBQ0gsd0JBQUMsS0FBRCxZQUFJLFNBQVMsYUFBZ0I7Ozs7O0lBQzVCLFNBQVMsZ0JBQWdCLHdCQUFDLEtBQUQsWUFBSSxTQUFTLGFBQWdCOzs7OztJQUN2RCx3QkFBQyxLQUFEO0tBQ0csU0FBUztLQUFLO0tBQUcsU0FBUztLQUFXO0tBQUcsU0FBUztJQUNqRDs7Ozs7SUFDSCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFhLFNBQVM7SUFBUzs7Ozs7SUFDNUMsd0JBQUMsS0FBRCxZQUFJLFNBQVMsTUFBUzs7Ozs7R0FDZjs7Ozs7VUFDRjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJlcGFyZWRDaGVja291dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDaGVja291dFN1bW1hcnkgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9jaGVja291dC50eXBlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuY2hlY2tvdXQ7XHJcbmV4cG9ydCBmdW5jdGlvbiBQcmVwYXJlZENoZWNrb3V0KHsgc3VtbWFyeSB9OiB7IHN1bW1hcnk6IENoZWNrb3V0U3VtbWFyeSB9KSB7XHJcbiAgY29uc3QgZGVsaXZlcnkgPSBzdW1tYXJ5LmRlbGl2ZXJ5O1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvblxyXG4gICAgICBhcmlhLWxhYmVsbGVkYnk9XCJwcmVwYXJlZC1kZWxpdmVyeVwiXHJcbiAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01ICBzbTpwLTZcIlxyXG4gICAgPlxyXG4gICAgICA8aDIgaWQ9XCJwcmVwYXJlZC1kZWxpdmVyeVwiIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAge3QuY29uZmlybWVkRGVsaXZlcnl9XHJcbiAgICAgIDwvaDI+XHJcbiAgICAgIDxhZGRyZXNzIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0xIGJyZWFrLXdvcmRzIHRleHQtc20gbm90LWl0YWxpYyBsZWFkaW5nLTYgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICB7ZGVsaXZlcnkuZmlyc3ROYW1lfSB7ZGVsaXZlcnkubGFzdE5hbWV9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxwPntkZWxpdmVyeS5hZGRyZXNzTGluZTF9PC9wPlxyXG4gICAgICAgIHtkZWxpdmVyeS5hZGRyZXNzTGluZTIgJiYgPHA+e2RlbGl2ZXJ5LmFkZHJlc3NMaW5lMn08L3A+fVxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAge2RlbGl2ZXJ5LmNpdHl9LCB7ZGVsaXZlcnkucG9zdGFsQ29kZX0sIHtkZWxpdmVyeS5jb3VudHJ5Q29kZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYnJlYWstYWxsXCI+e2RlbGl2ZXJ5LmVtYWlsfTwvcD5cclxuICAgICAgICA8cD57ZGVsaXZlcnkucGhvbmV9PC9wPlxyXG4gICAgICA8L2FkZHJlc3M+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=