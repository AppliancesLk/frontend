import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/chat/ChatPane.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useSyncExternalStore = __vite__cjsImport0_react["useSyncExternalStore"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Icon } from "/src/components/common/Icon.tsx";
import { ChatConnection } from "/src/components/chat/ChatConnection.tsx";
import { uiText } from "/src/utils/uiText.ts";
import { chatText } from "/src/utils/chatText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatPane.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
function subscribe(listener) {
	const media = window.matchMedia("(max-width: 1023px)");
	media.addEventListener("change", listener);
	return () => media.removeEventListener("change", listener);
}
function isMobile() {
	return window.matchMedia("(max-width: 1023px)").matches;
}
export function ChatPane({ chat, back, children }) {
	_s();
	const mobile = useSyncExternalStore(subscribe, isMobile, () => false);
	const dialog = useRef(null);
	const selected = chat.selectedId !== null;
	useEffect(() => {
		const element = dialog.current;
		if (!mobile || !selected || !element) return;
		const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		const overflow = document.body.style.overflow;
		element.showModal();
		document.body.style.overflow = "hidden";
		const viewport = window.visualViewport;
		const resize = () => {
			element.style.height = `${viewport?.height ?? window.innerHeight}px`;
			element.style.top = `${viewport?.offsetTop ?? 0}px`;
		};
		resize();
		viewport?.addEventListener("resize", resize);
		viewport?.addEventListener("scroll", resize);
		return () => {
			viewport?.removeEventListener("resize", resize);
			viewport?.removeEventListener("scroll", resize);
			element.close();
			document.body.style.overflow = overflow;
			previous?.focus();
		};
	}, [mobile, selected]);
	if (!mobile) return /* @__PURE__ */ _jsxDEV("section", {
		className: "min-w-0 overflow-hidden rounded-md border border-line bg-surface ",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 7
	}, this);
	if (!selected) return null;
	return /* @__PURE__ */ _jsxDEV("dialog", {
		ref: dialog,
		"aria-label": chatText.conversation,
		onCancel: (event) => {
			event.preventDefault();
			back();
		},
		className: "fixed inset-0 m-0 h-dvh max-h-dvh w-screen max-w-none overflow-hidden border-0 bg-surface p-0 text-fg backdrop:bg-inverse/40",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-full min-h-0 flex-col",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "flex shrink-0 items-center justify-between gap-2 border-b border-line px-3 py-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: back,
					className: "ui-button ui-button-ghost shrink-0",
					children: [/* @__PURE__ */ _jsxDEV(Icon, {
						name: "arrow",
						className: "h-4 w-4 rotate-180"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this), uiText.sessions]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0",
					children: /* @__PURE__ */ _jsxDEV(ChatConnection, {
						state: chat.connection,
						reconnect: chat.reconnect
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "min-h-0 flex-1",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 5
	}, this);
}
_s(ChatPane, "tq25wEHOKc5Y7JTxQ8SgLZQ6oMI=");
_c = ChatPane;
var _c;
$RefreshReg$(_c, "ChatPane");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/chat/ChatPane.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatPane.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatPane.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatPane.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsNEJBQTRDO0FBQ3hFLFNBQVMsWUFBWTtBQUNyQixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGNBQWM7QUFDdkIsU0FBUyxnQkFBZ0I7Ozs7QUFHekIsU0FBUyxVQUFVLFVBQXNCO0NBQ3ZDLE1BQU0sUUFBUSxPQUFPLFdBQVcscUJBQXFCO0NBQ3JELE1BQU0saUJBQWlCLFVBQVUsUUFBUTtDQUN6QyxhQUFhLE1BQU0sb0JBQW9CLFVBQVUsUUFBUTtBQUMzRDtBQUNBLFNBQVMsV0FBVztDQUNsQixPQUFPLE9BQU8sV0FBVyxxQkFBcUIsQ0FBQyxDQUFDO0FBQ2xEO0FBRUEsT0FBTyxTQUFTLFNBQVMsRUFDdkIsTUFDQSxNQUNBLFlBS0M7O0NBQ0QsTUFBTSxTQUFTLHFCQUFxQixXQUFXLGdCQUFnQixLQUFLO0NBQ3BFLE1BQU0sU0FBUyxPQUEwQixJQUFJO0NBQzdDLE1BQU0sV0FBVyxLQUFLLGVBQWU7Q0FDckMsZ0JBQWdCO0VBQ2QsTUFBTSxVQUFVLE9BQU87RUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsU0FBUztFQUN0QyxNQUFNLFdBQ0osU0FBUyx5QkFBeUIsY0FDOUIsU0FBUyxnQkFDVDtFQUNOLE1BQU0sV0FBVyxTQUFTLEtBQUssTUFBTTtFQUNyQyxRQUFRLFVBQVU7RUFDbEIsU0FBUyxLQUFLLE1BQU0sV0FBVztFQUMvQixNQUFNLFdBQVcsT0FBTztFQUN4QixNQUFNLGVBQWU7R0FDbkIsUUFBUSxNQUFNLFNBQVMsR0FBRyxVQUFVLFVBQVUsT0FBTyxZQUFZO0dBQ2pFLFFBQVEsTUFBTSxNQUFNLEdBQUcsVUFBVSxhQUFhLEVBQUU7RUFDbEQ7RUFDQSxPQUFPO0VBQ1AsVUFBVSxpQkFBaUIsVUFBVSxNQUFNO0VBQzNDLFVBQVUsaUJBQWlCLFVBQVUsTUFBTTtFQUMzQyxhQUFhO0dBQ1gsVUFBVSxvQkFBb0IsVUFBVSxNQUFNO0dBQzlDLFVBQVUsb0JBQW9CLFVBQVUsTUFBTTtHQUM5QyxRQUFRLE1BQU07R0FDZCxTQUFTLEtBQUssTUFBTSxXQUFXO0dBQy9CLFVBQVUsTUFBTTtFQUNsQjtDQUNGLEdBQUcsQ0FBQyxRQUFRLFFBQVEsQ0FBQztDQUNyQixJQUFJLENBQUMsUUFDSCxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQ2hCO0NBQ007Ozs7O0NBRWIsSUFBSSxDQUFDLFVBQVUsT0FBTztDQUN0QixPQUNFLHdCQUFDLFVBQUQ7RUFDRSxLQUFLO0VBQ0wsY0FBWSxTQUFTO0VBQ3JCLFdBQVcsVUFBVTtHQUNuQixNQUFNLGVBQWU7R0FDckIsS0FBSztFQUNQO0VBQ0EsV0FBVTtZQUVWLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUztLQUNULFdBQVU7ZUFIWixDQUtFLHdCQUFDLE1BQUQ7TUFBTSxNQUFLO01BQVEsV0FBVTtLQUFzQjs7OztlQUNsRCxPQUFPLFFBQ0Y7Ozs7O2NBQ1Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxnQkFBRDtNQUNFLE9BQU8sS0FBSztNQUNaLFdBQVcsS0FBSztLQUNqQjs7Ozs7SUFDRTs7OztZQUNDOzs7OzthQUNSLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWtCO0dBQWM7Ozs7V0FDNUM7Ozs7OztDQUNDOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoYXRQYW5lLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3luY0V4dGVybmFsU3RvcmUsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBDaGF0Q29ubmVjdGlvbiB9IGZyb20gJy4vQ2hhdENvbm5lY3Rpb24nO1xyXG5pbXBvcnQgeyB1aVRleHQgfSBmcm9tICcuLi8uLi91dGlscy91aVRleHQnO1xyXG5pbXBvcnQgeyBjaGF0VGV4dCB9IGZyb20gJy4uLy4uL3V0aWxzL2NoYXRUZXh0JztcclxuaW1wb3J0IHR5cGUgeyB1c2VTdXBwb3J0Q2hhdCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZVN1cHBvcnRDaGF0JztcclxuXHJcbmZ1bmN0aW9uIHN1YnNjcmliZShsaXN0ZW5lcjogKCkgPT4gdm9pZCkge1xyXG4gIGNvbnN0IG1lZGlhID0gd2luZG93Lm1hdGNoTWVkaWEoJyhtYXgtd2lkdGg6IDEwMjNweCknKTtcclxuICBtZWRpYS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBsaXN0ZW5lcik7XHJcbiAgcmV0dXJuICgpID0+IG1lZGlhLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGxpc3RlbmVyKTtcclxufVxyXG5mdW5jdGlvbiBpc01vYmlsZSgpIHtcclxuICByZXR1cm4gd2luZG93Lm1hdGNoTWVkaWEoJyhtYXgtd2lkdGg6IDEwMjNweCknKS5tYXRjaGVzO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ2hhdFBhbmUoe1xyXG4gIGNoYXQsXHJcbiAgYmFjayxcclxuICBjaGlsZHJlbixcclxufToge1xyXG4gIGNoYXQ6IFJldHVyblR5cGU8dHlwZW9mIHVzZVN1cHBvcnRDaGF0PjtcclxuICBiYWNrOiAoKSA9PiB2b2lkO1xyXG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XHJcbn0pIHtcclxuICBjb25zdCBtb2JpbGUgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGlzTW9iaWxlLCAoKSA9PiBmYWxzZSk7XHJcbiAgY29uc3QgZGlhbG9nID0gdXNlUmVmPEhUTUxEaWFsb2dFbGVtZW50PihudWxsKTtcclxuICBjb25zdCBzZWxlY3RlZCA9IGNoYXQuc2VsZWN0ZWRJZCAhPT0gbnVsbDtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZWxlbWVudCA9IGRpYWxvZy5jdXJyZW50O1xyXG4gICAgaWYgKCFtb2JpbGUgfHwgIXNlbGVjdGVkIHx8ICFlbGVtZW50KSByZXR1cm47XHJcbiAgICBjb25zdCBwcmV2aW91cyA9XHJcbiAgICAgIGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudFxyXG4gICAgICAgID8gZG9jdW1lbnQuYWN0aXZlRWxlbWVudFxyXG4gICAgICAgIDogbnVsbDtcclxuICAgIGNvbnN0IG92ZXJmbG93ID0gZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdztcclxuICAgIGVsZW1lbnQuc2hvd01vZGFsKCk7XHJcbiAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gJ2hpZGRlbic7XHJcbiAgICBjb25zdCB2aWV3cG9ydCA9IHdpbmRvdy52aXN1YWxWaWV3cG9ydDtcclxuICAgIGNvbnN0IHJlc2l6ZSA9ICgpID0+IHtcclxuICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSBgJHt2aWV3cG9ydD8uaGVpZ2h0ID8/IHdpbmRvdy5pbm5lckhlaWdodH1weGA7XHJcbiAgICAgIGVsZW1lbnQuc3R5bGUudG9wID0gYCR7dmlld3BvcnQ/Lm9mZnNldFRvcCA/PyAwfXB4YDtcclxuICAgIH07XHJcbiAgICByZXNpemUoKTtcclxuICAgIHZpZXdwb3J0Py5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCByZXNpemUpO1xyXG4gICAgdmlld3BvcnQ/LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIHJlc2l6ZSk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICB2aWV3cG9ydD8ucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVzaXplKTtcclxuICAgICAgdmlld3BvcnQ/LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIHJlc2l6ZSk7XHJcbiAgICAgIGVsZW1lbnQuY2xvc2UoKTtcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IG92ZXJmbG93O1xyXG4gICAgICBwcmV2aW91cz8uZm9jdXMoKTtcclxuICAgIH07XHJcbiAgfSwgW21vYmlsZSwgc2VsZWN0ZWRdKTtcclxuICBpZiAoIW1vYmlsZSlcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm1pbi13LTAgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgXCI+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG4gIGlmICghc2VsZWN0ZWQpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGlhbG9nXHJcbiAgICAgIHJlZj17ZGlhbG9nfVxyXG4gICAgICBhcmlhLWxhYmVsPXtjaGF0VGV4dC5jb252ZXJzYXRpb259XHJcbiAgICAgIG9uQ2FuY2VsPXsoZXZlbnQpID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGJhY2soKTtcclxuICAgICAgfX1cclxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBtLTAgaC1kdmggbWF4LWgtZHZoIHctc2NyZWVuIG1heC13LW5vbmUgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci0wIGJnLXN1cmZhY2UgcC0wIHRleHQtZmcgYmFja2Ryb3A6YmctaW52ZXJzZS80MFwiXHJcbiAgICA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgbWluLWgtMCBmbGV4LWNvbFwiPlxyXG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1saW5lIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17YmFja31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1naG9zdCBzaHJpbmstMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzTmFtZT1cImgtNCB3LTQgcm90YXRlLTE4MFwiIC8+XHJcbiAgICAgICAgICAgIHt1aVRleHQuc2Vzc2lvbnN9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICA8Q2hhdENvbm5lY3Rpb25cclxuICAgICAgICAgICAgICBzdGF0ZT17Y2hhdC5jb25uZWN0aW9ufVxyXG4gICAgICAgICAgICAgIHJlY29ubmVjdD17Y2hhdC5yZWNvbm5lY3R9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2hlYWRlcj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLTAgZmxleC0xXCI+e2NoaWxkcmVufTwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGlhbG9nPlxyXG4gICk7XHJcbn1cclxuIl19