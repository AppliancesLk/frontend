import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/SiteFooter.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { useAuth } from "/src/hooks/useAuth.ts";
import { BrandLogo } from "/src/components/common/BrandLogo.tsx";
import { ThemeToggle } from "/src/components/common/ThemeToggle.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteFooter.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const trust = [
	{
		icon: "truck",
		title: "Islandwide delivery",
		description: "From our store to your door."
	},
	{
		icon: "shield",
		title: "Shop with confidence",
		description: "Clear prices. Clear availability."
	},
	{
		icon: "repair",
		title: "Care beyond the purchase",
		description: "Request and track device repairs."
	},
	{
		icon: "chat",
		title: "A little help, anytime",
		description: "Leave a message for our team."
	}
];
export function SiteFooter() {
	_s();
	const { user } = useAuth();
	const { pathname } = useLocation();
	const customer = !user || user.role === "CUSTOMER";
	const checkout = pathname === ROUTES.checkout;
	const repairRoute = user?.role === "ADMIN" ? ROUTES.adminRepairs : user?.role === "REPAIRER" ? ROUTES.repairerRepairs : ROUTES.repairRequest;
	const supportRoute = user?.role === "ADMIN" ? ROUTES.adminChat : user?.role === "REPAIRER" ? ROUTES.repairerRepairs : ROUTES.liveChat;
	const groups = [
		{
			title: "Shop",
			links: [[ROUTES.products, "All products"], [ROUTES.home, "Discover Appliances.lk"]]
		},
		{
			title: "Repairs",
			links: [[repairRoute, customer ? "Request a repair" : "Manage repairs"], [customer ? ROUTES.repairs : repairRoute, "Repair status"]]
		},
		{
			title: "Account",
			links: [
				[ROUTES.account, "Your account"],
				[customer ? ROUTES.orders : user?.role === "ADMIN" ? ROUTES.admin : ROUTES.repairer, customer ? "Your orders" : "Your workspace"],
				...!user ? [[ROUTES.login, "Sign in"], [ROUTES.register, "Create account"]] : []
			]
		}
	];
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "site-footer",
		children: [!checkout && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "footer-trust shell-wide",
			children: trust.map((item) => /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Icon, {
					name: item.icon,
					className: "h-6 w-6 shrink-0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "font-semibold",
					children: item.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 19
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs leading-5",
					children: item.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 19
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 17
				}, this)]
			}, item.title, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 15
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "footer-columns shell-wide",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "footer-brand",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.home,
						"aria-label": "Appliances.lk home",
						children: /* @__PURE__ */ _jsxDEV(BrandLogo, { inverse: true }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-5 max-w-xs text-sm leading-7",
						children: "Good technology for everyday life. Appliances, electronics and a helping hand when you need it."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 13
				}, this),
				groups.map((group) => /* @__PURE__ */ _jsxDEV("details", {
					className: "footer-link-group",
					open: true,
					children: [/* @__PURE__ */ _jsxDEV("summary", { children: [group.title, /* @__PURE__ */ _jsxDEV("span", {
						className: "md:hidden",
						children: "+"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 19
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("ul", { children: group.links.map(([path, label]) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
						to: path,
						children: label
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 23
					}, this) }, `${path}-${label}`, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 21
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 17
					}, this)]
				}, group.title, true, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 15
				}, this)),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "footer-contact",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Let’s talk" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-3 text-sm leading-7",
							children: "Need a hand choosing, ordering or repairing a device?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: supportRoute,
							className: "mt-4 inline-flex min-h-11 items-center gap-2 text-sm font-semibold",
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "chat" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 17
							}, this), "Chat with us"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "footer-bottom shell-wide",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs",
				children: [
					"© ",
					new Date().getFullYear(),
					" Appliances.lk. All rights reserved."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs",
					children: "Make yourself at home"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(ThemeToggle, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 138,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 5
	}, this);
}
_s(SiteFooter, "F7uhSZBpwD4hq3eWLR50aiTNbD4=", false, function() {
	return [useAuth, useLocation];
});
_c = SiteFooter;
var _c;
$RefreshReg$(_c, "SiteFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/SiteFooter.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteFooter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteFooter.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/SiteFooter.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsWUFBMkI7Ozs7QUFDcEMsTUFBTSxRQUFrRTtDQUN0RTtFQUNFLE1BQU07RUFDTixPQUFPO0VBQ1AsYUFBYTtDQUNmO0NBQ0E7RUFDRSxNQUFNO0VBQ04sT0FBTztFQUNQLGFBQWE7Q0FDZjtDQUNBO0VBQ0UsTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0NBQ2Y7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPO0VBQ1AsYUFBYTtDQUNmO0FBQ0Y7QUFDQSxPQUFPLFNBQVMsYUFBYTs7Q0FDM0IsTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUN6QixNQUFNLEVBQUUsYUFBYSxZQUFZO0NBQ2pDLE1BQU0sV0FBVyxDQUFDLFFBQVEsS0FBSyxTQUFTO0NBQ3hDLE1BQU0sV0FBVyxhQUFhLE9BQU87Q0FDckMsTUFBTSxjQUNKLE1BQU0sU0FBUyxVQUNYLE9BQU8sZUFDUCxNQUFNLFNBQVMsYUFDYixPQUFPLGtCQUNQLE9BQU87Q0FDZixNQUFNLGVBQ0osTUFBTSxTQUFTLFVBQ1gsT0FBTyxZQUNQLE1BQU0sU0FBUyxhQUNiLE9BQU8sa0JBQ1AsT0FBTztDQUNmLE1BQU0sU0FBUztFQUNiO0dBQ0UsT0FBTztHQUNQLE9BQU8sQ0FDTCxDQUFDLE9BQU8sVUFBVSxjQUFjLEdBQ2hDLENBQUMsT0FBTyxNQUFNLHdCQUF3QixDQUN4QztFQUNGO0VBQ0E7R0FDRSxPQUFPO0dBQ1AsT0FBTyxDQUNMLENBQUMsYUFBYSxXQUFXLHFCQUFxQixnQkFBZ0IsR0FDOUQsQ0FBQyxXQUFXLE9BQU8sVUFBVSxhQUFhLGVBQWUsQ0FDM0Q7RUFDRjtFQUNBO0dBQ0UsT0FBTztHQUNQLE9BQU87SUFDTCxDQUFDLE9BQU8sU0FBUyxjQUFjO0lBQy9CLENBQ0UsV0FDSSxPQUFPLFNBQ1AsTUFBTSxTQUFTLFVBQ2IsT0FBTyxRQUNQLE9BQU8sVUFDYixXQUFXLGdCQUFnQixnQkFDN0I7SUFDQSxHQUFJLENBQUMsT0FDRCxDQUNFLENBQUMsT0FBTyxPQUFPLFNBQVMsR0FDeEIsQ0FBQyxPQUFPLFVBQVUsZ0JBQWdCLENBQ3BDLElBQ0EsQ0FBQztHQUNQO0VBQ0Y7Q0FDRjtDQUNBLE9BQ0Usd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFBbEIsQ0FDRyxDQUFDLFlBQ0EsZ0RBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixNQUFNLEtBQUssU0FDVix3QkFBQyxPQUFEO0lBQXNCLFdBQVU7Y0FBaEMsQ0FDRSx3QkFBQyxNQUFEO0tBQU0sTUFBTSxLQUFLO0tBQU0sV0FBVTtJQUFvQjs7OztjQUNyRCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBaUIsS0FBSztJQUFTOzs7O2NBQzVDLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTBCLEtBQUs7SUFBZTs7OztZQUN4RDs7OztZQUNGO01BTkssS0FBSzs7OztVQU1WLENBQ047RUFDRTs7OztZQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFNLElBQUksT0FBTztNQUFNLGNBQVc7Z0JBQ2hDLHdCQUFDLFdBQUQsRUFBVyxjQUFTOzs7OztLQUNoQjs7OztlQUNOLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFrQztLQUc1Qzs7OzthQUNBOzs7Ozs7SUFDSixPQUFPLEtBQUssVUFDWCx3QkFBQyxXQUFEO0tBQTJCLFdBQVU7S0FBb0I7ZUFBekQsQ0FDRSx3QkFBQyxXQUFELGFBQ0csTUFBTSxPQUNQLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFZO0tBQU87Ozs7YUFDNUI7Ozs7ZUFDVCx3QkFBQyxNQUFELFlBQ0csTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLFdBQ3ZCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO01BQU0sSUFBSTtnQkFBTztLQUFZOzs7O2NBQzNCLEdBRkssR0FBRyxLQUFLLEdBQUc7Ozs7WUFFaEIsQ0FDTCxFQUNDOzs7O2FBQ0c7T0FaSyxNQUFNOzs7O1dBWVgsQ0FDVjtJQUNELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxNQUFELFlBQUksYUFBYzs7Ozs7TUFDbEIsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7OztNQUNILHdCQUFDLE1BQUQ7T0FDRSxJQUFJO09BQ0osV0FBVTtpQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7aUJBQUMsY0FFaEI7Ozs7OztLQUNIOzs7Ozs7R0FDRjs7Ozs7VUFDTDs7OztZQUVKLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQXVCO0tBQ2xCLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUFFO0lBQzNCOzs7OzthQUNILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFVO0lBQTJCOzs7O2NBQ3JELHdCQUFDLGFBQUQsQ0FBYzs7OztZQUNYOzs7OztXQUNGOzs7OztVQUNDOzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaXRlRm9vdGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xyXG5pbXBvcnQgeyBCcmFuZExvZ28gfSBmcm9tICcuLi9jb21tb24vQnJhbmRMb2dvJztcclxuaW1wb3J0IHsgVGhlbWVUb2dnbGUgfSBmcm9tICcuLi9jb21tb24vVGhlbWVUb2dnbGUnO1xyXG5pbXBvcnQgeyBJY29uLCB0eXBlIEljb25OYW1lIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5jb25zdCB0cnVzdDogeyBpY29uOiBJY29uTmFtZTsgdGl0bGU6IHN0cmluZzsgZGVzY3JpcHRpb246IHN0cmluZyB9W10gPSBbXHJcbiAge1xyXG4gICAgaWNvbjogJ3RydWNrJyxcclxuICAgIHRpdGxlOiAnSXNsYW5kd2lkZSBkZWxpdmVyeScsXHJcbiAgICBkZXNjcmlwdGlvbjogJ0Zyb20gb3VyIHN0b3JlIHRvIHlvdXIgZG9vci4nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWNvbjogJ3NoaWVsZCcsXHJcbiAgICB0aXRsZTogJ1Nob3Agd2l0aCBjb25maWRlbmNlJyxcclxuICAgIGRlc2NyaXB0aW9uOiAnQ2xlYXIgcHJpY2VzLiBDbGVhciBhdmFpbGFiaWxpdHkuJyxcclxuICB9LFxyXG4gIHtcclxuICAgIGljb246ICdyZXBhaXInLFxyXG4gICAgdGl0bGU6ICdDYXJlIGJleW9uZCB0aGUgcHVyY2hhc2UnLFxyXG4gICAgZGVzY3JpcHRpb246ICdSZXF1ZXN0IGFuZCB0cmFjayBkZXZpY2UgcmVwYWlycy4nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWNvbjogJ2NoYXQnLFxyXG4gICAgdGl0bGU6ICdBIGxpdHRsZSBoZWxwLCBhbnl0aW1lJyxcclxuICAgIGRlc2NyaXB0aW9uOiAnTGVhdmUgYSBtZXNzYWdlIGZvciBvdXIgdGVhbS4nLFxyXG4gIH0sXHJcbl07XHJcbmV4cG9ydCBmdW5jdGlvbiBTaXRlRm9vdGVyKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgY3VzdG9tZXIgPSAhdXNlciB8fCB1c2VyLnJvbGUgPT09ICdDVVNUT01FUic7XHJcbiAgY29uc3QgY2hlY2tvdXQgPSBwYXRobmFtZSA9PT0gUk9VVEVTLmNoZWNrb3V0O1xyXG4gIGNvbnN0IHJlcGFpclJvdXRlID1cclxuICAgIHVzZXI/LnJvbGUgPT09ICdBRE1JTidcclxuICAgICAgPyBST1VURVMuYWRtaW5SZXBhaXJzXHJcbiAgICAgIDogdXNlcj8ucm9sZSA9PT0gJ1JFUEFJUkVSJ1xyXG4gICAgICAgID8gUk9VVEVTLnJlcGFpcmVyUmVwYWlyc1xyXG4gICAgICAgIDogUk9VVEVTLnJlcGFpclJlcXVlc3Q7XHJcbiAgY29uc3Qgc3VwcG9ydFJvdXRlID1cclxuICAgIHVzZXI/LnJvbGUgPT09ICdBRE1JTidcclxuICAgICAgPyBST1VURVMuYWRtaW5DaGF0XHJcbiAgICAgIDogdXNlcj8ucm9sZSA9PT0gJ1JFUEFJUkVSJ1xyXG4gICAgICAgID8gUk9VVEVTLnJlcGFpcmVyUmVwYWlyc1xyXG4gICAgICAgIDogUk9VVEVTLmxpdmVDaGF0O1xyXG4gIGNvbnN0IGdyb3VwcyA9IFtcclxuICAgIHtcclxuICAgICAgdGl0bGU6ICdTaG9wJyxcclxuICAgICAgbGlua3M6IFtcclxuICAgICAgICBbUk9VVEVTLnByb2R1Y3RzLCAnQWxsIHByb2R1Y3RzJ10sXHJcbiAgICAgICAgW1JPVVRFUy5ob21lLCAnRGlzY292ZXIgQXBwbGlhbmNlcy5sayddLFxyXG4gICAgICBdLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6ICdSZXBhaXJzJyxcclxuICAgICAgbGlua3M6IFtcclxuICAgICAgICBbcmVwYWlyUm91dGUsIGN1c3RvbWVyID8gJ1JlcXVlc3QgYSByZXBhaXInIDogJ01hbmFnZSByZXBhaXJzJ10sXHJcbiAgICAgICAgW2N1c3RvbWVyID8gUk9VVEVTLnJlcGFpcnMgOiByZXBhaXJSb3V0ZSwgJ1JlcGFpciBzdGF0dXMnXSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiAnQWNjb3VudCcsXHJcbiAgICAgIGxpbmtzOiBbXHJcbiAgICAgICAgW1JPVVRFUy5hY2NvdW50LCAnWW91ciBhY2NvdW50J10sXHJcbiAgICAgICAgW1xyXG4gICAgICAgICAgY3VzdG9tZXJcclxuICAgICAgICAgICAgPyBST1VURVMub3JkZXJzXHJcbiAgICAgICAgICAgIDogdXNlcj8ucm9sZSA9PT0gJ0FETUlOJ1xyXG4gICAgICAgICAgICAgID8gUk9VVEVTLmFkbWluXHJcbiAgICAgICAgICAgICAgOiBST1VURVMucmVwYWlyZXIsXHJcbiAgICAgICAgICBjdXN0b21lciA/ICdZb3VyIG9yZGVycycgOiAnWW91ciB3b3Jrc3BhY2UnLFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgLi4uKCF1c2VyXHJcbiAgICAgICAgICA/IFtcclxuICAgICAgICAgICAgICBbUk9VVEVTLmxvZ2luLCAnU2lnbiBpbiddLFxyXG4gICAgICAgICAgICAgIFtST1VURVMucmVnaXN0ZXIsICdDcmVhdGUgYWNjb3VudCddLFxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICA6IFtdKSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgXTtcclxuICByZXR1cm4gKFxyXG4gICAgPGZvb3RlciBjbGFzc05hbWU9XCJzaXRlLWZvb3RlclwiPlxyXG4gICAgICB7IWNoZWNrb3V0ICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItdHJ1c3Qgc2hlbGwtd2lkZVwiPlxyXG4gICAgICAgICAgICB7dHJ1c3QubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0udGl0bGV9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2l0ZW0uaWNvbn0gY2xhc3NOYW1lPVwiaC02IHctNiBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2l0ZW0udGl0bGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgbGVhZGluZy01XCI+e2l0ZW0uZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1jb2x1bW5zIHNoZWxsLXdpZGVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItYnJhbmRcIj5cclxuICAgICAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLmhvbWV9IGFyaWEtbGFiZWw9XCJBcHBsaWFuY2VzLmxrIGhvbWVcIj5cclxuICAgICAgICAgICAgICAgIDxCcmFuZExvZ28gaW52ZXJzZSAvPlxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC01IG1heC13LXhzIHRleHQtc20gbGVhZGluZy03XCI+XHJcbiAgICAgICAgICAgICAgICBHb29kIHRlY2hub2xvZ3kgZm9yIGV2ZXJ5ZGF5IGxpZmUuIEFwcGxpYW5jZXMsIGVsZWN0cm9uaWNzIGFuZCBhXHJcbiAgICAgICAgICAgICAgICBoZWxwaW5nIGhhbmQgd2hlbiB5b3UgbmVlZCBpdC5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICA8ZGV0YWlscyBrZXk9e2dyb3VwLnRpdGxlfSBjbGFzc05hbWU9XCJmb290ZXItbGluay1ncm91cFwiIG9wZW4+XHJcbiAgICAgICAgICAgICAgICA8c3VtbWFyeT5cclxuICAgICAgICAgICAgICAgICAge2dyb3VwLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZDpoaWRkZW5cIj4rPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9zdW1tYXJ5PlxyXG4gICAgICAgICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXAubGlua3MubWFwKChbcGF0aCwgbGFiZWxdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17YCR7cGF0aH0tJHtsYWJlbH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtwYXRofT57bGFiZWx9PC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICA8L2RldGFpbHM+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1jb250YWN0XCI+XHJcbiAgICAgICAgICAgICAgPGgyPkxldOKAmXMgdGFsazwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGxlYWRpbmctN1wiPlxyXG4gICAgICAgICAgICAgICAgTmVlZCBhIGhhbmQgY2hvb3NpbmcsIG9yZGVyaW5nIG9yIHJlcGFpcmluZyBhIGRldmljZT9cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPXtzdXBwb3J0Um91dGV9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IGlubGluZS1mbGV4IG1pbi1oLTExIGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjaGF0XCIgLz5cclxuICAgICAgICAgICAgICAgIENoYXQgd2l0aCB1c1xyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItYm90dG9tIHNoZWxsLXdpZGVcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+XHJcbiAgICAgICAgICDCqSB7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSBBcHBsaWFuY2VzLmxrLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+TWFrZSB5b3Vyc2VsZiBhdCBob21lPC9zcGFuPlxyXG4gICAgICAgICAgPFRoZW1lVG9nZ2xlIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb290ZXI+XHJcbiAgKTtcclxufVxyXG4iXX0=