import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Checkout/components/OrderSummary.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { translations } from "/src/utils/translations.ts";
import { commerceText } from "/src/utils/commerceText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/OrderSummary.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.checkout;
export function OrderSummary({ cart, summary, preview, credit = "0.00", amountDue }) {
	const current = summary ?? preview;
	const items = current ? current.items.map((item) => ({
		...item,
		id: item.cartItemId
	})) : cart.items;
	return /* @__PURE__ */ _jsxDEV("aside", {
		"aria-labelledby": "checkout-summary",
		className: "min-w-0 overflow-hidden rounded-lg border border-line bg-surface lg:sticky lg:top-24",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "border-b border-line p-5 sm:p-6",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "checkout-summary",
					className: "text-xl font-semibold text-fg",
					children: t.summary
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: [
						items.length,
						" ",
						items.length === 1 ? translations.cart.product : translations.cart.products
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "divide-y divide-line-subtle",
				children: items.map((item) => /* @__PURE__ */ _jsxDEV("li", {
					className: "flex items-start gap-3 p-5 sm:px-6",
					children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
						src: cart.items.find((product) => product.productId === item.productId)?.images[0],
						alt: item.name,
						className: "h-16 w-16 shrink-0 rounded-sm border border-line"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "break-words text-sm font-semibold text-fg",
								children: item.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 break-all text-xs text-fg-muted",
								children: [
									translations.productDetails.sku,
									": ",
									item.SKU
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 text-xs text-fg-secondary",
								children: [
									translations.cart.quantity,
									": ",
									item.quantity,
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										children: "/"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 17
									}, this),
									" ",
									formatCurrency(item.unitPrice),
									" ",
									t.each
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 break-all text-sm font-semibold text-fg",
								children: [
									translations.cart.lineTotal,
									": ",
									formatCurrency(item.lineTotal)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this),
							!current && !cart.items.find((product) => product.id === item.id)?.isAvailable && /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 text-xs text-warning",
								children: t.unavailableItem
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 13
					}, this)]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "border-t border-line p-5 sm:p-6",
				children: [/* @__PURE__ */ _jsxDEV("dl", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "text-fg-muted",
								children: translations.cart.subtotal
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "break-all font-medium text-fg",
								children: formatCurrency(current?.subtotal ?? cart.subtotal)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 11
						}, this),
						credit !== "0.00" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap justify-between gap-3 text-sm text-success",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: commerceText.creditUsed }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ["−", formatCurrency(credit)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-baseline justify-between gap-3 border-t border-line pt-4",
							children: [/* @__PURE__ */ _jsxDEV("dt", {
								className: "font-semibold text-fg",
								children: summary ? t.finalAmount : "Items total"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: summary ? "break-all text-2xl font-semibold text-fg" : "text-sm text-fg-muted",
								children: formatCurrency(amountDue ?? summary?.total ?? current?.subtotal ?? cart.subtotal)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-4 text-xs leading-5 text-fg-muted",
					children: summary ? t.validatedAmount : t.amountHint
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_c = OrderSummary;
var _c;
$RefreshReg$(_c, "OrderSummary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Checkout/components/OrderSummary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/OrderSummary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/OrderSummary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/OrderSummary.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsYUFBYSxFQUMzQixNQUNBLFNBQ0EsU0FDQSxTQUFTLFFBQ1QsYUFPQztDQUNELE1BQU0sVUFBVSxXQUFXO0NBQzNCLE1BQU0sUUFBUSxVQUNWLFFBQVEsTUFBTSxLQUFLLFVBQVU7RUFBRSxHQUFHO0VBQU0sSUFBSSxLQUFLO0NBQVcsRUFBRSxJQUM5RCxLQUFLO0NBQ1QsT0FDRSx3QkFBQyxTQUFEO0VBQ0UsbUJBQWdCO0VBQ2hCLFdBQVU7WUFGWjtHQUlFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksSUFBRztLQUFtQixXQUFVO2VBQ2pDLEVBQUU7SUFDRDs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWI7TUFDRyxNQUFNO01BQVE7TUFDZCxNQUFNLFdBQVcsSUFDZCxhQUFhLEtBQUssVUFDbEIsYUFBYSxLQUFLO0tBQ3JCOzs7OztZQUNBOzs7Ozs7R0FDTCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLE1BQU0sS0FBSyxTQUNWLHdCQUFDLE1BQUQ7S0FBa0IsV0FBVTtlQUE1QixDQUNFLHdCQUFDLGNBQUQ7TUFDRSxLQUNFLEtBQUssTUFBTSxNQUNSLFlBQVksUUFBUSxjQUFjLEtBQUssU0FDMUMsQ0FBQyxFQUFFLE9BQU87TUFFWixLQUFLLEtBQUs7TUFDVixXQUFVO0tBQ1g7Ozs7ZUFDRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLEtBQUs7T0FDSjs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNHLGFBQWEsZUFBZTtTQUFJO1NBQUcsS0FBSztRQUN4Qzs7Ozs7O09BQ0gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FDRyxhQUFhLEtBQUs7U0FBUztTQUFHLEtBQUs7U0FBVTtTQUM5Qyx3QkFBQyxRQUFEO1VBQU0sZUFBWTtvQkFBTztTQUFPOzs7OztTQUFFO1NBQ2pDLGVBQWUsS0FBSyxTQUFTO1NBQUU7U0FBRSxFQUFFO1FBQ25DOzs7Ozs7T0FDSCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNHLGFBQWEsS0FBSztTQUFVO1NBQUcsZUFBZSxLQUFLLFNBQVM7UUFDNUQ7Ozs7OztPQUNGLENBQUMsV0FDQSxDQUFDLEtBQUssTUFBTSxNQUFNLFlBQVksUUFBUSxPQUFPLEtBQUssRUFBRSxDQUFDLEVBQ2pELGVBQ0Ysd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsRUFBRTtPQUNGOzs7OztNQUVKOzs7OzthQUNIO09BakNLLEtBQUs7Ozs7V0FpQ1YsQ0FDTDtHQUNDOzs7OztHQUNKLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBaUIsYUFBYSxLQUFLO09BQWE7Ozs7aUJBQzlELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLGVBQWUsU0FBUyxZQUFZLEtBQUssUUFBUTtPQUNoRDs7OztlQUNEOzs7Ozs7TUFDSixXQUFXLFVBQ1Ysd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUssYUFBYSxXQUFlOzs7O2lCQUNqQyx3QkFBQyxNQUFELGFBQUksS0FBRSxlQUFlLE1BQU0sQ0FBTTs7OztlQUM5Qjs7Ozs7O01BRVAsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxVQUFVLEVBQUUsY0FBYztPQUN6Qjs7OztpQkFDSix3QkFBQyxNQUFEO1FBQ0UsV0FDRSxVQUNJLDZDQUNBO2tCQUdMLGVBQ0MsYUFDRSxTQUFTLFNBQ1QsU0FBUyxZQUNULEtBQUssUUFDVDtPQUNFOzs7O2VBQ0Q7Ozs7OztLQUNIOzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsVUFBVSxFQUFFLGtCQUFrQixFQUFFO0lBQ2hDOzs7O1lBQ0E7Ozs7OztFQUNBOzs7Ozs7QUFFWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPcmRlclN1bW1hcnkudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ2FydCB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL2NhcnQudHlwZXMnO1xyXG5pbXBvcnQgdHlwZSB7IENoZWNrb3V0U3VtbWFyeSB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL2NoZWNrb3V0LnR5cGVzJztcclxuaW1wb3J0IHsgUHJvZHVjdEltYWdlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJvZHVjdEltYWdlJztcclxuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9jdXJyZW5jeSc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IGNvbW1lcmNlVGV4dCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2NvbW1lcmNlVGV4dCc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuY2hlY2tvdXQ7XHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlclN1bW1hcnkoe1xyXG4gIGNhcnQsXHJcbiAgc3VtbWFyeSxcclxuICBwcmV2aWV3LFxyXG4gIGNyZWRpdCA9ICcwLjAwJyxcclxuICBhbW91bnREdWUsXHJcbn06IHtcclxuICBjYXJ0OiBDYXJ0O1xyXG4gIHN1bW1hcnk6IENoZWNrb3V0U3VtbWFyeSB8IG51bGw7XHJcbiAgcHJldmlldzogQ2hlY2tvdXRTdW1tYXJ5IHwgbnVsbDtcclxuICBjcmVkaXQ/OiBzdHJpbmc7XHJcbiAgYW1vdW50RHVlPzogc3RyaW5nO1xyXG59KSB7XHJcbiAgY29uc3QgY3VycmVudCA9IHN1bW1hcnkgPz8gcHJldmlldztcclxuICBjb25zdCBpdGVtcyA9IGN1cnJlbnRcclxuICAgID8gY3VycmVudC5pdGVtcy5tYXAoKGl0ZW0pID0+ICh7IC4uLml0ZW0sIGlkOiBpdGVtLmNhcnRJdGVtSWQgfSkpXHJcbiAgICA6IGNhcnQuaXRlbXM7XHJcbiAgcmV0dXJuIChcclxuICAgIDxhc2lkZVxyXG4gICAgICBhcmlhLWxhYmVsbGVkYnk9XCJjaGVja291dC1zdW1tYXJ5XCJcclxuICAgICAgY2xhc3NOYW1lPVwibWluLXctMCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBsZzpzdGlja3kgbGc6dG9wLTI0XCJcclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZSBwLTUgc206cC02XCI+XHJcbiAgICAgICAgPGgyIGlkPVwiY2hlY2tvdXQtc3VtbWFyeVwiIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICB7dC5zdW1tYXJ5fVxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHtpdGVtcy5sZW5ndGh9eycgJ31cclxuICAgICAgICAgIHtpdGVtcy5sZW5ndGggPT09IDFcclxuICAgICAgICAgICAgPyB0cmFuc2xhdGlvbnMuY2FydC5wcm9kdWN0XHJcbiAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLmNhcnQucHJvZHVjdHN9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1saW5lLXN1YnRsZVwiPlxyXG4gICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgIDxsaSBrZXk9e2l0ZW0uaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC01IHNtOnB4LTZcIj5cclxuICAgICAgICAgICAgPFByb2R1Y3RJbWFnZVxyXG4gICAgICAgICAgICAgIHNyYz17XHJcbiAgICAgICAgICAgICAgICBjYXJ0Lml0ZW1zLmZpbmQoXHJcbiAgICAgICAgICAgICAgICAgIChwcm9kdWN0KSA9PiBwcm9kdWN0LnByb2R1Y3RJZCA9PT0gaXRlbS5wcm9kdWN0SWQsXHJcbiAgICAgICAgICAgICAgICApPy5pbWFnZXNbMF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgYWx0PXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNiB3LTE2IHNocmluay0wIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJicmVhay13b3JkcyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge2l0ZW0ubmFtZX1cclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgYnJlYWstYWxsIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5za3V9OiB7aXRlbS5TS1V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jYXJ0LnF1YW50aXR5fToge2l0ZW0ucXVhbnRpdHl9eycgJ31cclxuICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPi88L3NwYW4+eycgJ31cclxuICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShpdGVtLnVuaXRQcmljZSl9IHt0LmVhY2h9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgYnJlYWstYWxsIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmNhcnQubGluZVRvdGFsfToge2Zvcm1hdEN1cnJlbmN5KGl0ZW0ubGluZVRvdGFsKX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgeyFjdXJyZW50ICYmXHJcbiAgICAgICAgICAgICAgICAhY2FydC5pdGVtcy5maW5kKChwcm9kdWN0KSA9PiBwcm9kdWN0LmlkID09PSBpdGVtLmlkKVxyXG4gICAgICAgICAgICAgICAgICA/LmlzQXZhaWxhYmxlICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtd2FybmluZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0LnVuYXZhaWxhYmxlSXRlbX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L3VsPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1saW5lIHAtNSBzbTpwLTZcIj5cclxuICAgICAgICA8ZGwgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LWZnLW11dGVkXCI+e3RyYW5zbGF0aW9ucy5jYXJ0LnN1YnRvdGFsfTwvZHQ+XHJcbiAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJicmVhay1hbGwgZm9udC1tZWRpdW0gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShjdXJyZW50Py5zdWJ0b3RhbCA/PyBjYXJ0LnN1YnRvdGFsKX1cclxuICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2NyZWRpdCAhPT0gJzAuMDAnICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgdGV4dC1zbSB0ZXh0LXN1Y2Nlc3NcIj5cclxuICAgICAgICAgICAgICA8ZHQ+e2NvbW1lcmNlVGV4dC5jcmVkaXRVc2VkfTwvZHQ+XHJcbiAgICAgICAgICAgICAgPGRkPuKIkntmb3JtYXRDdXJyZW5jeShjcmVkaXQpfTwvZGQ+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtYmFzZWxpbmUganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlci10IGJvcmRlci1saW5lIHB0LTRcIj5cclxuICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgIHtzdW1tYXJ5ID8gdC5maW5hbEFtb3VudCA6ICdJdGVtcyB0b3RhbCd9XHJcbiAgICAgICAgICAgIDwvZHQ+XHJcbiAgICAgICAgICAgIDxkZFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICBzdW1tYXJ5XHJcbiAgICAgICAgICAgICAgICAgID8gJ2JyZWFrLWFsbCB0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZmcnXHJcbiAgICAgICAgICAgICAgICAgIDogJ3RleHQtc20gdGV4dC1mZy1tdXRlZCdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koXHJcbiAgICAgICAgICAgICAgICBhbW91bnREdWUgPz9cclxuICAgICAgICAgICAgICAgICAgc3VtbWFyeT8udG90YWwgPz9cclxuICAgICAgICAgICAgICAgICAgY3VycmVudD8uc3VidG90YWwgPz9cclxuICAgICAgICAgICAgICAgICAgY2FydC5zdWJ0b3RhbCxcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kbD5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHtzdW1tYXJ5ID8gdC52YWxpZGF0ZWRBbW91bnQgOiB0LmFtb3VudEhpbnR9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvYXNpZGU+XHJcbiAgKTtcclxufVxyXG4iXX0=