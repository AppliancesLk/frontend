import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Orders/Details/index.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { AdminOrderDetails } from "/src/pages/Admin/Orders/components/AdminOrderDetails.tsx";
import { useAdminOrdersPage } from "/src/pages/Admin/Orders/hooks/useAdminOrdersPage.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/Details/index.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.adminOrders;
export default function AdminOrderDetailsPage() {
	_s();
	const { id } = useParams();
	const page = useAdminOrdersPage(id);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV(Link, {
				to: ROUTES.adminOrders,
				className: "text-sm font-medium text-fg-link hover:text-fg-link",
				children: ["← ", t.back]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title text-fg",
				children: t.detailsTitle
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-muted",
				children: t.description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			page.loading && /* @__PURE__ */ _jsxDEV(LoadingState, {
				label: t.loading,
				compact: false
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 24
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-danger/25 bg-danger-bg p-5 text-sm text-danger",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: page.error }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: page.refresh,
					className: "auth-secondary mt-4",
					children: translations.common.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 9
			}, this),
			page.notFound && /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-8 text-center",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-semibold text-fg",
					children: t.notFound
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.notFoundDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this),
			!page.loading && !page.error && !page.notFound && page.order && /* @__PURE__ */ _jsxDEV(AdminOrderDetails, {
				order: page.order,
				page
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s(AdminOrderDetailsPage, "qr55ii7xR5B9mbyUFHPlTieh6P4=", false, function() {
	return [useParams, useAdminOrdersPage];
});
_c = AdminOrderDetailsPage;
var _c;
$RefreshReg$(_c, "AdminOrderDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Orders/Details/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/Details/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/Details/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/Details/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxNQUFNLGlCQUFpQjtBQUNoQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUywwQkFBMEI7Ozs7QUFFbkMsTUFBTSxJQUFJLGFBQWE7QUFDdkIsZUFBZSxTQUFTLHdCQUF3Qjs7Q0FDOUMsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixNQUFNLE9BQU8sbUJBQW1CLEVBQUU7Q0FDbEMsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE1BQUQ7SUFDRSxJQUFJLE9BQU87SUFDWCxXQUFVO2NBRlosQ0FHQyxNQUNTLEVBQUUsSUFDTjs7Ozs7O0dBQ04sd0JBQUMsVUFBRCxhQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXlCLEVBQUU7R0FBaUI7Ozs7YUFDMUQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBOEIsRUFBRTtHQUFlOzs7O1dBQ3REOzs7OztHQUNQLEtBQUssV0FBVyx3QkFBQyxjQUFEO0lBQWMsT0FBTyxFQUFFO0lBQVMsU0FBUztHQUFROzs7OztHQUNqRSxLQUFLLFNBQ0osd0JBQUMsT0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRlosQ0FJRSx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7O2NBQ2xCLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUyxLQUFLO0tBQ2QsV0FBVTtlQUVULGFBQWEsT0FBTztJQUNmOzs7O1lBQ0w7Ozs7OztHQUVOLEtBQUssWUFDSix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBaUMsRUFBRTtJQUFhOzs7O2NBQzlELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCLEVBQUU7SUFBdUI7Ozs7WUFDakU7Ozs7OztHQUVOLENBQUMsS0FBSyxXQUFXLENBQUMsS0FBSyxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssU0FDdEQsd0JBQUMsbUJBQUQ7SUFBbUIsT0FBTyxLQUFLO0lBQWE7R0FBTzs7Ozs7RUFFOUM7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMb2FkaW5nU3RhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgTGluaywgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBBZG1pbk9yZGVyRGV0YWlscyB9IGZyb20gJy4uL2NvbXBvbmVudHMvQWRtaW5PcmRlckRldGFpbHMnO1xyXG5pbXBvcnQgeyB1c2VBZG1pbk9yZGVyc1BhZ2UgfSBmcm9tICcuLi9ob29rcy91c2VBZG1pbk9yZGVyc1BhZ2UnO1xyXG5cclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pbk9yZGVycztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQWRtaW5PcmRlckRldGFpbHNQYWdlKCkge1xyXG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpO1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VBZG1pbk9yZGVyc1BhZ2UoaWQpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPExpbmtcclxuICAgICAgICB0bz17Uk9VVEVTLmFkbWluT3JkZXJzfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgID5cclxuICAgICAgICAmbGFycjsge3QuYmFja31cclxuICAgICAgPC9MaW5rPlxyXG4gICAgICA8aGVhZGVyPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIHRleHQtZmdcIj57dC5kZXRhaWxzVGl0bGV9PC9oMT5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPnt0LmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICAgIHtwYWdlLmxvYWRpbmcgJiYgPExvYWRpbmdTdGF0ZSBsYWJlbD17dC5sb2FkaW5nfSBjb21wYWN0PXtmYWxzZX0gLz59XHJcbiAgICAgIHtwYWdlLmVycm9yICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWRhbmdlci8yNSBiZy1kYW5nZXItYmcgcC01IHRleHQtc20gdGV4dC1kYW5nZXJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwPntwYWdlLmVycm9yfTwvcD5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e3BhZ2UucmVmcmVzaH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnkgbXQtNFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLnJldHJ5fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLm5vdEZvdW5kICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC04IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dC5ub3RGb3VuZH08L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5ub3RGb3VuZERlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgeyFwYWdlLmxvYWRpbmcgJiYgIXBhZ2UuZXJyb3IgJiYgIXBhZ2Uubm90Rm91bmQgJiYgcGFnZS5vcmRlciAmJiAoXHJcbiAgICAgICAgPEFkbWluT3JkZXJEZXRhaWxzIG9yZGVyPXtwYWdlLm9yZGVyfSBwYWdlPXtwYWdlfSAvPlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19