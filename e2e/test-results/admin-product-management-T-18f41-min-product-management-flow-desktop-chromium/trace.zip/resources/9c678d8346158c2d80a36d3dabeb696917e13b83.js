import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/SeasonalThemeProvider.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { getActiveSeasonalTheme } from "/src/services/seasonalThemeService.ts";
import { DEFAULT_SEASONAL_THEME, SEASONAL_THEMES } from "/src/types/seasonal-theme.types.ts";
import { SeasonalThemeContext } from "/src/context/seasonal-theme-context.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/SeasonalThemeProvider.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function SeasonalThemeProvider({ children }) {
	_s();
	const [active, setActive] = useState(DEFAULT_SEASONAL_THEME);
	const request = useRef(null);
	const timer = useRef(undefined);
	const expiry = useRef(undefined);
	const alive = useRef(false);
	const load = useCallback(async function fetchTheme() {
		request.current?.abort();
		window.clearTimeout(timer.current);
		const controller = new AbortController();
		request.current = controller;
		const requestedAt = performance.now();
		let next = DEFAULT_SEASONAL_THEME;
		try {
			const result = await getActiveSeasonalTheme(controller.signal);
			if (SEASONAL_THEMES.includes(result.theme)) next = result;
		} catch {}
		if (!alive.current || controller.signal.aborted) return;
		window.clearTimeout(expiry.current);
		setActive(next);
		if (next.theme === "DEFAULT") document.documentElement.removeAttribute("data-season");
		else document.documentElement.setAttribute("data-season", next.theme);
		const transition = next.nextChangeAt ? Date.parse(next.nextChangeAt) - Date.parse(next.serverTime) - (performance.now() - requestedAt) : 6e4;
		// A known end date must still restore Default if the next API request stalls.
		if (next.theme !== "DEFAULT" && next.nextChangeAt && Number.isFinite(transition)) {
			const deadline = performance.now() + Math.max(0, transition);
			const expire = () => {
				if (!alive.current) return;
				const remaining = deadline - performance.now();
				if (remaining > 0) {
					expiry.current = window.setTimeout(expire, Math.min(remaining, 2147483647));
					return;
				}
				setActive(DEFAULT_SEASONAL_THEME);
				document.documentElement.removeAttribute("data-season");
			};
			expire();
		}
		const delay = Number.isFinite(transition) ? Math.max(250, Math.min(6e4, transition + 100)) : 6e4;
		timer.current = window.setTimeout(() => {
			if (document.visibilityState === "visible") void fetchTheme();
		}, delay);
	}, []);
	useEffect(() => {
		alive.current = true;
		void load();
		const focus = () => {
			if (document.visibilityState === "visible") void load();
		};
		window.addEventListener("focus", focus);
		document.addEventListener("visibilitychange", focus);
		return () => {
			alive.current = false;
			request.current?.abort();
			window.clearTimeout(timer.current);
			window.clearTimeout(expiry.current);
			window.removeEventListener("focus", focus);
			document.removeEventListener("visibilitychange", focus);
			document.documentElement.removeAttribute("data-season");
		};
	}, [load]);
	return /* @__PURE__ */ _jsxDEV(SeasonalThemeContext.Provider, {
		value: {
			active,
			refresh: load
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 94,
		columnNumber: 5
	}, this);
}
_s(SeasonalThemeProvider, "uBjDXdC7qHm9nixT/Ejb/tYTtCw=");
_c = SeasonalThemeProvider;
var _c;
$RefreshReg$(_c, "SeasonalThemeProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/SeasonalThemeProvider.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/SeasonalThemeProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/SeasonalThemeProvider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/SeasonalThemeProvider.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxhQUNBLFdBQ0EsUUFDQSxnQkFFSztBQUNQLFNBQVMsOEJBQThCO0FBQ3ZDLFNBQ0Usd0JBQ0EsdUJBRUs7QUFDUCxTQUFTLDRCQUE0Qjs7OztBQUVyQyxPQUFPLFNBQVMsc0JBQXNCLEVBQUUsWUFBcUM7O0NBQzNFLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxzQkFBc0I7Q0FDM0QsTUFBTSxVQUFVLE9BQStCLElBQUk7Q0FDbkQsTUFBTSxRQUFRLE9BQTJCLFNBQVM7Q0FDbEQsTUFBTSxTQUFTLE9BQTJCLFNBQVM7Q0FDbkQsTUFBTSxRQUFRLE9BQU8sS0FBSztDQUMxQixNQUFNLE9BQU8sWUFBWSxlQUFlLGFBQWE7RUFDbkQsUUFBUSxTQUFTLE1BQU07RUFDdkIsT0FBTyxhQUFhLE1BQU0sT0FBTztFQUNqQyxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFDdkMsUUFBUSxVQUFVO0VBQ2xCLE1BQU0sY0FBYyxZQUFZLElBQUk7RUFDcEMsSUFBSSxPQUE0QjtFQUNoQyxJQUFJO0dBQ0YsTUFBTSxTQUFTLE1BQU0sdUJBQXVCLFdBQVcsTUFBTTtHQUM3RCxJQUFJLGdCQUFnQixTQUFTLE9BQU8sS0FBSyxHQUFHLE9BQU87RUFDckQsUUFBUSxDQUVSO0VBQ0EsSUFBSSxDQUFDLE1BQU0sV0FBVyxXQUFXLE9BQU8sU0FBUztFQUNqRCxPQUFPLGFBQWEsT0FBTyxPQUFPO0VBQ2xDLFVBQVUsSUFBSTtFQUNkLElBQUksS0FBSyxVQUFVLFdBQ2pCLFNBQVMsZ0JBQWdCLGdCQUFnQixhQUFhO09BQ25ELFNBQVMsZ0JBQWdCLGFBQWEsZUFBZSxLQUFLLEtBQUs7RUFDcEUsTUFBTSxhQUFhLEtBQUssZUFDcEIsS0FBSyxNQUFNLEtBQUssWUFBWSxJQUM1QixLQUFLLE1BQU0sS0FBSyxVQUFVLEtBQ3pCLFlBQVksSUFBSSxJQUFJLGVBQ3JCOztFQUVKLElBQ0UsS0FBSyxVQUFVLGFBQ2YsS0FBSyxnQkFDTCxPQUFPLFNBQVMsVUFBVSxHQUMxQjtHQUNBLE1BQU0sV0FBVyxZQUFZLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxVQUFVO0dBQzNELE1BQU0sZUFBZTtJQUNuQixJQUFJLENBQUMsTUFBTSxTQUFTO0lBQ3BCLE1BQU0sWUFBWSxXQUFXLFlBQVksSUFBSTtJQUM3QyxJQUFJLFlBQVksR0FBRztLQUNqQixPQUFPLFVBQVUsT0FBTyxXQUN0QixRQUNBLEtBQUssSUFBSSxXQUFXLFVBQWEsQ0FDbkM7S0FDQTtJQUNGO0lBQ0EsVUFBVSxzQkFBc0I7SUFDaEMsU0FBUyxnQkFBZ0IsZ0JBQWdCLGFBQWE7R0FDeEQ7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxNQUFNLFFBQVEsT0FBTyxTQUFTLFVBQVUsSUFDcEMsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQVEsYUFBYSxHQUFHLENBQUMsSUFDaEQ7RUFDSixNQUFNLFVBQVUsT0FBTyxpQkFBaUI7R0FDdEMsSUFBSSxTQUFTLG9CQUFvQixXQUFXLEtBQUssV0FBVztFQUM5RCxHQUFHLEtBQUs7Q0FDVixHQUFHLENBQUMsQ0FBQztDQUNMLGdCQUFnQjtFQUNkLE1BQU0sVUFBVTtFQUNoQixLQUFLLEtBQUs7RUFDVixNQUFNLGNBQWM7R0FDbEIsSUFBSSxTQUFTLG9CQUFvQixXQUFXLEtBQUssS0FBSztFQUN4RDtFQUNBLE9BQU8saUJBQWlCLFNBQVMsS0FBSztFQUN0QyxTQUFTLGlCQUFpQixvQkFBb0IsS0FBSztFQUNuRCxhQUFhO0dBQ1gsTUFBTSxVQUFVO0dBQ2hCLFFBQVEsU0FBUyxNQUFNO0dBQ3ZCLE9BQU8sYUFBYSxNQUFNLE9BQU87R0FDakMsT0FBTyxhQUFhLE9BQU8sT0FBTztHQUNsQyxPQUFPLG9CQUFvQixTQUFTLEtBQUs7R0FDekMsU0FBUyxvQkFBb0Isb0JBQW9CLEtBQUs7R0FDdEQsU0FBUyxnQkFBZ0IsZ0JBQWdCLGFBQWE7RUFDeEQ7Q0FDRixHQUFHLENBQUMsSUFBSSxDQUFDO0NBQ1QsT0FDRSx3QkFBQyxxQkFBcUIsVUFBdEI7RUFBK0IsT0FBTztHQUFFO0dBQVEsU0FBUztFQUFLO0VBQzNEO0NBQzRCOzs7OztBQUVuQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZWFzb25hbFRoZW1lUHJvdmlkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgdXNlQ2FsbGJhY2ssXHJcbiAgdXNlRWZmZWN0LFxyXG4gIHVzZVJlZixcclxuICB1c2VTdGF0ZSxcclxuICB0eXBlIFJlYWN0Tm9kZSxcclxufSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IGdldEFjdGl2ZVNlYXNvbmFsVGhlbWUgfSBmcm9tICcuLi9zZXJ2aWNlcy9zZWFzb25hbFRoZW1lU2VydmljZSc7XHJcbmltcG9ydCB7XHJcbiAgREVGQVVMVF9TRUFTT05BTF9USEVNRSxcclxuICBTRUFTT05BTF9USEVNRVMsXHJcbiAgdHlwZSBBY3RpdmVTZWFzb25hbFRoZW1lLFxyXG59IGZyb20gJy4uL3R5cGVzL3NlYXNvbmFsLXRoZW1lLnR5cGVzJztcclxuaW1wb3J0IHsgU2Vhc29uYWxUaGVtZUNvbnRleHQgfSBmcm9tICcuL3NlYXNvbmFsLXRoZW1lLWNvbnRleHQnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNlYXNvbmFsVGhlbWVQcm92aWRlcih7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XHJcbiAgY29uc3QgW2FjdGl2ZSwgc2V0QWN0aXZlXSA9IHVzZVN0YXRlKERFRkFVTFRfU0VBU09OQUxfVEhFTUUpO1xyXG4gIGNvbnN0IHJlcXVlc3QgPSB1c2VSZWY8QWJvcnRDb250cm9sbGVyIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgdGltZXIgPSB1c2VSZWY8bnVtYmVyIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xyXG4gIGNvbnN0IGV4cGlyeSA9IHVzZVJlZjxudW1iZXIgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XHJcbiAgY29uc3QgYWxpdmUgPSB1c2VSZWYoZmFsc2UpO1xyXG4gIGNvbnN0IGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyBmdW5jdGlvbiBmZXRjaFRoZW1lKCkge1xyXG4gICAgcmVxdWVzdC5jdXJyZW50Py5hYm9ydCgpO1xyXG4gICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KTtcclxuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbiAgICByZXF1ZXN0LmN1cnJlbnQgPSBjb250cm9sbGVyO1xyXG4gICAgY29uc3QgcmVxdWVzdGVkQXQgPSBwZXJmb3JtYW5jZS5ub3coKTtcclxuICAgIGxldCBuZXh0OiBBY3RpdmVTZWFzb25hbFRoZW1lID0gREVGQVVMVF9TRUFTT05BTF9USEVNRTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGdldEFjdGl2ZVNlYXNvbmFsVGhlbWUoY29udHJvbGxlci5zaWduYWwpO1xyXG4gICAgICBpZiAoU0VBU09OQUxfVEhFTUVTLmluY2x1ZGVzKHJlc3VsdC50aGVtZSkpIG5leHQgPSByZXN1bHQ7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLyogU2Vhc29uYWwgc3R5bGluZyBpcyBvcHRpb25hbDsgdGhlIHN0b3JlIGtlZXBzIGl0cyBkZWZhdWx0IGFwcGVhcmFuY2UuICovXHJcbiAgICB9XHJcbiAgICBpZiAoIWFsaXZlLmN1cnJlbnQgfHwgY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgcmV0dXJuO1xyXG4gICAgd2luZG93LmNsZWFyVGltZW91dChleHBpcnkuY3VycmVudCk7XHJcbiAgICBzZXRBY3RpdmUobmV4dCk7XHJcbiAgICBpZiAobmV4dC50aGVtZSA9PT0gJ0RFRkFVTFQnKVxyXG4gICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXNlYXNvbicpO1xyXG4gICAgZWxzZSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2V0QXR0cmlidXRlKCdkYXRhLXNlYXNvbicsIG5leHQudGhlbWUpO1xyXG4gICAgY29uc3QgdHJhbnNpdGlvbiA9IG5leHQubmV4dENoYW5nZUF0XHJcbiAgICAgID8gRGF0ZS5wYXJzZShuZXh0Lm5leHRDaGFuZ2VBdCkgLVxyXG4gICAgICAgIERhdGUucGFyc2UobmV4dC5zZXJ2ZXJUaW1lKSAtXHJcbiAgICAgICAgKHBlcmZvcm1hbmNlLm5vdygpIC0gcmVxdWVzdGVkQXQpXHJcbiAgICAgIDogNjBfMDAwO1xyXG4gICAgLy8gQSBrbm93biBlbmQgZGF0ZSBtdXN0IHN0aWxsIHJlc3RvcmUgRGVmYXVsdCBpZiB0aGUgbmV4dCBBUEkgcmVxdWVzdCBzdGFsbHMuXHJcbiAgICBpZiAoXHJcbiAgICAgIG5leHQudGhlbWUgIT09ICdERUZBVUxUJyAmJlxyXG4gICAgICBuZXh0Lm5leHRDaGFuZ2VBdCAmJlxyXG4gICAgICBOdW1iZXIuaXNGaW5pdGUodHJhbnNpdGlvbilcclxuICAgICkge1xyXG4gICAgICBjb25zdCBkZWFkbGluZSA9IHBlcmZvcm1hbmNlLm5vdygpICsgTWF0aC5tYXgoMCwgdHJhbnNpdGlvbik7XHJcbiAgICAgIGNvbnN0IGV4cGlyZSA9ICgpID0+IHtcclxuICAgICAgICBpZiAoIWFsaXZlLmN1cnJlbnQpIHJldHVybjtcclxuICAgICAgICBjb25zdCByZW1haW5pbmcgPSBkZWFkbGluZSAtIHBlcmZvcm1hbmNlLm5vdygpO1xyXG4gICAgICAgIGlmIChyZW1haW5pbmcgPiAwKSB7XHJcbiAgICAgICAgICBleHBpcnkuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KFxyXG4gICAgICAgICAgICBleHBpcmUsXHJcbiAgICAgICAgICAgIE1hdGgubWluKHJlbWFpbmluZywgMl8xNDdfNDgzXzY0NyksXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRBY3RpdmUoREVGQVVMVF9TRUFTT05BTF9USEVNRSk7XHJcbiAgICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1zZWFzb24nKTtcclxuICAgICAgfTtcclxuICAgICAgZXhwaXJlKCk7XHJcbiAgICB9XHJcbiAgICBjb25zdCBkZWxheSA9IE51bWJlci5pc0Zpbml0ZSh0cmFuc2l0aW9uKVxyXG4gICAgICA/IE1hdGgubWF4KDI1MCwgTWF0aC5taW4oNjBfMDAwLCB0cmFuc2l0aW9uICsgMTAwKSlcclxuICAgICAgOiA2MF8wMDA7XHJcbiAgICB0aW1lci5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBpZiAoZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlID09PSAndmlzaWJsZScpIHZvaWQgZmV0Y2hUaGVtZSgpO1xyXG4gICAgfSwgZGVsYXkpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYWxpdmUuY3VycmVudCA9IHRydWU7XHJcbiAgICB2b2lkIGxvYWQoKTtcclxuICAgIGNvbnN0IGZvY3VzID0gKCkgPT4ge1xyXG4gICAgICBpZiAoZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlID09PSAndmlzaWJsZScpIHZvaWQgbG9hZCgpO1xyXG4gICAgfTtcclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdmb2N1cycsIGZvY3VzKTtcclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBmb2N1cyk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBhbGl2ZS5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIHJlcXVlc3QuY3VycmVudD8uYWJvcnQoKTtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lci5jdXJyZW50KTtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dChleHBpcnkuY3VycmVudCk7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdmb2N1cycsIGZvY3VzKTtcclxuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGZvY3VzKTtcclxuICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1zZWFzb24nKTtcclxuICAgIH07XHJcbiAgfSwgW2xvYWRdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPFNlYXNvbmFsVGhlbWVDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGFjdGl2ZSwgcmVmcmVzaDogbG9hZCB9fT5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9TZWFzb25hbFRoZW1lQ29udGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59XHJcbiJdfQ==