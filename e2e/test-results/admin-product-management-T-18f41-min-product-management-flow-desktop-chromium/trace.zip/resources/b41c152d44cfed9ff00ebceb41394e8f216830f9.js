import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { aiText } from "/src/utils/aiText.ts";
import { useProductAiAssistant } from "/src/pages/Customer/ProductDetails/hooks/useProductAiAssistant.ts";
import { AiChatMessage } from "/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx";
import { AiChatInput } from "/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatInput.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function ProductAiAssistant({ productId, productName }) {
	_s();
	const { user } = useAuth();
	return /* @__PURE__ */ _jsxDEV(AssistantPanel, {
		productId,
		productName
	}, `${productId}-${user?.id ?? "guest"}`, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_s(ProductAiAssistant, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = ProductAiAssistant;
function AssistantPanel({ productId, productName }) {
	_s2();
	const { user, loading } = useAuth();
	const location = useLocation();
	const [open, setOpen] = useState(false);
	const chat = useProductAiAssistant(productId);
	const launcher = useRef(null);
	const heading = useRef(null);
	const end = useRef(null);
	useEffect(() => {
		if (open) heading.current?.focus();
	}, [open]);
	useEffect(() => {
		if (open) end.current?.scrollIntoView({ block: "nearest" });
	}, [
		open,
		chat.messages,
		chat.sending,
		chat.error
	]);
	function close() {
		setOpen(false);
		requestAnimationFrame(() => launcher.current?.focus());
	}
	const focusStyle = "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "product-assistant z-40",
		"aria-label": aiText.title,
		children: [open && /* @__PURE__ */ _jsxDEV("section", {
			role: "dialog",
			"aria-labelledby": "product-ai-title",
			"aria-describedby": "product-ai-context",
			onKeyDown: (event) => {
				if (event.key === "Tab" && window.matchMedia("(max-width: 767px)").matches) {
					const controls = Array.from(event.currentTarget.querySelectorAll("button:not(:disabled), a[href], textarea:not(:disabled), input:not(:disabled), [tabindex=\"0\"]"));
					const first = controls[0], last = controls[controls.length - 1];
					if (event.shiftKey && (document.activeElement === first || document.activeElement === heading.current)) {
						event.preventDefault();
						last?.focus();
					} else if (!event.shiftKey && document.activeElement === last) {
						event.preventDefault();
						first?.focus();
					}
				}
				if (event.key === "Escape") {
					event.stopPropagation();
					close();
				}
			},
			className: "ai-panel flex flex-col overflow-hidden rounded-lg border border-line bg-raised shadow-lg",
			children: [
				/* @__PURE__ */ _jsxDEV("header", {
					className: "flex items-start justify-between gap-3 border-b border-line bg-raised px-4 py-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								id: "product-ai-title",
								ref: heading,
								tabIndex: -1,
								className: "font-semibold text-fg outline-none",
								children: aiText.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								id: "product-ai-context",
								className: "mt-1 truncate text-xs text-fg-muted",
								children: productName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("details", {
								className: "mt-2 text-xs text-fg-muted",
								children: [/* @__PURE__ */ _jsxDEV("summary", { children: "About this assistant" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-2 max-w-xs leading-5",
									children: aiText.providerNote
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: close,
						"aria-label": aiText.close,
						className: `flex h-11 w-11 shrink-0 items-center justify-center rounded-sm text-fg-secondary hover:bg-subtle ${focusStyle}`,
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "min-h-0 flex-1 overflow-y-auto overscroll-contain p-4",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm leading-6 text-fg-secondary",
							children: aiText.greeting
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this),
						loading ? /* @__PURE__ */ _jsxDEV(LoadingState, {
							label: aiText.checking,
							compact: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 15
						}, this) : !user ? /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.login,
							state: { from: location.pathname + location.search },
							className: `mt-4 inline-block rounded-sm bg-primary px-4 py-3 text-sm font-medium text-primary-on ${focusStyle}`,
							children: aiText.signIn
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							chat.messages.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 flex flex-col items-start gap-2",
								children: aiText.prompts.map((prompt) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => void chat.send(prompt),
									disabled: chat.sending,
									className: `rounded-sm border border-primary px-3 py-2 text-left text-xs text-fg-link hover:bg-primary-subtle  ${focusStyle}`,
									children: prompt
								}, prompt, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 23
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								role: "log",
								"aria-label": aiText.conversation,
								"aria-live": "polite",
								"aria-relevant": "additions",
								className: "mt-4 space-y-3",
								children: chat.messages.map((message) => /* @__PURE__ */ _jsxDEV(AiChatMessage, { message }, message.id, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 17
							}, this),
							chat.sending && /* @__PURE__ */ _jsxDEV(LoadingState, {
								label: aiText.sending,
								compact: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 19
							}, this),
							chat.error && /* @__PURE__ */ _jsxDEV("div", {
								role: "alert",
								className: "mt-3 rounded-sm bg-danger-bg p-3 text-sm text-danger",
								children: [/* @__PURE__ */ _jsxDEV("p", { children: chat.error }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: chat.retry,
									className: `mt-2 rounded font-medium underline ${focusStyle}`,
									children: aiText.retry
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 19
							}, this),
							chat.messages.length > 0 && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: chat.reset,
								disabled: chat.sending,
								className: `mt-3 rounded text-xs text-fg-link underline  ${focusStyle}`,
								children: aiText.newChat
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 19
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { ref: end }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 11
				}, this),
				user && /* @__PURE__ */ _jsxDEV(AiChatInput, {
					disabled: chat.sending,
					send: (value) => void chat.send(value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "px-4 pb-4 text-xs leading-5 text-fg-muted",
					children: aiText.note
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 202,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 9
		}, this), !open && /* @__PURE__ */ _jsxDEV("div", {
			className: "flex justify-end",
			children: /* @__PURE__ */ _jsxDEV("button", {
				ref: launcher,
				type: "button",
				"aria-expanded": open,
				onClick: () => setOpen((current) => !current),
				className: `ai-launcher flex h-13 items-center gap-2 rounded-full bg-primary px-4 text-sm font-medium text-primary-on shadow-lg hover:bg-primary-hover ${focusStyle}`,
				children: [/* @__PURE__ */ _jsxDEV("svg", {
					"aria-hidden": "true",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.8",
					className: "h-5 w-5",
					children: [/* @__PURE__ */ _jsxDEV("path", { d: "M20 11.5a7.5 7.5 0 0 1-7.5 7.5H5l-3 3V11.5A7.5 7.5 0 0 1 9.5 4h3A7.5 7.5 0 0 1 20 11.5Z" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 224,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("path", { d: "m17 2 1-2 1 2 2 1-2 1-1 2-1-2-2-1Z" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 13
				}, this), aiText.open]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 209,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 208,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 5
	}, this);
}
_s2(AssistantPanel, "dqwkZLQm2i7x2DsKSF00bXXWfOM=", false, function() {
	return [
		useAuth,
		useLocation,
		useProductAiAssistant
	];
});
_c2 = AssistantPanel;
var _c, _c2;
$RefreshReg$(_c, "ProductAiAssistant");
$RefreshReg$(_c2, "AssistantPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsTUFBTSxtQkFBbUI7QUFDbEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxtQkFBbUI7Ozs7QUFFNUIsT0FBTyxTQUFTLG1CQUFtQixFQUNqQyxXQUNBLGVBSUM7O0NBQ0QsTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUN6QixPQUNFLHdCQUFDLGdCQUFEO0VBRWE7RUFDRTtDQUNkLEdBSE0sR0FBRyxVQUFVLEdBQUcsTUFBTSxNQUFNOzs7O1FBR2xDO0FBRUw7Ozs7O0FBRUEsU0FBUyxlQUFlLEVBQ3RCLFdBQ0EsZUFJQzs7Q0FDRCxNQUFNLEVBQUUsTUFBTSxZQUFZLFFBQVE7Q0FDbEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxPQUFPLHNCQUFzQixTQUFTO0NBQzVDLE1BQU0sV0FBVyxPQUEwQixJQUFJO0NBQy9DLE1BQU0sVUFBVSxPQUEyQixJQUFJO0NBQy9DLE1BQU0sTUFBTSxPQUF1QixJQUFJO0NBQ3ZDLGdCQUFnQjtFQUNkLElBQUksTUFBTSxRQUFRLFNBQVMsTUFBTTtDQUNuQyxHQUFHLENBQUMsSUFBSSxDQUFDO0NBQ1QsZ0JBQWdCO0VBQ2QsSUFBSSxNQUFNLElBQUksU0FBUyxlQUFlLEVBQUUsT0FBTyxVQUFVLENBQUM7Q0FDNUQsR0FBRztFQUFDO0VBQU0sS0FBSztFQUFVLEtBQUs7RUFBUyxLQUFLO0NBQUssQ0FBQztDQUNsRCxTQUFTLFFBQVE7RUFDZixRQUFRLEtBQUs7RUFDYiw0QkFBNEIsU0FBUyxTQUFTLE1BQU0sQ0FBQztDQUN2RDtDQUNBLE1BQU0sYUFDSjtDQUNGLE9BQ0Usd0JBQUMsU0FBRDtFQUFPLFdBQVU7RUFBeUIsY0FBWSxPQUFPO1lBQTdELENBQ0csUUFDQyx3QkFBQyxXQUFEO0dBQ0UsTUFBSztHQUNMLG1CQUFnQjtHQUNoQixvQkFBaUI7R0FDakIsWUFBWSxVQUFVO0lBQ3BCLElBQ0UsTUFBTSxRQUFRLFNBQ2QsT0FBTyxXQUFXLG9CQUFvQixDQUFDLENBQUMsU0FDeEM7S0FDQSxNQUFNLFdBQVcsTUFBTSxLQUNyQixNQUFNLGNBQWMsaUJBQ2xCLGlHQUNGLENBQ0Y7S0FDQSxNQUFNLFFBQVEsU0FBUyxJQUNyQixPQUFPLFNBQVMsU0FBUyxTQUFTO0tBQ3BDLElBQ0UsTUFBTSxhQUNMLFNBQVMsa0JBQWtCLFNBQzFCLFNBQVMsa0JBQWtCLFFBQVEsVUFDckM7TUFDQSxNQUFNLGVBQWU7TUFDckIsTUFBTSxNQUFNO0tBQ2QsT0FBTyxJQUFJLENBQUMsTUFBTSxZQUFZLFNBQVMsa0JBQWtCLE1BQU07TUFDN0QsTUFBTSxlQUFlO01BQ3JCLE9BQU8sTUFBTTtLQUNmO0lBQ0Y7SUFDQSxJQUFJLE1BQU0sUUFBUSxVQUFVO0tBQzFCLE1BQU0sZ0JBQWdCO0tBQ3RCLE1BQU07SUFDUjtHQUNGO0dBQ0EsV0FBVTthQWpDWjtJQW1DRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUFsQixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUNFLElBQUc7UUFDSCxLQUFLO1FBQ0wsVUFBVSxDQUFDO1FBQ1gsV0FBVTtrQkFFVCxPQUFPO09BQ047Ozs7O09BQ0osd0JBQUMsS0FBRDtRQUNFLElBQUc7UUFDSCxXQUFVO2tCQUVUO09BQ0E7Ozs7O09BQ0gsd0JBQUMsV0FBRDtRQUFTLFdBQVU7a0JBQW5CLENBQ0Usd0JBQUMsV0FBRCxZQUFTLHVCQUE2Qjs7OztrQkFDdEMsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTJCLE9BQU87UUFBZ0I7Ozs7Z0JBQ3hEOzs7Ozs7TUFDTjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVM7TUFDVCxjQUFZLE9BQU87TUFDbkIsV0FBVyxvR0FBb0c7Z0JBQ2hIO0tBRU87Ozs7YUFDRjs7Ozs7O0lBQ1Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLE9BQU87TUFDUDs7Ozs7TUFDRixVQUNDLHdCQUFDLGNBQUQ7T0FBYyxPQUFPLE9BQU87T0FBVSxTQUFTO01BQU87Ozs7aUJBQ3BELENBQUMsT0FDSCx3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPO09BQ1gsT0FBTyxFQUFFLE1BQU0sU0FBUyxXQUFXLFNBQVMsT0FBTztPQUNuRCxXQUFXLHlGQUF5RjtpQkFFbkcsT0FBTztNQUNKOzs7O2lCQUVOO09BQ0csS0FBSyxTQUFTLFdBQVcsS0FDeEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osT0FBTyxRQUFRLEtBQUssV0FDbkIsd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxlQUFlLEtBQUssS0FBSyxLQUFLLE1BQU07U0FDcEMsVUFBVSxLQUFLO1NBQ2YsV0FBVyxzR0FBc0c7bUJBRWhIO1FBQ0ssR0FQRDs7OztlQU9DLENBQ1Q7T0FDRTs7Ozs7T0FFUCx3QkFBQyxPQUFEO1FBQ0UsTUFBSztRQUNMLGNBQVksT0FBTztRQUNuQixhQUFVO1FBQ1YsaUJBQWM7UUFDZCxXQUFVO2tCQUVULEtBQUssU0FBUyxLQUFLLFlBQ2xCLHdCQUFDLGVBQUQsRUFBeUMsUUFBVSxHQUEvQixRQUFROzs7O2VBQXVCLENBQ3BEO09BQ0U7Ozs7O09BQ0osS0FBSyxXQUNKLHdCQUFDLGNBQUQ7UUFBYyxPQUFPLE9BQU87UUFBUyxTQUFTO09BQU87Ozs7O09BRXRELEtBQUssU0FDSix3QkFBQyxPQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7O2tCQUNsQix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFNBQVMsS0FBSztTQUNkLFdBQVcsc0NBQXNDO21CQUVoRCxPQUFPO1FBQ0Y7Ozs7Z0JBQ0w7Ozs7OztPQUVOLEtBQUssU0FBUyxTQUFTLEtBQ3RCLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsU0FBUyxLQUFLO1FBQ2QsVUFBVSxLQUFLO1FBQ2YsV0FBVyxnREFBZ0Q7a0JBRTFELE9BQU87T0FDRjs7Ozs7TUFFVjs7Ozs7TUFFSix3QkFBQyxPQUFELEVBQUssS0FBSyxJQUFNOzs7OztLQUNiOzs7Ozs7SUFDSixRQUNDLHdCQUFDLGFBQUQ7S0FDRSxVQUFVLEtBQUs7S0FDZixPQUFPLFVBQVUsS0FBSyxLQUFLLEtBQUssS0FBSztJQUN0Qzs7Ozs7SUFFSCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUNWLE9BQU87SUFDUDs7Ozs7R0FDSTs7Ozs7WUFFVixDQUFDLFFBQ0Esd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxVQUFEO0lBQ0UsS0FBSztJQUNMLE1BQUs7SUFDTCxpQkFBZTtJQUNmLGVBQWUsU0FBUyxZQUFZLENBQUMsT0FBTztJQUM1QyxXQUFXLDhJQUE4STtjQUwzSixDQU9FLHdCQUFDLE9BQUQ7S0FDRSxlQUFZO0tBQ1osU0FBUTtLQUNSLE1BQUs7S0FDTCxRQUFPO0tBQ1AsYUFBWTtLQUNaLFdBQVU7ZUFOWixDQVFFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDBGQUEyRjs7OztlQUNuRyx3QkFBQyxRQUFELEVBQU0sR0FBRSxxQ0FBc0M7Ozs7YUFDM0M7Ozs7O2NBQ0osT0FBTyxJQUNGOzs7Ozs7RUFDTDs7OztVQUVGOzs7Ozs7QUFFWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0QWlBc3Npc3RhbnQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9ob29rcy91c2VBdXRoJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IGFpVGV4dCB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3V0aWxzL2FpVGV4dCc7XHJcbmltcG9ydCB7IHVzZVByb2R1Y3RBaUFzc2lzdGFudCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZVByb2R1Y3RBaUFzc2lzdGFudCc7XHJcbmltcG9ydCB7IEFpQ2hhdE1lc3NhZ2UgfSBmcm9tICcuL0FpQ2hhdE1lc3NhZ2UnO1xyXG5pbXBvcnQgeyBBaUNoYXRJbnB1dCB9IGZyb20gJy4vQWlDaGF0SW5wdXQnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RBaUFzc2lzdGFudCh7XHJcbiAgcHJvZHVjdElkLFxyXG4gIHByb2R1Y3ROYW1lLFxyXG59OiB7XHJcbiAgcHJvZHVjdElkOiBzdHJpbmc7XHJcbiAgcHJvZHVjdE5hbWU6IHN0cmluZztcclxufSkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8QXNzaXN0YW50UGFuZWxcclxuICAgICAga2V5PXtgJHtwcm9kdWN0SWR9LSR7dXNlcj8uaWQgPz8gJ2d1ZXN0J31gfVxyXG4gICAgICBwcm9kdWN0SWQ9e3Byb2R1Y3RJZH1cclxuICAgICAgcHJvZHVjdE5hbWU9e3Byb2R1Y3ROYW1lfVxyXG4gICAgLz5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBBc3Npc3RhbnRQYW5lbCh7XHJcbiAgcHJvZHVjdElkLFxyXG4gIHByb2R1Y3ROYW1lLFxyXG59OiB7XHJcbiAgcHJvZHVjdElkOiBzdHJpbmc7XHJcbiAgcHJvZHVjdE5hbWU6IHN0cmluZztcclxufSkge1xyXG4gIGNvbnN0IHsgdXNlciwgbG9hZGluZyB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgY2hhdCA9IHVzZVByb2R1Y3RBaUFzc2lzdGFudChwcm9kdWN0SWQpO1xyXG4gIGNvbnN0IGxhdW5jaGVyID0gdXNlUmVmPEhUTUxCdXR0b25FbGVtZW50PihudWxsKTtcclxuICBjb25zdCBoZWFkaW5nID0gdXNlUmVmPEhUTUxIZWFkaW5nRWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgZW5kID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKG9wZW4pIGhlYWRpbmcuY3VycmVudD8uZm9jdXMoKTtcclxuICB9LCBbb3Blbl0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAob3BlbikgZW5kLmN1cnJlbnQ/LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6ICduZWFyZXN0JyB9KTtcclxuICB9LCBbb3BlbiwgY2hhdC5tZXNzYWdlcywgY2hhdC5zZW5kaW5nLCBjaGF0LmVycm9yXSk7XHJcbiAgZnVuY3Rpb24gY2xvc2UoKSB7XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiBsYXVuY2hlci5jdXJyZW50Py5mb2N1cygpKTtcclxuICB9XHJcbiAgY29uc3QgZm9jdXNTdHlsZSA9XHJcbiAgICAnZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW9mZnNldC0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1wcmltYXJ5JztcclxuICByZXR1cm4gKFxyXG4gICAgPGFzaWRlIGNsYXNzTmFtZT1cInByb2R1Y3QtYXNzaXN0YW50IHotNDBcIiBhcmlhLWxhYmVsPXthaVRleHQudGl0bGV9PlxyXG4gICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgIHJvbGU9XCJkaWFsb2dcIlxyXG4gICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwicHJvZHVjdC1haS10aXRsZVwiXHJcbiAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PVwicHJvZHVjdC1haS1jb250ZXh0XCJcclxuICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICBldmVudC5rZXkgPT09ICdUYWInICYmXHJcbiAgICAgICAgICAgICAgd2luZG93Lm1hdGNoTWVkaWEoJyhtYXgtd2lkdGg6IDc2N3B4KScpLm1hdGNoZXNcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgY29udHJvbHMgPSBBcnJheS5mcm9tKFxyXG4gICAgICAgICAgICAgICAgZXZlbnQuY3VycmVudFRhcmdldC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihcclxuICAgICAgICAgICAgICAgICAgJ2J1dHRvbjpub3QoOmRpc2FibGVkKSwgYVtocmVmXSwgdGV4dGFyZWE6bm90KDpkaXNhYmxlZCksIGlucHV0Om5vdCg6ZGlzYWJsZWQpLCBbdGFiaW5kZXg9XCIwXCJdJyxcclxuICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICBjb25zdCBmaXJzdCA9IGNvbnRyb2xzWzBdLFxyXG4gICAgICAgICAgICAgICAgbGFzdCA9IGNvbnRyb2xzW2NvbnRyb2xzLmxlbmd0aCAtIDFdO1xyXG4gICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIGV2ZW50LnNoaWZ0S2V5ICYmXHJcbiAgICAgICAgICAgICAgICAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gZmlyc3QgfHxcclxuICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gaGVhZGluZy5jdXJyZW50KVxyXG4gICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgIGxhc3Q/LmZvY3VzKCk7XHJcbiAgICAgICAgICAgICAgfSBlbHNlIGlmICghZXZlbnQuc2hpZnRLZXkgJiYgZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gbGFzdCkge1xyXG4gICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgIGZpcnN0Py5mb2N1cygpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykge1xyXG4gICAgICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgIGNsb3NlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhaS1wYW5lbCBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1yYWlzZWQgc2hhZG93LWxnXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlci1iIGJvcmRlci1saW5lIGJnLXJhaXNlZCBweC00IHB5LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgPGgyXHJcbiAgICAgICAgICAgICAgICBpZD1cInByb2R1Y3QtYWktdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgcmVmPXtoZWFkaW5nfVxyXG4gICAgICAgICAgICAgICAgdGFiSW5kZXg9ey0xfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZnIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2FpVGV4dC50aXRsZX1cclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgICBpZD1cInByb2R1Y3QtYWktY29udGV4dFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIHRydW5jYXRlIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3ROYW1lfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGV0YWlscyBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgPHN1bW1hcnk+QWJvdXQgdGhpcyBhc3Npc3RhbnQ8L3N1bW1hcnk+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIG1heC13LXhzIGxlYWRpbmctNVwiPnthaVRleHQucHJvdmlkZXJOb3RlfTwvcD5cclxuICAgICAgICAgICAgICA8L2RldGFpbHM+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17Y2xvc2V9XHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YWlUZXh0LmNsb3NlfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaC0xMSB3LTExIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXNtIHRleHQtZmctc2Vjb25kYXJ5IGhvdmVyOmJnLXN1YnRsZSAke2ZvY3VzU3R5bGV9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIOKclVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvaGVhZGVyPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC0wIGZsZXgtMSBvdmVyZmxvdy15LWF1dG8gb3ZlcnNjcm9sbC1jb250YWluIHAtNFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIHthaVRleHQuZ3JlZXRpbmd9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPExvYWRpbmdTdGF0ZSBsYWJlbD17YWlUZXh0LmNoZWNraW5nfSBjb21wYWN0PXt0cnVlfSAvPlxyXG4gICAgICAgICAgICApIDogIXVzZXIgPyAoXHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPXtST1VURVMubG9naW59XHJcbiAgICAgICAgICAgICAgICBzdGF0ZT17eyBmcm9tOiBsb2NhdGlvbi5wYXRobmFtZSArIGxvY2F0aW9uLnNlYXJjaCB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbXQtNCBpbmxpbmUtYmxvY2sgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHB4LTQgcHktMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcHJpbWFyeS1vbiAke2ZvY3VzU3R5bGV9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7YWlUZXh0LnNpZ25Jbn1cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIHtjaGF0Lm1lc3NhZ2VzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGZsZXgtY29sIGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FpVGV4dC5wcm9tcHRzLm1hcCgocHJvbXB0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cHJvbXB0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBjaGF0LnNlbmQocHJvbXB0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NoYXQuc2VuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLXByaW1hcnkgcHgtMyBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIHRleHQtZmctbGluayBob3ZlcjpiZy1wcmltYXJ5LXN1YnRsZSAgJHtmb2N1c1N0eWxlfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9tcHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICByb2xlPVwibG9nXCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YWlUZXh0LmNvbnZlcnNhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1yZWxldmFudD1cImFkZGl0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0zXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2NoYXQubWVzc2FnZXMubWFwKChtZXNzYWdlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEFpQ2hhdE1lc3NhZ2Uga2V5PXttZXNzYWdlLmlkfSBtZXNzYWdlPXttZXNzYWdlfSAvPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge2NoYXQuc2VuZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9e2FpVGV4dC5zZW5kaW5nfSBjb21wYWN0PXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtjaGF0LmVycm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLXNtIGJnLWRhbmdlci1iZyBwLTMgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cD57Y2hhdC5lcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjaGF0LnJldHJ5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbXQtMiByb3VuZGVkIGZvbnQtbWVkaXVtIHVuZGVybGluZSAke2ZvY3VzU3R5bGV9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWlUZXh0LnJldHJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7Y2hhdC5tZXNzYWdlcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NoYXQucmVzZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NoYXQuc2VuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtdC0zIHJvdW5kZWQgdGV4dC14cyB0ZXh0LWZnLWxpbmsgdW5kZXJsaW5lICAke2ZvY3VzU3R5bGV9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHthaVRleHQubmV3Q2hhdH1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8ZGl2IHJlZj17ZW5kfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7dXNlciAmJiAoXHJcbiAgICAgICAgICAgIDxBaUNoYXRJbnB1dFxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtjaGF0LnNlbmRpbmd9XHJcbiAgICAgICAgICAgICAgc2VuZD17KHZhbHVlKSA9PiB2b2lkIGNoYXQuc2VuZCh2YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHgtNCBwYi00IHRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAge2FpVGV4dC5ub3RlfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgKX1cclxuICAgICAgeyFvcGVuICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgcmVmPXtsYXVuY2hlcn1cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e29wZW59XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKGN1cnJlbnQpID0+ICFjdXJyZW50KX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWktbGF1bmNoZXIgZmxleCBoLTEzIGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeSBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LW9uIHNoYWRvdy1sZyBob3ZlcjpiZy1wcmltYXJ5LWhvdmVyICR7Zm9jdXNTdHlsZX1gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuOFwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC01IHctNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIwIDExLjVhNy41IDcuNSAwIDAgMS03LjUgNy41SDVsLTMgM1YxMS41QTcuNSA3LjUgMCAwIDEgOS41IDRoM0E3LjUgNy41IDAgMCAxIDIwIDExLjVaXCIgLz5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwibTE3IDIgMS0yIDEgMiAyIDEtMiAxLTEgMi0xLTItMi0xWlwiIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICB7YWlUZXh0Lm9wZW59XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvYXNpZGU+XHJcbiAgKTtcclxufVxyXG4iXX0=