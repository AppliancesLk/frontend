import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Themes/components/ThemePreview.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { BrandLogo } from "/src/components/common/BrandLogo.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import { SeasonalGreeting } from "/src/components/seasonal/SeasonalGreeting.tsx";
import { seasonalPresets, seasonalText as t } from "/src/utils/seasonalText.ts";
import { DEFAULT_SEASONAL_THEME } from "/src/types/seasonal-theme.types.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemePreview.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function ThemePreview({ draft, dark }) {
	const preset = seasonalPresets[draft.theme];
	const appearance = {
		...DEFAULT_SEASONAL_THEME,
		theme: draft.theme,
		headline: draft.headline || preset.headline,
		message: draft.message || preset.message,
		showGreeting: draft.showGreeting,
		decorations: draft.decorations,
		animations: draft.animations
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "season-preview",
		"data-testid": "season-preview",
		"data-theme": dark ? "dark" : "light",
		"data-season": draft.theme !== "DEFAULT" ? draft.theme : undefined,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "season-preview-header flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV(BrandLogo, {
					theme: draft.theme,
					decorations: draft.decorations
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Icon, {
					name: "bag",
					className: "h-5 w-5 shrink-0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SeasonalGreeting, { appearance }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 sm:p-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "font-display text-xl font-semibold",
							children: "Good things for every day."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { className: "h-2 w-2 shrink-0 rounded-full bg-primary" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-fg-secondary",
						children: "Your next upgrade, with a little seasonal charm."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-5 grid grid-cols-2 gap-3",
						"aria-hidden": "true",
						children: ["appliance", "phone"].map((icon) => /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-hidden rounded-md border border-line bg-surface",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-24 items-center justify-center bg-subtle",
								children: /* @__PURE__ */ _jsxDEV(Icon, {
									name: icon,
									className: "h-10 w-10 text-fg-muted"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 57,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2 p-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { className: "h-2 w-3/4 rounded-full bg-line" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "h-2 w-1/2 rounded-full bg-line-subtle" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 61,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "mt-3 h-6 rounded-sm bg-primary-subtle" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 15
							}, this)]
						}, icon, true, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "ui-button ui-button-primary mt-5 w-full",
						children: t.browse
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
}
_c = ThemePreview;
var _c;
$RefreshReg$(_c, "ThemePreview");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Themes/components/ThemePreview.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemePreview.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemePreview.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemePreview.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQ0UsaUJBQ0EsZ0JBQWdCLFNBQ1g7QUFDUCxTQUFTLDhCQUE4Qjs7O0FBR3ZDLE9BQU8sU0FBUyxhQUFhLEVBQzNCLE9BQ0EsUUFJQztDQUNELE1BQU0sU0FBUyxnQkFBZ0IsTUFBTTtDQUNyQyxNQUFNLGFBQWE7RUFDakIsR0FBRztFQUNILE9BQU8sTUFBTTtFQUNiLFVBQVUsTUFBTSxZQUFZLE9BQU87RUFDbkMsU0FBUyxNQUFNLFdBQVcsT0FBTztFQUNqQyxjQUFjLE1BQU07RUFDcEIsYUFBYSxNQUFNO0VBQ25CLFlBQVksTUFBTTtDQUNwQjtDQUNBLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVU7RUFDVixlQUFZO0VBQ1osY0FBWSxPQUFPLFNBQVM7RUFDNUIsZUFBYSxNQUFNLFVBQVUsWUFBWSxNQUFNLFFBQVE7WUFKekQ7R0FNRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsV0FBRDtLQUFXLE9BQU8sTUFBTTtLQUFPLGFBQWEsTUFBTTtJQUFjOzs7O2NBQ2hFLHdCQUFDLE1BQUQ7S0FBTSxNQUFLO0tBQU0sV0FBVTtJQUFvQjs7OztZQUM1Qzs7Ozs7O0dBQ0wsd0JBQUMsa0JBQUQsRUFBOEIsV0FBYTs7Ozs7R0FDM0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXFDO01BRS9DOzs7O2dCQUNILHdCQUFDLFFBQUQsRUFBTSxXQUFVLDJDQUE0Qzs7OztjQUN6RDs7Ozs7O0tBQ0wsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWlDO0tBRTNDOzs7OztLQUNILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQThCLGVBQVk7Z0JBQ3JELENBQUMsYUFBYSxPQUFPLENBQUMsQ0FBVyxLQUFLLFNBQ3RDLHdCQUFDLE9BQUQ7T0FFRSxXQUFVO2lCQUZaLENBSUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsTUFBRDtTQUFNLE1BQU07U0FBTSxXQUFVO1FBQTJCOzs7OztPQUNwRDs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGlDQUFrQzs7Ozs7U0FDakQsd0JBQUMsT0FBRCxFQUFLLFdBQVUsd0NBQXlDOzs7OztTQUN4RCx3QkFBQyxPQUFELEVBQUssV0FBVSx3Q0FBeUM7Ozs7O1FBQ3JEOzs7OztlQUNGO1NBWEU7Ozs7YUFXRixDQUNOO0tBQ0U7Ozs7O0tBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQ2IsRUFBRTtLQUNDOzs7OztJQUNIOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGhlbWVQcmV2aWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCcmFuZExvZ28gfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9CcmFuZExvZ28nO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IFNlYXNvbmFsR3JlZXRpbmcgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3NlYXNvbmFsL1NlYXNvbmFsR3JlZXRpbmcnO1xyXG5pbXBvcnQge1xyXG4gIHNlYXNvbmFsUHJlc2V0cyxcclxuICBzZWFzb25hbFRleHQgYXMgdCxcclxufSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9zZWFzb25hbFRleHQnO1xyXG5pbXBvcnQgeyBERUZBVUxUX1NFQVNPTkFMX1RIRU1FIH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvc2Vhc29uYWwtdGhlbWUudHlwZXMnO1xyXG5pbXBvcnQgdHlwZSB7IFRoZW1lRHJhZnQgfSBmcm9tICcuLi9oZWxwZXJzL3RoZW1lLmhlbHBlcnMnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFRoZW1lUHJldmlldyh7XHJcbiAgZHJhZnQsXHJcbiAgZGFyayxcclxufToge1xyXG4gIGRyYWZ0OiBUaGVtZURyYWZ0O1xyXG4gIGRhcms6IGJvb2xlYW47XHJcbn0pIHtcclxuICBjb25zdCBwcmVzZXQgPSBzZWFzb25hbFByZXNldHNbZHJhZnQudGhlbWVdO1xyXG4gIGNvbnN0IGFwcGVhcmFuY2UgPSB7XHJcbiAgICAuLi5ERUZBVUxUX1NFQVNPTkFMX1RIRU1FLFxyXG4gICAgdGhlbWU6IGRyYWZ0LnRoZW1lLFxyXG4gICAgaGVhZGxpbmU6IGRyYWZ0LmhlYWRsaW5lIHx8IHByZXNldC5oZWFkbGluZSxcclxuICAgIG1lc3NhZ2U6IGRyYWZ0Lm1lc3NhZ2UgfHwgcHJlc2V0Lm1lc3NhZ2UsXHJcbiAgICBzaG93R3JlZXRpbmc6IGRyYWZ0LnNob3dHcmVldGluZyxcclxuICAgIGRlY29yYXRpb25zOiBkcmFmdC5kZWNvcmF0aW9ucyxcclxuICAgIGFuaW1hdGlvbnM6IGRyYWZ0LmFuaW1hdGlvbnMsXHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJzZWFzb24tcHJldmlld1wiXHJcbiAgICAgIGRhdGEtdGVzdGlkPVwic2Vhc29uLXByZXZpZXdcIlxyXG4gICAgICBkYXRhLXRoZW1lPXtkYXJrID8gJ2RhcmsnIDogJ2xpZ2h0J31cclxuICAgICAgZGF0YS1zZWFzb249e2RyYWZ0LnRoZW1lICE9PSAnREVGQVVMVCcgPyBkcmFmdC50aGVtZSA6IHVuZGVmaW5lZH1cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFzb24tcHJldmlldy1oZWFkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgPEJyYW5kTG9nbyB0aGVtZT17ZHJhZnQudGhlbWV9IGRlY29yYXRpb25zPXtkcmFmdC5kZWNvcmF0aW9uc30gLz5cclxuICAgICAgICA8SWNvbiBuYW1lPVwiYmFnXCIgY2xhc3NOYW1lPVwiaC01IHctNSBzaHJpbmstMFwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8U2Vhc29uYWxHcmVldGluZyBhcHBlYXJhbmNlPXthcHBlYXJhbmNlfSAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBzbTpwLTZcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICBHb29kIHRoaW5ncyBmb3IgZXZlcnkgZGF5LlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0yIHctMiBzaHJpbmstMCByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICBZb3VyIG5leHQgdXBncmFkZSwgd2l0aCBhIGxpdHRsZSBzZWFzb25hbCBjaGFybS5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICAgIHsoWydhcHBsaWFuY2UnLCAncGhvbmUnXSBhcyBjb25zdCkubWFwKChpY29uKSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e2ljb259XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2VcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMjQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXN1YnRsZVwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT17aWNvbn0gY2xhc3NOYW1lPVwiaC0xMCB3LTEwIHRleHQtZmctbXV0ZWRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgdy0zLzQgcm91bmRlZC1mdWxsIGJnLWxpbmVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgdy0xLzIgcm91bmRlZC1mdWxsIGJnLWxpbmUtc3VidGxlXCIgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBoLTYgcm91bmRlZC1zbSBiZy1wcmltYXJ5LXN1YnRsZVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1wcmltYXJ5IG10LTUgdy1mdWxsXCI+XHJcbiAgICAgICAgICB7dC5icm93c2V9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19