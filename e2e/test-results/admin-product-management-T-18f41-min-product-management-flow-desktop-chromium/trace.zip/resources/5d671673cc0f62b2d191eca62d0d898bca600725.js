import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_URL": "http://localhost:3001"};import axios from "/node_modules/.vite/deps/axios.js?v=50079ced";
const apiClient = axios.create({
	baseURL: import.meta.env.VITE_API_URL ?? "http://localhost:3000",
	withCredentials: true,
	headers: {
		"Content-Type": "application/json",
		"X-Requested-With": "XMLHttpRequest"
	}
});
export default apiClient;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE1BQU0sWUFBWSxNQUFNLE9BQU87Q0FDN0IsU0FBUyxZQUFZLElBQUksZ0JBQWdCO0NBQ3pDLGlCQUFpQjtDQUNqQixTQUFTO0VBQ1AsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtDQUN0QjtBQUNGLENBQUM7QUFFRCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImFwaUNsaWVudC50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xuXG5jb25zdCBhcGlDbGllbnQgPSBheGlvcy5jcmVhdGUoe1xuICBiYXNlVVJMOiBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfVVJMID8/ICdodHRwOi8vbG9jYWxob3N0OjMwMDAnLFxuICB3aXRoQ3JlZGVudGlhbHM6IHRydWUsXG4gIGhlYWRlcnM6IHtcbiAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICdYLVJlcXVlc3RlZC1XaXRoJzogJ1hNTEh0dHBSZXF1ZXN0JyxcbiAgfSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBhcGlDbGllbnQ7XG4iXX0=