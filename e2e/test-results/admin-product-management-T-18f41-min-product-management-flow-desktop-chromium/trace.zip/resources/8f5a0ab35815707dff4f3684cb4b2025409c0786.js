import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductInformation.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { formatCategoryName } from "/src/utils/category.ts";
import { Rating } from "/src/components/common/Rating.tsx";
import { RatingPlate } from "/src/components/common/RatingPlate.tsx";
import { CopyReference } from "/src/components/common/CopyReference.tsx";
import { translations } from "/src/utils/translations.ts";
import { formatSpecificationValue, getSpecificationEntries, formatSpecificationLabel } from "/src/pages/Customer/ProductDetails/helpers/product-details.helpers.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductInformation.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.experience;
export function ProductInformation({ product, showReviews }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "min-w-0 py-2",
		children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mb-3 text-sm font-medium text-fg-link",
				children: product.brand || formatCategoryName(product.category.name)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title break-words    text-fg",
				children: product.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			product.subtitle && /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 inline-flex rounded-sm border border-line bg-surface px-3 py-2 text-sm text-fg-secondary",
				children: product.subtitle
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 flex flex-wrap items-center gap-4",
				children: [(product.ratingCount ?? 0) > 0 && /* @__PURE__ */ _jsxDEV(Rating, {
					average: product.ratingAverage ?? 0,
					count: product.ratingCount ?? 0
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: showReviews,
					className: "rounded-sm px-2 py-2 text-sm font-medium text-fg-link hover:bg-primary-subtle",
					children: (product.ratingCount ?? 0) > 0 ? "Read reviews" : "No reviews yet"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-5 line-clamp-3 whitespace-pre-line text-sm leading-7 text-fg-secondary",
				children: product.description || t.noDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-4 flex flex-wrap items-center gap-1 text-xs text-fg-muted",
				children: [
					"SKU ",
					/* @__PURE__ */ _jsxDEV("span", {
						className: "tnum",
						children: product.SKU
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(CopyReference, { value: product.SKU }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 7
			}, this),
			getSpecificationEntries(product.specifications).length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6",
				children: /* @__PURE__ */ _jsxDEV(RatingPlate, {
					title: product.brand || "Product specifications",
					reference: product.SKU,
					rows: getSpecificationEntries(product.specifications).slice(0, 5).map(([label, value]) => ({
						label: formatSpecificationLabel(label),
						value: formatSpecificationValue(value)
					}))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 5
	}, this);
}
_c = ProductInformation;
var _c;
$RefreshReg$(_c, "ProductInformation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductInformation.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductInformation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductInformation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductInformation.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFFbkMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQ0UsMEJBQ0EseUJBQ0EsZ0NBQ0s7OztBQUNQLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxtQkFBbUIsRUFDakMsU0FDQSxlQUlDO0NBQ0QsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsUUFBUSxTQUFTLG1CQUFtQixRQUFRLFNBQVMsSUFBSTtHQUN6RDs7Ozs7R0FDSCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF3QyxRQUFRO0dBQVM7Ozs7O0dBQ3RFLFFBQVEsWUFDUCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNWLFFBQVE7R0FDUjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLEVBQ0ksUUFBUSxlQUFlLEtBQUssS0FDNUIsd0JBQUMsUUFBRDtLQUNFLFNBQVMsUUFBUSxpQkFBaUI7S0FDbEMsT0FBTyxRQUFRLGVBQWU7SUFDL0I7Ozs7Y0FFSCx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7Z0JBRVIsUUFBUSxlQUFlLEtBQUssSUFBSSxpQkFBaUI7SUFDN0M7Ozs7WUFDTDs7Ozs7O0dBQ0wsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixRQUFRLGVBQWUsRUFBRTtHQUN6Qjs7Ozs7R0FDSCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQTRFO0tBQ3RFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFRLFFBQVE7S0FBVTs7Ozs7S0FDOUMsd0JBQUMsZUFBRCxFQUFlLE9BQU8sUUFBUSxJQUFNOzs7OztJQUNuQzs7Ozs7O0dBQ0Ysd0JBQXdCLFFBQVEsY0FBYyxDQUFDLENBQUMsU0FBUyxLQUN4RCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLGFBQUQ7S0FDRSxPQUFPLFFBQVEsU0FBUztLQUN4QixXQUFXLFFBQVE7S0FDbkIsTUFBTSx3QkFBd0IsUUFBUSxjQUFjLENBQUMsQ0FDbEQsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUNYLEtBQUssQ0FBQyxPQUFPLFlBQVk7TUFDeEIsT0FBTyx5QkFBeUIsS0FBSztNQUNyQyxPQUFPLHlCQUF5QixLQUFLO0tBQ3ZDLEVBQUU7SUFDTDs7Ozs7R0FDRTs7Ozs7RUFFQTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEluZm9ybWF0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRDYXRlZ29yeU5hbWUgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9jYXRlZ29yeSc7XHJcbmltcG9ydCB0eXBlIHsgUHJvZHVjdCB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3Byb2R1Y3QudHlwZXMnO1xyXG5pbXBvcnQgeyBSYXRpbmcgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9SYXRpbmcnO1xyXG5pbXBvcnQgeyBSYXRpbmdQbGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JhdGluZ1BsYXRlJztcclxuaW1wb3J0IHsgQ29weVJlZmVyZW5jZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0NvcHlSZWZlcmVuY2UnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQge1xyXG4gIGZvcm1hdFNwZWNpZmljYXRpb25WYWx1ZSxcclxuICBnZXRTcGVjaWZpY2F0aW9uRW50cmllcyxcclxuICBmb3JtYXRTcGVjaWZpY2F0aW9uTGFiZWwsXHJcbn0gZnJvbSAnLi4vaGVscGVycy9wcm9kdWN0LWRldGFpbHMuaGVscGVycyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuZXhwZXJpZW5jZTtcclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RJbmZvcm1hdGlvbih7XHJcbiAgcHJvZHVjdCxcclxuICBzaG93UmV2aWV3cyxcclxufToge1xyXG4gIHByb2R1Y3Q6IFByb2R1Y3Q7XHJcbiAgc2hvd1Jldmlld3M6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibWluLXctMCBweS0yXCI+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmtcIj5cclxuICAgICAgICB7cHJvZHVjdC5icmFuZCB8fCBmb3JtYXRDYXRlZ29yeU5hbWUocHJvZHVjdC5jYXRlZ29yeS5uYW1lKX1cclxuICAgICAgPC9wPlxyXG4gICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSBicmVhay13b3JkcyAgICB0ZXh0LWZnXCI+e3Byb2R1Y3QubmFtZX08L2gxPlxyXG4gICAgICB7cHJvZHVjdC5zdWJ0aXRsZSAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyBpbmxpbmUtZmxleCByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICB7cHJvZHVjdC5zdWJ0aXRsZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICB7KHByb2R1Y3QucmF0aW5nQ291bnQgPz8gMCkgPiAwICYmIChcclxuICAgICAgICAgIDxSYXRpbmdcclxuICAgICAgICAgICAgYXZlcmFnZT17cHJvZHVjdC5yYXRpbmdBdmVyYWdlID8/IDB9XHJcbiAgICAgICAgICAgIGNvdW50PXtwcm9kdWN0LnJhdGluZ0NvdW50ID8/IDB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17c2hvd1Jldmlld3N9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIHB4LTIgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3ZlcjpiZy1wcmltYXJ5LXN1YnRsZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgeyhwcm9kdWN0LnJhdGluZ0NvdW50ID8/IDApID4gMCA/ICdSZWFkIHJldmlld3MnIDogJ05vIHJldmlld3MgeWV0J31cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTUgbGluZS1jbGFtcC0zIHdoaXRlc3BhY2UtcHJlLWxpbmUgdGV4dC1zbSBsZWFkaW5nLTcgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICB7cHJvZHVjdC5kZXNjcmlwdGlvbiB8fCB0Lm5vRGVzY3JpcHRpb259XHJcbiAgICAgIDwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgU0tVIDxzcGFuIGNsYXNzTmFtZT1cInRudW1cIj57cHJvZHVjdC5TS1V9PC9zcGFuPlxyXG4gICAgICAgIDxDb3B5UmVmZXJlbmNlIHZhbHVlPXtwcm9kdWN0LlNLVX0gLz5cclxuICAgICAgPC9wPlxyXG4gICAgICB7Z2V0U3BlY2lmaWNhdGlvbkVudHJpZXMocHJvZHVjdC5zcGVjaWZpY2F0aW9ucykubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICA8UmF0aW5nUGxhdGVcclxuICAgICAgICAgICAgdGl0bGU9e3Byb2R1Y3QuYnJhbmQgfHwgJ1Byb2R1Y3Qgc3BlY2lmaWNhdGlvbnMnfVxyXG4gICAgICAgICAgICByZWZlcmVuY2U9e3Byb2R1Y3QuU0tVfVxyXG4gICAgICAgICAgICByb3dzPXtnZXRTcGVjaWZpY2F0aW9uRW50cmllcyhwcm9kdWN0LnNwZWNpZmljYXRpb25zKVxyXG4gICAgICAgICAgICAgIC5zbGljZSgwLCA1KVxyXG4gICAgICAgICAgICAgIC5tYXAoKFtsYWJlbCwgdmFsdWVdKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgbGFiZWw6IGZvcm1hdFNwZWNpZmljYXRpb25MYWJlbChsYWJlbCksXHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogZm9ybWF0U3BlY2lmaWNhdGlvblZhbHVlKHZhbHVlKSxcclxuICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19