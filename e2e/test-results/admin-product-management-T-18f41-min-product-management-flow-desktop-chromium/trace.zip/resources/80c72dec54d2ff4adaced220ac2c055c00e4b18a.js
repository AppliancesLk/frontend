import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/components/RecipientPicker.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { getAdminUsers } from "/src/services/userService.ts";
import { promotionText as t } from "/src/utils/promotionText.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { Button } from "/src/components/ui/Button.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/RecipientPicker.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function RecipientPicker({ draft, onChange, selectedUsers, onUsers }) {
	_s();
	const [search, setSearch] = useState(""), [page, setPage] = useState(1), [result, setResult] = useState(null), [loading, setLoading] = useState(true), [error, setError] = useState(""), [revision, setRevision] = useState(0), [expanded, setExpanded] = useState(false);
	useEffect(() => {
		const controller = new AbortController();
		const timer = window.setTimeout(async () => {
			setLoading(true);
			setError("");
			try {
				const next = await getAdminUsers({
					page,
					search,
					role: "",
					status: "active"
				}, controller.signal);
				if (!controller.signal.aborted) setResult(next);
			} catch (err) {
				if (!controller.signal.aborted) setError(getApiError(err, "Unable to load users. Please try again."));
			} finally {
				if (!controller.signal.aborted) setLoading(false);
			}
		}, 300);
		return () => {
			controller.abort();
			window.clearTimeout(timer);
		};
	}, [
		search,
		page,
		revision
	]);
	function toggle(user) {
		const has = draft.userIds.includes(user.id);
		onChange({
			...draft,
			userIds: has ? draft.userIds.filter((id) => id !== user.id) : [...draft.userIds, user.id]
		});
		if (!has && !selectedUsers.some((item) => item.id === user.id)) onUsers([...selectedUsers, user]);
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "ui-panel p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-semibold",
				children: t.recipients
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-xs leading-5 text-fg-muted",
				children: t.eligibility
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: ["SELECTED", "ALL"].map((audience) => /* @__PURE__ */ _jsxDEV("label", {
					className: `flex min-h-14 cursor-pointer items-center gap-3 rounded-md border p-3 text-sm ${draft.audience === audience ? "border-primary bg-primary-subtle" : "border-line"}`,
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "radio",
						name: "audience",
						checked: draft.audience === audience,
						onChange: () => onChange({
							...draft,
							audience
						}),
						className: "h-4 w-4 shrink-0 accent-primary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 13
					}, this), audience === "ALL" ? t.all : t.selected]
				}, audience, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 7
			}, this),
			draft.audience === "SELECTED" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex flex-wrap items-center justify-between gap-2 text-xs",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "font-semibold",
						children: [
							draft.userIds.length,
							" / 1000 ",
							t.selectedCount
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this), draft.userIds.length > 0 && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "underline",
						onClick: () => onChange({
							...draft,
							userIds: []
						}),
						children: "Clear selection"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this),
				draft.userIds.length > 0 && /* @__PURE__ */ _jsxDEV("ul", {
					className: "mt-3 space-y-2",
					children: draft.userIds.slice(0, expanded ? undefined : 5).map((id) => {
						const user = selectedUsers.find((item) => item.id === id);
						return /* @__PURE__ */ _jsxDEV("li", {
							className: "flex min-w-0 items-center justify-between gap-3 rounded-md bg-subtle px-3 py-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "min-w-0 break-all",
								children: user ? `${user.username} · ${user.email}` : "Unavailable account"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-label": `Remove ${user?.username ?? "account"}`,
								className: "shrink-0 px-2 py-1 underline",
								onClick: () => onChange({
									...draft,
									userIds: draft.userIds.filter((value) => value !== id)
								}),
								children: "Remove"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 21
							}, this)]
						}, id, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 19
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 13
				}, this),
				draft.userIds.length > 5 && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "mt-2 text-xs underline",
					onClick: () => setExpanded(!expanded),
					children: expanded ? "Show fewer" : "Show all selected users"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "auth-label mt-4",
					htmlFor: "promotion-user-search",
					children: t.recipientSearch
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: "promotion-user-search",
					className: "ui-field",
					type: "search",
					value: search,
					maxLength: 100,
					onChange: (e) => {
						setSearch(e.target.value);
						setPage(1);
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 11
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "mt-3 text-sm text-danger",
					children: [
						error,
						" ",
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "underline",
							onClick: () => setRevision((n) => n + 1),
							children: "Retry"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 13
				}, this),
				loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { compact: true }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-3 max-h-64 overflow-y-auto rounded-md border border-line",
					children: result?.items.length ? result.items.map((user) => /* @__PURE__ */ _jsxDEV("label", {
						className: "flex cursor-pointer items-start gap-3 border-b border-line px-3 py-3 last:border-0 hover:bg-subtle",
						children: [/* @__PURE__ */ _jsxDEV("input", {
							type: "checkbox",
							"aria-label": `Select user ${user.username}`,
							checked: draft.userIds.includes(user.id),
							disabled: draft.userIds.length >= 1e3 && !draft.userIds.includes(user.id),
							onChange: () => toggle(user),
							className: "mt-1 h-4 w-4 shrink-0 accent-primary"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "min-w-0 text-sm",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "block font-medium",
								children: user.username
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 23
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "mt-1 block break-all text-xs text-fg-muted",
								children: user.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 23
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 21
						}, this)]
					}, user.id, true, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 19
					}, this)) : /* @__PURE__ */ _jsxDEV("p", {
						className: "p-4 text-sm text-fg-muted",
						children: "No matching users."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-3 flex items-center justify-between gap-2 text-xs",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: [result?.total ?? 0, " eligible users"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							disabled: page <= 1 || loading,
							onClick: () => setPage(page - 1),
							children: "Previous"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							disabled: loading || !result || page * result.limit >= result.total,
							onClick: () => setPage(page + 1),
							children: "Next"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 204,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 65,
		columnNumber: 5
	}, this);
}
_s(RecipientPicker, "57rLjOBIHjMb0tZu0bmbjKXdFK8=");
_c = RecipientPicker;
var _c;
$RefreshReg$(_c, "RecipientPicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/components/RecipientPicker.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/RecipientPicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/RecipientPicker.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/RecipientPicker.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHFCQUFxQjtBQU05QixTQUFTLGlCQUFpQixTQUFTO0FBQ25DLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjs7OztBQUM3QixPQUFPLFNBQVMsZ0JBQWdCLEVBQzlCLE9BQ0EsVUFDQSxlQUNBLFdBTUM7O0NBQ0QsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUUsR0FDckMsQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDLEdBQzVCLENBQUMsUUFBUSxhQUFhLFNBQWtDLElBQUksR0FDNUQsQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJLEdBQ3JDLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRSxHQUMvQixDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUMsR0FDcEMsQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzFDLGdCQUFnQjtFQUNkLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtFQUN2QyxNQUFNLFFBQVEsT0FBTyxXQUFXLFlBQVk7R0FDMUMsV0FBVyxJQUFJO0dBQ2YsU0FBUyxFQUFFO0dBQ1gsSUFBSTtJQUNGLE1BQU0sT0FBTyxNQUFNLGNBQ2pCO0tBQUU7S0FBTTtLQUFRLE1BQU07S0FBSSxRQUFRO0lBQVMsR0FDM0MsV0FBVyxNQUNiO0lBQ0EsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTLFVBQVUsSUFBSTtHQUNoRCxTQUFTLEtBQUs7SUFDWixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQ3JCLFNBQVMsWUFBWSxLQUFLLHlDQUF5QyxDQUFDO0dBQ3hFLFVBQVU7SUFDUixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVMsV0FBVyxLQUFLO0dBQ2xEO0VBQ0YsR0FBRyxHQUFHO0VBQ04sYUFBYTtHQUNYLFdBQVcsTUFBTTtHQUNqQixPQUFPLGFBQWEsS0FBSztFQUMzQjtDQUNGLEdBQUc7RUFBQztFQUFRO0VBQU07Q0FBUSxDQUFDO0NBQzNCLFNBQVMsT0FBTyxNQUFxQjtFQUNuQyxNQUFNLE1BQU0sTUFBTSxRQUFRLFNBQVMsS0FBSyxFQUFFO0VBQzFDLFNBQVM7R0FDUCxHQUFHO0dBQ0gsU0FBUyxNQUNMLE1BQU0sUUFBUSxRQUFRLE9BQU8sT0FBTyxLQUFLLEVBQUUsSUFDM0MsQ0FBQyxHQUFHLE1BQU0sU0FBUyxLQUFLLEVBQUU7RUFDaEMsQ0FBQztFQUNELElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxNQUFNLFNBQVMsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUMzRCxRQUFRLENBQUMsR0FBRyxlQUFlLElBQUksQ0FBQztDQUNwQztDQUNBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF5QixFQUFFO0dBQWU7Ozs7O0dBQ3hELHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXdDLEVBQUU7R0FBZTs7Ozs7R0FDdEUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWCxDQUFDLFlBQVksS0FBSyxDQUFDLENBQVcsS0FBSyxhQUNuQyx3QkFBQyxTQUFEO0tBRUUsV0FBVyxpRkFBaUYsTUFBTSxhQUFhLFdBQVcscUNBQXFDO2VBRmpLLENBSUUsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxNQUFLO01BQ0wsU0FBUyxNQUFNLGFBQWE7TUFDNUIsZ0JBQWdCLFNBQVM7T0FBRSxHQUFHO09BQU87TUFBUyxDQUFDO01BQy9DLFdBQVU7S0FDWDs7OztlQUNBLGFBQWEsUUFBUSxFQUFFLE1BQU0sRUFBRSxRQUMzQjtPQVhBOzs7O1dBV0EsQ0FDUjtHQUNFOzs7OztHQUNKLE1BQU0sYUFBYSxjQUNsQjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUNHLE1BQU0sUUFBUTtPQUFPO09BQVMsRUFBRTtNQUNoQzs7Ozs7ZUFDRixNQUFNLFFBQVEsU0FBUyxLQUN0Qix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7TUFDVixlQUFlLFNBQVM7T0FBRSxHQUFHO09BQU8sU0FBUyxDQUFDO01BQUUsQ0FBQztnQkFDbEQ7S0FFTzs7OzthQUVQOzs7Ozs7SUFDSixNQUFNLFFBQVEsU0FBUyxLQUN0Qix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLE1BQU0sUUFBUSxNQUFNLEdBQUcsV0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTztNQUM1RCxNQUFNLE9BQU8sY0FBYyxNQUFNLFNBQVMsS0FBSyxPQUFPLEVBQUU7TUFDeEQsT0FDRSx3QkFBQyxNQUFEO09BRUUsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLE9BQ0csR0FBRyxLQUFLLFNBQVMsS0FBSyxLQUFLLFVBQzNCO09BQ0E7Ozs7aUJBQ04sd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxjQUFZLFVBQVUsTUFBTSxZQUFZO1FBQ3hDLFdBQVU7UUFDVixlQUNFLFNBQVM7U0FDUCxHQUFHO1NBQ0gsU0FBUyxNQUFNLFFBQVEsUUFDcEIsVUFBVSxVQUFVLEVBQ3ZCO1FBQ0YsQ0FBQztrQkFFSjtPQUVPOzs7O2VBQ047U0F2Qkc7Ozs7YUF1Qkg7S0FFUixDQUFDO0lBQ0M7Ozs7O0lBRUwsTUFBTSxRQUFRLFNBQVMsS0FDdEIsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsZUFBZSxZQUFZLENBQUMsUUFBUTtlQUVuQyxXQUFXLGVBQWU7SUFDckI7Ozs7O0lBRVYsd0JBQUMsU0FBRDtLQUFPLFdBQVU7S0FBa0IsU0FBUTtlQUN4QyxFQUFFO0lBQ0U7Ozs7O0lBQ1Asd0JBQUMsU0FBRDtLQUNFLElBQUc7S0FDSCxXQUFVO0tBQ1YsTUFBSztLQUNMLE9BQU87S0FDUCxXQUFXO0tBQ1gsV0FBVyxNQUFNO01BQ2YsVUFBVSxFQUFFLE9BQU8sS0FBSztNQUN4QixRQUFRLENBQUM7S0FDWDtJQUNEOzs7OztJQUNBLFNBQ0Msd0JBQUMsS0FBRDtLQUFHLE1BQUs7S0FBUSxXQUFVO2VBQTFCO01BQ0c7TUFBTztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtPQUNWLGVBQWUsYUFBYSxNQUFNLElBQUksQ0FBQztpQkFDeEM7TUFFTzs7Ozs7S0FDUDs7Ozs7O0lBRUosVUFDQyx3QkFBQyxjQUFELEVBQWMsY0FBUzs7OztlQUV2Qix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFFBQVEsTUFBTSxTQUNiLE9BQU8sTUFBTSxLQUFLLFNBQ2hCLHdCQUFDLFNBQUQ7TUFFRSxXQUFVO2dCQUZaLENBSUUsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxjQUFZLGVBQWUsS0FBSztPQUNoQyxTQUFTLE1BQU0sUUFBUSxTQUFTLEtBQUssRUFBRTtPQUN2QyxVQUNFLE1BQU0sUUFBUSxVQUFVLE9BQ3hCLENBQUMsTUFBTSxRQUFRLFNBQVMsS0FBSyxFQUFFO09BRWpDLGdCQUFnQixPQUFPLElBQUk7T0FDM0IsV0FBVTtNQUNYOzs7O2dCQUNELHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFxQixLQUFLO09BQWU7Ozs7aUJBQ3pELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLEtBQUs7T0FDRjs7OztlQUNGOzs7OztjQUNEO1FBcEJBLEtBQUs7Ozs7WUFvQkwsQ0FDUixJQUVELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE0QjtLQUFxQjs7Ozs7SUFFN0Q7Ozs7O0lBRVAsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLEtBQUQsYUFBSSxRQUFRLFNBQVMsR0FBRSxpQkFBa0I7Ozs7ZUFDekMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQ0UsU0FBUTtPQUNSLFVBQVUsUUFBUSxLQUFLO09BQ3ZCLGVBQWUsUUFBUSxPQUFPLENBQUM7aUJBQ2hDO01BRU87Ozs7Z0JBQ1Isd0JBQUMsUUFBRDtPQUNFLFNBQVE7T0FDUixVQUNFLFdBQVcsQ0FBQyxVQUFVLE9BQU8sT0FBTyxTQUFTLE9BQU87T0FFdEQsZUFBZSxRQUFRLE9BQU8sQ0FBQztpQkFDaEM7TUFFTzs7OztjQUNMOzs7OzthQUNGOzs7Ozs7R0FDTDs7Ozs7RUFFRzs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVjaXBpZW50UGlja2VyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBnZXRBZG1pblVzZXJzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2VydmljZXMvdXNlclNlcnZpY2UnO1xyXG5pbXBvcnQgdHlwZSB7IEFkbWluVXNlcnNSZXN1bHQgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy91c2VyLnR5cGVzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIFByb21vdGlvbkNvbnRlbnQsXHJcbiAgUHJvbW90aW9uVXNlcixcclxufSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9wcm9tb3Rpb24udHlwZXMnO1xyXG5pbXBvcnQgeyBwcm9tb3Rpb25UZXh0IGFzIHQgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9wcm9tb3Rpb25UZXh0JztcclxuaW1wb3J0IHsgZ2V0QXBpRXJyb3IgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9hcGlFcnJvcnMnO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0J1dHRvbic7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5leHBvcnQgZnVuY3Rpb24gUmVjaXBpZW50UGlja2VyKHtcclxuICBkcmFmdCxcclxuICBvbkNoYW5nZSxcclxuICBzZWxlY3RlZFVzZXJzLFxyXG4gIG9uVXNlcnMsXHJcbn06IHtcclxuICBkcmFmdDogUHJvbW90aW9uQ29udGVudDtcclxuICBvbkNoYW5nZTogKHZhbHVlOiBQcm9tb3Rpb25Db250ZW50KSA9PiB2b2lkO1xyXG4gIHNlbGVjdGVkVXNlcnM6IFByb21vdGlvblVzZXJbXTtcclxuICBvblVzZXJzOiAodmFsdWU6IFByb21vdGlvblVzZXJbXSkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyksXHJcbiAgICBbcGFnZSwgc2V0UGFnZV0gPSB1c2VTdGF0ZSgxKSxcclxuICAgIFtyZXN1bHQsIHNldFJlc3VsdF0gPSB1c2VTdGF0ZTxBZG1pblVzZXJzUmVzdWx0IHwgbnVsbD4obnVsbCksXHJcbiAgICBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKSxcclxuICAgIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpLFxyXG4gICAgW3JldmlzaW9uLCBzZXRSZXZpc2lvbl0gPSB1c2VTdGF0ZSgwKSxcclxuICAgIFtleHBhbmRlZCwgc2V0RXhwYW5kZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dChhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9yKCcnKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBuZXh0ID0gYXdhaXQgZ2V0QWRtaW5Vc2VycyhcclxuICAgICAgICAgIHsgcGFnZSwgc2VhcmNoLCByb2xlOiAnJywgc3RhdHVzOiAnYWN0aXZlJyB9LFxyXG4gICAgICAgICAgY29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHNldFJlc3VsdChuZXh0KTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKVxyXG4gICAgICAgICAgc2V0RXJyb3IoZ2V0QXBpRXJyb3IoZXJyLCAnVW5hYmxlIHRvIGxvYWQgdXNlcnMuIFBsZWFzZSB0cnkgYWdhaW4uJykpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH0sIDMwMCk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBjb250cm9sbGVyLmFib3J0KCk7XHJcbiAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgfTtcclxuICB9LCBbc2VhcmNoLCBwYWdlLCByZXZpc2lvbl0pO1xyXG4gIGZ1bmN0aW9uIHRvZ2dsZSh1c2VyOiBQcm9tb3Rpb25Vc2VyKSB7XHJcbiAgICBjb25zdCBoYXMgPSBkcmFmdC51c2VySWRzLmluY2x1ZGVzKHVzZXIuaWQpO1xyXG4gICAgb25DaGFuZ2Uoe1xyXG4gICAgICAuLi5kcmFmdCxcclxuICAgICAgdXNlcklkczogaGFzXHJcbiAgICAgICAgPyBkcmFmdC51c2VySWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB1c2VyLmlkKVxyXG4gICAgICAgIDogWy4uLmRyYWZ0LnVzZXJJZHMsIHVzZXIuaWRdLFxyXG4gICAgfSk7XHJcbiAgICBpZiAoIWhhcyAmJiAhc2VsZWN0ZWRVc2Vycy5zb21lKChpdGVtKSA9PiBpdGVtLmlkID09PSB1c2VyLmlkKSlcclxuICAgICAgb25Vc2VycyhbLi4uc2VsZWN0ZWRVc2VycywgdXNlcl0pO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidWktcGFuZWwgcC01IHNtOnAtNlwiPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+e3QucmVjaXBpZW50c308L2gyPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj57dC5lbGlnaWJpbGl0eX08L3A+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgeyhbJ1NFTEVDVEVEJywgJ0FMTCddIGFzIGNvbnN0KS5tYXAoKGF1ZGllbmNlKSA9PiAoXHJcbiAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAga2V5PXthdWRpZW5jZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBtaW4taC0xNCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1tZCBib3JkZXIgcC0zIHRleHQtc20gJHtkcmFmdC5hdWRpZW5jZSA9PT0gYXVkaWVuY2UgPyAnYm9yZGVyLXByaW1hcnkgYmctcHJpbWFyeS1zdWJ0bGUnIDogJ2JvcmRlci1saW5lJ31gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4gICAgICAgICAgICAgIG5hbWU9XCJhdWRpZW5jZVwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17ZHJhZnQuYXVkaWVuY2UgPT09IGF1ZGllbmNlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBvbkNoYW5nZSh7IC4uLmRyYWZ0LCBhdWRpZW5jZSB9KX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIGFjY2VudC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAge2F1ZGllbmNlID09PSAnQUxMJyA/IHQuYWxsIDogdC5zZWxlY3RlZH1cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7ZHJhZnQuYXVkaWVuY2UgPT09ICdTRUxFQ1RFRCcgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICB7ZHJhZnQudXNlcklkcy5sZW5ndGh9IC8gMTAwMCB7dC5zZWxlY3RlZENvdW50fVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIHtkcmFmdC51c2VySWRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHsgLi4uZHJhZnQsIHVzZXJJZHM6IFtdIH0pfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENsZWFyIHNlbGVjdGlvblxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7ZHJhZnQudXNlcklkcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTMgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAge2RyYWZ0LnVzZXJJZHMuc2xpY2UoMCwgZXhwYW5kZWQgPyB1bmRlZmluZWQgOiA1KS5tYXAoKGlkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VyID0gc2VsZWN0ZWRVc2Vycy5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBpZCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHJvdW5kZWQtbWQgYmctc3VidGxlIHB4LTMgcHktMiB0ZXh0LXhzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgYnJlYWstYWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXNlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGAke3VzZXIudXNlcm5hbWV9IMK3ICR7dXNlci5lbWFpbH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ1VuYXZhaWxhYmxlIGFjY291bnQnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BSZW1vdmUgJHt1c2VyPy51c2VybmFtZSA/PyAnYWNjb3VudCd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHB4LTIgcHktMSB1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmRyYWZ0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJJZHM6IGRyYWZ0LnVzZXJJZHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHZhbHVlKSA9PiB2YWx1ZSAhPT0gaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge2RyYWZ0LnVzZXJJZHMubGVuZ3RoID4gNSAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZCghZXhwYW5kZWQpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2V4cGFuZGVkID8gJ1Nob3cgZmV3ZXInIDogJ1Nob3cgYWxsIHNlbGVjdGVkIHVzZXJzJ31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImF1dGgtbGFiZWwgbXQtNFwiIGh0bWxGb3I9XCJwcm9tb3Rpb24tdXNlci1zZWFyY2hcIj5cclxuICAgICAgICAgICAge3QucmVjaXBpZW50U2VhcmNofVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBpZD1cInByb21vdGlvbi11c2VyLXNlYXJjaFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkXCJcclxuICAgICAgICAgICAgdHlwZT1cInNlYXJjaFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XHJcbiAgICAgICAgICAgIG1heExlbmd0aD17MTAwfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgIHNldFBhZ2UoMSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+XHJcbiAgICAgICAgICAgICAge2Vycm9yfXsnICd9XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmV2aXNpb24oKG4pID0+IG4gKyAxKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBSZXRyeVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxMb2FkaW5nU3RhdGUgY29tcGFjdCAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIG1heC1oLTY0IG92ZXJmbG93LXktYXV0byByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZVwiPlxyXG4gICAgICAgICAgICAgIHtyZXN1bHQ/Lml0ZW1zLmxlbmd0aCA/IChcclxuICAgICAgICAgICAgICAgIHJlc3VsdC5pdGVtcy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXt1c2VyLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggY3Vyc29yLXBvaW50ZXIgaXRlbXMtc3RhcnQgZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcHgtMyBweS0zIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc3VidGxlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BTZWxlY3QgdXNlciAke3VzZXIudXNlcm5hbWV9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2RyYWZ0LnVzZXJJZHMuaW5jbHVkZXModXNlci5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRyYWZ0LnVzZXJJZHMubGVuZ3RoID49IDEwMDAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgIWRyYWZ0LnVzZXJJZHMuaW5jbHVkZXModXNlci5pZClcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGUodXNlcil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGgtNCB3LTQgc2hyaW5rLTAgYWNjZW50LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bVwiPnt1c2VyLnVzZXJuYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgYnJlYWstYWxsIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+Tm8gbWF0Y2hpbmcgdXNlcnMuPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICA8cD57cmVzdWx0Py50b3RhbCA/PyAwfSBlbGlnaWJsZSB1c2VyczwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlIDw9IDEgfHwgbG9hZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhZ2UocGFnZSAtIDEpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFByZXZpb3VzXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZyB8fCAhcmVzdWx0IHx8IHBhZ2UgKiByZXN1bHQubGltaXQgPj0gcmVzdWx0LnRvdGFsXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKHBhZ2UgKyAxKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBOZXh0XHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=