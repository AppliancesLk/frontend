import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/feedback/EmptyCart.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { EmptyState } from "/src/components/ui/Feedback.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/EmptyCart.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.cart;
export function EmptyCart({ headingAs = "h2" }) {
	return /* @__PURE__ */ _jsxDEV(EmptyState, {
		title: t.empty,
		headingAs,
		description: t.emptyDescription,
		action: /* @__PURE__ */ _jsxDEV(Link, {
			to: ROUTES.products,
			className: "auth-primary mt-6",
			children: translations.common.continueShopping
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 9
		}, this),
		icon: "bag"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = EmptyCart;
var _c;
$RefreshReg$(_c, "EmptyCart");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/feedback/EmptyCart.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/EmptyCart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/EmptyCart.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/EmptyCart.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjs7O0FBQzdCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxVQUFVLEVBQUUsWUFBWSxRQUFxQztDQUMzRSxPQUNFLHdCQUFDLFlBQUQ7RUFDRSxPQUFPLEVBQUU7RUFDRTtFQUNYLGFBQWEsRUFBRTtFQUNmLFFBQ0Usd0JBQUMsTUFBRDtHQUFNLElBQUksT0FBTztHQUFVLFdBQVU7YUFDbEMsYUFBYSxPQUFPO0VBQ2pCOzs7OztFQUVSLE1BQUs7Q0FDTjs7Ozs7QUFFTCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFbXB0eUNhcnQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tICcuLi91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuY2FydDtcclxuZXhwb3J0IGZ1bmN0aW9uIEVtcHR5Q2FydCh7IGhlYWRpbmdBcyA9ICdoMicgfTogeyBoZWFkaW5nQXM/OiAnaDEnIHwgJ2gyJyB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgIHRpdGxlPXt0LmVtcHR5fVxyXG4gICAgICBoZWFkaW5nQXM9e2hlYWRpbmdBc31cclxuICAgICAgZGVzY3JpcHRpb249e3QuZW1wdHlEZXNjcmlwdGlvbn1cclxuICAgICAgYWN0aW9uPXtcclxuICAgICAgICA8TGluayB0bz17Uk9VVEVTLnByb2R1Y3RzfSBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnkgbXQtNlwiPlxyXG4gICAgICAgICAge3RyYW5zbGF0aW9ucy5jb21tb24uY29udGludWVTaG9wcGluZ31cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIH1cclxuICAgICAgaWNvbj1cImJhZ1wiXHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuIl19