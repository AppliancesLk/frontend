import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Button.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function Button({ variant = "primary", busy = false, children, className = "", disabled, ...props }) {
	return /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		...props,
		"aria-busy": busy || undefined,
		disabled: disabled || busy,
		className: `ui-button ui-button-${variant} ${className}`,
		children: [busy && /* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 16
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/Button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxlQUFlOzs7QUFDeEIsT0FBTyxTQUFTLE9BQU8sRUFDckIsVUFBVSxXQUNWLE9BQU8sT0FDUCxVQUNBLFlBQVksSUFDWixVQUNBLEdBQUcsU0FJRjtDQUNELE9BQ0Usd0JBQUMsVUFBRDtFQUNFLE1BQUs7RUFDTCxHQUFJO0VBQ0osYUFBVyxRQUFRO0VBQ25CLFVBQVUsWUFBWTtFQUN0QixXQUFXLHVCQUF1QixRQUFRLEdBQUc7WUFML0MsQ0FPRyxRQUFRLHdCQUFDLFNBQUQsQ0FBVTs7OztZQUNsQixRQUNLOzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCdXR0b24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQnV0dG9uSFRNTEF0dHJpYnV0ZXMgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnLi9GZWVkYmFjayc7XG5leHBvcnQgZnVuY3Rpb24gQnV0dG9uKHtcbiAgdmFyaWFudCA9ICdwcmltYXJ5JyxcbiAgYnVzeSA9IGZhbHNlLFxuICBjaGlsZHJlbixcbiAgY2xhc3NOYW1lID0gJycsXG4gIGRpc2FibGVkLFxuICAuLi5wcm9wc1xufTogQnV0dG9uSFRNTEF0dHJpYnV0ZXM8SFRNTEJ1dHRvbkVsZW1lbnQ+ICYge1xuICB2YXJpYW50PzogJ3ByaW1hcnknIHwgJ3NlY29uZGFyeScgfCAnZ2hvc3QnIHwgJ2Rhbmdlcic7XG4gIGJ1c3k/OiBib29sZWFuO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgey4uLnByb3BzfVxuICAgICAgYXJpYS1idXN5PXtidXN5IHx8IHVuZGVmaW5lZH1cbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZCB8fCBidXN5fVxuICAgICAgY2xhc3NOYW1lPXtgdWktYnV0dG9uIHVpLWJ1dHRvbi0ke3ZhcmlhbnR9ICR7Y2xhc3NOYW1lfWB9XG4gICAgPlxuICAgICAge2J1c3kgJiYgPFNwaW5uZXIgLz59XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9idXR0b24+XG4gICk7XG59XG4iXX0=