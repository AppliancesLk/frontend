import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Themes/components/ThemeChoices.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { SEASONAL_THEMES } from "/src/types/seasonal-theme.types.ts";
import { seasonalPresets, seasonalText as t } from "/src/utils/seasonalText.ts";
import { SeasonalArtwork } from "/src/components/seasonal/SeasonalArtwork.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeChoices.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function ThemeChoices({ draft, saving, onChange }) {
	return /* @__PURE__ */ _jsxDEV("fieldset", {
		disabled: saving,
		children: [/* @__PURE__ */ _jsxDEV("legend", {
			className: "mb-4 text-lg font-semibold",
			children: t.choose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-3 2xl:grid-cols-5",
			children: SEASONAL_THEMES.map((theme) => /* @__PURE__ */ _jsxDEV("label", {
				className: `relative flex cursor-pointer flex-col overflow-hidden rounded-lg border bg-surface transition-colors focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-primary ${draft.theme === theme ? "border-primary ring-1 ring-primary" : "border-line hover:border-line-strong"}`,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "season-choice-art",
					"data-season": theme === "DEFAULT" ? undefined : theme,
					children: /* @__PURE__ */ _jsxDEV(SeasonalArtwork, { theme }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-1 flex-col p-3 sm:p-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-display text-base font-semibold",
							children: seasonalPresets[theme].name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "radio",
							name: "seasonalTheme",
							"aria-label": seasonalPresets[theme].name,
							value: theme,
							checked: draft.theme === theme,
							onChange: () => onChange({
								...draft,
								theme
							}),
							className: "h-4 w-4 shrink-0 accent-primary"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-xs leading-5 text-fg-secondary",
						children: seasonalPresets[theme].description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 13
				}, this)]
			}, theme, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_c = ThemeChoices;
var _c;
$RefreshReg$(_c, "ThemeChoices");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Themes/components/ThemeChoices.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeChoices.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeChoices.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeChoices.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyx1QkFBdUI7QUFDaEMsU0FDRSxpQkFDQSxnQkFBZ0IsU0FDWDtBQUNQLFNBQVMsdUJBQXVCOzs7QUFHaEMsT0FBTyxTQUFTLGFBQWEsRUFDM0IsT0FDQSxRQUNBLFlBS0M7Q0FDRCxPQUNFLHdCQUFDLFlBQUQ7RUFBVSxVQUFVO1lBQXBCLENBQ0Usd0JBQUMsVUFBRDtHQUFRLFdBQVU7YUFBOEIsRUFBRTtFQUFlOzs7O1lBQ2pFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osZ0JBQWdCLEtBQUssVUFDcEIsd0JBQUMsU0FBRDtJQUVFLFdBQVcsMExBQTBMLE1BQU0sVUFBVSxRQUFRLHVDQUF1QztjQUZ0USxDQUlFLHdCQUFDLE9BQUQ7S0FDRSxXQUFVO0tBQ1YsZUFBYSxVQUFVLFlBQVksWUFBWTtlQUUvQyx3QkFBQyxpQkFBRCxFQUF3QixNQUFROzs7OztJQUM3Qjs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLGdCQUFnQixNQUFNLENBQUM7TUFDcEI7Ozs7Z0JBQ04sd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxNQUFLO09BQ0wsY0FBWSxnQkFBZ0IsTUFBTSxDQUFDO09BQ25DLE9BQU87T0FDUCxTQUFTLE1BQU0sVUFBVTtPQUN6QixnQkFBZ0IsU0FBUztRQUFFLEdBQUc7UUFBTztPQUFNLENBQUM7T0FDNUMsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O2VBQ0wsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsZ0JBQWdCLE1BQU0sQ0FBQztLQUN2Qjs7OzthQUNBOzs7OztZQUNBO01BNUJBOzs7O1VBNEJBLENBQ1I7RUFDRTs7OztVQUNHOzs7Ozs7QUFFZCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUaGVtZUNob2ljZXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNFQVNPTkFMX1RIRU1FUyB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3NlYXNvbmFsLXRoZW1lLnR5cGVzJztcclxuaW1wb3J0IHtcclxuICBzZWFzb25hbFByZXNldHMsXHJcbiAgc2Vhc29uYWxUZXh0IGFzIHQsXHJcbn0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvc2Vhc29uYWxUZXh0JztcclxuaW1wb3J0IHsgU2Vhc29uYWxBcnR3b3JrIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9zZWFzb25hbC9TZWFzb25hbEFydHdvcmsnO1xyXG5pbXBvcnQgdHlwZSB7IFRoZW1lRHJhZnQgfSBmcm9tICcuLi9oZWxwZXJzL3RoZW1lLmhlbHBlcnMnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFRoZW1lQ2hvaWNlcyh7XHJcbiAgZHJhZnQsXHJcbiAgc2F2aW5nLFxyXG4gIG9uQ2hhbmdlLFxyXG59OiB7XHJcbiAgZHJhZnQ6IFRoZW1lRHJhZnQ7XHJcbiAgc2F2aW5nOiBib29sZWFuO1xyXG4gIG9uQ2hhbmdlOiAoZHJhZnQ6IFRoZW1lRHJhZnQpID0+IHZvaWQ7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGZpZWxkc2V0IGRpc2FibGVkPXtzYXZpbmd9PlxyXG4gICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1sZyBmb250LXNlbWlib2xkXCI+e3QuY2hvb3NlfTwvbGVnZW5kPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbGc6Z3JpZC1jb2xzLTMgMnhsOmdyaWQtY29scy01XCI+XHJcbiAgICAgICAge1NFQVNPTkFMX1RIRU1FUy5tYXAoKHRoZW1lKSA9PiAoXHJcbiAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAga2V5PXt0aGVtZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgZmxleCBjdXJzb3ItcG9pbnRlciBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBib3JkZXIgYmctc3VyZmFjZSB0cmFuc2l0aW9uLWNvbG9ycyBmb2N1cy13aXRoaW46b3V0bGluZS0yIGZvY3VzLXdpdGhpbjpvdXRsaW5lLW9mZnNldC0yIGZvY3VzLXdpdGhpbjpvdXRsaW5lLXByaW1hcnkgJHtkcmFmdC50aGVtZSA9PT0gdGhlbWUgPyAnYm9yZGVyLXByaW1hcnkgcmluZy0xIHJpbmctcHJpbWFyeScgOiAnYm9yZGVyLWxpbmUgaG92ZXI6Ym9yZGVyLWxpbmUtc3Ryb25nJ31gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2Vhc29uLWNob2ljZS1hcnRcIlxyXG4gICAgICAgICAgICAgIGRhdGEtc2Vhc29uPXt0aGVtZSA9PT0gJ0RFRkFVTFQnID8gdW5kZWZpbmVkIDogdGhlbWV9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2Vhc29uYWxBcnR3b3JrIHRoZW1lPXt0aGVtZX0gLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgcC0zIHNtOnAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge3NlYXNvbmFsUHJlc2V0c1t0aGVtZV0ubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwic2Vhc29uYWxUaGVtZVwiXHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e3NlYXNvbmFsUHJlc2V0c1t0aGVtZV0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RoZW1lfVxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtkcmFmdC50aGVtZSA9PT0gdGhlbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBvbkNoYW5nZSh7IC4uLmRyYWZ0LCB0aGVtZSB9KX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCBzaHJpbmstMCBhY2NlbnQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBsZWFkaW5nLTUgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgIHtzZWFzb25hbFByZXNldHNbdGhlbWVdLmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZmllbGRzZXQ+XHJcbiAgKTtcclxufVxyXG4iXX0=