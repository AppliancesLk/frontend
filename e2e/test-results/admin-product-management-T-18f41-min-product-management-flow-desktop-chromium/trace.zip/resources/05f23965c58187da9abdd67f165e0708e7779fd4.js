import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Orders/components/OrderStatusBadge.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderStatusBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function OrderStatusBadge({ status }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status,
		children: translations.orders.statuses[status] ?? status
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = OrderStatusBadge;
var _c;
$RefreshReg$(_c, "OrderStatusBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Orders/components/OrderStatusBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderStatusBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderStatusBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderStatusBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7OztBQUM1QixPQUFPLFNBQVMsaUJBQWlCLEVBQUUsVUFBbUM7Q0FDcEUsT0FDRSx3QkFBQyxhQUFEO0VBQXFCO1lBQ2xCLGFBQWEsT0FBTyxTQUFTLFdBQVc7Q0FDOUI7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk9yZGVyU3RhdHVzQmFkZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgT3JkZXJTdGF0dXMgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9vcmRlci50eXBlcyc7XG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL1N0YXR1c0JhZGdlJztcbmV4cG9ydCBmdW5jdGlvbiBPcmRlclN0YXR1c0JhZGdlKHsgc3RhdHVzIH06IHsgc3RhdHVzOiBPcmRlclN0YXR1cyB9KSB7XG4gIHJldHVybiAoXG4gICAgPFN0YXR1c0JhZGdlIHN0YXR1cz17c3RhdHVzfT5cbiAgICAgIHt0cmFuc2xhdGlvbnMub3JkZXJzLnN0YXR1c2VzW3N0YXR1c10gPz8gc3RhdHVzfVxuICAgIDwvU3RhdHVzQmFkZ2U+XG4gICk7XG59XG4iXX0=