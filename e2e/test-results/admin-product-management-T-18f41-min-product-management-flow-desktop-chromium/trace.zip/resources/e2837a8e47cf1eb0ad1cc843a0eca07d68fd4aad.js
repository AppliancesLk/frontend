import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/components/ProductFields.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import { translations } from "/src/utils/translations.ts";
import { ImageUploader } from "/src/components/forms/ImageUploader.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductFields.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.admin;
export function ProductFields({ draft, categories, onChange, editing = false, onUploadState, productID, onPendingFilesChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		[
			"name",
			"SKU",
			"price"
		].map((field) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
			className: "auth-label",
			htmlFor: field,
			children: {
				name: t.productName,
				SKU: t.sku,
				price: t.price
			}[field]
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("input", {
			id: field,
			required: true,
			className: "ui-field auth-input",
			type: field === "price" ? "number" : "text",
			min: field === "price" ? 0 : undefined,
			max: field === "price" ? 9999999999.99 : undefined,
			step: field === "price" ? "0.01" : undefined,
			value: draft[field],
			onChange: (event) => onChange(field, event.target.value)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 11
		}, this)] }, field, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 9
		}, this)),
		/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: "categoryID",
			className: "auth-label",
			children: t.category
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("select", {
			id: "categoryID",
			required: true,
			className: "ui-field auth-input",
			value: draft.categoryID,
			onChange: (event) => onChange("categoryID", event.target.value),
			children: [/* @__PURE__ */ _jsxDEV("option", {
				value: "",
				children: t.selectCategory
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 11
			}, this), categories.map((category) => /* @__PURE__ */ _jsxDEV("option", {
				value: category.categoryID,
				children: [
					category.parent ? `${category.parent.name} / ` : "",
					category.name,
					!category.isActive ? ` (${t.inactive})` : ""
				]
			}, category.categoryID, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 13
			}, this))]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "sm:col-span-2",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-fg-muted",
				children: translations.catalog.metadataHint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this),
		[
			"brand",
			"subtitle",
			"compareAtPrice"
		].map((field) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
			className: "auth-label",
			htmlFor: field,
			children: translations.catalog[field]
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("input", {
			id: field,
			className: "ui-field auth-input",
			value: draft[field] ?? "",
			type: field === "compareAtPrice" ? "number" : "text",
			min: field === "compareAtPrice" ? 0 : undefined,
			step: field === "compareAtPrice" ? "0.01" : undefined,
			max: field === "compareAtPrice" ? 9999999999.99 : undefined,
			maxLength: field === "brand" ? 80 : field === "subtitle" ? 160 : undefined,
			onChange: (event) => onChange(field, event.target.value)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 11
		}, this)] }, field, true, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 9
		}, this)),
		/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
			className: "auth-label",
			htmlFor: "badge",
			children: translations.catalog.badge
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("select", {
			id: "badge",
			className: "ui-field auth-input",
			value: draft.badge ?? "",
			onChange: (event) => onChange("badge", event.target.value),
			children: [/* @__PURE__ */ _jsxDEV("option", {
				value: "",
				children: translations.catalog.noBadge
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 11
			}, this), Object.entries(translations.catalog.badges).map(([key, label]) => /* @__PURE__ */ _jsxDEV("option", {
				value: key,
				children: label
			}, key, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 13
			}, this))]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "sm:col-span-2",
			children: [
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "imageUrls",
					className: "auth-label",
					children: t.imageUrls
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(ImageUploader, {
					value: draft.imageUrls.split("\n").map((value) => value.trim()).filter(Boolean),
					onChange: (images) => onChange("imageUrls", images.join("\n")),
					onBusyChange: onUploadState,
					productID,
					onPendingFilesChange
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("textarea", {
					id: "imageUrls",
					rows: 3,
					className: "ui-field auth-input h-auto py-2",
					value: draft.imageUrls,
					onChange: (event) => onChange("imageUrls", event.target.value),
					"aria-describedby": "image-hint"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					id: "image-hint",
					className: "mt-2 text-xs text-fg-muted",
					children: [
						t.imageHint,
						" ",
						editing && translations.productEdit.clearImagesHint
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 7
		}, this),
		[
			"description",
			"features",
			"boxContents",
			"warranty"
		].map((field) => /* @__PURE__ */ _jsxDEV("div", {
			className: field === "description" ? "sm:col-span-2" : "",
			children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "auth-label",
					htmlFor: field,
					children: translations.experience[field]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("textarea", {
					id: field,
					rows: field === "description" ? 4 : 3,
					maxLength: field === "description" ? 1e4 : field === "warranty" ? 300 : undefined,
					value: draft[field] ?? "",
					onChange: (event) => onChange(field, event.target.value),
					className: "ui-field auth-input h-auto py-2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-fg-muted",
					children: field === "features" || field === "boxContents" ? translations.experience.listHint : ""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 13
				}, this)
			]
		}, field, true, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 11
		}, this))
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_c = ProductFields;
var _c;
$RefreshReg$(_c, "ProductFields");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/components/ProductFields.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductFields.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductFields.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductFields.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxxQkFBcUI7OztBQUM5QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsY0FBYyxFQUM1QixPQUNBLFlBQ0EsVUFDQSxVQUFVLE9BQ1YsZUFDQSxXQUNBLHdCQVNDO0NBQ0QsT0FDRTtFQUNJO0dBQUM7R0FBUTtHQUFPO0VBQU8sQ0FBQyxDQUFXLEtBQUssVUFDeEMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7R0FBTyxXQUFVO0dBQWEsU0FBUzthQUNwQztJQUFFLE1BQU0sRUFBRTtJQUFhLEtBQUssRUFBRTtJQUFLLE9BQU8sRUFBRTtHQUFNLEVBQUU7RUFDaEQ7Ozs7WUFDUCx3QkFBQyxTQUFEO0dBQ0UsSUFBSTtHQUNKO0dBQ0EsV0FBVTtHQUNWLE1BQU0sVUFBVSxVQUFVLFdBQVc7R0FDckMsS0FBSyxVQUFVLFVBQVUsSUFBSTtHQUM3QixLQUFLLFVBQVUsVUFBVSxnQkFBZ0I7R0FDekMsTUFBTSxVQUFVLFVBQVUsU0FBUztHQUNuQyxPQUFPLE1BQU07R0FDYixXQUFXLFVBQVUsU0FBUyxPQUFPLE1BQU0sT0FBTyxLQUFLO0VBQ3hEOzs7O1VBQ0UsS0FmSzs7OztTQWVMLENBQ047RUFDRCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtHQUFPLFNBQVE7R0FBYSxXQUFVO2FBQ25DLEVBQUU7RUFDRTs7OztZQUNQLHdCQUFDLFVBQUQ7R0FDRSxJQUFHO0dBQ0g7R0FDQSxXQUFVO0dBQ1YsT0FBTyxNQUFNO0dBQ2IsV0FBVyxVQUFVLFNBQVMsY0FBYyxNQUFNLE9BQU8sS0FBSzthQUxoRSxDQU9FLHdCQUFDLFVBQUQ7SUFBUSxPQUFNO2NBQUksRUFBRTtHQUF1Qjs7OzthQUMxQyxXQUFXLEtBQUssYUFDZix3QkFBQyxVQUFEO0lBQWtDLE9BQU8sU0FBUztjQUFsRDtLQUNHLFNBQVMsU0FBUyxHQUFHLFNBQVMsT0FBTyxLQUFLLE9BQU87S0FDakQsU0FBUztLQUNULENBQUMsU0FBUyxXQUFXLEtBQUssRUFBRSxTQUFTLEtBQUs7SUFDckM7TUFKSyxTQUFTOzs7O1VBSWQsQ0FDVCxDQUNLOzs7OztVQUNMOzs7OztFQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixhQUFhLFFBQVE7R0FDckI7Ozs7O0VBQ0E7Ozs7O0VBQ0g7R0FBQztHQUFTO0dBQVk7RUFBZ0IsQ0FBQyxDQUFXLEtBQUssVUFDdkQsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7R0FBTyxXQUFVO0dBQWEsU0FBUzthQUNwQyxhQUFhLFFBQVE7RUFDakI7Ozs7WUFDUCx3QkFBQyxTQUFEO0dBQ0UsSUFBSTtHQUNKLFdBQVU7R0FDVixPQUFPLE1BQU0sVUFBVTtHQUN2QixNQUFNLFVBQVUsbUJBQW1CLFdBQVc7R0FDOUMsS0FBSyxVQUFVLG1CQUFtQixJQUFJO0dBQ3RDLE1BQU0sVUFBVSxtQkFBbUIsU0FBUztHQUM1QyxLQUFLLFVBQVUsbUJBQW1CLGdCQUFnQjtHQUNsRCxXQUNFLFVBQVUsVUFBVSxLQUFLLFVBQVUsYUFBYSxNQUFNO0dBRXhELFdBQVcsVUFBVSxTQUFTLE9BQU8sTUFBTSxPQUFPLEtBQUs7RUFDeEQ7Ozs7VUFDRSxLQWpCSzs7OztTQWlCTCxDQUNOO0VBQ0Qsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7R0FBTyxXQUFVO0dBQWEsU0FBUTthQUNuQyxhQUFhLFFBQVE7RUFDakI7Ozs7WUFDUCx3QkFBQyxVQUFEO0dBQ0UsSUFBRztHQUNILFdBQVU7R0FDVixPQUFPLE1BQU0sU0FBUztHQUN0QixXQUFXLFVBQVUsU0FBUyxTQUFTLE1BQU0sT0FBTyxLQUFLO2FBSjNELENBTUUsd0JBQUMsVUFBRDtJQUFRLE9BQU07Y0FBSSxhQUFhLFFBQVE7R0FBZ0I7Ozs7YUFDdEQsT0FBTyxRQUFRLGFBQWEsUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUN0RCx3QkFBQyxVQUFEO0lBQWtCLE9BQU87Y0FDdEI7R0FDSyxHQUZLOzs7O1VBRUwsQ0FDVCxDQUNLOzs7OztVQUNMOzs7OztFQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxTQUFEO0tBQU8sU0FBUTtLQUFZLFdBQVU7ZUFDbEMsRUFBRTtJQUNFOzs7OztJQUNQLHdCQUFDLGVBQUQ7S0FDRSxPQUFPLE1BQU0sVUFDVixNQUFNLElBQUksQ0FBQyxDQUNYLEtBQUssVUFBVSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQzVCLE9BQU8sT0FBTztLQUNqQixXQUFXLFdBQVcsU0FBUyxhQUFhLE9BQU8sS0FBSyxJQUFJLENBQUM7S0FDN0QsY0FBYztLQUNIO0tBQ1c7SUFDdkI7Ozs7O0lBQ0Qsd0JBQUMsWUFBRDtLQUNFLElBQUc7S0FDSCxNQUFNO0tBQ04sV0FBVTtLQUNWLE9BQU8sTUFBTTtLQUNiLFdBQVcsVUFBVSxTQUFTLGFBQWEsTUFBTSxPQUFPLEtBQUs7S0FDN0Qsb0JBQWlCO0lBQ2xCOzs7OztJQUNELHdCQUFDLEtBQUQ7S0FBRyxJQUFHO0tBQWEsV0FBVTtlQUE3QjtNQUNHLEVBQUU7TUFBVTtNQUFFLFdBQVcsYUFBYSxZQUFZO0tBQ2xEOzs7Ozs7R0FDQTs7Ozs7O0VBQ0g7R0FBQztHQUFlO0dBQVk7R0FBZTtFQUFVLENBQUMsQ0FBVyxLQUNoRSxVQUNDLHdCQUFDLE9BQUQ7R0FFRSxXQUFXLFVBQVUsZ0JBQWdCLGtCQUFrQjthQUZ6RDtJQUlFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO0tBQWEsU0FBUztlQUNwQyxhQUFhLFdBQVc7SUFDcEI7Ozs7O0lBQ1Asd0JBQUMsWUFBRDtLQUNFLElBQUk7S0FDSixNQUFNLFVBQVUsZ0JBQWdCLElBQUk7S0FDcEMsV0FDRSxVQUFVLGdCQUNOLE1BQ0EsVUFBVSxhQUNSLE1BQ0E7S0FFUixPQUFPLE1BQU0sVUFBVTtLQUN2QixXQUFXLFVBQVUsU0FBUyxPQUFPLE1BQU0sT0FBTyxLQUFLO0tBQ3ZELFdBQVU7SUFDWDs7Ozs7SUFDRCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUNWLFVBQVUsY0FBYyxVQUFVLGdCQUMvQixhQUFhLFdBQVcsV0FDeEI7SUFDSDs7Ozs7R0FDQTtLQXpCRTs7OztTQXlCRixDQUVUO0NBQ0E7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEZpZWxkcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBQcm9kdWN0RmllbGRzRHJhZnQgfSBmcm9tICcuLi90eXBlcy9wcm9kdWN0LWZvcm0udHlwZXMnO1xyXG5pbXBvcnQgdHlwZSB7IENhdGVnb3J5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvY2F0ZWdvcnkudHlwZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBJbWFnZVVwbG9hZGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9mb3Jtcy9JbWFnZVVwbG9hZGVyJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pbjtcclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RGaWVsZHMoe1xyXG4gIGRyYWZ0LFxyXG4gIGNhdGVnb3JpZXMsXHJcbiAgb25DaGFuZ2UsXHJcbiAgZWRpdGluZyA9IGZhbHNlLFxyXG4gIG9uVXBsb2FkU3RhdGUsXHJcbiAgcHJvZHVjdElELFxyXG4gIG9uUGVuZGluZ0ZpbGVzQ2hhbmdlLFxyXG59OiB7XHJcbiAgZHJhZnQ6IFByb2R1Y3RGaWVsZHNEcmFmdDtcclxuICBjYXRlZ29yaWVzOiBDYXRlZ29yeVtdO1xyXG4gIG9uQ2hhbmdlOiAoZmllbGQ6IGtleW9mIFByb2R1Y3RGaWVsZHNEcmFmdCwgdmFsdWU6IHN0cmluZykgPT4gdm9pZDtcclxuICBlZGl0aW5nPzogYm9vbGVhbjtcclxuICBvblVwbG9hZFN0YXRlPzogKGJ1c3k6IGJvb2xlYW4pID0+IHZvaWQ7XHJcbiAgcHJvZHVjdElEPzogc3RyaW5nO1xyXG4gIG9uUGVuZGluZ0ZpbGVzQ2hhbmdlPzogKGZpbGVzOiBGaWxlW10pID0+IHZvaWQ7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgeyhbJ25hbWUnLCAnU0tVJywgJ3ByaWNlJ10gYXMgY29uc3QpLm1hcCgoZmllbGQpID0+IChcclxuICAgICAgICA8ZGl2IGtleT17ZmllbGR9PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIiBodG1sRm9yPXtmaWVsZH0+XHJcbiAgICAgICAgICAgIHt7IG5hbWU6IHQucHJvZHVjdE5hbWUsIFNLVTogdC5za3UsIHByaWNlOiB0LnByaWNlIH1bZmllbGRdfVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBpZD17ZmllbGR9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXRcIlxyXG4gICAgICAgICAgICB0eXBlPXtmaWVsZCA9PT0gJ3ByaWNlJyA/ICdudW1iZXInIDogJ3RleHQnfVxyXG4gICAgICAgICAgICBtaW49e2ZpZWxkID09PSAncHJpY2UnID8gMCA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgbWF4PXtmaWVsZCA9PT0gJ3ByaWNlJyA/IDk5OTk5OTk5OTkuOTkgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgIHN0ZXA9e2ZpZWxkID09PSAncHJpY2UnID8gJzAuMDEnIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICB2YWx1ZT17ZHJhZnRbZmllbGRdfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBvbkNoYW5nZShmaWVsZCwgZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY2F0ZWdvcnlJRFwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgIHt0LmNhdGVnb3J5fVxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgaWQ9XCJjYXRlZ29yeUlEXCJcclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0XCJcclxuICAgICAgICAgIHZhbHVlPXtkcmFmdC5jYXRlZ29yeUlEfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25DaGFuZ2UoJ2NhdGVnb3J5SUQnLCBldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj57dC5zZWxlY3RDYXRlZ29yeX08L29wdGlvbj5cclxuICAgICAgICAgIHtjYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NhdGVnb3J5LmNhdGVnb3J5SUR9IHZhbHVlPXtjYXRlZ29yeS5jYXRlZ29yeUlEfT5cclxuICAgICAgICAgICAgICB7Y2F0ZWdvcnkucGFyZW50ID8gYCR7Y2F0ZWdvcnkucGFyZW50Lm5hbWV9IC8gYCA6ICcnfVxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeS5uYW1lfVxyXG4gICAgICAgICAgICAgIHshY2F0ZWdvcnkuaXNBY3RpdmUgPyBgICgke3QuaW5hY3RpdmV9KWAgOiAnJ31cclxuICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAge3RyYW5zbGF0aW9ucy5jYXRhbG9nLm1ldGFkYXRhSGludH1cclxuICAgICAgICA8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7KFsnYnJhbmQnLCAnc3VidGl0bGUnLCAnY29tcGFyZUF0UHJpY2UnXSBhcyBjb25zdCkubWFwKChmaWVsZCkgPT4gKFxyXG4gICAgICAgIDxkaXYga2V5PXtmaWVsZH0+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiIGh0bWxGb3I9e2ZpZWxkfT5cclxuICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jYXRhbG9nW2ZpZWxkXX1cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9e2ZpZWxkfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0XCJcclxuICAgICAgICAgICAgdmFsdWU9e2RyYWZ0W2ZpZWxkXSA/PyAnJ31cclxuICAgICAgICAgICAgdHlwZT17ZmllbGQgPT09ICdjb21wYXJlQXRQcmljZScgPyAnbnVtYmVyJyA6ICd0ZXh0J31cclxuICAgICAgICAgICAgbWluPXtmaWVsZCA9PT0gJ2NvbXBhcmVBdFByaWNlJyA/IDAgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgIHN0ZXA9e2ZpZWxkID09PSAnY29tcGFyZUF0UHJpY2UnID8gJzAuMDEnIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICBtYXg9e2ZpZWxkID09PSAnY29tcGFyZUF0UHJpY2UnID8gOTk5OTk5OTk5OS45OSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgbWF4TGVuZ3RoPXtcclxuICAgICAgICAgICAgICBmaWVsZCA9PT0gJ2JyYW5kJyA/IDgwIDogZmllbGQgPT09ICdzdWJ0aXRsZScgPyAxNjAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBvbkNoYW5nZShmaWVsZCwgZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCIgaHRtbEZvcj1cImJhZGdlXCI+XHJcbiAgICAgICAgICB7dHJhbnNsYXRpb25zLmNhdGFsb2cuYmFkZ2V9XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICBpZD1cImJhZGdlXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXRcIlxyXG4gICAgICAgICAgdmFsdWU9e2RyYWZ0LmJhZGdlID8/ICcnfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25DaGFuZ2UoJ2JhZGdlJywgZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3RyYW5zbGF0aW9ucy5jYXRhbG9nLm5vQmFkZ2V9PC9vcHRpb24+XHJcbiAgICAgICAgICB7T2JqZWN0LmVudHJpZXModHJhbnNsYXRpb25zLmNhdGFsb2cuYmFkZ2VzKS5tYXAoKFtrZXksIGxhYmVsXSkgPT4gKFxyXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17a2V5fSB2YWx1ZT17a2V5fT5cclxuICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImltYWdlVXJsc1wiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgIHt0LmltYWdlVXJsc31cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxJbWFnZVVwbG9hZGVyXHJcbiAgICAgICAgICB2YWx1ZT17ZHJhZnQuaW1hZ2VVcmxzXHJcbiAgICAgICAgICAgIC5zcGxpdCgnXFxuJylcclxuICAgICAgICAgICAgLm1hcCgodmFsdWUpID0+IHZhbHVlLnRyaW0oKSlcclxuICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoaW1hZ2VzKSA9PiBvbkNoYW5nZSgnaW1hZ2VVcmxzJywgaW1hZ2VzLmpvaW4oJ1xcbicpKX1cclxuICAgICAgICAgIG9uQnVzeUNoYW5nZT17b25VcGxvYWRTdGF0ZX1cclxuICAgICAgICAgIHByb2R1Y3RJRD17cHJvZHVjdElEfVxyXG4gICAgICAgICAgb25QZW5kaW5nRmlsZXNDaGFuZ2U9e29uUGVuZGluZ0ZpbGVzQ2hhbmdlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICBpZD1cImltYWdlVXJsc1wiXHJcbiAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgYXV0aC1pbnB1dCBoLWF1dG8gcHktMlwiXHJcbiAgICAgICAgICB2YWx1ZT17ZHJhZnQuaW1hZ2VVcmxzfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25DaGFuZ2UoJ2ltYWdlVXJscycsIGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PVwiaW1hZ2UtaGludFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgICA8cCBpZD1cImltYWdlLWhpbnRcIiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAge3QuaW1hZ2VIaW50fSB7ZWRpdGluZyAmJiB0cmFuc2xhdGlvbnMucHJvZHVjdEVkaXQuY2xlYXJJbWFnZXNIaW50fVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsoWydkZXNjcmlwdGlvbicsICdmZWF0dXJlcycsICdib3hDb250ZW50cycsICd3YXJyYW50eSddIGFzIGNvbnN0KS5tYXAoXHJcbiAgICAgICAgKGZpZWxkKSA9PiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGtleT17ZmllbGR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGQgPT09ICdkZXNjcmlwdGlvbicgPyAnc206Y29sLXNwYW4tMicgOiAnJ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIiBodG1sRm9yPXtmaWVsZH0+XHJcbiAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5leHBlcmllbmNlW2ZpZWxkXX1cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgaWQ9e2ZpZWxkfVxyXG4gICAgICAgICAgICAgIHJvd3M9e2ZpZWxkID09PSAnZGVzY3JpcHRpb24nID8gNCA6IDN9XHJcbiAgICAgICAgICAgICAgbWF4TGVuZ3RoPXtcclxuICAgICAgICAgICAgICAgIGZpZWxkID09PSAnZGVzY3JpcHRpb24nXHJcbiAgICAgICAgICAgICAgICAgID8gMTAwMDBcclxuICAgICAgICAgICAgICAgICAgOiBmaWVsZCA9PT0gJ3dhcnJhbnR5J1xyXG4gICAgICAgICAgICAgICAgICAgID8gMzAwXHJcbiAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0W2ZpZWxkXSA/PyAnJ31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBvbkNoYW5nZShmaWVsZCwgZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0IGgtYXV0byBweS0yXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICB7ZmllbGQgPT09ICdmZWF0dXJlcycgfHwgZmllbGQgPT09ICdib3hDb250ZW50cydcclxuICAgICAgICAgICAgICAgID8gdHJhbnNsYXRpb25zLmV4cGVyaWVuY2UubGlzdEhpbnRcclxuICAgICAgICAgICAgICAgIDogJyd9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdfQ==