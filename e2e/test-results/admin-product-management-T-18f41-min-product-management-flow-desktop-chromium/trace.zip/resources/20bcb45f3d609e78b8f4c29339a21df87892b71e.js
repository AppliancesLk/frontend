import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/index.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport13_react_jsxDevRuntime["Fragment"];import { formatCategoryName } from "/src/utils/category.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { useProductDetails } from "/src/pages/Customer/ProductDetails/hooks/useProductDetails.ts";
import { ProductGallery } from "/src/pages/Customer/ProductDetails/components/ProductGallery.tsx";
import { ProductInformation } from "/src/pages/Customer/ProductDetails/components/ProductInformation.tsx";
import { PurchasePanel } from "/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx";
import { ProductContent } from "/src/pages/Customer/ProductDetails/components/ProductContent.tsx";
import { RelatedProducts } from "/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx";
import { ProductDetailsState } from "/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx";
import { ProductAiAssistant } from "/src/pages/Customer/ProductDetails/components/ProductAiAssistant/ProductAiAssistant.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/index.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function ProductDetailsPage() {
	_s();
	const { id } = useParams();
	const page = useProductDetails(id);
	const [contentTab, setContentTab] = useState(null);
	const activeTab = contentTab?.id === id ? contentTab?.tab ?? "overview" : "overview";
	const changeTab = (tab) => {
		if (id) setContentTab({
			id,
			tab
		});
	};
	const [reviewSummary, setReviewSummary] = useState(null);
	const updateSummary = useCallback((summary) => {
		if (id) setReviewSummary({
			id,
			summary
		});
	}, [id]);
	const product = page.product ? {
		...page.product,
		...reviewSummary && reviewSummary.id === id ? {
			ratingAverage: reviewSummary.summary.average,
			ratingCount: reviewSummary.summary.count
		} : {}
	} : null;
	useEffect(() => {
		const previous = document.title;
		document.title = `${page.product?.name ?? translations.productDetails.details} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, [page.product?.name]);
	useEffect(() => {
		window.scrollTo({
			top: 0,
			behavior: "instant"
		});
	}, [id]);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "product-detail-page bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-[1200px] space-y-8",
			children: [/* @__PURE__ */ _jsxDEV("nav", {
				"aria-label": translations.productDetails.breadcrumb,
				className: "text-sm",
				children: /* @__PURE__ */ _jsxDEV("ol", {
					className: "flex flex-wrap items-center gap-2 text-fg-muted",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.home,
							className: "font-medium text-fg-link hover:text-fg-link",
							children: translations.storefront.home
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("li", {
							"aria-hidden": "true",
							children: "/"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this),
						product && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							to: `${ROUTES.products}?category=${product.category.categoryID}`,
							className: "hover:text-fg-link",
							children: formatCategoryName(product.category.name)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("li", {
							"aria-hidden": "true",
							children: "/"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("li", {
							"aria-current": "page",
							className: "min-w-0 break-words",
							children: page.product?.name ?? translations.productDetails.details
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this), page.status === "ready" && product ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "product-detail-grid grid items-start gap-6 md:grid-cols-2 xl:grid-cols-[1.3fr_1fr_.9fr]",
					children: [
						/* @__PURE__ */ _jsxDEV(ProductGallery, {
							images: product.images,
							name: product.name
						}, `gallery-${product.productID}`, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(ProductInformation, {
							product,
							showReviews: () => {
								changeTab("reviews");
								requestAnimationFrame(() => {
									document.getElementById("tab-reviews")?.focus();
									document.getElementById("product-content")?.scrollIntoView({ block: "start" });
								});
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(PurchasePanel, { product }, `purchase-${product.productID}`, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(ProductContent, {
					product,
					active: activeTab,
					setActive: changeTab,
					onSummary: updateSummary
				}, product.productID, false, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(RelatedProducts, { product }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(ProductAiAssistant, {
					productId: product.productID,
					productName: product.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV(ProductDetailsState, {
				status: page.status === "ready" ? "error" : page.status,
				retry: page.retry
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
}
_s(ProductDetailsPage, "7ZFzEfFOx15ZtabbocVEZ64RGxw=", false, function() {
	return [useParams, useProductDetails];
});
_c = ProductDetailsPage;
var _c;
$RefreshReg$(_c, "ProductDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxXQUFXLGFBQWEsZ0JBQWdCO0FBQ2pELFNBQVMsTUFBTSxpQkFBaUI7QUFDaEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsc0JBQXNCO0FBRy9CLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsMkJBQTJCO0FBQ3BDLFNBQVMsMEJBQTBCOzs7O0FBQ25DLGVBQWUsU0FBUyxxQkFBcUI7O0NBQzNDLE1BQU0sRUFBRSxPQUFPLFVBQVU7Q0FDekIsTUFBTSxPQUFPLGtCQUFrQixFQUFFO0NBQ2pDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUcxQixJQUFJO0NBQ2QsTUFBTSxZQUNKLFlBQVksT0FBTyxLQUFNLFlBQVksT0FBTyxhQUFjO0NBQzVELE1BQU0sYUFBYSxRQUFvQjtFQUNyQyxJQUFJLElBQUksY0FBYztHQUFFO0dBQUk7RUFBSSxDQUFDO0NBQ25DO0NBQ0EsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBR2hDLElBQUk7Q0FDZCxNQUFNLGdCQUFnQixhQUNuQixZQUEyQjtFQUMxQixJQUFJLElBQUksaUJBQWlCO0dBQUU7R0FBSTtFQUFRLENBQUM7Q0FDMUMsR0FDQSxDQUFDLEVBQUUsQ0FDTDtDQUNBLE1BQU0sVUFBVSxLQUFLLFVBQ2pCO0VBQ0UsR0FBRyxLQUFLO0VBQ1IsR0FBSSxpQkFBaUIsY0FBYyxPQUFPLEtBQ3RDO0dBQ0UsZUFBZSxjQUFjLFFBQVE7R0FDckMsYUFBYSxjQUFjLFFBQVE7RUFDckMsSUFDQSxDQUFDO0NBQ1AsSUFDQTtDQUNKLGdCQUFnQjtFQUNkLE1BQU0sV0FBVyxTQUFTO0VBQzFCLFNBQVMsUUFBUSxHQUFHLEtBQUssU0FBUyxRQUFRLGFBQWEsZUFBZSxRQUFRLEtBQUssYUFBYSxPQUFPO0VBQ3ZHLGFBQWE7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRixHQUFHLENBQUMsS0FBSyxTQUFTLElBQUksQ0FBQztDQUN2QixnQkFBZ0I7RUFDZCxPQUFPLFNBQVM7R0FBRSxLQUFLO0dBQUcsVUFBVTtFQUFVLENBQUM7Q0FDakQsR0FBRyxDQUFDLEVBQUUsQ0FBQztDQUNQLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUNFLGNBQVksYUFBYSxlQUFlO0lBQ3hDLFdBQVU7Y0FFVix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLE9BQU87T0FDWCxXQUFVO2lCQUVULGFBQWEsV0FBVztNQUNyQjs7OztlQUNKOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxlQUFZO2lCQUFPO01BQUs7Ozs7O01BQzNCLFdBQ0MsZ0RBQ0Usd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLEdBQUcsT0FBTyxTQUFTLFlBQVksUUFBUSxTQUFTO09BQ3BELFdBQVU7aUJBRVQsbUJBQW1CLFFBQVEsU0FBUyxJQUFJO01BQ3JDOzs7O2VBQ0o7Ozs7Z0JBQ0osd0JBQUMsTUFBRDtPQUFJLGVBQVk7aUJBQU87TUFBSzs7OztjQUM1Qjs7Ozs7TUFFSix3QkFBQyxNQUFEO09BQUksZ0JBQWE7T0FBTyxXQUFVO2lCQUMvQixLQUFLLFNBQVMsUUFBUSxhQUFhLGVBQWU7TUFDakQ7Ozs7O0tBQ0Y7Ozs7OztHQUNEOzs7O2FBQ0osS0FBSyxXQUFXLFdBQVcsVUFDMUI7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsZ0JBQUQ7T0FFRSxRQUFRLFFBQVE7T0FDaEIsTUFBTSxRQUFRO01BQ2YsR0FITSxXQUFXLFFBQVE7Ozs7YUFHekI7TUFDRCx3QkFBQyxvQkFBRDtPQUNXO09BQ1QsbUJBQW1CO1FBQ2pCLFVBQVUsU0FBUztRQUNuQiw0QkFBNEI7U0FDMUIsU0FBUyxlQUFlLGFBQWEsQ0FBQyxFQUFFLE1BQU07U0FDOUMsU0FDRyxlQUFlLGlCQUFpQixDQUFDLEVBQ2hDLGVBQWUsRUFBRSxPQUFPLFFBQVEsQ0FBQztRQUN2QyxDQUFDO09BQ0g7TUFDRDs7Ozs7TUFDRCx3QkFBQyxlQUFELEVBRVcsUUFDVixHQUZNLFlBQVksUUFBUTs7OzthQUUxQjtLQUNFOzs7Ozs7SUFDTCx3QkFBQyxnQkFBRDtLQUVXO0tBQ1QsUUFBUTtLQUNSLFdBQVc7S0FDWCxXQUFXO0lBQ1osR0FMTSxRQUFROzs7O1dBS2Q7SUFDRCx3QkFBQyxpQkFBRCxFQUEwQixRQUFVOzs7OztJQUNwQyx3QkFBQyxvQkFBRDtLQUNFLFdBQVcsUUFBUTtLQUNuQixhQUFhLFFBQVE7SUFDdEI7Ozs7O0dBQ0Q7Ozs7Y0FFRix3QkFBQyxxQkFBRDtJQUNFLFFBQVEsS0FBSyxXQUFXLFVBQVUsVUFBVSxLQUFLO0lBQ2pELE9BQU8sS0FBSztHQUNiOzs7O1dBRUE7Ozs7OztDQUNEOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRDYXRlZ29yeU5hbWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9jYXRlZ29yeSc7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IHVzZVByb2R1Y3REZXRhaWxzIH0gZnJvbSAnLi9ob29rcy91c2VQcm9kdWN0RGV0YWlscyc7XHJcbmltcG9ydCB7IFByb2R1Y3RHYWxsZXJ5IH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RHYWxsZXJ5JztcclxuaW1wb3J0IHsgUHJvZHVjdEluZm9ybWF0aW9uIH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RJbmZvcm1hdGlvbic7XHJcbmltcG9ydCB7IFB1cmNoYXNlUGFuZWwgfSBmcm9tICcuL2NvbXBvbmVudHMvUHVyY2hhc2VQYW5lbCc7XHJcbmltcG9ydCB7IFByb2R1Y3RDb250ZW50IH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RDb250ZW50JztcclxuaW1wb3J0IHR5cGUgeyBQcm9kdWN0VGFiIH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2R1Y3RDb250ZW50JztcclxuaW1wb3J0IHR5cGUgeyBSZXZpZXdTdW1tYXJ5IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvcmV2aWV3LnR5cGVzJztcclxuaW1wb3J0IHsgUmVsYXRlZFByb2R1Y3RzIH0gZnJvbSAnLi9jb21wb25lbnRzL1JlbGF0ZWRQcm9kdWN0cyc7XHJcbmltcG9ydCB7IFByb2R1Y3REZXRhaWxzU3RhdGUgfSBmcm9tICcuL2NvbXBvbmVudHMvUHJvZHVjdERldGFpbHNTdGF0ZSc7XHJcbmltcG9ydCB7IFByb2R1Y3RBaUFzc2lzdGFudCB9IGZyb20gJy4vY29tcG9uZW50cy9Qcm9kdWN0QWlBc3Npc3RhbnQvUHJvZHVjdEFpQXNzaXN0YW50JztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZHVjdERldGFpbHNQYWdlKCkge1xyXG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpO1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VQcm9kdWN0RGV0YWlscyhpZCk7XHJcbiAgY29uc3QgW2NvbnRlbnRUYWIsIHNldENvbnRlbnRUYWJdID0gdXNlU3RhdGU8e1xyXG4gICAgaWQ6IHN0cmluZztcclxuICAgIHRhYjogUHJvZHVjdFRhYjtcclxuICB9IHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgYWN0aXZlVGFiID1cclxuICAgIGNvbnRlbnRUYWI/LmlkID09PSBpZCA/IChjb250ZW50VGFiPy50YWIgPz8gJ292ZXJ2aWV3JykgOiAnb3ZlcnZpZXcnO1xyXG4gIGNvbnN0IGNoYW5nZVRhYiA9ICh0YWI6IFByb2R1Y3RUYWIpID0+IHtcclxuICAgIGlmIChpZCkgc2V0Q29udGVudFRhYih7IGlkLCB0YWIgfSk7XHJcbiAgfTtcclxuICBjb25zdCBbcmV2aWV3U3VtbWFyeSwgc2V0UmV2aWV3U3VtbWFyeV0gPSB1c2VTdGF0ZTx7XHJcbiAgICBpZDogc3RyaW5nO1xyXG4gICAgc3VtbWFyeTogUmV2aWV3U3VtbWFyeTtcclxuICB9IHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgdXBkYXRlU3VtbWFyeSA9IHVzZUNhbGxiYWNrKFxyXG4gICAgKHN1bW1hcnk6IFJldmlld1N1bW1hcnkpID0+IHtcclxuICAgICAgaWYgKGlkKSBzZXRSZXZpZXdTdW1tYXJ5KHsgaWQsIHN1bW1hcnkgfSk7XHJcbiAgICB9LFxyXG4gICAgW2lkXSxcclxuICApO1xyXG4gIGNvbnN0IHByb2R1Y3QgPSBwYWdlLnByb2R1Y3RcclxuICAgID8ge1xyXG4gICAgICAgIC4uLnBhZ2UucHJvZHVjdCxcclxuICAgICAgICAuLi4ocmV2aWV3U3VtbWFyeSAmJiByZXZpZXdTdW1tYXJ5LmlkID09PSBpZFxyXG4gICAgICAgICAgPyB7XHJcbiAgICAgICAgICAgICAgcmF0aW5nQXZlcmFnZTogcmV2aWV3U3VtbWFyeS5zdW1tYXJ5LmF2ZXJhZ2UsXHJcbiAgICAgICAgICAgICAgcmF0aW5nQ291bnQ6IHJldmlld1N1bW1hcnkuc3VtbWFyeS5jb3VudCxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgOiB7fSksXHJcbiAgICAgIH1cclxuICAgIDogbnVsbDtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgcHJldmlvdXMgPSBkb2N1bWVudC50aXRsZTtcclxuICAgIGRvY3VtZW50LnRpdGxlID0gYCR7cGFnZS5wcm9kdWN0Py5uYW1lID8/IHRyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5kZXRhaWxzfSB8ICR7dHJhbnNsYXRpb25zLmNvbW1vbi5zdG9yZU5hbWV9YDtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGRvY3VtZW50LnRpdGxlID0gcHJldmlvdXM7XHJcbiAgICB9O1xyXG4gIH0sIFtwYWdlLnByb2R1Y3Q/Lm5hbWVdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogJ2luc3RhbnQnIH0pO1xyXG4gIH0sIFtpZF0pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJwcm9kdWN0LWRldGFpbC1wYWdlIGJnLXBhZ2UgcHgtNCBweS02IHNtOnB4LTYgbWQ6cHktOCBsZzpweC04XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1bMTIwMHB4XSBzcGFjZS15LThcIj5cclxuICAgICAgICA8bmF2XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXt0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMuYnJlYWRjcnVtYn1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc21cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPXtST1VURVMuaG9tZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuc3RvcmVmcm9udC5ob21lfVxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgPGxpIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPi88L2xpPlxyXG4gICAgICAgICAgICB7cHJvZHVjdCAmJiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz17YCR7Uk9VVEVTLnByb2R1Y3RzfT9jYXRlZ29yeT0ke3Byb2R1Y3QuY2F0ZWdvcnkuY2F0ZWdvcnlJRH1gfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q2F0ZWdvcnlOYW1lKHByb2R1Y3QuY2F0ZWdvcnkubmFtZSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGkgYXJpYS1oaWRkZW49XCJ0cnVlXCI+LzwvbGk+XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxsaSBhcmlhLWN1cnJlbnQ9XCJwYWdlXCIgY2xhc3NOYW1lPVwibWluLXctMCBicmVhay13b3Jkc1wiPlxyXG4gICAgICAgICAgICAgIHtwYWdlLnByb2R1Y3Q/Lm5hbWUgPz8gdHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLmRldGFpbHN9XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICA8L29sPlxyXG4gICAgICAgIDwvbmF2PlxyXG4gICAgICAgIHtwYWdlLnN0YXR1cyA9PT0gJ3JlYWR5JyAmJiBwcm9kdWN0ID8gKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWRldGFpbC1ncmlkIGdyaWQgaXRlbXMtc3RhcnQgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLVsxLjNmcl8xZnJfLjlmcl1cIj5cclxuICAgICAgICAgICAgICA8UHJvZHVjdEdhbGxlcnlcclxuICAgICAgICAgICAgICAgIGtleT17YGdhbGxlcnktJHtwcm9kdWN0LnByb2R1Y3RJRH1gfVxyXG4gICAgICAgICAgICAgICAgaW1hZ2VzPXtwcm9kdWN0LmltYWdlc31cclxuICAgICAgICAgICAgICAgIG5hbWU9e3Byb2R1Y3QubmFtZX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxQcm9kdWN0SW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgIHByb2R1Y3Q9e3Byb2R1Y3R9XHJcbiAgICAgICAgICAgICAgICBzaG93UmV2aWV3cz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjaGFuZ2VUYWIoJ3Jldmlld3MnKTtcclxuICAgICAgICAgICAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGFiLXJldmlld3MnKT8uZm9jdXMoKTtcclxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgLmdldEVsZW1lbnRCeUlkKCdwcm9kdWN0LWNvbnRlbnQnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgPy5zY3JvbGxJbnRvVmlldyh7IGJsb2NrOiAnc3RhcnQnIH0pO1xyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8UHVyY2hhc2VQYW5lbFxyXG4gICAgICAgICAgICAgICAga2V5PXtgcHVyY2hhc2UtJHtwcm9kdWN0LnByb2R1Y3RJRH1gfVxyXG4gICAgICAgICAgICAgICAgcHJvZHVjdD17cHJvZHVjdH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPFByb2R1Y3RDb250ZW50XHJcbiAgICAgICAgICAgICAga2V5PXtwcm9kdWN0LnByb2R1Y3RJRH1cclxuICAgICAgICAgICAgICBwcm9kdWN0PXtwcm9kdWN0fVxyXG4gICAgICAgICAgICAgIGFjdGl2ZT17YWN0aXZlVGFifVxyXG4gICAgICAgICAgICAgIHNldEFjdGl2ZT17Y2hhbmdlVGFifVxyXG4gICAgICAgICAgICAgIG9uU3VtbWFyeT17dXBkYXRlU3VtbWFyeX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFJlbGF0ZWRQcm9kdWN0cyBwcm9kdWN0PXtwcm9kdWN0fSAvPlxyXG4gICAgICAgICAgICA8UHJvZHVjdEFpQXNzaXN0YW50XHJcbiAgICAgICAgICAgICAgcHJvZHVjdElkPXtwcm9kdWN0LnByb2R1Y3RJRH1cclxuICAgICAgICAgICAgICBwcm9kdWN0TmFtZT17cHJvZHVjdC5uYW1lfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxQcm9kdWN0RGV0YWlsc1N0YXRlXHJcbiAgICAgICAgICAgIHN0YXR1cz17cGFnZS5zdGF0dXMgPT09ICdyZWFkeScgPyAnZXJyb3InIDogcGFnZS5zdGF0dXN9XHJcbiAgICAgICAgICAgIHJldHJ5PXtwYWdlLnJldHJ5fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==