import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Dialog.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useId = __vite__cjsImport0_react["useId"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { uiText } from "/src/utils/uiText.ts";
import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Dialog.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function Dialog({ open, onClose, title, description, children, drawer = false, busy = false }) {
	_s();
	const ref = useRef(null);
	const id = useId();
	useEffect(() => {
		const element = ref.current;
		if (!open || !element) return;
		const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		element.showModal();
		const overflow = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			element.close();
			document.body.style.overflow = overflow;
			previous?.focus();
		};
	}, [open]);
	if (!open) return null;
	return /* @__PURE__ */ _jsxDEV("dialog", {
		ref,
		"aria-labelledby": id,
		"aria-describedby": description ? `${id}-description` : undefined,
		className: drawer ? "ui-dialog ui-drawer" : "ui-dialog",
		onCancel: (event) => {
			event.preventDefault();
			event.stopPropagation();
			if (!busy) onClose();
		},
		onClick: (event) => {
			if (!busy && event.target === event.currentTarget) {
				const rect = event.currentTarget.getBoundingClientRect();
				if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) onClose();
			}
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-5 flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				id,
				className: "text-xl font-semibold tracking-tight text-fg",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 11
			}, this), description && /* @__PURE__ */ _jsxDEV("p", {
				id: `${id}-description`,
				className: "mt-2 text-sm leading-6 text-fg-secondary",
				children: description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				disabled: busy,
				"aria-label": uiText.close,
				onClick: onClose,
				className: "ui-icon-button shrink-0",
				children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_s(Dialog, "bn6wQSg700njlGbXzxidrTnilM0=");
_c = Dialog;
var _c;
$RefreshReg$(_c, "Dialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/Dialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Dialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLE9BQU8sY0FBOEI7QUFDekQsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsWUFBWTs7OztBQUNyQixPQUFPLFNBQVMsT0FBTyxFQUNyQixNQUNBLFNBQ0EsT0FDQSxhQUNBLFVBQ0EsU0FBUyxPQUNULE9BQU8sU0FTTjs7Q0FDRCxNQUFNLE1BQU0sT0FBMEIsSUFBSTtDQUMxQyxNQUFNLEtBQUssTUFBTTtDQUNqQixnQkFBZ0I7RUFDZCxNQUFNLFVBQVUsSUFBSTtFQUNwQixJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVM7RUFDdkIsTUFBTSxXQUNKLFNBQVMseUJBQXlCLGNBQzlCLFNBQVMsZ0JBQ1Q7RUFDTixRQUFRLFVBQVU7RUFDbEIsTUFBTSxXQUFXLFNBQVMsS0FBSyxNQUFNO0VBQ3JDLFNBQVMsS0FBSyxNQUFNLFdBQVc7RUFDL0IsYUFBYTtHQUNYLFFBQVEsTUFBTTtHQUNkLFNBQVMsS0FBSyxNQUFNLFdBQVc7R0FDL0IsVUFBVSxNQUFNO0VBQ2xCO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQztDQUNULElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsT0FDRSx3QkFBQyxVQUFEO0VBQ087RUFDTCxtQkFBaUI7RUFDakIsb0JBQWtCLGNBQWMsR0FBRyxHQUFHLGdCQUFnQjtFQUN0RCxXQUFXLFNBQVMsd0JBQXdCO0VBQzVDLFdBQVcsVUFBVTtHQUNuQixNQUFNLGVBQWU7R0FDckIsTUFBTSxnQkFBZ0I7R0FDdEIsSUFBSSxDQUFDLE1BQU0sUUFBUTtFQUNyQjtFQUNBLFVBQVUsVUFBVTtHQUNsQixJQUFJLENBQUMsUUFBUSxNQUFNLFdBQVcsTUFBTSxlQUFlO0lBQ2pELE1BQU0sT0FBTyxNQUFNLGNBQWMsc0JBQXNCO0lBQ3ZELElBQ0UsTUFBTSxVQUFVLEtBQUssUUFDckIsTUFBTSxVQUFVLEtBQUssU0FDckIsTUFBTSxVQUFVLEtBQUssT0FDckIsTUFBTSxVQUFVLEtBQUssUUFFckIsUUFBUTtHQUNaO0VBQ0Y7WUFyQkYsQ0F1QkUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0lBQVE7SUFBSSxXQUFVO2NBQ25CO0dBQ0M7Ozs7YUFDSCxlQUNDLHdCQUFDLEtBQUQ7SUFDRSxJQUFJLEdBQUcsR0FBRztJQUNWLFdBQVU7Y0FFVDtHQUNBOzs7O1dBRUY7Ozs7YUFDTCx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFVBQVU7SUFDVixjQUFZLE9BQU87SUFDbkIsU0FBUztJQUNULFdBQVU7Y0FFVix3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztHQUNkOzs7O1dBQ0w7Ozs7O1lBQ0osUUFDSzs7Ozs7O0FBRVoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGlhbG9nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZUlkLCB1c2VSZWYsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1aVRleHQgfSBmcm9tICcuLi8uLi91dGlscy91aVRleHQnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5leHBvcnQgZnVuY3Rpb24gRGlhbG9nKHtcclxuICBvcGVuLFxyXG4gIG9uQ2xvc2UsXHJcbiAgdGl0bGUsXHJcbiAgZGVzY3JpcHRpb24sXHJcbiAgY2hpbGRyZW4sXHJcbiAgZHJhd2VyID0gZmFsc2UsXHJcbiAgYnVzeSA9IGZhbHNlLFxyXG59OiB7XHJcbiAgb3BlbjogYm9vbGVhbjtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxuICBkcmF3ZXI/OiBib29sZWFuO1xyXG4gIGJ1c3k/OiBib29sZWFuO1xyXG59KSB7XHJcbiAgY29uc3QgcmVmID0gdXNlUmVmPEhUTUxEaWFsb2dFbGVtZW50PihudWxsKTtcclxuICBjb25zdCBpZCA9IHVzZUlkKCk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGVsZW1lbnQgPSByZWYuY3VycmVudDtcclxuICAgIGlmICghb3BlbiB8fCAhZWxlbWVudCkgcmV0dXJuO1xyXG4gICAgY29uc3QgcHJldmlvdXMgPVxyXG4gICAgICBkb2N1bWVudC5hY3RpdmVFbGVtZW50IGluc3RhbmNlb2YgSFRNTEVsZW1lbnRcclxuICAgICAgICA/IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnRcclxuICAgICAgICA6IG51bGw7XHJcbiAgICBlbGVtZW50LnNob3dNb2RhbCgpO1xyXG4gICAgY29uc3Qgb3ZlcmZsb3cgPSBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93O1xyXG4gICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZWxlbWVudC5jbG9zZSgpO1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gb3ZlcmZsb3c7XHJcbiAgICAgIHByZXZpb3VzPy5mb2N1cygpO1xyXG4gICAgfTtcclxuICB9LCBbb3Blbl0pO1xyXG4gIGlmICghb3BlbikgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaWFsb2dcclxuICAgICAgcmVmPXtyZWZ9XHJcbiAgICAgIGFyaWEtbGFiZWxsZWRieT17aWR9XHJcbiAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e2Rlc2NyaXB0aW9uID8gYCR7aWR9LWRlc2NyaXB0aW9uYCA6IHVuZGVmaW5lZH1cclxuICAgICAgY2xhc3NOYW1lPXtkcmF3ZXIgPyAndWktZGlhbG9nIHVpLWRyYXdlcicgOiAndWktZGlhbG9nJ31cclxuICAgICAgb25DYW5jZWw9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgaWYgKCFidXN5KSBvbkNsb3NlKCk7XHJcbiAgICAgIH19XHJcbiAgICAgIG9uQ2xpY2s9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGlmICghYnVzeSAmJiBldmVudC50YXJnZXQgPT09IGV2ZW50LmN1cnJlbnRUYXJnZXQpIHtcclxuICAgICAgICAgIGNvbnN0IHJlY3QgPSBldmVudC5jdXJyZW50VGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICBldmVudC5jbGllbnRYIDwgcmVjdC5sZWZ0IHx8XHJcbiAgICAgICAgICAgIGV2ZW50LmNsaWVudFggPiByZWN0LnJpZ2h0IHx8XHJcbiAgICAgICAgICAgIGV2ZW50LmNsaWVudFkgPCByZWN0LnRvcCB8fFxyXG4gICAgICAgICAgICBldmVudC5jbGllbnRZID4gcmVjdC5ib3R0b21cclxuICAgICAgICAgIClcclxuICAgICAgICAgICAgb25DbG9zZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IGZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMiBpZD17aWR9IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgIHt0aXRsZX1cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICB7ZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgIGlkPXtgJHtpZH0tZGVzY3JpcHRpb25gfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1mZy1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXt1aVRleHQuY2xvc2V9XHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktaWNvbi1idXR0b24gc2hyaW5rLTBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJjbG9zZVwiIC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L2RpYWxvZz5cclxuICApO1xyXG59XHJcbiJdfQ==