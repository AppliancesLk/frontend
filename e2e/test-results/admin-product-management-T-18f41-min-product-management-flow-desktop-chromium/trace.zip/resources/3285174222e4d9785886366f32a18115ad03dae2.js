import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Repairs/components/RepairsTable.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { formatDate } from "/src/utils/date.ts";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { translations } from "/src/utils/translations.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { RepairStatusBadge } from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairsTable.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.adminRepairs;
export function RepairsTable({ repairs }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "overflow-hidden rounded-md border border-line bg-surface ",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "ui-table ui-card-table min-w-full divide-y divide-line",
				children: [/* @__PURE__ */ _jsxDEV("thead", {
					className: "bg-page",
					children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-4 py-3 text-left text-sm font-semibold text-fg",
							children: t.reference
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-4 py-3 text-left text-sm font-semibold text-fg",
							children: t.customer
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-4 py-3 text-left text-sm font-semibold text-fg",
							children: t.device
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-4 py-3 text-left text-sm font-semibold text-fg",
							children: t.status
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-4 py-3 text-left text-sm font-semibold text-fg",
							children: t.submittedDate
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-4 py-3",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "sr-only",
								children: translations.admin.actions
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("tbody", {
					className: "divide-y divide-line bg-surface",
					children: repairs.map((repair) => /* @__PURE__ */ _jsxDEV("tr", {
						className: "hover:bg-page transition-colors",
						children: [
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": t.reference,
								className: "xl:whitespace-nowrap px-4 py-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "tabular-nums text-sm font-medium text-fg",
										children: repair.reference
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": t.customer,
								className: "px-4 py-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-sm text-fg",
										children: repair.customer.username
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-sm text-fg-muted",
										children: repair.customer.email
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 70,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": t.device,
								className: "px-4 py-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-sm text-fg",
										children: repair.device.deviceType
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-sm text-fg-muted",
										children: [
											repair.device.brand,
											" ",
											repair.device.model
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 80,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": t.status,
								className: "px-4 py-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status: repair.status }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 87,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": t.submittedDate,
								className: "xl:whitespace-nowrap px-4 py-4 text-sm text-fg-muted",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: formatDate(repair.createdAt)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": translations.admin.actions,
								className: "xl:whitespace-nowrap px-4 py-4 text-right text-sm",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV(Link, {
										to: ROUTES.adminRepairDetail.replace(":id", repair.id),
										className: "font-medium text-fg-link hover:text-fg-link",
										children: t.viewDetails
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 103,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 17
							}, this)
						]
					}, repair.id, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = RepairsTable;
var _c;
$RefreshReg$(_c, "RepairsTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Repairs/components/RepairsTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairsTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairsTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairsTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZO0FBRXJCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsY0FBYztBQUN2QixTQUFTLHlCQUF5Qjs7O0FBRWxDLE1BQU0sSUFBSSxhQUFhO0FBRXZCLE9BQU8sU0FBUyxhQUFhLEVBQUUsV0FBNkM7Q0FDMUUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakIsQ0FDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUNmLHdCQUFDLE1BQUQ7TUFDRSx3QkFBQyxNQUFEO09BQ0UsT0FBTTtPQUNOLFdBQVU7aUJBRVQsRUFBRTtNQUNEOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FDRSxPQUFNO09BQ04sV0FBVTtpQkFFVCxFQUFFO01BQ0Q7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUNFLE9BQU07T0FDTixXQUFVO2lCQUVULEVBQUU7TUFDRDs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQ0UsT0FBTTtPQUNOLFdBQVU7aUJBRVQsRUFBRTtNQUNEOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FDRSxPQUFNO09BQ04sV0FBVTtpQkFFVCxFQUFFO01BQ0Q7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUFJLE9BQU07T0FBTSxXQUFVO2lCQUN4Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBVyxhQUFhLE1BQU07T0FBYzs7Ozs7TUFDMUQ7Ozs7O0tBQ0Y7Ozs7O0lBQ0M7Ozs7Y0FDUCx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUNkLFFBQVEsS0FBSyxXQUNaLHdCQUFDLE1BQUQ7TUFBb0IsV0FBVTtnQkFBOUI7T0FDRSx3QkFBQyxNQUFEO1FBQ0UsY0FBWSxFQUFFO1FBQ2QsV0FBVTtrQkFFVix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixPQUFPO1NBQ0w7Ozs7O1FBQ0Y7Ozs7O09BQ0g7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLGNBQVksRUFBRTtRQUFVLFdBQVU7a0JBQ3BDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osT0FBTyxTQUFTO1NBQ2Q7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osT0FBTyxTQUFTO1NBQ2Q7Ozs7aUJBQ0Y7Ozs7OztPQUNIOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxjQUFZLEVBQUU7UUFBUSxXQUFVO2tCQUNsQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaLE9BQU8sT0FBTztTQUNaOzs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0csT0FBTyxPQUFPO1dBQU07V0FBRSxPQUFPLE9BQU87VUFDbEM7Ozs7O2lCQUNGOzs7Ozs7T0FDSDs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksY0FBWSxFQUFFO1FBQVEsV0FBVTtrQkFDbEMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsbUJBQUQsRUFBbUIsUUFBUSxPQUFPLE9BQVM7Ozs7O1FBQ3hDOzs7OztPQUNIOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFDRSxjQUFZLEVBQUU7UUFDZCxXQUFVO2tCQUVWLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFdBQVcsT0FBTyxTQUFTO1FBQ3pCOzs7OztPQUNIOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFDRSxjQUFZLGFBQWEsTUFBTTtRQUMvQixXQUFVO2tCQUVWLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE1BQUQ7VUFDRSxJQUFJLE9BQU8sa0JBQWtCLFFBQVEsT0FBTyxPQUFPLEVBQUU7VUFDckQsV0FBVTtvQkFFVCxFQUFFO1NBQ0M7Ozs7O1FBQ0g7Ozs7O09BQ0g7Ozs7O01BQ0Y7UUF6REssT0FBTzs7OztZQXlEWixDQUNMO0lBQ0k7Ozs7WUFDRjs7Ozs7O0VBQ0o7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVwYWlyc1RhYmxlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHR5cGUgeyBBZG1pblJlcGFpclRpY2tldCB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3JlcGFpci50eXBlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyBSZXBhaXJTdGF0dXNCYWRnZSB9IGZyb20gJy4vUmVwYWlyU3RhdHVzQmFkZ2UnO1xyXG5cclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pblJlcGFpcnM7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmVwYWlyc1RhYmxlKHsgcmVwYWlycyB9OiB7IHJlcGFpcnM6IEFkbWluUmVwYWlyVGlja2V0W10gfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ1aS10YWJsZSB1aS1jYXJkLXRhYmxlIG1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWxpbmVcIj5cclxuICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1wYWdlXCI+XHJcbiAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICA8dGhcclxuICAgICAgICAgICAgICAgIHNjb3BlPVwiY29sXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZmdcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0LnJlZmVyZW5jZX1cclxuICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aFxyXG4gICAgICAgICAgICAgICAgc2NvcGU9XCJjb2xcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3QuY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICA8dGhcclxuICAgICAgICAgICAgICAgIHNjb3BlPVwiY29sXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZmdcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0LmRldmljZX1cclxuICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aFxyXG4gICAgICAgICAgICAgICAgc2NvcGU9XCJjb2xcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Quc3RhdHVzfVxyXG4gICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoXHJcbiAgICAgICAgICAgICAgICBzY29wZT1cImNvbFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dC5zdWJtaXR0ZWREYXRlfVxyXG4gICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+e3RyYW5zbGF0aW9ucy5hZG1pbi5hY3Rpb25zfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtbGluZSBiZy1zdXJmYWNlXCI+XHJcbiAgICAgICAgICAgIHtyZXBhaXJzLm1hcCgocmVwYWlyKSA9PiAoXHJcbiAgICAgICAgICAgICAgPHRyIGtleT17cmVwYWlyLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1wYWdlIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17dC5yZWZlcmVuY2V9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInhsOndoaXRlc3BhY2Utbm93cmFwIHB4LTQgcHktNFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktY2VsbC12YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFidWxhci1udW1zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3JlcGFpci5yZWZlcmVuY2V9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPXt0LmN1c3RvbWVyfSBjbGFzc05hbWU9XCJweC00IHB5LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZXBhaXIuY3VzdG9tZXIudXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZXBhaXIuY3VzdG9tZXIuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPXt0LmRldmljZX0gY2xhc3NOYW1lPVwicHgtNCBweS00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktY2VsbC12YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmVwYWlyLmRldmljZS5kZXZpY2VUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmVwYWlyLmRldmljZS5icmFuZH0ge3JlcGFpci5kZXZpY2UubW9kZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPXt0LnN0YXR1c30gY2xhc3NOYW1lPVwicHgtNCBweS00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktY2VsbC12YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSZXBhaXJTdGF0dXNCYWRnZSBzdGF0dXM9e3JlcGFpci5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICBkYXRhLWxhYmVsPXt0LnN1Ym1pdHRlZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInhsOndoaXRlc3BhY2Utbm93cmFwIHB4LTQgcHktNCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShyZXBhaXIuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgIGRhdGEtbGFiZWw9e3RyYW5zbGF0aW9ucy5hZG1pbi5hY3Rpb25zfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ4bDp3aGl0ZXNwYWNlLW5vd3JhcCBweC00IHB5LTQgdGV4dC1yaWdodCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuYWRtaW5SZXBhaXJEZXRhaWwucmVwbGFjZSgnOmlkJywgcmVwYWlyLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0LnZpZXdEZXRhaWxzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICA8L3RhYmxlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19