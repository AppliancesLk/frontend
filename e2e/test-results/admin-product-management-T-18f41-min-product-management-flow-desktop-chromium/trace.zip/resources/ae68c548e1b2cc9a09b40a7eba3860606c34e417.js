import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/reviews/ProductReviews.tsx");const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport16_react_jsxDevRuntime["Fragment"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { uiText } from "/src/utils/uiText.ts";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { USER_ROLES } from "/src/constants/roles.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { formatDate } from "/src/utils/date.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { saveReview, deleteReview } from "/src/services/reviewService.ts";
import { useProductReviews } from "/src/components/reviews/hooks/useProductReviews.ts";
import { Rating } from "/src/components/common/Rating.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/reviews/ProductReviews.tsx";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const t = translations.experience;
function ReviewForm({ productId, mine, onSaved }) {
	_s();
	const [rating, setRating] = useState(mine?.rating ?? 5), [title, setTitle] = useState(mine?.title ?? ""), [body, setBody] = useState(mine?.body ?? ""), [busy, setBusy] = useState(false), [error, setError] = useState("");
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "rounded-md border border-line bg-page p-5",
		onSubmit: (event) => {
			event.preventDefault();
			if (busy) return;
			setBusy(true);
			setError("");
			void saveReview(productId, {
				rating,
				title,
				body
			}, !!mine).then(onSaved).catch((error) => setError(getApiError(error, t.reviewSaveError))).finally(() => setBusy(false));
		},
		children: [
			/* @__PURE__ */ _jsxDEV("h3", {
				className: "mb-4 font-semibold text-fg",
				children: mine ? t.editReview : t.writeReview
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				disabled: busy,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-medium text-fg-secondary",
						children: [t.rating, /* @__PURE__ */ _jsxDEV("select", {
							"aria-label": t.rating,
							value: rating,
							onChange: (event) => setRating(Number(event.target.value)),
							className: "ui-field auth-input mt-2",
							children: [
								5,
								4,
								3,
								2,
								1
							].map((value) => /* @__PURE__ */ _jsxDEV("option", {
								value,
								children: [
									"★".repeat(value),
									" (",
									value,
									"/5)"
								]
							}, value, true, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-medium text-fg-secondary",
						children: [t.reviewTitle, /* @__PURE__ */ _jsxDEV("input", {
							required: true,
							minLength: 2,
							maxLength: 120,
							value: title,
							onChange: (event) => setTitle(event.target.value),
							className: "ui-field auth-input mt-2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-medium text-fg-secondary",
						children: [t.reviewBody, /* @__PURE__ */ _jsxDEV("textarea", {
							required: true,
							minLength: 10,
							maxLength: 3e3,
							rows: 4,
							value: body,
							onChange: (event) => setBody(event.target.value),
							className: "ui-field auth-input mt-2 h-auto py-2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "auth-primary",
						children: [busy && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 20
						}, this), busy ? t.loading : mine ? t.updateReview : t.submitReview]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mt-3 text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 5
	}, this);
}
_s(ReviewForm, "EuvITNDLKzlQFRSQXv/mPs98bco=");
_c = ReviewForm;
export function ProductReviews({ productId, onSummary }) {
	_s2();
	const { user } = useAuth();
	const location = useLocation();
	const customer = user?.role === USER_ROLES.CUSTOMER;
	const page = useProductReviews(productId, customer ? user.id : undefined, user?.role === USER_ROLES.ADMIN);
	const [feedback, setFeedback] = useState(""), [error, setError] = useState(""), [deleting, setDeleting] = useState(false);
	const [deleteId, setDeleteId] = useState(null);
	const summary = page.data?.summary;
	useEffect(() => {
		if (summary) onSummary?.(summary);
	}, [summary, onSummary]);
	async function remove(id) {
		if (deleting) return;
		setDeleting(true);
		setError("");
		try {
			await deleteReview(productId, id);
			setFeedback(t.reviewDeleted);
			setDeleteId(null);
			page.refresh();
		} catch {
			setError(t.reviewDeleteError);
		} finally {
			setDeleting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "reviews",
		"aria-label": t.reviews,
		className: "scroll-mt-32 space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: deleteId !== null,
				onClose: () => setDeleteId(null),
				title: t.deleteReview,
				description: t.deleteConfirm,
				busy: deleting,
				children: [error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "ui-alert ui-tone-danger mb-4",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-end gap-3",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: deleting,
						onClick: () => setDeleteId(null),
						children: uiText.cancel
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "danger",
						busy: deleting,
						onClick: () => {
							if (deleteId) void remove(deleteId);
						},
						children: t.deleteReview
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-semibold text-fg",
				children: user?.role === USER_ROLES.ADMIN ? t.moderation : t.reviews
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 177,
				columnNumber: 7
			}, this),
			page.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, {
				label: t.loading,
				compact: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 181,
				columnNumber: 9
			}, this) : page.error ? /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-danger",
					children: t.reviewError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 184,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "auth-secondary mt-3",
					onClick: page.refresh,
					children: t.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 9
			}, this) : page.data && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-6 md:grid-cols-[13rem_1fr]",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md bg-primary-subtle p-5",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-4xl font-bold text-fg",
							children: summary?.count ? summary.average.toFixed(1) : "—"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV(Rating, {
							average: summary?.average ?? 0,
							count: summary?.count ?? 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 17
						}, this),
						summary?.distribution.map((row) => /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-center gap-2 text-xs text-fg-muted",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: [row.rating, " ★"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "h-2 flex-1 overflow-hidden rounded-full bg-surface",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "h-full bg-accent",
										style: { width: `${summary.count ? row.count / summary.count * 100 : 0}%` }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 208,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: row.count }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 21
								}, this)
							]
						}, row.rating, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 19
						}, this))
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [page.data.items.length ? page.data.items.map((review) => /* @__PURE__ */ _jsxDEV("article", {
						className: "rounded-md border border-line p-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-semibold text-fg",
									children: review.author
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("time", {
									className: "text-xs text-fg-muted",
									dateTime: review.createdAt,
									children: formatDate(review.createdAt)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 23
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 text-warning",
								"aria-label": `${t.rating}: ${review.rating}/5`,
								children: "★".repeat(review.rating)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 23
							}, this),
							review.verifiedPurchase && /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 text-xs font-medium text-success",
								children: t.verified
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "mt-2 break-words font-semibold text-fg",
								children: review.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 23
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 whitespace-pre-wrap break-words text-sm leading-6 text-fg-secondary",
								children: review.body
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 23
							}, this),
							(review.id === page.mine?.id || user?.role === USER_ROLES.ADMIN) && /* @__PURE__ */ _jsxDEV("button", {
								disabled: deleting,
								className: "mt-3 rounded-sm px-3 py-2 text-xs font-medium text-danger hover:bg-danger-bg ",
								onClick: () => {
									setError("");
									setDeleteId(review.id);
								},
								children: t.deleteReview
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 25
							}, this)
						]
					}, review.id, true, {
						fileName: _jsxFileName,
						lineNumber: 222,
						columnNumber: 21
					}, this)) : /* @__PURE__ */ _jsxDEV("p", {
						className: "p-4 text-sm text-fg-muted",
						children: t.noReviews
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 270,
						columnNumber: 19
					}, this), page.data.totalPages > 1 && /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								className: "auth-secondary",
								disabled: page.data.page <= 1,
								onClick: () => page.setPage(page.data.page - 1),
								children: t.previous
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm text-fg-muted",
								children: [
									page.data.page,
									"/",
									page.data.totalPages
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "auth-secondary",
								disabled: page.data.page >= page.data.totalPages,
								onClick: () => page.setPage(page.data.page + 1),
								children: t.next
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 21
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 273,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 192,
				columnNumber: 13
			}, this), customer ? /* @__PURE__ */ _jsxDEV(ReviewForm, {
				productId,
				mine: page.mine,
				onSaved: () => {
					setFeedback(t.reviewSaved);
					page.refresh();
				}
			}, page.mine?.id ?? "new", false, {
				fileName: _jsxFileName,
				lineNumber: 296,
				columnNumber: 15
			}, this) : !user ? /* @__PURE__ */ _jsxDEV(Link, {
				to: ROUTES.login,
				state: { from: location.pathname + location.search },
				className: "inline-flex rounded-sm bg-primary px-4 py-3 text-sm font-medium text-primary-on",
				children: t.signInReview
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 306,
				columnNumber: 15
			}, this) : null] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 11
			}, this),
			feedback && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "text-sm text-success",
				children: feedback
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 318,
				columnNumber: 9
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 323,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 141,
		columnNumber: 5
	}, this);
}
_s2(ProductReviews, "u11xq0EDB3PbmdsxzpPabE++QE8=", false, function() {
	return [
		useAuth,
		useLocation,
		useProductReviews
	];
});
_c2 = ProductReviews;
var _c, _c2;
$RefreshReg$(_c, "ReviewForm");
$RefreshReg$(_c2, "ProductReviews");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/reviews/ProductReviews.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/reviews/ProductReviews.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/reviews/ProductReviews.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/reviews/ProductReviews.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsV0FBVyxnQkFBZ0I7QUFDcEMsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsWUFBWSxvQkFBb0I7QUFDekMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxjQUFjOzs7O0FBRXZCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLFNBQVMsV0FBVyxFQUNsQixXQUNBLE1BQ0EsV0FLQzs7Q0FDRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsTUFBTSxVQUFVLENBQUMsR0FDcEQsQ0FBQyxPQUFPLFlBQVksU0FBUyxNQUFNLFNBQVMsRUFBRSxHQUM5QyxDQUFDLE1BQU0sV0FBVyxTQUFTLE1BQU0sUUFBUSxFQUFFLEdBQzNDLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSyxHQUNoQyxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDakMsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVTtFQUNWLFdBQVcsVUFBVTtHQUNuQixNQUFNLGVBQWU7R0FDckIsSUFBSSxNQUFNO0dBQ1YsUUFBUSxJQUFJO0dBQ1osU0FBUyxFQUFFO0dBQ1gsS0FBSyxXQUFXLFdBQVc7SUFBRTtJQUFRO0lBQU87R0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FDeEQsS0FBSyxPQUFPLENBQUMsQ0FDYixPQUFPLFVBQVUsU0FBUyxZQUFZLE9BQU8sRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQ2pFLGNBQWMsUUFBUSxLQUFLLENBQUM7RUFDakM7WUFYRjtHQWFFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsT0FBTyxFQUFFLGFBQWEsRUFBRTtHQUN2Qjs7Ozs7R0FDSix3QkFBQyxZQUFEO0lBQVUsVUFBVTtJQUFNLFdBQVU7Y0FBcEM7S0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRyxFQUFFLFFBQ0gsd0JBQUMsVUFBRDtPQUNFLGNBQVksRUFBRTtPQUNkLE9BQU87T0FDUCxXQUFXLFVBQVUsVUFBVSxPQUFPLE1BQU0sT0FBTyxLQUFLLENBQUM7T0FDekQsV0FBVTtpQkFFVDtRQUFDO1FBQUc7UUFBRztRQUFHO1FBQUc7T0FBQyxDQUFDLENBQUMsS0FBSyxVQUNwQix3QkFBQyxVQUFEO1FBQTJCO2tCQUEzQjtTQUNHLElBQUksT0FBTyxLQUFLO1NBQUU7U0FBRztTQUFNO1FBQ3RCO1VBRks7Ozs7Y0FFTCxDQUNUO01BQ0s7Ozs7Y0FDSDs7Ozs7O0tBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0csRUFBRSxhQUNILHdCQUFDLFNBQUQ7T0FDRTtPQUNBLFdBQVc7T0FDWCxXQUFXO09BQ1gsT0FBTztPQUNQLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO09BQ2hELFdBQVU7TUFDWDs7OztjQUNJOzs7Ozs7S0FDUCx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRyxFQUFFLFlBQ0gsd0JBQUMsWUFBRDtPQUNFO09BQ0EsV0FBVztPQUNYLFdBQVc7T0FDWCxNQUFNO09BQ04sT0FBTztPQUNQLFdBQVcsVUFBVSxRQUFRLE1BQU0sT0FBTyxLQUFLO09BQy9DLFdBQVU7TUFDWDs7OztjQUNJOzs7Ozs7S0FDUCx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFBbEIsQ0FDRyxRQUFRLHdCQUFDLFNBQUQsRUFBUyxXQUFVLE9BQVE7Ozs7Z0JBQ25DLE9BQU8sRUFBRSxVQUFVLE9BQU8sRUFBRSxlQUFlLEVBQUUsWUFDeEM7Ozs7OztJQUNBOzs7Ozs7R0FDVCxTQUNDLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVEsV0FBVTtjQUN2QjtHQUNBOzs7OztFQUVEOzs7Ozs7QUFFVjs7O0FBQ0EsT0FBTyxTQUFTLGVBQWUsRUFDN0IsV0FDQSxhQUlDOztDQUNELE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLE1BQU0sU0FBUyxXQUFXO0NBQzNDLE1BQU0sT0FBTyxrQkFDWCxXQUNBLFdBQVcsS0FBSyxLQUFLLFdBQ3JCLE1BQU0sU0FBUyxXQUFXLEtBQzVCO0NBQ0EsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUUsR0FDekMsQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFLEdBQy9CLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7Q0FDNUQsTUFBTSxVQUFVLEtBQUssTUFBTTtDQUMzQixnQkFBZ0I7RUFDZCxJQUFJLFNBQVMsWUFBWSxPQUFPO0NBQ2xDLEdBQUcsQ0FBQyxTQUFTLFNBQVMsQ0FBQztDQUN2QixlQUFlLE9BQU8sSUFBWTtFQUNoQyxJQUFJLFVBQVU7RUFDZCxZQUFZLElBQUk7RUFDaEIsU0FBUyxFQUFFO0VBQ1gsSUFBSTtHQUNGLE1BQU0sYUFBYSxXQUFXLEVBQUU7R0FDaEMsWUFBWSxFQUFFLGFBQWE7R0FDM0IsWUFBWSxJQUFJO0dBQ2hCLEtBQUssUUFBUTtFQUNmLFFBQVE7R0FDTixTQUFTLEVBQUUsaUJBQWlCO0VBQzlCLFVBQVU7R0FDUixZQUFZLEtBQUs7RUFDbkI7Q0FDRjtDQUNBLE9BQ0Usd0JBQUMsV0FBRDtFQUNFLElBQUc7RUFDSCxjQUFZLEVBQUU7RUFDZCxXQUFVO1lBSFo7R0FLRSx3QkFBQyxRQUFEO0lBQ0UsTUFBTSxhQUFhO0lBQ25CLGVBQWUsWUFBWSxJQUFJO0lBQy9CLE9BQU8sRUFBRTtJQUNULGFBQWEsRUFBRTtJQUNmLE1BQU07Y0FMUixDQU9HLFNBQ0Msd0JBQUMsS0FBRDtLQUFHLE1BQUs7S0FBUSxXQUFVO2VBQ3ZCO0lBQ0E7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixVQUFVO01BQ1YsZUFBZSxZQUFZLElBQUk7Z0JBRTlCLE9BQU87S0FDRjs7OztlQUNSLHdCQUFDLFFBQUQ7TUFDRSxTQUFRO01BQ1IsTUFBTTtNQUNOLGVBQWU7T0FDYixJQUFJLFVBQVUsS0FBSyxPQUFPLFFBQVE7TUFDcEM7Z0JBRUMsRUFBRTtLQUNHOzs7O2FBQ0w7Ozs7O1lBQ0M7Ozs7OztHQUNSLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsTUFBTSxTQUFTLFdBQVcsUUFBUSxFQUFFLGFBQWEsRUFBRTtHQUNsRDs7Ozs7R0FDSCxLQUFLLFVBQ0osd0JBQUMsY0FBRDtJQUFjLE9BQU8sRUFBRTtJQUFTLFNBQVM7R0FBTzs7OztjQUM5QyxLQUFLLFFBQ1Asd0JBQUMsT0FBRDtJQUFLLE1BQUs7Y0FBVixDQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXVCLEVBQUU7SUFBZTs7OztjQUNyRCx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFzQixTQUFTLEtBQUs7ZUFDbkQsRUFBRTtJQUNHOzs7O1lBQ0w7Ozs7O2NBRUwsS0FBSyxRQUNILGdEQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsU0FBUyxRQUFRLFFBQVEsUUFBUSxRQUFRLENBQUMsSUFBSTtNQUM5Qzs7Ozs7TUFDSCx3QkFBQyxRQUFEO09BQ0UsU0FBUyxTQUFTLFdBQVc7T0FDN0IsT0FBTyxTQUFTLFNBQVM7TUFDMUI7Ozs7O01BQ0EsU0FBUyxhQUFhLEtBQUssUUFDMUIsd0JBQUMsT0FBRDtPQUVFLFdBQVU7aUJBRlo7UUFJRSx3QkFBQyxRQUFELGFBQU8sSUFBSSxRQUFPLElBQVE7Ozs7O1FBQzFCLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQ7VUFDRSxXQUFVO1VBQ1YsT0FBTyxFQUNMLE9BQU8sR0FBRyxRQUFRLFFBQVMsSUFBSSxRQUFRLFFBQVEsUUFBUyxNQUFNLEVBQUUsR0FDbEU7U0FDRDs7Ozs7UUFDRTs7Ozs7UUFDTCx3QkFBQyxRQUFELFlBQU8sSUFBSSxNQUFZOzs7OztPQUNwQjtTQWJFLElBQUk7Ozs7YUFhTixDQUNOO0tBQ0U7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNHLEtBQUssS0FBSyxNQUFNLFNBQ2YsS0FBSyxLQUFLLE1BQU0sS0FBSyxXQUNuQix3QkFBQyxXQUFEO01BRUUsV0FBVTtnQkFGWjtPQUlFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsT0FBTztRQUNQOzs7O2tCQUNILHdCQUFDLFFBQUQ7U0FDRSxXQUFVO1NBQ1YsVUFBVSxPQUFPO21CQUVoQixXQUFXLE9BQU8sU0FBUztRQUN4Qjs7OztnQkFDSDs7Ozs7O09BQ0wsd0JBQUMsS0FBRDtRQUNFLFdBQVU7UUFDVixjQUFZLEdBQUcsRUFBRSxPQUFPLElBQUksT0FBTyxPQUFPO2tCQUV6QyxJQUFJLE9BQU8sT0FBTyxNQUFNO09BQ3hCOzs7OztPQUNGLE9BQU8sb0JBQ04sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsRUFBRTtPQUNGOzs7OztPQUVMLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLE9BQU87T0FDTjs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixPQUFPO09BQ1A7Ozs7O1FBQ0QsT0FBTyxPQUFPLEtBQUssTUFBTSxNQUN6QixNQUFNLFNBQVMsV0FBVyxVQUMxQix3QkFBQyxVQUFEO1FBQ0UsVUFBVTtRQUNWLFdBQVU7UUFDVixlQUFlO1NBQ2IsU0FBUyxFQUFFO1NBQ1gsWUFBWSxPQUFPLEVBQUU7UUFDdkI7a0JBRUMsRUFBRTtPQUNHOzs7OztNQUVIO1FBNUNGLE9BQU87Ozs7WUE0Q0wsQ0FDVixJQUVELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE2QixFQUFFO0tBQWE7Ozs7ZUFFMUQsS0FBSyxLQUFLLGFBQWEsS0FDdEIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsV0FBVTtRQUNWLFVBQVUsS0FBSyxLQUFLLFFBQVE7UUFDNUIsZUFBZSxLQUFLLFFBQVEsS0FBSyxLQUFNLE9BQU8sQ0FBQztrQkFFOUMsRUFBRTtPQUNHOzs7OztPQUNSLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUNHLEtBQUssS0FBSztTQUFLO1NBQUUsS0FBSyxLQUFLO1FBQ3hCOzs7Ozs7T0FDTix3QkFBQyxVQUFEO1FBQ0UsV0FBVTtRQUNWLFVBQVUsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLO1FBQ3RDLGVBQWUsS0FBSyxRQUFRLEtBQUssS0FBTSxPQUFPLENBQUM7a0JBRTlDLEVBQUU7T0FDRzs7Ozs7TUFDTDs7Ozs7YUFFSjs7Ozs7WUFDRjs7Ozs7YUFDSixXQUNDLHdCQUFDLFlBQUQ7SUFFYTtJQUNYLE1BQU0sS0FBSztJQUNYLGVBQWU7S0FDYixZQUFZLEVBQUUsV0FBVztLQUN6QixLQUFLLFFBQVE7SUFDZjtHQUNELEdBUE0sS0FBSyxNQUFNLE1BQU07Ozs7VUFPdkIsSUFDQyxDQUFDLE9BQ0gsd0JBQUMsTUFBRDtJQUNFLElBQUksT0FBTztJQUNYLE9BQU8sRUFBRSxNQUFNLFNBQVMsV0FBVyxTQUFTLE9BQU87SUFDbkQsV0FBVTtjQUVULEVBQUU7R0FDQzs7OztjQUNKLElBQ0o7Ozs7O0dBR0wsWUFDQyx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFTLFdBQVU7Y0FDeEI7R0FDQTs7Ozs7R0FFSixTQUNDLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVEsV0FBVTtjQUN2QjtHQUNBOzs7OztFQUVFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0UmV2aWV3cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgRGlhbG9nIH0gZnJvbSAnLi4vdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgdWlUZXh0IH0gZnJvbSAnLi4vLi4vdXRpbHMvdWlUZXh0JztcclxuaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IFVTRVJfUk9MRVMgfSBmcm9tICcuLi8uLi9jb25zdGFudHMvcm9sZXMnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uL3V0aWxzL2RhdGUnO1xyXG5pbXBvcnQgeyBnZXRBcGlFcnJvciB9IGZyb20gJy4uLy4uL3V0aWxzL2FwaUVycm9ycyc7XHJcbmltcG9ydCB7IHNhdmVSZXZpZXcsIGRlbGV0ZVJldmlldyB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3Jldmlld1NlcnZpY2UnO1xyXG5pbXBvcnQgeyB1c2VQcm9kdWN0UmV2aWV3cyB9IGZyb20gJy4vaG9va3MvdXNlUHJvZHVjdFJldmlld3MnO1xyXG5pbXBvcnQgeyBSYXRpbmcgfSBmcm9tICcuLi9jb21tb24vUmF0aW5nJztcclxuaW1wb3J0IHR5cGUgeyBQcm9kdWN0UmV2aWV3LCBSZXZpZXdTdW1tYXJ5IH0gZnJvbSAnLi4vLi4vdHlwZXMvcmV2aWV3LnR5cGVzJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5leHBlcmllbmNlO1xyXG5mdW5jdGlvbiBSZXZpZXdGb3JtKHtcclxuICBwcm9kdWN0SWQsXHJcbiAgbWluZSxcclxuICBvblNhdmVkLFxyXG59OiB7XHJcbiAgcHJvZHVjdElkOiBzdHJpbmc7XHJcbiAgbWluZT86IFByb2R1Y3RSZXZpZXcgfCBudWxsO1xyXG4gIG9uU2F2ZWQ6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBjb25zdCBbcmF0aW5nLCBzZXRSYXRpbmddID0gdXNlU3RhdGUobWluZT8ucmF0aW5nID8/IDUpLFxyXG4gICAgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShtaW5lPy50aXRsZSA/PyAnJyksXHJcbiAgICBbYm9keSwgc2V0Qm9keV0gPSB1c2VTdGF0ZShtaW5lPy5ib2R5ID8/ICcnKSxcclxuICAgIFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKSxcclxuICAgIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybVxyXG4gICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1wYWdlIHAtNVwiXHJcbiAgICAgIG9uU3VibWl0PXsoZXZlbnQpID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmIChidXN5KSByZXR1cm47XHJcbiAgICAgICAgc2V0QnVzeSh0cnVlKTtcclxuICAgICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgICAgdm9pZCBzYXZlUmV2aWV3KHByb2R1Y3RJZCwgeyByYXRpbmcsIHRpdGxlLCBib2R5IH0sICEhbWluZSlcclxuICAgICAgICAgIC50aGVuKG9uU2F2ZWQpXHJcbiAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiBzZXRFcnJvcihnZXRBcGlFcnJvcihlcnJvciwgdC5yZXZpZXdTYXZlRXJyb3IpKSlcclxuICAgICAgICAgIC5maW5hbGx5KCgpID0+IHNldEJ1c3koZmFsc2UpKTtcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAge21pbmUgPyB0LmVkaXRSZXZpZXcgOiB0LndyaXRlUmV2aWV3fVxyXG4gICAgICA8L2gzPlxyXG4gICAgICA8ZmllbGRzZXQgZGlzYWJsZWQ9e2J1c3l9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICB7dC5yYXRpbmd9XHJcbiAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e3QucmF0aW5nfVxyXG4gICAgICAgICAgICB2YWx1ZT17cmF0aW5nfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSYXRpbmcoTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0IG10LTJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7WzUsIDQsIDMsIDIsIDFdLm1hcCgodmFsdWUpID0+IChcclxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dmFsdWV9IHZhbHVlPXt2YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICB7J+KYhScucmVwZWF0KHZhbHVlKX0gKHt2YWx1ZX0vNSlcclxuICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICB7dC5yZXZpZXdUaXRsZX1cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICBtaW5MZW5ndGg9ezJ9XHJcbiAgICAgICAgICAgIG1heExlbmd0aD17MTIwfVxyXG4gICAgICAgICAgICB2YWx1ZT17dGl0bGV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFRpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXQgbXQtMlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgIHt0LnJldmlld0JvZHl9XHJcbiAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgbWluTGVuZ3RoPXsxMH1cclxuICAgICAgICAgICAgbWF4TGVuZ3RoPXszMDAwfVxyXG4gICAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgICB2YWx1ZT17Ym9keX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Qm9keShldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBhdXRoLWlucHV0IG10LTIgaC1hdXRvIHB5LTJcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICB7YnVzeSAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICB7YnVzeSA/IHQubG9hZGluZyA6IG1pbmUgPyB0LnVwZGF0ZVJldmlldyA6IHQuc3VibWl0UmV2aWV3fVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSB0ZXh0LWRhbmdlclwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvZm9ybT5cclxuICApO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0UmV2aWV3cyh7XHJcbiAgcHJvZHVjdElkLFxyXG4gIG9uU3VtbWFyeSxcclxufToge1xyXG4gIHByb2R1Y3RJZDogc3RyaW5nO1xyXG4gIG9uU3VtbWFyeT86IChzdW1tYXJ5OiBSZXZpZXdTdW1tYXJ5KSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4gIGNvbnN0IGN1c3RvbWVyID0gdXNlcj8ucm9sZSA9PT0gVVNFUl9ST0xFUy5DVVNUT01FUjtcclxuICBjb25zdCBwYWdlID0gdXNlUHJvZHVjdFJldmlld3MoXHJcbiAgICBwcm9kdWN0SWQsXHJcbiAgICBjdXN0b21lciA/IHVzZXIuaWQgOiB1bmRlZmluZWQsXHJcbiAgICB1c2VyPy5yb2xlID09PSBVU0VSX1JPTEVTLkFETUlOLFxyXG4gICk7XHJcbiAgY29uc3QgW2ZlZWRiYWNrLCBzZXRGZWVkYmFja10gPSB1c2VTdGF0ZSgnJyksXHJcbiAgICBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKSxcclxuICAgIFtkZWxldGluZywgc2V0RGVsZXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkZWxldGVJZCwgc2V0RGVsZXRlSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3Qgc3VtbWFyeSA9IHBhZ2UuZGF0YT8uc3VtbWFyeTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHN1bW1hcnkpIG9uU3VtbWFyeT8uKHN1bW1hcnkpO1xyXG4gIH0sIFtzdW1tYXJ5LCBvblN1bW1hcnldKTtcclxuICBhc3luYyBmdW5jdGlvbiByZW1vdmUoaWQ6IHN0cmluZykge1xyXG4gICAgaWYgKGRlbGV0aW5nKSByZXR1cm47XHJcbiAgICBzZXREZWxldGluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKCcnKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGRlbGV0ZVJldmlldyhwcm9kdWN0SWQsIGlkKTtcclxuICAgICAgc2V0RmVlZGJhY2sodC5yZXZpZXdEZWxldGVkKTtcclxuICAgICAgc2V0RGVsZXRlSWQobnVsbCk7XHJcbiAgICAgIHBhZ2UucmVmcmVzaCgpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHNldEVycm9yKHQucmV2aWV3RGVsZXRlRXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RGVsZXRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb25cclxuICAgICAgaWQ9XCJyZXZpZXdzXCJcclxuICAgICAgYXJpYS1sYWJlbD17dC5yZXZpZXdzfVxyXG4gICAgICBjbGFzc05hbWU9XCJzY3JvbGwtbXQtMzIgc3BhY2UteS02XCJcclxuICAgID5cclxuICAgICAgPERpYWxvZ1xyXG4gICAgICAgIG9wZW49e2RlbGV0ZUlkICE9PSBudWxsfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldERlbGV0ZUlkKG51bGwpfVxyXG4gICAgICAgIHRpdGxlPXt0LmRlbGV0ZVJldmlld31cclxuICAgICAgICBkZXNjcmlwdGlvbj17dC5kZWxldGVDb25maXJtfVxyXG4gICAgICAgIGJ1c3k9e2RlbGV0aW5nfVxyXG4gICAgICA+XHJcbiAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtZGFuZ2VyIG1iLTRcIj5cclxuICAgICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17ZGVsZXRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldERlbGV0ZUlkKG51bGwpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dWlUZXh0LmNhbmNlbH1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgYnVzeT17ZGVsZXRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICBpZiAoZGVsZXRlSWQpIHZvaWQgcmVtb3ZlKGRlbGV0ZUlkKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3QuZGVsZXRlUmV2aWV3fVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICB7dXNlcj8ucm9sZSA9PT0gVVNFUl9ST0xFUy5BRE1JTiA/IHQubW9kZXJhdGlvbiA6IHQucmV2aWV3c31cclxuICAgICAgPC9oMj5cclxuICAgICAge3BhZ2UubG9hZGluZyA/IChcclxuICAgICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LmxvYWRpbmd9IGNvbXBhY3Q9e3RydWV9IC8+XHJcbiAgICAgICkgOiBwYWdlLmVycm9yID8gKFxyXG4gICAgICAgIDxkaXYgcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+e3QucmV2aWV3RXJyb3J9PC9wPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeSBtdC0zXCIgb25DbGljaz17cGFnZS5yZWZyZXNofT5cclxuICAgICAgICAgICAge3QucmV0cnl9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICBwYWdlLmRhdGEgJiYgKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IG1kOmdyaWQtY29scy1bMTNyZW1fMWZyXVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBiZy1wcmltYXJ5LXN1YnRsZSBwLTVcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5Py5jb3VudCA/IHN1bW1hcnkuYXZlcmFnZS50b0ZpeGVkKDEpIDogJ+KAlCd9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8UmF0aW5nXHJcbiAgICAgICAgICAgICAgICAgIGF2ZXJhZ2U9e3N1bW1hcnk/LmF2ZXJhZ2UgPz8gMH1cclxuICAgICAgICAgICAgICAgICAgY291bnQ9e3N1bW1hcnk/LmNvdW50ID8/IDB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnk/LmRpc3RyaWJ1dGlvbi5tYXAoKHJvdykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtyb3cucmF0aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntyb3cucmF0aW5nfSDimIU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgZmxleC0xIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctc3VyZmFjZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgYmctYWNjZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogYCR7c3VtbWFyeS5jb3VudCA/IChyb3cuY291bnQgLyBzdW1tYXJ5LmNvdW50KSAqIDEwMCA6IDB9JWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntyb3cuY291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5kYXRhLml0ZW1zLmxlbmd0aCA/IChcclxuICAgICAgICAgICAgICAgICAgcGFnZS5kYXRhLml0ZW1zLm1hcCgocmV2aWV3KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGFydGljbGVcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17cmV2aWV3LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgcC00XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cmV2aWV3LmF1dGhvcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGltZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1mZy1tdXRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZVRpbWU9e3Jldmlldy5jcmVhdGVkQXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShyZXZpZXcuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aW1lPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQtd2FybmluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2Ake3QucmF0aW5nfTogJHtyZXZpZXcucmF0aW5nfS81YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeyfimIUnLnJlcGVhdChyZXZpZXcucmF0aW5nKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZXZpZXcudmVyaWZpZWRQdXJjaGFzZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXN1Y2Nlc3NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dC52ZXJpZmllZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtdC0yIGJyZWFrLXdvcmRzIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmV2aWV3LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgd2hpdGVzcGFjZS1wcmUtd3JhcCBicmVhay13b3JkcyB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmV2aWV3LmJvZHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KHJldmlldy5pZCA9PT0gcGFnZS5taW5lPy5pZCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyPy5yb2xlID09PSBVU0VSX1JPTEVTLkFETUlOKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGVsZXRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLXNtIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZGFuZ2VyIGhvdmVyOmJnLWRhbmdlci1iZyBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9yKCcnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldERlbGV0ZUlkKHJldmlldy5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0LmRlbGV0ZVJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYXJ0aWNsZT5cclxuICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5ub1Jldmlld3N9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtwYWdlLmRhdGEudG90YWxQYWdlcyA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UuZGF0YS5wYWdlIDw9IDF9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwYWdlLnNldFBhZ2UocGFnZS5kYXRhIS5wYWdlIC0gMSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3QucHJldmlvdXN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGFnZS5kYXRhLnBhZ2V9L3twYWdlLmRhdGEudG90YWxQYWdlc31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UuZGF0YS5wYWdlID49IHBhZ2UuZGF0YS50b3RhbFBhZ2VzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRQYWdlKHBhZ2UuZGF0YSEucGFnZSArIDEpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0Lm5leHR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtjdXN0b21lciA/IChcclxuICAgICAgICAgICAgICA8UmV2aWV3Rm9ybVxyXG4gICAgICAgICAgICAgICAga2V5PXtwYWdlLm1pbmU/LmlkID8/ICduZXcnfVxyXG4gICAgICAgICAgICAgICAgcHJvZHVjdElkPXtwcm9kdWN0SWR9XHJcbiAgICAgICAgICAgICAgICBtaW5lPXtwYWdlLm1pbmV9XHJcbiAgICAgICAgICAgICAgICBvblNhdmVkPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldEZlZWRiYWNrKHQucmV2aWV3U2F2ZWQpO1xyXG4gICAgICAgICAgICAgICAgICBwYWdlLnJlZnJlc2goKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6ICF1c2VyID8gKFxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLmxvZ2lufVxyXG4gICAgICAgICAgICAgICAgc3RhdGU9e3sgZnJvbTogbG9jYXRpb24ucGF0aG5hbWUgKyBsb2NhdGlvbi5zZWFyY2ggfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJvdW5kZWQtc20gYmctcHJpbWFyeSBweC00IHB5LTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0LnNpZ25JblJldmlld31cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKVxyXG4gICAgICApfVxyXG4gICAgICB7ZmVlZGJhY2sgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc3VjY2Vzc1wiPlxyXG4gICAgICAgICAge2ZlZWRiYWNrfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19