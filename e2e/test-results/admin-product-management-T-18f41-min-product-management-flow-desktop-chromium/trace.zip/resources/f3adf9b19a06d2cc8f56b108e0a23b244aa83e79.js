import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Dashboard/index.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useCatalog } from "/src/hooks/useCatalog.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import ReportsPage from "/src/pages/Admin/Reports/index.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Dashboard/index.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.admin;
export default function DashboardPage() {
	_s();
	const page = useCatalog();
	const metrics = [
		{
			label: t.products,
			value: page.products.length,
			route: ROUTES.adminProducts
		},
		{
			label: t.categories,
			value: page.categories.length,
			route: ROUTES.adminCategories
		},
		{
			label: t.totalStock,
			value: page.products.reduce((total, product) => total + product.stockQty, 0),
			route: ROUTES.adminInventory
		},
		{
			label: t.outOfStock,
			value: page.products.filter((product) => product.stockQty === 0).length,
			route: ROUTES.adminInventory
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.dashboardTitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.dashboardDescription
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: page.refresh,
					disabled: page.loading,
					className: "auth-secondary",
					children: t.refresh
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 7
			}, this),
			!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
					children: metrics.map((metric) => /* @__PURE__ */ _jsxDEV(Link, {
						to: metric.route,
						className: "rounded-md border border-line bg-surface p-6   ",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-fg-muted",
							children: metric.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-3 text-3xl font-semibold text-fg",
							children: metric.value.toLocaleString()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 17
						}, this)]
					}, metric.label, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-4 lg:grid-cols-3",
					children: [
						{
							route: ROUTES.adminProducts,
							title: t.viewProducts,
							detail: t.productsDescription
						},
						{
							route: ROUTES.adminCategories,
							title: t.viewCategories,
							detail: t.categoriesDescription
						},
						{
							route: ROUTES.adminInventory,
							title: t.viewInventory,
							detail: t.inventoryDescription
						},
						{
							route: ROUTES.adminOrders,
							title: translations.adminOrders.title,
							detail: translations.adminOrders.description
						}
					].map((item) => /* @__PURE__ */ _jsxDEV(Link, {
						to: item.route,
						className: "rounded-md border border-line bg-surface p-6 ",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-semibold text-fg-link",
							children: item.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-3 text-sm leading-6 text-fg-muted",
							children: item.detail
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 17
						}, this)]
					}, item.route, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(ReportsPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this);
}
_s(DashboardPage, "yed7pGGvGfCOXGak+IPTzn00oAk=", false, function() {
	return [useCatalog];
});
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Dashboard/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Dashboard/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Dashboard/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Dashboard/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixPQUFPLGlCQUFpQjs7OztBQUN4QixNQUFNLElBQUksYUFBYTtBQUN2QixlQUFlLFNBQVMsZ0JBQWdCOztDQUN0QyxNQUFNLE9BQU8sV0FBVztDQUN4QixNQUFNLFVBQVU7RUFDZDtHQUNFLE9BQU8sRUFBRTtHQUNULE9BQU8sS0FBSyxTQUFTO0dBQ3JCLE9BQU8sT0FBTztFQUNoQjtFQUNBO0dBQ0UsT0FBTyxFQUFFO0dBQ1QsT0FBTyxLQUFLLFdBQVc7R0FDdkIsT0FBTyxPQUFPO0VBQ2hCO0VBQ0E7R0FDRSxPQUFPLEVBQUU7R0FDVCxPQUFPLEtBQUssU0FBUyxRQUNsQixPQUFPLFlBQVksUUFBUSxRQUFRLFVBQ3BDLENBQ0Y7R0FDQSxPQUFPLE9BQU87RUFDaEI7RUFDQTtHQUNFLE9BQU8sRUFBRTtHQUNULE9BQU8sS0FBSyxTQUFTLFFBQVEsWUFBWSxRQUFRLGFBQWEsQ0FBQyxDQUFDLENBQUM7R0FDakUsT0FBTyxPQUFPO0VBQ2hCO0NBQ0Y7Q0FDQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFtQjs7OztjQUM1RCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE4QixFQUFFO0lBQXdCOzs7O1lBQ2xFOzs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLFNBQVMsS0FBSztLQUNkLFVBQVUsS0FBSztLQUNmLFdBQVU7ZUFFVCxFQUFFO0lBQ0c7Ozs7WUFDRjs7Ozs7O0dBQ1Isd0JBQUMsaUJBQUQ7SUFDRSxTQUFTLEtBQUs7SUFDZCxPQUFPLEtBQUs7SUFDWixPQUFPLEtBQUs7R0FDYjs7Ozs7R0FDQSxDQUFDLEtBQUssV0FBVyxDQUFDLEtBQUssU0FDdEI7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFFBQVEsS0FBSyxXQUNaLHdCQUFDLE1BQUQ7TUFFRSxJQUFJLE9BQU87TUFDWCxXQUFVO2dCQUhaLENBS0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCLE9BQU87TUFBUzs7OztnQkFDdEQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsT0FBTyxNQUFNLGVBQWU7TUFDNUI7Ozs7Y0FDQztRQVJDLE9BQU87Ozs7WUFRUixDQUNQO0lBQ0U7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWjtNQUNDO09BQ0UsT0FBTyxPQUFPO09BQ2QsT0FBTyxFQUFFO09BQ1QsUUFBUSxFQUFFO01BQ1o7TUFDQTtPQUNFLE9BQU8sT0FBTztPQUNkLE9BQU8sRUFBRTtPQUNULFFBQVEsRUFBRTtNQUNaO01BQ0E7T0FDRSxPQUFPLE9BQU87T0FDZCxPQUFPLEVBQUU7T0FDVCxRQUFRLEVBQUU7TUFDWjtNQUNBO09BQ0UsT0FBTyxPQUFPO09BQ2QsT0FBTyxhQUFhLFlBQVk7T0FDaEMsUUFBUSxhQUFhLFlBQVk7TUFDbkM7S0FDRixDQUFDLENBQUMsS0FBSyxTQUNMLHdCQUFDLE1BQUQ7TUFFRSxJQUFJLEtBQUs7TUFDVCxXQUFVO2dCQUhaLENBS0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQThCLEtBQUs7TUFBVTs7OztnQkFDM0Qsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsS0FBSztNQUNMOzs7O2NBQ0M7UUFSQyxLQUFLOzs7O1lBUU4sQ0FDUDtJQUNFOzs7OztJQUNMLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7R0FDZDs7Ozs7RUFFRzs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQ2F0YWxvZyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNhdGFsb2cnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgUmVwb3J0c1BhZ2UgZnJvbSAnLi4vUmVwb3J0cyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuYWRtaW47XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZFBhZ2UoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZUNhdGFsb2coKTtcclxuICBjb25zdCBtZXRyaWNzID0gW1xyXG4gICAge1xyXG4gICAgICBsYWJlbDogdC5wcm9kdWN0cyxcclxuICAgICAgdmFsdWU6IHBhZ2UucHJvZHVjdHMubGVuZ3RoLFxyXG4gICAgICByb3V0ZTogUk9VVEVTLmFkbWluUHJvZHVjdHMsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogdC5jYXRlZ29yaWVzLFxyXG4gICAgICB2YWx1ZTogcGFnZS5jYXRlZ29yaWVzLmxlbmd0aCxcclxuICAgICAgcm91dGU6IFJPVVRFUy5hZG1pbkNhdGVnb3JpZXMsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogdC50b3RhbFN0b2NrLFxyXG4gICAgICB2YWx1ZTogcGFnZS5wcm9kdWN0cy5yZWR1Y2UoXHJcbiAgICAgICAgKHRvdGFsLCBwcm9kdWN0KSA9PiB0b3RhbCArIHByb2R1Y3Quc3RvY2tRdHksXHJcbiAgICAgICAgMCxcclxuICAgICAgKSxcclxuICAgICAgcm91dGU6IFJPVVRFUy5hZG1pbkludmVudG9yeSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiB0Lm91dE9mU3RvY2ssXHJcbiAgICAgIHZhbHVlOiBwYWdlLnByb2R1Y3RzLmZpbHRlcigocHJvZHVjdCkgPT4gcHJvZHVjdC5zdG9ja1F0eSA9PT0gMCkubGVuZ3RoLFxyXG4gICAgICByb3V0ZTogUk9VVEVTLmFkbWluSW52ZW50b3J5LFxyXG4gICAgfSxcclxuICBdO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIHRleHQtZmdcIj57dC5kYXNoYm9hcmRUaXRsZX08L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5kYXNoYm9hcmREZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17cGFnZS5yZWZyZXNofVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7dC5yZWZyZXNofVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAgPENhdGFsb2dGZWVkYmFja1xyXG4gICAgICAgIGxvYWRpbmc9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICBlcnJvcj17cGFnZS5lcnJvcn1cclxuICAgICAgICByZXRyeT17cGFnZS5yZWZyZXNofVxyXG4gICAgICAvPlxyXG4gICAgICB7IXBhZ2UubG9hZGluZyAmJiAhcGFnZS5lcnJvciAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBzbTpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtNFwiPlxyXG4gICAgICAgICAgICB7bWV0cmljcy5tYXAoKG1ldHJpYykgPT4gKFxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICBrZXk9e21ldHJpYy5sYWJlbH1cclxuICAgICAgICAgICAgICAgIHRvPXttZXRyaWMucm91dGV9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiAgIFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e21ldHJpYy5sYWJlbH08L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7bWV0cmljLnZhbHVlLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IGxnOmdyaWQtY29scy0zXCI+XHJcbiAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcm91dGU6IFJPVVRFUy5hZG1pblByb2R1Y3RzLFxyXG4gICAgICAgICAgICAgICAgdGl0bGU6IHQudmlld1Byb2R1Y3RzLFxyXG4gICAgICAgICAgICAgICAgZGV0YWlsOiB0LnByb2R1Y3RzRGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICByb3V0ZTogUk9VVEVTLmFkbWluQ2F0ZWdvcmllcyxcclxuICAgICAgICAgICAgICAgIHRpdGxlOiB0LnZpZXdDYXRlZ29yaWVzLFxyXG4gICAgICAgICAgICAgICAgZGV0YWlsOiB0LmNhdGVnb3JpZXNEZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJvdXRlOiBST1VURVMuYWRtaW5JbnZlbnRvcnksXHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdC52aWV3SW52ZW50b3J5LFxyXG4gICAgICAgICAgICAgICAgZGV0YWlsOiB0LmludmVudG9yeURlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcm91dGU6IFJPVVRFUy5hZG1pbk9yZGVycyxcclxuICAgICAgICAgICAgICAgIHRpdGxlOiB0cmFuc2xhdGlvbnMuYWRtaW5PcmRlcnMudGl0bGUsXHJcbiAgICAgICAgICAgICAgICBkZXRhaWw6IHRyYW5zbGF0aW9ucy5hZG1pbk9yZGVycy5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ucm91dGV9XHJcbiAgICAgICAgICAgICAgICB0bz17aXRlbS5yb3V0ZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC02IFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZy1saW5rXCI+e2l0ZW0udGl0bGV9PC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS5kZXRhaWx9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPFJlcG9ydHNQYWdlIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=