import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Cart/index.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { useCartPage } from "/src/pages/Customer/Cart/hooks/useCartPage.ts";
import { CartItemRow } from "/src/pages/Customer/Cart/components/CartItemRow.tsx";
import { CartSummary } from "/src/pages/Customer/Cart/components/CartSummary.tsx";
import { EmptyCart } from "/src/components/feedback/EmptyCart.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import { CartRecommendations } from "/src/pages/Customer/Cart/components/CartRecommendations.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/index.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const t = translations.cart;
export default function CartPage() {
	_s();
	const { user } = useAuth();
	// Remount local data if the authenticated account changes.
	return user ? /* @__PURE__ */ _jsxDEV(CartContent, {}, user.id, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 17
	}, this) : null;
}
_s(CartPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = CartPage;
function CartContent() {
	_s2();
	const page = useCartPage();
	const [confirmClear, setConfirmClear] = useState(false);
	const busy = page.pending !== null;
	useEffect(() => {
		const previous = document.title;
		document.title = `${t.title} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-[1200px] space-y-8",
			children: [
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": translations.productDetails.breadcrumb,
					className: "text-sm",
					children: /* @__PURE__ */ _jsxDEV("ol", {
						className: "flex items-center gap-2 text-fg-muted",
						children: [
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.home,
								className: "font-medium text-fg-link hover:text-fg-link",
								children: t.home
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 39,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-hidden": "true",
								children: "/"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-current": "page",
								children: t.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this),
				(!page.cart || page.cart.items.length > 0) && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title text-fg",
						children: t.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: t.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 13
					}, this), page.cart && /* @__PURE__ */ _jsxDEV("p", {
						className: "self-end text-sm text-fg-muted",
						children: [
							page.cart.itemCount,
							" ",
							page.cart.itemCount === 1 ? t.oneInCart : t.inCart
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this),
				page.error && /* @__PURE__ */ _jsxDEV("div", {
					role: "alert",
					className: "flex flex-wrap items-center justify-between gap-3 rounded-md border border-danger/25 bg-danger-bg p-4 text-sm text-danger",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: page.error }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => void page.refresh(),
						disabled: busy || page.loading,
						className: "rounded-sm px-3 py-2 font-semibold underline underline-offset-4 ",
						children: translations.common.retry
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					role: "status",
					"aria-live": "polite",
					className: page.notice ? "rounded-sm bg-success-bg px-4 py-3 text-sm text-success" : "sr-only",
					children: page.notice
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this),
				page.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: t.loading }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 11
				}, this) : page.cart && (page.cart.items.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyCart, { headingAs: "h1" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-8",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_22rem] xl:gap-8",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "min-w-0 space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("section", {
									"aria-labelledby": "cart-items",
									"aria-busy": busy,
									className: "min-w-0 overflow-hidden rounded-md border border-line bg-surface ",
									children: [
										/* @__PURE__ */ _jsxDEV("h2", {
											id: "cart-items",
											className: "sr-only",
											children: t.items
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 107,
											columnNumber: 21
										}, this),
										confirmClear && /* @__PURE__ */ _jsxDEV("div", {
											role: "alert",
											className: "border-b border-warning/25 bg-warning-bg p-4 sm:px-6",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm text-warning",
												children: t.confirmClear
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 115,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "mt-3 flex flex-wrap gap-3",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													disabled: busy,
													onClick: () => {
														setConfirmClear(false);
														void page.clear();
													},
													className: "ui-button ui-button-danger min-h-11 rounded-sm bg-danger px-4 text-sm font-medium text-primary-on hover:bg-danger ",
													children: t.clear
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 117,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													disabled: busy,
													onClick: () => setConfirmClear(false),
													className: "auth-secondary",
													children: t.cancel
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 128,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 116,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 111,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("ul", {
											className: "divide-y divide-line",
											children: page.cart.items.map((item) => /* @__PURE__ */ _jsxDEV(CartItemRow, {
												item,
												disabled: busy,
												updating: page.pending?.kind === "quantity" && page.pending.itemId === item.id,
												removing: page.pending?.kind === "remove" && page.pending.itemId === item.id,
												onQuantity: (direction) => void page.changeQuantity(item, direction),
												onRemove: () => void page.remove(item)
											}, item.id, false, {
												fileName: _jsxFileName,
												lineNumber: 141,
												columnNumber: 25
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 139,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap items-center justify-between gap-3",
									children: [/* @__PURE__ */ _jsxDEV(Link, {
										to: ROUTES.products,
										className: "auth-secondary gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Icon, {
											name: "arrow",
											className: "h-4 w-4 rotate-180"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 163,
											columnNumber: 23
										}, this), translations.common.continueShopping]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: busy,
										onClick: () => setConfirmClear(true),
										className: "flex min-h-11 items-center gap-2 rounded-sm px-3 text-sm font-medium text-danger hover:bg-danger-bg ",
										children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "trash" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 172,
											columnNumber: 23
										}, this), page.pending?.kind === "clear" ? t.clearing : t.clear]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(CartRecommendations, {
									cart: page.cart,
									busy,
									onAdd: (id) => void page.add(id)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(CartSummary, {
							cart: page.cart,
							busy
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 13
				}, this))
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_s2(CartContent, "icMsU2yPhKiNIAFkYrxAq20a/Sc=", false, function() {
	return [useCartPage];
});
_c2 = CartContent;
var _c, _c2;
$RefreshReg$(_c, "CartPage");
$RefreshReg$(_c2, "CartContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Cart/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLFlBQVk7QUFDckIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLFlBQVk7QUFDckIsU0FBUywyQkFBMkI7Ozs7QUFDcEMsTUFBTSxJQUFJLGFBQWE7QUFFdkIsZUFBZSxTQUFTLFdBQVc7O0NBQ2pDLE1BQU0sRUFBRSxTQUFTLFFBQVE7O0NBRXpCLE9BQU8sT0FBTyx3QkFBQyxhQUFELENBQTRCLEdBQVYsS0FBSzs7OztRQUFLLElBQUk7QUFDaEQ7Ozs7O0FBQ0EsU0FBUyxjQUFjOztDQUNyQixNQUFNLE9BQU8sWUFBWTtDQUN6QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sT0FBTyxLQUFLLFlBQVk7Q0FDOUIsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLFNBQVM7RUFDMUIsU0FBUyxRQUFRLEdBQUcsRUFBRSxNQUFNLEtBQUssYUFBYSxPQUFPO0VBQ3JELGFBQWE7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUNMLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUNFLGNBQVksYUFBYSxlQUFlO0tBQ3hDLFdBQVU7ZUFFVix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPO1FBQ1gsV0FBVTtrQkFFVCxFQUFFO09BQ0M7Ozs7Z0JBQ0o7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLGVBQVk7a0JBQU87T0FBSzs7Ozs7T0FDNUIsd0JBQUMsTUFBRDtRQUFJLGdCQUFhO2tCQUFRLEVBQUU7T0FBVTs7Ozs7TUFDbkM7Ozs7OztJQUNEOzs7OztLQUNILENBQUMsS0FBSyxRQUFRLEtBQUssS0FBSyxNQUFNLFNBQVMsTUFDdkMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBeUIsRUFBRTtLQUFVOzs7O2VBQ25ELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE4QixFQUFFO0tBQWU7Ozs7YUFDekQ7Ozs7ZUFDSixLQUFLLFFBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FDRyxLQUFLLEtBQUs7T0FBVztPQUNyQixLQUFLLEtBQUssY0FBYyxJQUFJLEVBQUUsWUFBWSxFQUFFO01BQzVDOzs7OzthQUVGOzs7Ozs7SUFFTixLQUFLLFNBQ0osd0JBQUMsT0FBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO2VBRlosQ0FJRSx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7O2VBQ2xCLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsZUFBZSxLQUFLLEtBQUssUUFBUTtNQUNqQyxVQUFVLFFBQVEsS0FBSztNQUN2QixXQUFVO2dCQUVULGFBQWEsT0FBTztLQUNmOzs7O2FBQ0w7Ozs7OztJQUVQLHdCQUFDLEtBQUQ7S0FDRSxNQUFLO0tBQ0wsYUFBVTtLQUNWLFdBQ0UsS0FBSyxTQUNELDREQUNBO2VBR0wsS0FBSztJQUNMOzs7OztJQUNGLEtBQUssVUFDSix3QkFBQyxjQUFELEVBQWMsT0FBTyxFQUFFLFFBQVU7Ozs7ZUFFakMsS0FBSyxTQUNKLEtBQUssS0FBSyxNQUFNLFdBQVcsSUFDMUIsd0JBQUMsV0FBRCxFQUFXLFdBQVUsS0FBTTs7OztlQUUzQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxXQUFEO1NBQ0UsbUJBQWdCO1NBQ2hCLGFBQVc7U0FDWCxXQUFVO21CQUhaO1VBS0Usd0JBQUMsTUFBRDtXQUFJLElBQUc7V0FBYSxXQUFVO3FCQUMzQixFQUFFO1VBQ0Q7Ozs7O1VBQ0gsZ0JBQ0Msd0JBQUMsT0FBRDtXQUNFLE1BQUs7V0FDTCxXQUFVO3FCQUZaLENBSUUsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXdCLEVBQUU7V0FBZ0I7Ozs7cUJBQ3ZELHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsVUFBRDthQUNFLE1BQUs7YUFDTCxVQUFVO2FBQ1YsZUFBZTtjQUNiLGdCQUFnQixLQUFLO2NBQ3JCLEtBQUssS0FBSyxNQUFNO2FBQ2xCO2FBQ0EsV0FBVTt1QkFFVCxFQUFFO1lBQ0c7Ozs7c0JBQ1Isd0JBQUMsVUFBRDthQUNFLE1BQUs7YUFDTCxVQUFVO2FBQ1YsZUFBZSxnQkFBZ0IsS0FBSzthQUNwQyxXQUFVO3VCQUVULEVBQUU7WUFDRzs7OztvQkFDTDs7Ozs7bUJBQ0Y7Ozs7OztVQUVQLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEtBQUssS0FBSyxNQUFNLEtBQUssU0FDcEIsd0JBQUMsYUFBRDtZQUVRO1lBQ04sVUFBVTtZQUNWLFVBQ0UsS0FBSyxTQUFTLFNBQVMsY0FDdkIsS0FBSyxRQUFRLFdBQVcsS0FBSztZQUUvQixVQUNFLEtBQUssU0FBUyxTQUFTLFlBQ3ZCLEtBQUssUUFBUSxXQUFXLEtBQUs7WUFFL0IsYUFBYSxjQUNYLEtBQUssS0FBSyxlQUFlLE1BQU0sU0FBUztZQUUxQyxnQkFBZ0IsS0FBSyxLQUFLLE9BQU8sSUFBSTtXQUN0QyxHQWZNLEtBQUs7Ozs7a0JBZVgsQ0FDRjtVQUNDOzs7OztTQUNHOzs7Ozs7UUFDVCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBTSxJQUFJLE9BQU87VUFBVSxXQUFVO29CQUFyQyxDQUNFLHdCQUFDLE1BQUQ7V0FBTSxNQUFLO1dBQVEsV0FBVTtVQUFzQjs7OztvQkFDbEQsYUFBYSxPQUFPLGdCQUNqQjs7Ozs7bUJBQ04sd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxVQUFVO1VBQ1YsZUFBZSxnQkFBZ0IsSUFBSTtVQUNuQyxXQUFVO29CQUpaLENBTUUsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztvQkFDbkIsS0FBSyxTQUFTLFNBQVMsVUFBVSxFQUFFLFdBQVcsRUFBRSxLQUMzQzs7Ozs7aUJBQ0w7Ozs7OztRQUNMLHdCQUFDLHFCQUFEO1NBQ0UsTUFBTSxLQUFLO1NBQ0w7U0FDTixRQUFRLE9BQU8sS0FBSyxLQUFLLElBQUksRUFBRTtRQUNoQzs7Ozs7T0FDRTs7Ozs7Z0JBQ0wsd0JBQUMsYUFBRDtPQUFhLE1BQU0sS0FBSztPQUFZO01BQU87Ozs7Y0FDeEM7Ozs7OztJQUNGOzs7OztHQUdOOzs7Ozs7Q0FDRDs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgdXNlQ2FydFBhZ2UgfSBmcm9tICcuL2hvb2tzL3VzZUNhcnRQYWdlJztcclxuaW1wb3J0IHsgQ2FydEl0ZW1Sb3cgfSBmcm9tICcuL2NvbXBvbmVudHMvQ2FydEl0ZW1Sb3cnO1xyXG5pbXBvcnQgeyBDYXJ0U3VtbWFyeSB9IGZyb20gJy4vY29tcG9uZW50cy9DYXJ0U3VtbWFyeSc7XHJcbmltcG9ydCB7IEVtcHR5Q2FydCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvZmVlZGJhY2svRW1wdHlDYXJ0JztcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBDYXJ0UmVjb21tZW5kYXRpb25zIH0gZnJvbSAnLi9jb21wb25lbnRzL0NhcnRSZWNvbW1lbmRhdGlvbnMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmNhcnQ7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDYXJ0UGFnZSgpIHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICAvLyBSZW1vdW50IGxvY2FsIGRhdGEgaWYgdGhlIGF1dGhlbnRpY2F0ZWQgYWNjb3VudCBjaGFuZ2VzLlxyXG4gIHJldHVybiB1c2VyID8gPENhcnRDb250ZW50IGtleT17dXNlci5pZH0gLz4gOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIENhcnRDb250ZW50KCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VDYXJ0UGFnZSgpO1xyXG4gIGNvbnN0IFtjb25maXJtQ2xlYXIsIHNldENvbmZpcm1DbGVhcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgYnVzeSA9IHBhZ2UucGVuZGluZyAhPT0gbnVsbDtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgcHJldmlvdXMgPSBkb2N1bWVudC50aXRsZTtcclxuICAgIGRvY3VtZW50LnRpdGxlID0gYCR7dC50aXRsZX0gfCAke3RyYW5zbGF0aW9ucy5jb21tb24uc3RvcmVOYW1lfWA7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC50aXRsZSA9IHByZXZpb3VzO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cImJnLXBhZ2UgcHgtNCBweS02IHNtOnB4LTYgbWQ6cHktOCBsZzpweC04XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1bMTIwMHB4XSBzcGFjZS15LThcIj5cclxuICAgICAgICA8bmF2XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXt0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMuYnJlYWRjcnVtYn1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc21cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89e1JPVVRFUy5ob21lfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3QuaG9tZX1cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBhcmlhLWhpZGRlbj1cInRydWVcIj4vPC9saT5cclxuICAgICAgICAgICAgPGxpIGFyaWEtY3VycmVudD1cInBhZ2VcIj57dC50aXRsZX08L2xpPlxyXG4gICAgICAgICAgPC9vbD5cclxuICAgICAgICA8L25hdj5cclxuICAgICAgICB7KCFwYWdlLmNhcnQgfHwgcGFnZS5jYXJ0Lml0ZW1zLmxlbmd0aCA+IDApICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGUgdGV4dC1mZ1wiPnt0LnRpdGxlfTwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7cGFnZS5jYXJ0ICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzZWxmLWVuZCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgIHtwYWdlLmNhcnQuaXRlbUNvdW50fXsnICd9XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5jYXJ0Lml0ZW1Db3VudCA9PT0gMSA/IHQub25lSW5DYXJ0IDogdC5pbkNhcnR9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7cGFnZS5lcnJvciAmJiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWRhbmdlci8yNSBiZy1kYW5nZXItYmcgcC00IHRleHQtc20gdGV4dC1kYW5nZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8cD57cGFnZS5lcnJvcn08L3A+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVmcmVzaCgpfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5IHx8IHBhZ2UubG9hZGluZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIHB4LTMgcHktMiBmb250LXNlbWlib2xkIHVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTQgXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLnJldHJ5fVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgIHBhZ2Uubm90aWNlXHJcbiAgICAgICAgICAgICAgPyAncm91bmRlZC1zbSBiZy1zdWNjZXNzLWJnIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtc3VjY2VzcydcclxuICAgICAgICAgICAgICA6ICdzci1vbmx5J1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtwYWdlLm5vdGljZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAge3BhZ2UubG9hZGluZyA/IChcclxuICAgICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9e3QubG9hZGluZ30gLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgcGFnZS5jYXJ0ICYmXHJcbiAgICAgICAgICAocGFnZS5jYXJ0Lml0ZW1zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgPEVtcHR5Q2FydCBoZWFkaW5nQXM9XCJoMVwiIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNiBsZzpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfMjJyZW1dIHhsOmdhcC04XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwiY2FydC1pdGVtc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1idXN5PXtidXN5fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTAgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBpZD1cImNhcnQtaXRlbXNcIiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dC5pdGVtc31cclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjb25maXJtQ2xlYXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItd2FybmluZy8yNSBiZy13YXJuaW5nLWJnIHAtNCBzbTpweC02XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXdhcm5pbmdcIj57dC5jb25maXJtQ2xlYXJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDb25maXJtQ2xlYXIoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b2lkIHBhZ2UuY2xlYXIoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLWRhbmdlciBtaW4taC0xMSByb3VuZGVkLXNtIGJnLWRhbmdlciBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LW9uIGhvdmVyOmJnLWRhbmdlciBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0LmNsZWFyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtQ2xlYXIoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0LmNhbmNlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtbGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BhZ2UuY2FydC5pdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRJdGVtUm93XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRpbmc9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnZS5wZW5kaW5nPy5raW5kID09PSAncXVhbnRpdHknICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWdlLnBlbmRpbmcuaXRlbUlkID09PSBpdGVtLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92aW5nPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2UucGVuZGluZz8ua2luZCA9PT0gJ3JlbW92ZScgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2UucGVuZGluZy5pdGVtSWQgPT09IGl0ZW0uaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25RdWFudGl0eT17KGRpcmVjdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvaWQgcGFnZS5jaGFuZ2VRdWFudGl0eShpdGVtLCBkaXJlY3Rpb24pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uUmVtb3ZlPXsoKSA9PiB2b2lkIHBhZ2UucmVtb3ZlKGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Uk9VVEVTLnByb2R1Y3RzfSBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeSBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImFycm93XCIgY2xhc3NOYW1lPVwiaC00IHctNCByb3RhdGUtMTgwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLmNvbnRpbnVlU2hvcHBpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtQ2xlYXIodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTExIGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXNtIHB4LTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWRhbmdlciBob3ZlcjpiZy1kYW5nZXItYmcgXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwidHJhc2hcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BhZ2UucGVuZGluZz8ua2luZCA9PT0gJ2NsZWFyJyA/IHQuY2xlYXJpbmcgOiB0LmNsZWFyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPENhcnRSZWNvbW1lbmRhdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICBjYXJ0PXtwYWdlLmNhcnR9XHJcbiAgICAgICAgICAgICAgICAgICAgYnVzeT17YnVzeX1cclxuICAgICAgICAgICAgICAgICAgICBvbkFkZD17KGlkKSA9PiB2b2lkIHBhZ2UuYWRkKGlkKX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPENhcnRTdW1tYXJ5IGNhcnQ9e3BhZ2UuY2FydH0gYnVzeT17YnVzeX0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKVxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl19