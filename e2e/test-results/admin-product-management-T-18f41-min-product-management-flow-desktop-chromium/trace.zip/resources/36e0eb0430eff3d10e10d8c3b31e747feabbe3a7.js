import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx");const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import { Price } from "/src/components/common/Price.tsx";
import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { USER_ROLES } from "/src/constants/roles.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { addCartItem } from "/src/services/cartService.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { translations } from "/src/utils/translations.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { notifyToast } from "/src/utils/toast.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.experience;
export function PurchasePanel({ product }) {
	_s();
	const { user, loading } = useAuth(), navigate = useNavigate(), location = useLocation();
	const [quantity, setQuantity] = useState(1), [busy, setBusy] = useState(false), [error, setError] = useState(""), [added, setAdded] = useState(false);
	const pending = useRef(false);
	const actions = useRef(null);
	const [sticky, setSticky] = useState(false);
	useEffect(() => {
		const target = actions.current;
		if (!target) return;
		const observer = new IntersectionObserver(([entry]) => {
			setSticky(!entry.isIntersecting && entry.boundingClientRect.top < 0);
		});
		observer.observe(target);
		return () => observer.disconnect();
	}, []);
	const available = product.isActive && product.stockQty > 0;
	async function purchase(buyNow) {
		if (pending.current || !available || quantity < 1 || quantity > product.stockQty) return;
		pending.current = true;
		setBusy(true);
		setError("");
		setAdded(false);
		try {
			await addCartItem({
				productId: product.productID,
				quantity
			});
			setAdded(true);
			if (!buyNow) notifyToast({
				message: translations.storefront.added,
				action: {
					label: translations.cart.view,
					to: ROUTES.cart
				}
			});
			if (buyNow) navigate(ROUTES.checkout);
		} catch (error) {
			setError(getApiError(error, t.purchaseError));
		} finally {
			pending.current = false;
			setBusy(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-label": t.purchaseOptions,
		className: "purchase-panel rounded-lg border border-line bg-surface p-5 xl:sticky xl:top-24 xl:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV(StatusBadge, {
					status: available ? product.stockQty <= 5 ? "LOW_STOCK" : "IN_STOCK" : "OUT_OF_STOCK",
					children: available ? product.stockQty <= 5 ? `Only ${product.stockQty} left` : translations.productDetails.inStock : translations.productDetails.outOfStock
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "break-all text-xs text-fg-muted",
					children: [
						translations.productDetails.sku,
						": ",
						product.SKU
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-5 text-3xl font-bold tracking-tight text-fg",
				children: /* @__PURE__ */ _jsxDEV(Price, { value: product.price }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 7
			}, this),
			product.compareAtPrice != null && Number(product.compareAtPrice) > Number(product.price) && /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-muted",
				children: /* @__PURE__ */ _jsxDEV("s", { children: /* @__PURE__ */ _jsxDEV(Price, { value: product.compareAtPrice }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "sr-only",
				children: product.warranty || t.noWarranty
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "purchase-quantity",
				className: "mb-2 mt-6 block text-sm font-semibold text-fg",
				children: t.quantity
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-5 flex w-fit items-center overflow-hidden rounded-sm border border-line",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						"aria-label": t.decrease,
						disabled: busy || quantity <= 1,
						onClick: () => setQuantity((value) => Math.max(1, value - 1)),
						className: "min-h-11 w-11 bg-page text-fg-link disabled:text-fg-disabled",
						children: "−"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "purchase-quantity",
						"aria-label": t.quantity,
						type: "number",
						min: 1,
						max: Math.max(product.stockQty, 1),
						step: 1,
						disabled: busy || !available,
						value: quantity,
						onChange: (event) => {
							const value = Number(event.target.value);
							setQuantity(Number.isInteger(value) ? Math.min(Math.max(value, 1), Math.max(product.stockQty, 1)) : 1);
						},
						className: "ui-field min-h-11 w-16 border-x border-line bg-surface text-center text-sm outline-none focus:ring-2 focus:ring-primary/20"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						"aria-label": t.increase,
						disabled: busy || quantity >= product.stockQty,
						onClick: () => setQuantity((value) => Math.min(product.stockQty, value + 1)),
						className: "min-h-11 w-11 bg-page text-fg-link disabled:text-fg-disabled",
						children: "+"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: actions,
				children: loading ? /* @__PURE__ */ _jsxDEV(LoadingState, {
					label: t.loading,
					compact: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 11
				}, this) : !user ? /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.login,
					state: { from: location.pathname },
					className: "auth-primary w-full",
					children: t.signIn
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 11
				}, this) : user.role === USER_ROLES.CUSTOMER ? /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						disabled: busy || !available,
						onClick: () => void purchase(false),
						className: "ui-button ui-button-primary flex min-h-12 w-full items-center justify-center gap-3 rounded-sm bg-primary px-4 py-3 text-sm font-semibold text-primary-on hover:bg-primary-hover disabled:text-fg-disabled",
						children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "cart" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 15
						}, this), busy ? t.adding : t.addToCart]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						disabled: busy || !available,
						onClick: () => void purchase(true),
						className: "ui-button ui-button-accent min-h-12 w-full",
						children: t.buyNow
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 11
				}, this) : null
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 space-y-3 border-t border-line-subtle pt-5 text-xs text-fg-secondary",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "truck",
							className: "h-4 w-4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 11
						}, this), "Delivery details at checkout"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "shield",
							className: "h-4 w-4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 11
						}, this), product.warranty || "Ask our team about warranty"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.repairRequest,
						className: "flex items-center gap-2 text-fg-link",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "repair",
							className: "h-4 w-4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 11
						}, this), "Care and repair support"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mt-4 rounded-sm bg-danger-bg p-3 text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 196,
				columnNumber: 9
			}, this),
			added && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "mt-4 text-sm text-success",
				children: [
					t.added,
					" ",
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.cart,
						className: "underline",
						children: translations.cart.view
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 9
			}, this),
			sticky && user?.role === USER_ROLES.CUSTOMER && /* @__PURE__ */ _jsxDEV("div", {
				className: "purchase-sticky-bar",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "block text-xs text-fg-muted",
					children: available ? "In stock" : "Out of stock"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 214,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(Price, {
					value: product.price,
					className: "text-sm font-semibold"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 217,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void purchase(false),
					disabled: busy || !available,
					"aria-busy": busy,
					className: "ui-button ui-button-primary flex-1",
					children: busy ? t.adding : t.addToCart
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
}
_s(PurchasePanel, "GhVqb4jyE4v0FpEmg240m78ck18=", false, function() {
	return [
		useAuth,
		useNavigate,
		useLocation
	];
});
_c = PurchasePanel;
var _c;
$RefreshReg$(_c, "PurchasePanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/PurchasePanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsV0FBVyxRQUFRLGdCQUFnQjtBQUM1QyxTQUFTLE1BQU0sYUFBYSxtQkFBbUI7QUFFL0MsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFlBQVk7QUFDckIsU0FBUyxtQkFBbUI7Ozs7QUFDNUIsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGNBQWMsRUFBRSxXQUFpQzs7Q0FDL0QsTUFBTSxFQUFFLE1BQU0sWUFBWSxRQUFRLEdBQ2hDLFdBQVcsWUFBWSxHQUN2QixXQUFXLFlBQVk7Q0FDekIsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUMsR0FDeEMsQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLLEdBQ2hDLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRSxHQUMvQixDQUFDLE9BQU8sWUFBWSxTQUFTLEtBQUs7Q0FDcEMsTUFBTSxVQUFVLE9BQU8sS0FBSztDQUM1QixNQUFNLFVBQVUsT0FBdUIsSUFBSTtDQUMzQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxnQkFBZ0I7RUFDZCxNQUFNLFNBQVMsUUFBUTtFQUN2QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sV0FBVyxJQUFJLHNCQUFzQixDQUFDLFdBQVc7R0FDckQsVUFBVSxDQUFDLE1BQU0sa0JBQWtCLE1BQU0sbUJBQW1CLE1BQU0sQ0FBQztFQUNyRSxDQUFDO0VBQ0QsU0FBUyxRQUFRLE1BQU07RUFDdkIsYUFBYSxTQUFTLFdBQVc7Q0FDbkMsR0FBRyxDQUFDLENBQUM7Q0FDTCxNQUFNLFlBQVksUUFBUSxZQUFZLFFBQVEsV0FBVztDQUN6RCxlQUFlLFNBQVMsUUFBaUI7RUFDdkMsSUFDRSxRQUFRLFdBQ1IsQ0FBQyxhQUNELFdBQVcsS0FDWCxXQUFXLFFBQVEsVUFFbkI7RUFDRixRQUFRLFVBQVU7RUFDbEIsUUFBUSxJQUFJO0VBQ1osU0FBUyxFQUFFO0VBQ1gsU0FBUyxLQUFLO0VBQ2QsSUFBSTtHQUNGLE1BQU0sWUFBWTtJQUFFLFdBQVcsUUFBUTtJQUFXO0dBQVMsQ0FBQztHQUM1RCxTQUFTLElBQUk7R0FDYixJQUFJLENBQUMsUUFDSCxZQUFZO0lBQ1YsU0FBUyxhQUFhLFdBQVc7SUFDakMsUUFBUTtLQUFFLE9BQU8sYUFBYSxLQUFLO0tBQU0sSUFBSSxPQUFPO0lBQUs7R0FDM0QsQ0FBQztHQUNILElBQUksUUFBUSxTQUFTLE9BQU8sUUFBUTtFQUN0QyxTQUFTLE9BQU87R0FDZCxTQUFTLFlBQVksT0FBTyxFQUFFLGFBQWEsQ0FBQztFQUM5QyxVQUFVO0dBQ1IsUUFBUSxVQUFVO0dBQ2xCLFFBQVEsS0FBSztFQUNmO0NBQ0Y7Q0FDQSxPQUNFLHdCQUFDLFdBQUQ7RUFDRSxjQUFZLEVBQUU7RUFDZCxXQUFVO1lBRlo7R0FJRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsYUFBRDtLQUNFLFFBQ0UsWUFDSSxRQUFRLFlBQVksSUFDbEIsY0FDQSxhQUNGO2VBR0wsWUFDRyxRQUFRLFlBQVksSUFDbEIsUUFBUSxRQUFRLFNBQVMsU0FDekIsYUFBYSxlQUFlLFVBQzlCLGFBQWEsZUFBZTtJQUNyQjs7OztjQUNiLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BQ0csYUFBYSxlQUFlO01BQUk7TUFBRyxRQUFRO0tBQ3hDOzs7OztZQUNIOzs7Ozs7R0FDTCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNYLHdCQUFDLE9BQUQsRUFBTyxPQUFPLFFBQVEsTUFBUTs7Ozs7R0FDN0I7Ozs7O0dBQ0YsUUFBUSxrQkFBa0IsUUFDekIsT0FBTyxRQUFRLGNBQWMsSUFBSSxPQUFPLFFBQVEsS0FBSyxLQUNuRCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNYLHdCQUFDLEtBQUQsWUFDRSx3QkFBQyxPQUFELEVBQU8sT0FBTyxRQUFRLGVBQWlCOzs7O2FBQ3RDOzs7OztHQUNGOzs7OztHQUVQLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQVcsUUFBUSxZQUFZLEVBQUU7R0FBYzs7Ozs7R0FDNUQsd0JBQUMsU0FBRDtJQUNFLFNBQVE7SUFDUixXQUFVO2NBRVQsRUFBRTtHQUNFOzs7OztHQUNQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFEO01BQ0UsY0FBWSxFQUFFO01BQ2QsVUFBVSxRQUFRLFlBQVk7TUFDOUIsZUFBZSxhQUFhLFVBQVUsS0FBSyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUM7TUFDNUQsV0FBVTtnQkFDWDtLQUVPOzs7OztLQUNSLHdCQUFDLFNBQUQ7TUFDRSxJQUFHO01BQ0gsY0FBWSxFQUFFO01BQ2QsTUFBSztNQUNMLEtBQUs7TUFDTCxLQUFLLEtBQUssSUFBSSxRQUFRLFVBQVUsQ0FBQztNQUNqQyxNQUFNO01BQ04sVUFBVSxRQUFRLENBQUM7TUFDbkIsT0FBTztNQUNQLFdBQVcsVUFBVTtPQUNuQixNQUFNLFFBQVEsT0FBTyxNQUFNLE9BQU8sS0FBSztPQUN2QyxZQUNFLE9BQU8sVUFBVSxLQUFLLElBQ2xCLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJLFFBQVEsVUFBVSxDQUFDLENBQUMsSUFDMUQsQ0FDTjtNQUNGO01BQ0EsV0FBVTtLQUNYOzs7OztLQUNELHdCQUFDLFVBQUQ7TUFDRSxjQUFZLEVBQUU7TUFDZCxVQUFVLFFBQVEsWUFBWSxRQUFRO01BQ3RDLGVBQ0UsYUFBYSxVQUFVLEtBQUssSUFBSSxRQUFRLFVBQVUsUUFBUSxDQUFDLENBQUM7TUFFOUQsV0FBVTtnQkFDWDtLQUVPOzs7OztJQUNMOzs7Ozs7R0FDTCx3QkFBQyxPQUFEO0lBQUssS0FBSztjQUNQLFVBQ0Msd0JBQUMsY0FBRDtLQUFjLE9BQU8sRUFBRTtLQUFTLFNBQVM7SUFBTzs7OztlQUM5QyxDQUFDLE9BQ0gsd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTztLQUNYLE9BQU8sRUFBRSxNQUFNLFNBQVMsU0FBUztLQUNqQyxXQUFVO2VBRVQsRUFBRTtJQUNDOzs7O2VBQ0osS0FBSyxTQUFTLFdBQVcsV0FDM0Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxVQUFVLFFBQVEsQ0FBQztNQUNuQixlQUFlLEtBQUssU0FBUyxLQUFLO01BQ2xDLFdBQVU7Z0JBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7O2dCQUNsQixPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQ2Y7Ozs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNFLFVBQVUsUUFBUSxDQUFDO01BQ25CLGVBQWUsS0FBSyxTQUFTLElBQUk7TUFDakMsV0FBVTtnQkFFVCxFQUFFO0tBQ0c7Ozs7YUFDTDs7Ozs7ZUFDSDtHQUNEOzs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUNFLHdCQUFDLE1BQUQ7T0FBTSxNQUFLO09BQVEsV0FBVTtNQUFXOzs7O2dCQUFDLDhCQUV4Qzs7Ozs7O0tBQ0gsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FDRSx3QkFBQyxNQUFEO09BQU0sTUFBSztPQUFTLFdBQVU7TUFBVzs7OztnQkFDeEMsUUFBUSxZQUFZLDZCQUNwQjs7Ozs7O0tBQ0gsd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTztNQUNYLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxNQUFEO09BQU0sTUFBSztPQUFTLFdBQVU7TUFBVzs7OztnQkFBQyx5QkFFdEM7Ozs7OztJQUNIOzs7Ozs7R0FDSixTQUNDLHdCQUFDLEtBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtjQUVUO0dBQ0E7Ozs7O0dBRUosU0FDQyx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFTLFdBQVU7Y0FBM0I7S0FDRyxFQUFFO0tBQU87S0FDVix3QkFBQyxNQUFEO01BQU0sSUFBSSxPQUFPO01BQU0sV0FBVTtnQkFDOUIsYUFBYSxLQUFLO0tBQ2Y7Ozs7O0lBQ0w7Ozs7OztHQUVKLFVBQVUsTUFBTSxTQUFTLFdBQVcsWUFDbkMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNiLFlBQVksYUFBYTtJQUN0Qjs7OztjQUNOLHdCQUFDLE9BQUQ7S0FBTyxPQUFPLFFBQVE7S0FBTyxXQUFVO0lBQXlCOzs7O1lBQzdEOzs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLEtBQUssU0FBUyxLQUFLO0tBQ2xDLFVBQVUsUUFBUSxDQUFDO0tBQ25CLGFBQVc7S0FDWCxXQUFVO2VBRVQsT0FBTyxFQUFFLFNBQVMsRUFBRTtJQUNmOzs7O1lBQ0w7Ozs7OztFQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQdXJjaGFzZVBhbmVsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQcmljZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1ByaWNlJztcclxuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL1N0YXR1c0JhZGdlJztcclxuaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB0eXBlIHsgUHJvZHVjdCB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3Byb2R1Y3QudHlwZXMnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IFVTRVJfUk9MRVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm9sZXMnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgYWRkQ2FydEl0ZW0gfSBmcm9tICcuLi8uLi8uLi8uLi9zZXJ2aWNlcy9jYXJ0U2VydmljZSc7XHJcbmltcG9ydCB7IGdldEFwaUVycm9yIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvYXBpRXJyb3JzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBub3RpZnlUb2FzdCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RvYXN0JztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5leHBlcmllbmNlO1xyXG5leHBvcnQgZnVuY3Rpb24gUHVyY2hhc2VQYW5lbCh7IHByb2R1Y3QgfTogeyBwcm9kdWN0OiBQcm9kdWN0IH0pIHtcclxuICBjb25zdCB7IHVzZXIsIGxvYWRpbmcgfSA9IHVzZUF1dGgoKSxcclxuICAgIG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKSxcclxuICAgIGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCBbcXVhbnRpdHksIHNldFF1YW50aXR5XSA9IHVzZVN0YXRlKDEpLFxyXG4gICAgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpLFxyXG4gICAgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyksXHJcbiAgICBbYWRkZWQsIHNldEFkZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBwZW5kaW5nID0gdXNlUmVmKGZhbHNlKTtcclxuICBjb25zdCBhY3Rpb25zID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuICBjb25zdCBbc3RpY2t5LCBzZXRTdGlja3ldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0YXJnZXQgPSBhY3Rpb25zLmN1cnJlbnQ7XHJcbiAgICBpZiAoIXRhcmdldCkgcmV0dXJuO1xyXG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKFtlbnRyeV0pID0+IHtcclxuICAgICAgc2V0U3RpY2t5KCFlbnRyeS5pc0ludGVyc2VjdGluZyAmJiBlbnRyeS5ib3VuZGluZ0NsaWVudFJlY3QudG9wIDwgMCk7XHJcbiAgICB9KTtcclxuICAgIG9ic2VydmVyLm9ic2VydmUodGFyZ2V0KTtcclxuICAgIHJldHVybiAoKSA9PiBvYnNlcnZlci5kaXNjb25uZWN0KCk7XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IGF2YWlsYWJsZSA9IHByb2R1Y3QuaXNBY3RpdmUgJiYgcHJvZHVjdC5zdG9ja1F0eSA+IDA7XHJcbiAgYXN5bmMgZnVuY3Rpb24gcHVyY2hhc2UoYnV5Tm93OiBib29sZWFuKSB7XHJcbiAgICBpZiAoXHJcbiAgICAgIHBlbmRpbmcuY3VycmVudCB8fFxyXG4gICAgICAhYXZhaWxhYmxlIHx8XHJcbiAgICAgIHF1YW50aXR5IDwgMSB8fFxyXG4gICAgICBxdWFudGl0eSA+IHByb2R1Y3Quc3RvY2tRdHlcclxuICAgIClcclxuICAgICAgcmV0dXJuO1xyXG4gICAgcGVuZGluZy5jdXJyZW50ID0gdHJ1ZTtcclxuICAgIHNldEJ1c3kodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcignJyk7XHJcbiAgICBzZXRBZGRlZChmYWxzZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhZGRDYXJ0SXRlbSh7IHByb2R1Y3RJZDogcHJvZHVjdC5wcm9kdWN0SUQsIHF1YW50aXR5IH0pO1xyXG4gICAgICBzZXRBZGRlZCh0cnVlKTtcclxuICAgICAgaWYgKCFidXlOb3cpXHJcbiAgICAgICAgbm90aWZ5VG9hc3Qoe1xyXG4gICAgICAgICAgbWVzc2FnZTogdHJhbnNsYXRpb25zLnN0b3JlZnJvbnQuYWRkZWQsXHJcbiAgICAgICAgICBhY3Rpb246IHsgbGFiZWw6IHRyYW5zbGF0aW9ucy5jYXJ0LnZpZXcsIHRvOiBST1VURVMuY2FydCB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICBpZiAoYnV5Tm93KSBuYXZpZ2F0ZShST1VURVMuY2hlY2tvdXQpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0RXJyb3IoZ2V0QXBpRXJyb3IoZXJyb3IsIHQucHVyY2hhc2VFcnJvcikpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgcGVuZGluZy5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb25cclxuICAgICAgYXJpYS1sYWJlbD17dC5wdXJjaGFzZU9wdGlvbnN9XHJcbiAgICAgIGNsYXNzTmFtZT1cInB1cmNoYXNlLXBhbmVsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IHhsOnN0aWNreSB4bDp0b3AtMjQgeGw6cC02XCJcclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgPFN0YXR1c0JhZGdlXHJcbiAgICAgICAgICBzdGF0dXM9e1xyXG4gICAgICAgICAgICBhdmFpbGFibGVcclxuICAgICAgICAgICAgICA/IHByb2R1Y3Quc3RvY2tRdHkgPD0gNVxyXG4gICAgICAgICAgICAgICAgPyAnTE9XX1NUT0NLJ1xyXG4gICAgICAgICAgICAgICAgOiAnSU5fU1RPQ0snXHJcbiAgICAgICAgICAgICAgOiAnT1VUX09GX1NUT0NLJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHthdmFpbGFibGVcclxuICAgICAgICAgICAgPyBwcm9kdWN0LnN0b2NrUXR5IDw9IDVcclxuICAgICAgICAgICAgICA/IGBPbmx5ICR7cHJvZHVjdC5zdG9ja1F0eX0gbGVmdGBcclxuICAgICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5pblN0b2NrXHJcbiAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLm91dE9mU3RvY2t9XHJcbiAgICAgICAgPC9TdGF0dXNCYWRnZT5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJicmVhay1hbGwgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICB7dHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLnNrdX06IHtwcm9kdWN0LlNLVX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC01IHRleHQtM3hsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgPFByaWNlIHZhbHVlPXtwcm9kdWN0LnByaWNlfSAvPlxyXG4gICAgICA8L3A+XHJcbiAgICAgIHtwcm9kdWN0LmNvbXBhcmVBdFByaWNlICE9IG51bGwgJiZcclxuICAgICAgICBOdW1iZXIocHJvZHVjdC5jb21wYXJlQXRQcmljZSkgPiBOdW1iZXIocHJvZHVjdC5wcmljZSkgJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgPHM+XHJcbiAgICAgICAgICAgICAgPFByaWNlIHZhbHVlPXtwcm9kdWN0LmNvbXBhcmVBdFByaWNlfSAvPlxyXG4gICAgICAgICAgICA8L3M+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgPHAgY2xhc3NOYW1lPVwic3Itb25seVwiPntwcm9kdWN0LndhcnJhbnR5IHx8IHQubm9XYXJyYW50eX08L3A+XHJcbiAgICAgIDxsYWJlbFxyXG4gICAgICAgIGh0bWxGb3I9XCJwdXJjaGFzZS1xdWFudGl0eVwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwibWItMiBtdC02IGJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCJcclxuICAgICAgPlxyXG4gICAgICAgIHt0LnF1YW50aXR5fVxyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTUgZmxleCB3LWZpdCBpdGVtcy1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgYXJpYS1sYWJlbD17dC5kZWNyZWFzZX1cclxuICAgICAgICAgIGRpc2FibGVkPXtidXN5IHx8IHF1YW50aXR5IDw9IDF9XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRRdWFudGl0eSgodmFsdWUpID0+IE1hdGgubWF4KDEsIHZhbHVlIC0gMSkpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWluLWgtMTEgdy0xMSBiZy1wYWdlIHRleHQtZmctbGluayBkaXNhYmxlZDp0ZXh0LWZnLWRpc2FibGVkXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICDiiJJcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPVwicHVyY2hhc2UtcXVhbnRpdHlcIlxyXG4gICAgICAgICAgYXJpYS1sYWJlbD17dC5xdWFudGl0eX1cclxuICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgbWluPXsxfVxyXG4gICAgICAgICAgbWF4PXtNYXRoLm1heChwcm9kdWN0LnN0b2NrUXR5LCAxKX1cclxuICAgICAgICAgIHN0ZXA9ezF9XHJcbiAgICAgICAgICBkaXNhYmxlZD17YnVzeSB8fCAhYXZhaWxhYmxlfVxyXG4gICAgICAgICAgdmFsdWU9e3F1YW50aXR5fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICBzZXRRdWFudGl0eShcclxuICAgICAgICAgICAgICBOdW1iZXIuaXNJbnRlZ2VyKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgPyBNYXRoLm1pbihNYXRoLm1heCh2YWx1ZSwgMSksIE1hdGgubWF4KHByb2R1Y3Quc3RvY2tRdHksIDEpKVxyXG4gICAgICAgICAgICAgICAgOiAxLFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIG1pbi1oLTExIHctMTYgYm9yZGVyLXggYm9yZGVyLWxpbmUgYmctc3VyZmFjZSB0ZXh0LWNlbnRlciB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIGFyaWEtbGFiZWw9e3QuaW5jcmVhc2V9XHJcbiAgICAgICAgICBkaXNhYmxlZD17YnVzeSB8fCBxdWFudGl0eSA+PSBwcm9kdWN0LnN0b2NrUXR5fVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgc2V0UXVhbnRpdHkoKHZhbHVlKSA9PiBNYXRoLm1pbihwcm9kdWN0LnN0b2NrUXR5LCB2YWx1ZSArIDEpKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWluLWgtMTEgdy0xMSBiZy1wYWdlIHRleHQtZmctbGluayBkaXNhYmxlZDp0ZXh0LWZnLWRpc2FibGVkXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICArXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IHJlZj17YWN0aW9uc30+XHJcbiAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LmxvYWRpbmd9IGNvbXBhY3Q9e3RydWV9IC8+XHJcbiAgICAgICAgKSA6ICF1c2VyID8gKFxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5sb2dpbn1cclxuICAgICAgICAgICAgc3RhdGU9e3sgZnJvbTogbG9jYXRpb24ucGF0aG5hbWUgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IHctZnVsbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LnNpZ25Jbn1cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICApIDogdXNlci5yb2xlID09PSBVU0VSX1JPTEVTLkNVU1RPTUVSID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5IHx8ICFhdmFpbGFibGV9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwdXJjaGFzZShmYWxzZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1wcmltYXJ5IGZsZXggbWluLWgtMTIgdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMyByb3VuZGVkLXNtIGJnLXByaW1hcnkgcHgtNCBweS0zIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXByaW1hcnktb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlciBkaXNhYmxlZDp0ZXh0LWZnLWRpc2FibGVkXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjYXJ0XCIgLz5cclxuICAgICAgICAgICAgICB7YnVzeSA/IHQuYWRkaW5nIDogdC5hZGRUb0NhcnR9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3kgfHwgIWF2YWlsYWJsZX1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHB1cmNoYXNlKHRydWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tYWNjZW50IG1pbi1oLTEyIHctZnVsbFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dC5idXlOb3d9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IG51bGx9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgc3BhY2UteS0zIGJvcmRlci10IGJvcmRlci1saW5lLXN1YnRsZSBwdC01IHRleHQteHMgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cInRydWNrXCIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICBEZWxpdmVyeSBkZXRhaWxzIGF0IGNoZWNrb3V0XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwic2hpZWxkXCIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICB7cHJvZHVjdC53YXJyYW50eSB8fCAnQXNrIG91ciB0ZWFtIGFib3V0IHdhcnJhbnR5J31cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMucmVwYWlyUmVxdWVzdH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cInJlcGFpclwiIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgQ2FyZSBhbmQgcmVwYWlyIHN1cHBvcnRcclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgIDxwXHJcbiAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLXNtIGJnLWRhbmdlci1iZyBwLTMgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2FkZGVkICYmIChcclxuICAgICAgICA8cCByb2xlPVwic3RhdHVzXCIgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtc3VjY2Vzc1wiPlxyXG4gICAgICAgICAge3QuYWRkZWR9eycgJ31cclxuICAgICAgICAgIDxMaW5rIHRvPXtST1VURVMuY2FydH0gY2xhc3NOYW1lPVwidW5kZXJsaW5lXCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY2FydC52aWV3fVxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge3N0aWNreSAmJiB1c2VyPy5yb2xlID09PSBVU0VSX1JPTEVTLkNVU1RPTUVSICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB1cmNoYXNlLXN0aWNreS1iYXJcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgIHthdmFpbGFibGUgPyAnSW4gc3RvY2snIDogJ091dCBvZiBzdG9jayd9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPFByaWNlIHZhbHVlPXtwcm9kdWN0LnByaWNlfSBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHB1cmNoYXNlKGZhbHNlKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3kgfHwgIWF2YWlsYWJsZX1cclxuICAgICAgICAgICAgYXJpYS1idXN5PXtidXN5fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgZmxleC0xXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2J1c3kgPyB0LmFkZGluZyA6IHQuYWRkVG9DYXJ0fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=