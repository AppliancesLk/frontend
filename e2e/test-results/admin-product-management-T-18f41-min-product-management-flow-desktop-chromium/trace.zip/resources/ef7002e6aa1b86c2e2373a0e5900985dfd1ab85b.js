import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/CopyReference.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/CopyReference.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function CopyReference({ value }) {
	_s();
	const [copied, setCopied] = useState(false);
	const [error, setError] = useState(false);
	async function copy() {
		try {
			await navigator.clipboard.writeText(value);
			setCopied(true);
			setError(false);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setError(true);
		}
	}
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "relative inline-flex",
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "ui-icon-button h-8 w-8",
			onClick: () => void copy(),
			"aria-label": copied ? "Copied reference" : "Copy full reference",
			title: value,
			children: /* @__PURE__ */ _jsxDEV(Icon, {
				name: copied ? "check" : "copy",
				className: "h-4 w-4"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			role: "status",
			children: copied ? "Copied" : error ? `Could not copy. Reference: ${value}` : ""
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(CopyReference, "SDoH5fhEjZ38MdIIlqlxLpj7TUE=");
_c = CopyReference;
var _c;
$RefreshReg$(_c, "CopyReference");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/CopyReference.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/CopyReference.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/CopyReference.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/CopyReference.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZOzs7O0FBQ3JCLE9BQU8sU0FBUyxjQUFjLEVBQUUsU0FBNEI7O0NBQzFELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxLQUFLO0NBQ3hDLGVBQWUsT0FBTztFQUNwQixJQUFJO0dBQ0YsTUFBTSxVQUFVLFVBQVUsVUFBVSxLQUFLO0dBQ3pDLFVBQVUsSUFBSTtHQUNkLFNBQVMsS0FBSztHQUNkLE9BQU8saUJBQWlCLFVBQVUsS0FBSyxHQUFHLElBQUk7RUFDaEQsUUFBUTtHQUNOLFNBQVMsSUFBSTtFQUNmO0NBQ0Y7Q0FDQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQ0Usd0JBQUMsVUFBRDtHQUNFLE1BQUs7R0FDTCxXQUFVO0dBQ1YsZUFBZSxLQUFLLEtBQUs7R0FDekIsY0FBWSxTQUFTLHFCQUFxQjtHQUMxQyxPQUFPO2FBRVAsd0JBQUMsTUFBRDtJQUFNLE1BQU0sU0FBUyxVQUFVO0lBQVEsV0FBVTtHQUFXOzs7OztFQUN0RDs7OztZQUNSLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO0dBQVUsTUFBSzthQUM1QixTQUFTLFdBQVcsUUFBUSw4QkFBOEIsVUFBVTtFQUNqRTs7OztVQUNGOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb3B5UmVmZXJlbmNlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gJy4vSWNvbic7XHJcbmV4cG9ydCBmdW5jdGlvbiBDb3B5UmVmZXJlbmNlKHsgdmFsdWUgfTogeyB2YWx1ZTogc3RyaW5nIH0pIHtcclxuICBjb25zdCBbY29waWVkLCBzZXRDb3BpZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGNvcHkoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh2YWx1ZSk7XHJcbiAgICAgIHNldENvcGllZCh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IoZmFsc2UpO1xyXG4gICAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWQoZmFsc2UpLCAxNjAwKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBzZXRFcnJvcih0cnVlKTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4XCI+XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJ1aS1pY29uLWJ1dHRvbiBoLTggdy04XCJcclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGNvcHkoKX1cclxuICAgICAgICBhcmlhLWxhYmVsPXtjb3BpZWQgPyAnQ29waWVkIHJlZmVyZW5jZScgOiAnQ29weSBmdWxsIHJlZmVyZW5jZSd9XHJcbiAgICAgICAgdGl0bGU9e3ZhbHVlfVxyXG4gICAgICA+XHJcbiAgICAgICAgPEljb24gbmFtZT17Y29waWVkID8gJ2NoZWNrJyA6ICdjb3B5J30gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgIHtjb3BpZWQgPyAnQ29waWVkJyA6IGVycm9yID8gYENvdWxkIG5vdCBjb3B5LiBSZWZlcmVuY2U6ICR7dmFsdWV9YCA6ICcnfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufVxyXG4iXX0=