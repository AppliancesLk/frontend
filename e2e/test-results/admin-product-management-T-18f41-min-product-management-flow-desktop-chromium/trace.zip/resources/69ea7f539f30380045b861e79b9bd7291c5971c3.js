import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Cart/components/CartBenefits.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/components/common/Icon.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartBenefits.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.cart;
const benefits = [
	{
		icon: "lock",
		title: t.secureTitle,
		description: t.secureDescription
	},
	{
		icon: "truck",
		title: t.deliveryTitle,
		description: t.deliveryDescription
	},
	{
		icon: "shield",
		title: t.stockTitle,
		description: t.stockDescription
	},
	{
		icon: "repair",
		title: t.supportTitle,
		description: t.supportDescription
	}
];
export function CartBenefits({ compact = false }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `rounded-md bg-primary-subtle p-5 ${compact ? "cart-trust space-y-3" : "grid gap-6 sm:grid-cols-2 xl:grid-cols-4"}`,
		children: benefits.slice(0, compact ? 3 : 4).map(({ icon, title, description }) => /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ _jsxDEV(Icon, {
				name: icon,
				className: compact ? "h-4 w-4 shrink-0 text-fg-muted" : "h-8 w-8 shrink-0 text-fg-link"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm font-semibold text-fg",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: compact ? "sr-only" : "mt-1 text-xs leading-5 text-fg-muted",
				children: description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 15
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 13
			}, this)]
		}, title, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 11
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = CartBenefits;
var _c;
$RefreshReg$(_c, "CartBenefits");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Cart/components/CartBenefits.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartBenefits.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartBenefits.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartBenefits.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUEyQjtBQUNwQyxTQUFTLG9CQUFvQjs7O0FBQzdCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE1BQU0sV0FBcUU7Q0FDekU7RUFBRSxNQUFNO0VBQVEsT0FBTyxFQUFFO0VBQWEsYUFBYSxFQUFFO0NBQWtCO0NBQ3ZFO0VBQUUsTUFBTTtFQUFTLE9BQU8sRUFBRTtFQUFlLGFBQWEsRUFBRTtDQUFvQjtDQUM1RTtFQUFFLE1BQU07RUFBVSxPQUFPLEVBQUU7RUFBWSxhQUFhLEVBQUU7Q0FBaUI7Q0FDdkU7RUFBRSxNQUFNO0VBQVUsT0FBTyxFQUFFO0VBQWMsYUFBYSxFQUFFO0NBQW1CO0FBQzdFO0FBQ0EsT0FBTyxTQUFTLGFBQWEsRUFBRSxVQUFVLFNBQWdDO0NBQ3ZFLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVcsb0NBQW9DLFVBQVUseUJBQXlCO1lBRWpGLFNBQ0UsTUFBTSxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FDekIsS0FBSyxFQUFFLE1BQU0sT0FBTyxrQkFDbkIsd0JBQUMsT0FBRDtHQUFpQixXQUFVO2FBQTNCLENBQ0Usd0JBQUMsTUFBRDtJQUNFLE1BQU07SUFDTixXQUNFLFVBQ0ksbUNBQ0E7R0FFUDs7OzthQUNELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFpQztHQUFTOzs7O2FBQ3ZELHdCQUFDLEtBQUQ7SUFDRSxXQUNFLFVBQVUsWUFBWTtjQUd2QjtHQUNBOzs7O1dBQ0E7Ozs7V0FDRjtLQW5CSzs7OztTQW1CTCxDQUNOO0NBQ0E7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2FydEJlbmVmaXRzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJY29uLCB0eXBlIEljb25OYW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuY2FydDtcclxuY29uc3QgYmVuZWZpdHM6IHsgaWNvbjogSWNvbk5hbWU7IHRpdGxlOiBzdHJpbmc7IGRlc2NyaXB0aW9uOiBzdHJpbmcgfVtdID0gW1xyXG4gIHsgaWNvbjogJ2xvY2snLCB0aXRsZTogdC5zZWN1cmVUaXRsZSwgZGVzY3JpcHRpb246IHQuc2VjdXJlRGVzY3JpcHRpb24gfSxcclxuICB7IGljb246ICd0cnVjaycsIHRpdGxlOiB0LmRlbGl2ZXJ5VGl0bGUsIGRlc2NyaXB0aW9uOiB0LmRlbGl2ZXJ5RGVzY3JpcHRpb24gfSxcclxuICB7IGljb246ICdzaGllbGQnLCB0aXRsZTogdC5zdG9ja1RpdGxlLCBkZXNjcmlwdGlvbjogdC5zdG9ja0Rlc2NyaXB0aW9uIH0sXHJcbiAgeyBpY29uOiAncmVwYWlyJywgdGl0bGU6IHQuc3VwcG9ydFRpdGxlLCBkZXNjcmlwdGlvbjogdC5zdXBwb3J0RGVzY3JpcHRpb24gfSxcclxuXTtcclxuZXhwb3J0IGZ1bmN0aW9uIENhcnRCZW5lZml0cyh7IGNvbXBhY3QgPSBmYWxzZSB9OiB7IGNvbXBhY3Q/OiBib29sZWFuIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLW1kIGJnLXByaW1hcnktc3VidGxlIHAtNSAke2NvbXBhY3QgPyAnY2FydC10cnVzdCBzcGFjZS15LTMnIDogJ2dyaWQgZ2FwLTYgc206Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTQnfWB9XHJcbiAgICA+XHJcbiAgICAgIHtiZW5lZml0c1xyXG4gICAgICAgIC5zbGljZSgwLCBjb21wYWN0ID8gMyA6IDQpXHJcbiAgICAgICAgLm1hcCgoeyBpY29uLCB0aXRsZSwgZGVzY3JpcHRpb24gfSkgPT4gKFxyXG4gICAgICAgICAgPGRpdiBrZXk9e3RpdGxlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxJY29uXHJcbiAgICAgICAgICAgICAgbmFtZT17aWNvbn1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgY29tcGFjdFxyXG4gICAgICAgICAgICAgICAgICA/ICdoLTQgdy00IHNocmluay0wIHRleHQtZmctbXV0ZWQnXHJcbiAgICAgICAgICAgICAgICAgIDogJ2gtOCB3LTggc2hyaW5rLTAgdGV4dC1mZy1saW5rJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt0aXRsZX08L3A+XHJcbiAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhY3QgPyAnc3Itb25seScgOiAnbXQtMSB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtkZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==