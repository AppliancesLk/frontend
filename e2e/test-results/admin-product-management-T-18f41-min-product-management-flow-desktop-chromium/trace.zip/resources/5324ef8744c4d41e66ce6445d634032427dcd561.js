import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Reports/index.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { getAdminReportOverview } from "/src/services/reportService.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Reports/index.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
function BarChart({ points, value, color = "bg-primary" }) {
	const max = Math.max(...points.map((point) => Number(point[value] ?? 0)), 1);
	if (points.length === 0) return /* @__PURE__ */ _jsxDEV("p", {
		className: "text-sm text-fg-muted",
		children: "No data for this period."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 35
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex h-48 items-end gap-2 overflow-x-auto pt-4",
		children: points.map((point) => {
			const amount = Number(point[value] ?? 0);
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "flex min-w-8 flex-1 flex-col items-center gap-2",
				title: `${point.date}: ${amount}`,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: `w-full rounded-t ${color}`,
					style: { height: `${Math.max(amount / max * 100, 4)}%` }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] text-fg-muted",
					children: new Date(point.date).toLocaleDateString(undefined, {
						month: "short",
						day: "numeric"
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 7
				}, this)]
			}, point.date, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 12
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 10
	}, this);
}
_c = BarChart;
export default function ReportsPage() {
	_s();
	const [period, setPeriod] = useState("day");
	const [data, setData] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	useEffect(() => {
		let active = true;
		getAdminReportOverview(period).then((result) => {
			if (active) setData(result);
		}).catch(() => {
			if (active) setError("Unable to load reports.");
		}).finally(() => {
			if (active) setLoading(false);
		});
		return () => {
			active = false;
		};
	}, [period]);
	const changePeriod = (next) => {
		setLoading(true);
		setError("");
		setPeriod(next);
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: "Reports"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 79
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: "Sales, customer and repair performance."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 129
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 74
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex rounded-md border border-line bg-surface p-1",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						className: `ui-button ${period === "day" ? "ui-button-primary" : "ui-button-ghost"}`,
						onClick: () => changePeriod("day"),
						children: "Daily"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 287
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: `ui-button ${period === "month" ? "ui-button-primary" : "ui-button-ghost"}`,
						onClick: () => changePeriod("month"),
						children: "Monthly"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 431
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 220
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading,
				error,
				retry: () => setPeriod(period)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 5
			}, this),
			data && !loading && !error && /* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ _jsxDEV("article", {
						className: "rounded-md border border-line bg-surface p-5",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-semibold text-fg",
							children: "New user registrations"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 73
						}, this), /* @__PURE__ */ _jsxDEV(BarChart, {
							points: data.registrations,
							value: "count",
							color: "bg-primary"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 138
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						className: "rounded-md border border-line bg-surface p-5",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-semibold text-fg",
							children: "Revenue"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 73
						}, this), /* @__PURE__ */ _jsxDEV(BarChart, {
							points: data.revenue,
							value: "total",
							color: "bg-success"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 123
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						className: "rounded-md border border-line bg-surface p-5",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-semibold text-fg",
							children: "Repair requests"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 73
						}, this), /* @__PURE__ */ _jsxDEV(BarChart, {
							points: data.repairs,
							value: "count",
							color: "bg-warning"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 131
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						className: "rounded-md border border-line bg-surface p-5",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-semibold text-fg",
							children: "Best-selling products"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 73
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-4 space-y-3",
							children: data.topProducts.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-fg-muted",
								children: "No sales for this period."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 202
							}, this) : data.topProducts.map((product, index) => /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between gap-3 border-b border-line pb-3 text-sm",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-medium text-fg",
									children: [
										index + 1,
										". ",
										product.name
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 427
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-fg-muted",
									children: [
										product.quantity,
										" sold · ",
										formatCurrency(product.revenue)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 499
								}, this)]
							}, product.productId, true, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 312
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 137
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 36
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 10
	}, this);
}
_s(ReportsPage, "0SYSnLQXkoZ6Tmy/t57w9cF1jXc=");
_c2 = ReportsPage;
var _c, _c2;
$RefreshReg$(_c, "BarChart");
$RefreshReg$(_c2, "ReportsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Reports/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Reports/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Reports/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Reports/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLDhCQUE4Qjs7OztBQUd2QyxTQUFTLFNBQVMsRUFBRSxRQUFRLE9BQU8sUUFBUSxnQkFBcUY7Q0FDOUgsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxVQUFVLE9BQU8sTUFBTSxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUM7Q0FDM0UsSUFBSSxPQUFPLFdBQVcsR0FBRyxPQUFPLHdCQUFDLEtBQUQ7RUFBRyxXQUFVO1lBQXdCO0NBQTJCOzs7OztDQUNoRyxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWtELE9BQU8sS0FBSyxVQUFVO0dBQzVGLE1BQU0sU0FBUyxPQUFPLE1BQU0sVUFBVSxDQUFDO0dBQ3ZDLE9BQU8sd0JBQUMsT0FBRDtJQUFzQixXQUFVO0lBQWtELE9BQU8sR0FBRyxNQUFNLEtBQUssSUFBSTtjQUEzRyxDQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLG9CQUFvQjtLQUFTLE9BQU8sRUFBRSxRQUFRLEdBQUcsS0FBSyxJQUFLLFNBQVMsTUFBTyxLQUFLLENBQUMsRUFBRSxHQUFHO0lBQUk7Ozs7Y0FDMUcsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBNkIsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDLENBQUMsbUJBQW1CLFdBQVc7TUFBRSxPQUFPO01BQVMsS0FBSztLQUFVLENBQUM7SUFBUTs7OztZQUN2STtNQUhZLE1BQU07Ozs7VUFHbEI7RUFDUCxDQUFDO0NBQU87Ozs7O0FBQ1Y7O0FBRUEsZUFBZSxTQUFTLGNBQWM7O0NBQ3BDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBMEIsS0FBSztDQUMzRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQXFDLElBQUk7Q0FDakUsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsZ0JBQWdCO0VBQUUsSUFBSSxTQUFTO0VBQU0sdUJBQXVCLE1BQU0sQ0FBQyxDQUFDLE1BQU0sV0FBVztHQUFFLElBQUksUUFBUSxRQUFRLE1BQU07RUFBRyxDQUFDLENBQUMsQ0FBQyxZQUFZO0dBQUUsSUFBSSxRQUFRLFNBQVMseUJBQXlCO0VBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYztHQUFFLElBQUksUUFBUSxXQUFXLEtBQUs7RUFBRyxDQUFDO0VBQUcsYUFBYTtHQUFFLFNBQVM7RUFBTztDQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDelIsTUFBTSxnQkFBZ0IsU0FBMEI7RUFBRSxXQUFXLElBQUk7RUFBRyxTQUFTLEVBQUU7RUFBRyxVQUFVLElBQUk7Q0FBRztDQUNuRyxPQUFPLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0wsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FBcUUsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXdCO0lBQVc7Ozs7Y0FBQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE2QjtJQUEwQzs7OztZQUFNOzs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFtRSx3QkFBQyxVQUFEO01BQVEsV0FBVyxhQUFhLFdBQVcsUUFBUSxzQkFBc0I7TUFBcUIsZUFBZSxhQUFhLEtBQUs7Z0JBQUc7S0FBYTs7OztlQUFDLHdCQUFDLFVBQUQ7TUFBUSxXQUFXLGFBQWEsV0FBVyxVQUFVLHNCQUFzQjtNQUFxQixlQUFlLGFBQWEsT0FBTztnQkFBRztLQUFlOzs7O2FBQU07Ozs7O1lBQVM7Ozs7OztHQUM5a0Isd0JBQUMsaUJBQUQ7SUFBMEI7SUFBZ0I7SUFBTyxhQUFhLFVBQVUsTUFBTTtHQUFJOzs7OztHQUNqRixRQUFRLENBQUMsV0FBVyxDQUFDLFNBQVMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUM3Qix3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FBa0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXdCO01BQTBCOzs7O2dCQUFDLHdCQUFDLFVBQUQ7T0FBVSxRQUFRLEtBQUs7T0FBZSxPQUFNO09BQVEsT0FBTTtNQUFjOzs7O2NBQVU7Ozs7OztLQUNyTix3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FBa0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXdCO01BQVc7Ozs7Z0JBQUMsd0JBQUMsVUFBRDtPQUFVLFFBQVEsS0FBSztPQUFTLE9BQU07T0FBUSxPQUFNO01BQWM7Ozs7Y0FBVTs7Ozs7O0tBQ2hNLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQixDQUFrRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBd0I7TUFBbUI7Ozs7Z0JBQUMsd0JBQUMsVUFBRDtPQUFVLFFBQVEsS0FBSztPQUFTLE9BQU07T0FBUSxPQUFNO01BQWM7Ozs7Y0FBVTs7Ozs7O0tBQ3hNLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQixDQUFrRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBd0I7TUFBeUI7Ozs7Z0JBQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWtCLEtBQUssWUFBWSxXQUFXLElBQUksd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXdCO09BQTRCOzs7O2tCQUFJLEtBQUssWUFBWSxLQUFLLFNBQVMsVUFBVSx3QkFBQyxPQUFEO1FBQTZCLFdBQVU7a0JBQXZDLENBQW1ILHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUF1QyxRQUFRO1VBQUU7VUFBRyxRQUFRO1NBQVc7Ozs7O2tCQUFDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUFpQyxRQUFRO1VBQVM7VUFBUyxlQUFlLFFBQVEsT0FBTztTQUFROzs7OztnQkFBTTtVQUF4UixRQUFROzs7O2NBQWdSLENBQUM7TUFBTzs7OztjQUFVOzs7Ozs7SUFDbG1COzs7Ozs7RUFDRTs7Ozs7O0FBQ1giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcbmltcG9ydCB7IGdldEFkbWluUmVwb3J0T3ZlcnZpZXcgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9yZXBvcnRTZXJ2aWNlJztcbmltcG9ydCB0eXBlIHsgQWRtaW5SZXBvcnRPdmVydmlldywgUmVwb3J0UG9pbnQgfSBmcm9tICcuLi8uLi8uLi90eXBlcy9yZXBvcnQudHlwZXMnO1xuXG5mdW5jdGlvbiBCYXJDaGFydCh7IHBvaW50cywgdmFsdWUsIGNvbG9yID0gJ2JnLXByaW1hcnknIH06IHsgcG9pbnRzOiBSZXBvcnRQb2ludFtdOyB2YWx1ZTogJ2NvdW50JyB8ICd0b3RhbCc7IGNvbG9yPzogc3RyaW5nIH0pIHtcbiAgY29uc3QgbWF4ID0gTWF0aC5tYXgoLi4ucG9pbnRzLm1hcCgocG9pbnQpID0+IE51bWJlcihwb2ludFt2YWx1ZV0gPz8gMCkpLCAxKTtcbiAgaWYgKHBvaW50cy5sZW5ndGggPT09IDApIHJldHVybiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5ObyBkYXRhIGZvciB0aGlzIHBlcmlvZC48L3A+O1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtNDggaXRlbXMtZW5kIGdhcC0yIG92ZXJmbG93LXgtYXV0byBwdC00XCI+e3BvaW50cy5tYXAoKHBvaW50KSA9PiB7XG4gICAgY29uc3QgYW1vdW50ID0gTnVtYmVyKHBvaW50W3ZhbHVlXSA/PyAwKTtcbiAgICByZXR1cm4gPGRpdiBrZXk9e3BvaW50LmRhdGV9IGNsYXNzTmFtZT1cImZsZXggbWluLXctOCBmbGV4LTEgZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yXCIgdGl0bGU9e2Ake3BvaW50LmRhdGV9OiAke2Ftb3VudH1gfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy1mdWxsIHJvdW5kZWQtdCAke2NvbG9yfWB9IHN0eWxlPXt7IGhlaWdodDogYCR7TWF0aC5tYXgoKGFtb3VudCAvIG1heCkgKiAxMDAsIDQpfSVgIH19IC8+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWZnLW11dGVkXCI+e25ldyBEYXRlKHBvaW50LmRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyh1bmRlZmluZWQsIHsgbW9udGg6ICdzaG9ydCcsIGRheTogJ251bWVyaWMnIH0pfTwvc3Bhbj5cbiAgICA8L2Rpdj47XG4gIH0pfTwvZGl2Pjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmVwb3J0c1BhZ2UoKSB7XG4gIGNvbnN0IFtwZXJpb2QsIHNldFBlcmlvZF0gPSB1c2VTdGF0ZTwnZGF5JyB8ICdtb250aCc+KCdkYXknKTtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGU8QWRtaW5SZXBvcnRPdmVydmlldyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7IGxldCBhY3RpdmUgPSB0cnVlOyBnZXRBZG1pblJlcG9ydE92ZXJ2aWV3KHBlcmlvZCkudGhlbigocmVzdWx0KSA9PiB7IGlmIChhY3RpdmUpIHNldERhdGEocmVzdWx0KTsgfSkuY2F0Y2goKCkgPT4geyBpZiAoYWN0aXZlKSBzZXRFcnJvcignVW5hYmxlIHRvIGxvYWQgcmVwb3J0cy4nKTsgfSkuZmluYWxseSgoKSA9PiB7IGlmIChhY3RpdmUpIHNldExvYWRpbmcoZmFsc2UpOyB9KTsgcmV0dXJuICgpID0+IHsgYWN0aXZlID0gZmFsc2U7IH07IH0sIFtwZXJpb2RdKTtcbiAgY29uc3QgY2hhbmdlUGVyaW9kID0gKG5leHQ6ICdkYXknIHwgJ21vbnRoJykgPT4geyBzZXRMb2FkaW5nKHRydWUpOyBzZXRFcnJvcignJyk7IHNldFBlcmlvZChuZXh0KTsgfTtcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+PGRpdj48aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+UmVwb3J0czwvaDE+PHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5TYWxlcywgY3VzdG9tZXIgYW5kIHJlcGFpciBwZXJmb3JtYW5jZS48L3A+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJmbGV4IHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC0xXCI+PGJ1dHRvbiBjbGFzc05hbWU9e2B1aS1idXR0b24gJHtwZXJpb2QgPT09ICdkYXknID8gJ3VpLWJ1dHRvbi1wcmltYXJ5JyA6ICd1aS1idXR0b24tZ2hvc3QnfWB9IG9uQ2xpY2s9eygpID0+IGNoYW5nZVBlcmlvZCgnZGF5Jyl9PkRhaWx5PC9idXR0b24+PGJ1dHRvbiBjbGFzc05hbWU9e2B1aS1idXR0b24gJHtwZXJpb2QgPT09ICdtb250aCcgPyAndWktYnV0dG9uLXByaW1hcnknIDogJ3VpLWJ1dHRvbi1naG9zdCd9YH0gb25DbGljaz17KCkgPT4gY2hhbmdlUGVyaW9kKCdtb250aCcpfT5Nb250aGx5PC9idXR0b24+PC9kaXY+PC9oZWFkZXI+XG4gICAgPENhdGFsb2dGZWVkYmFjayBsb2FkaW5nPXtsb2FkaW5nfSBlcnJvcj17ZXJyb3J9IHJldHJ5PXsoKSA9PiBzZXRQZXJpb2QocGVyaW9kKX0gLz5cbiAgICB7ZGF0YSAmJiAhbG9hZGluZyAmJiAhZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IGxnOmdyaWQtY29scy0yXCI+XG4gICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNVwiPjxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZmdcIj5OZXcgdXNlciByZWdpc3RyYXRpb25zPC9oMj48QmFyQ2hhcnQgcG9pbnRzPXtkYXRhLnJlZ2lzdHJhdGlvbnN9IHZhbHVlPVwiY291bnRcIiBjb2xvcj1cImJnLXByaW1hcnlcIiAvPjwvYXJ0aWNsZT5cbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01XCI+PGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlJldmVudWU8L2gyPjxCYXJDaGFydCBwb2ludHM9e2RhdGEucmV2ZW51ZX0gdmFsdWU9XCJ0b3RhbFwiIGNvbG9yPVwiYmctc3VjY2Vzc1wiIC8+PC9hcnRpY2xlPlxuICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTVcIj48aDIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+UmVwYWlyIHJlcXVlc3RzPC9oMj48QmFyQ2hhcnQgcG9pbnRzPXtkYXRhLnJlcGFpcnN9IHZhbHVlPVwiY291bnRcIiBjb2xvcj1cImJnLXdhcm5pbmdcIiAvPjwvYXJ0aWNsZT5cbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01XCI+PGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPkJlc3Qtc2VsbGluZyBwcm9kdWN0czwvaDI+PGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktM1wiPntkYXRhLnRvcFByb2R1Y3RzLmxlbmd0aCA9PT0gMCA/IDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1mZy1tdXRlZFwiPk5vIHNhbGVzIGZvciB0aGlzIHBlcmlvZC48L3A+IDogZGF0YS50b3BQcm9kdWN0cy5tYXAoKHByb2R1Y3QsIGluZGV4KSA9PiA8ZGl2IGtleT17cHJvZHVjdC5wcm9kdWN0SWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBib3JkZXItYiBib3JkZXItbGluZSBwYi0zIHRleHQtc21cIj48c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnXCI+e2luZGV4ICsgMX0uIHtwcm9kdWN0Lm5hbWV9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZmctbXV0ZWRcIj57cHJvZHVjdC5xdWFudGl0eX0gc29sZCDCtyB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5yZXZlbnVlKX08L3NwYW4+PC9kaXY+KX08L2Rpdj48L2FydGljbGU+XG4gICAgPC9kaXY+fVxuICA8L3NlY3Rpb24+O1xufVxuIl19