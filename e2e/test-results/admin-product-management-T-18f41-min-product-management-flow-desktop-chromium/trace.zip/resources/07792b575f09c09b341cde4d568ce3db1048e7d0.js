import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Profile/index.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { AccountDetails } from "/src/components/common/AccountDetails.tsx";
import { ThemeToggle } from "/src/components/common/ThemeToggle.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { commerceText } from "/src/utils/commerceText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Profile/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function ProfilePage() {
	_s();
	const { user } = useAuth();
	const [section, setSection] = useState("details");
	const customer = user?.role === "CUSTOMER";
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title",
				children: "Your account"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-secondary",
				children: "A little space for everything that’s yours."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-10 grid items-start gap-6 md:grid-cols-[240px_minmax(0,1fr)]",
				children: [/* @__PURE__ */ _jsxDEV("aside", {
					className: "overflow-hidden rounded-md border border-line bg-surface p-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4 border-b border-line-subtle px-2 pb-5",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-primary-subtle font-display text-xl font-semibold text-fg-link",
								children: user?.username.slice(0, 2).toUpperCase()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 22,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "font-semibold",
								children: user?.username
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 break-all text-xs text-fg-muted",
								children: user?.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 26,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("nav", {
						"aria-label": "Account sections",
						className: "space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								className: `account-section ${section === "details" ? "is-active" : ""}`,
								onClick: () => setSection("details"),
								"aria-pressed": section === "details",
								children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "user" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 15
								}, this), "Personal details"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 13
							}, this),
							customer && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(Link, {
									className: "account-section",
									to: ROUTES.orders,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "orders" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 42,
										columnNumber: 19
									}, this), "Your orders"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 41,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									className: "account-section",
									to: ROUTES.loyalty,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "bag" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 46,
										columnNumber: 19
									}, this), commerceText.loyalty]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 45,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									className: "account-section",
									to: ROUTES.repairs,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "repair" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 50,
										columnNumber: 19
									}, this), "Your repairs"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									className: "account-section",
									to: ROUTES.liveChat,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "chat" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 54,
										columnNumber: 19
									}, this), "Live support"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 15
							}, this),
							!customer && /* @__PURE__ */ _jsxDEV(Link, {
								className: "account-section",
								to: user?.role === "ADMIN" ? ROUTES.admin : ROUTES.repairer,
								children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "grid" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 17
								}, this), "Your workspace"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: `account-section ${section === "preferences" ? "is-active" : ""}`,
								onClick: () => setSection("preferences"),
								"aria-pressed": section === "preferences",
								children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "filter" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 15
								}, this), "Preferences"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("section", {
					className: "rounded-md border border-line bg-surface p-6 sm:p-8",
					"aria-live": "polite",
					children: section === "details" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-2xl font-semibold",
							children: "Personal details"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm text-fg-muted",
							children: [
								"Hello, ",
								user?.username,
								". Here are your account details."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(AccountDetails, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.products,
							className: "ui-button ui-button-primary",
							children: "Continue shopping"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-2xl font-semibold",
						children: "Preferences"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 flex flex-wrap items-start justify-between gap-6 border-t border-line-subtle pt-6",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-semibold",
							children: "Appearance"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 max-w-xs text-sm text-fg-muted",
							children: "Choose your theme, or let it follow your device. Your choice is saved on this browser."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(ThemeToggle, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_s(ProfilePage, "F1QEuImtS2YDfIg5KFOEYxE6nRM=", false, function() {
	return [useAuth];
});
_c = ProfilePage;
var _c;
$RefreshReg$(_c, "ProfilePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Profile/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Profile/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Profile/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Profile/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZTtBQUN4QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLFlBQVk7QUFDckIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9COzs7O0FBQzdCLGVBQWUsU0FBUyxjQUFjOztDQUNwQyxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBb0MsU0FBUztDQUMzRSxNQUFNLFdBQVcsTUFBTSxTQUFTO0NBQ2hDLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFnQjtHQUFnQjs7Ozs7R0FDOUMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBaUM7R0FFM0M7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixNQUFNLFNBQVMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVk7T0FDcEM7Ozs7O09BQ04sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWlCLE1BQU07T0FBWTs7Ozs7T0FDaEQsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsTUFBTTtPQUNOOzs7OztNQUNBOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxjQUFXO01BQW1CLFdBQVU7Z0JBQTdDO09BQ0Usd0JBQUMsVUFBRDtRQUNFLFdBQVcsbUJBQW1CLFlBQVksWUFBWSxjQUFjO1FBQ3BFLGVBQWUsV0FBVyxTQUFTO1FBQ25DLGdCQUFjLFlBQVk7a0JBSDVCLENBS0Usd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztrQkFBQyxrQkFFZDs7Ozs7O09BQ1AsWUFDQztRQUNFLHdCQUFDLE1BQUQ7U0FBTSxXQUFVO1NBQWtCLElBQUksT0FBTzttQkFBN0MsQ0FDRSx3QkFBQyxNQUFELEVBQU0sTUFBSyxTQUFVOzs7O21CQUFDLGFBRWxCOzs7Ozs7UUFDTix3QkFBQyxNQUFEO1NBQU0sV0FBVTtTQUFrQixJQUFJLE9BQU87bUJBQTdDLENBQ0Usd0JBQUMsTUFBRCxFQUFNLE1BQUssTUFBTzs7OzttQkFDakIsYUFBYSxPQUNWOzs7Ozs7UUFDTix3QkFBQyxNQUFEO1NBQU0sV0FBVTtTQUFrQixJQUFJLE9BQU87bUJBQTdDLENBQ0Usd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7OzttQkFBQyxjQUVsQjs7Ozs7O1FBQ04sd0JBQUMsTUFBRDtTQUFNLFdBQVU7U0FBa0IsSUFBSSxPQUFPO21CQUE3QyxDQUNFLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7bUJBQUMsY0FFaEI7Ozs7OztPQUNOOzs7OztPQUVILENBQUMsWUFDQSx3QkFBQyxNQUFEO1FBQ0UsV0FBVTtRQUNWLElBQUksTUFBTSxTQUFTLFVBQVUsT0FBTyxRQUFRLE9BQU87a0JBRnJELENBSUUsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztrQkFBQyxnQkFFaEI7Ozs7OztPQUVSLHdCQUFDLFVBQUQ7UUFDRSxXQUFXLG1CQUFtQixZQUFZLGdCQUFnQixjQUFjO1FBQ3hFLGVBQWUsV0FBVyxhQUFhO1FBQ3ZDLGdCQUFjLFlBQVk7a0JBSDVCLENBS0Usd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7OztrQkFBQyxhQUVoQjs7Ozs7O01BQ0w7Ozs7O2FBQ0E7Ozs7O2NBQ1Asd0JBQUMsV0FBRDtLQUNFLFdBQVU7S0FDVixhQUFVO2VBRVQsWUFBWSxZQUNYO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXlCO01BQW9COzs7OztNQUMzRCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUEwQztRQUNoQyxNQUFNO1FBQVM7T0FDdEI7Ozs7OztNQUNILHdCQUFDLGdCQUFELENBQWlCOzs7OztNQUNqQix3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPO09BQ1gsV0FBVTtpQkFDWDtNQUVLOzs7OztLQUNOOzs7O2dCQUVGLGdEQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUF5QjtLQUFlOzs7O2VBQ3RELHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFnQjtNQUFjOzs7O2dCQUM1Qyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBc0M7TUFHaEQ7Ozs7Y0FDQTs7OztnQkFDTCx3QkFBQyxhQUFELENBQWM7Ozs7Y0FDWDs7Ozs7YUFDTDs7Ozs7SUFFRzs7OztZQUNOOzs7Ozs7RUFDRDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VBdXRoJztcclxuaW1wb3J0IHsgQWNjb3VudERldGFpbHMgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9BY2NvdW50RGV0YWlscyc7XHJcbmltcG9ydCB7IFRoZW1lVG9nZ2xlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vVGhlbWVUb2dnbGUnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyBjb21tZXJjZVRleHQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9jb21tZXJjZVRleHQnO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9maWxlUGFnZSgpIHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbc2VjdGlvbiwgc2V0U2VjdGlvbl0gPSB1c2VTdGF0ZTwnZGV0YWlscycgfCAncHJlZmVyZW5jZXMnPignZGV0YWlscycpO1xyXG4gIGNvbnN0IGN1c3RvbWVyID0gdXNlcj8ucm9sZSA9PT0gJ0NVU1RPTUVSJztcclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1bMTIwMHB4XSBweC00IHB5LTggc206cHgtNiBsZzpweC04XCI+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlXCI+WW91ciBhY2NvdW50PC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgQSBsaXR0bGUgc3BhY2UgZm9yIGV2ZXJ5dGhpbmcgdGhhdOKAmXMgeW91cnMuXHJcbiAgICAgIDwvcD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCBncmlkIGl0ZW1zLXN0YXJ0IGdhcC02IG1kOmdyaWQtY29scy1bMjQwcHhfbWlubWF4KDAsMWZyKV1cIj5cclxuICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgYm9yZGVyLWIgYm9yZGVyLWxpbmUtc3VidGxlIHB4LTIgcGItNVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0zIGZsZXggaC0xNCB3LTE0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeS1zdWJ0bGUgZm9udC1kaXNwbGF5IHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnLWxpbmtcIj5cclxuICAgICAgICAgICAgICB7dXNlcj8udXNlcm5hbWUuc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e3VzZXI/LnVzZXJuYW1lfTwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSBicmVhay1hbGwgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAge3VzZXI/LmVtYWlsfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIkFjY291bnQgc2VjdGlvbnNcIiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFjY291bnQtc2VjdGlvbiAke3NlY3Rpb24gPT09ICdkZXRhaWxzJyA/ICdpcy1hY3RpdmUnIDogJyd9YH1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWN0aW9uKCdkZXRhaWxzJyl9XHJcbiAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtzZWN0aW9uID09PSAnZGV0YWlscyd9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwidXNlclwiIC8+XHJcbiAgICAgICAgICAgICAgUGVyc29uYWwgZGV0YWlsc1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAge2N1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYWNjb3VudC1zZWN0aW9uXCIgdG89e1JPVVRFUy5vcmRlcnN9PlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwib3JkZXJzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgWW91ciBvcmRlcnNcclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImFjY291bnQtc2VjdGlvblwiIHRvPXtST1VURVMubG95YWx0eX0+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJiYWdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICB7Y29tbWVyY2VUZXh0LmxveWFsdHl9XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJhY2NvdW50LXNlY3Rpb25cIiB0bz17Uk9VVEVTLnJlcGFpcnN9PlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwicmVwYWlyXCIgLz5cclxuICAgICAgICAgICAgICAgICAgWW91ciByZXBhaXJzXHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJhY2NvdW50LXNlY3Rpb25cIiB0bz17Uk9VVEVTLmxpdmVDaGF0fT5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImNoYXRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBMaXZlIHN1cHBvcnRcclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgeyFjdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY291bnQtc2VjdGlvblwiXHJcbiAgICAgICAgICAgICAgICB0bz17dXNlcj8ucm9sZSA9PT0gJ0FETUlOJyA/IFJPVVRFUy5hZG1pbiA6IFJPVVRFUy5yZXBhaXJlcn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiZ3JpZFwiIC8+XHJcbiAgICAgICAgICAgICAgICBZb3VyIHdvcmtzcGFjZVxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFjY291bnQtc2VjdGlvbiAke3NlY3Rpb24gPT09ICdwcmVmZXJlbmNlcycgPyAnaXMtYWN0aXZlJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VjdGlvbigncHJlZmVyZW5jZXMnKX1cclxuICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e3NlY3Rpb24gPT09ICdwcmVmZXJlbmNlcyd9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiZmlsdGVyXCIgLz5cclxuICAgICAgICAgICAgICBQcmVmZXJlbmNlc1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC02IHNtOnAtOFwiXHJcbiAgICAgICAgICBhcmlhLWxpdmU9XCJwb2xpdGVcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzZWN0aW9uID09PSAnZGV0YWlscycgPyAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5QZXJzb25hbCBkZXRhaWxzPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgSGVsbG8sIHt1c2VyPy51c2VybmFtZX0uIEhlcmUgYXJlIHlvdXIgYWNjb3VudCBkZXRhaWxzLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8QWNjb3VudERldGFpbHMgLz5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89e1JPVVRFUy5wcm9kdWN0c31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29udGludWUgc2hvcHBpbmdcclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlByZWZlcmVuY2VzPC9oMj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC02IGJvcmRlci10IGJvcmRlci1saW5lLXN1YnRsZSBwdC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkFwcGVhcmFuY2U8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIG1heC13LXhzIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENob29zZSB5b3VyIHRoZW1lLCBvciBsZXQgaXQgZm9sbG93IHlvdXIgZGV2aWNlLiBZb3VyIGNob2ljZVxyXG4gICAgICAgICAgICAgICAgICAgIGlzIHNhdmVkIG9uIHRoaXMgYnJvd3Nlci5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8VGhlbWVUb2dnbGUgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXX0=