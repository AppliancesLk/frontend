import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Home/components/HomeCategorySection.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { formatCategoryName } from "/src/utils/category.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeCategorySection.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.storefront;
export function HomeCategorySection({ categories }) {
	_s();
	const scrollRef = useRef(null);
	const [hasOverflow, setHasOverflow] = useState(false);
	const topLevelCategories = categories.filter((category) => !category.parent);
	useEffect(() => {
		const element = scrollRef.current;
		if (!element) return;
		const updateOverflow = () => {
			setHasOverflow(element.scrollWidth > element.clientWidth + 1);
		};
		updateOverflow();
		const observer = new ResizeObserver(updateOverflow);
		observer.observe(element);
		return () => observer.disconnect();
	}, [topLevelCategories.length]);
	if (!topLevelCategories.length) return null;
	function scrollCategories(direction) {
		const element = scrollRef.current;
		if (!element) return;
		element.scrollBy({
			left: direction * element.clientWidth * .75,
			behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"
		});
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "home-categories-heading",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-end justify-between gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				id: "home-categories-heading",
				className: "text-2xl font-semibold tracking-tight text-fg",
				children: t.categories
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-muted",
				children: t.categoryDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 9
			}, this), hasOverflow && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex shrink-0 items-center gap-1",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					"aria-label": t.previousCategory,
					onClick: () => scrollCategories(-1),
					className: "flex min-h-11 w-11 items-center justify-center rounded-sm border border-line bg-surface text-fg-secondary hover:bg-page",
					children: /* @__PURE__ */ _jsxDEV(Icon, {
						name: "arrow",
						className: "h-4 w-4 rotate-180"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					"aria-label": t.nextCategory,
					onClick: () => scrollCategories(1),
					className: "flex min-h-11 w-11 items-center justify-center rounded-sm border border-line bg-surface text-fg-secondary hover:bg-page",
					children: /* @__PURE__ */ _jsxDEV(Icon, {
						name: "arrow",
						className: "h-4 w-4"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			ref: scrollRef,
			tabIndex: 0,
			"aria-label": t.categories,
			className: "mt-6 flex gap-4 overflow-x-auto overscroll-x-contain py-2",
			children: topLevelCategories.map((category) => /* @__PURE__ */ _jsxDEV(Link, {
				to: `${ROUTES.products}?category=${encodeURIComponent(category.categoryID)}`,
				className: "group flex w-28 shrink-0 flex-col items-center gap-3 rounded-sm text-center sm:w-36",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "flex aspect-square w-full items-center justify-center overflow-hidden rounded-full border border-line-subtle bg-primary-subtle text-fg-link shadow-sm transition-colors group-hover:border-primary group-focus-visible:border-primary",
					children: category.imageUrl ? /* @__PURE__ */ _jsxDEV(ProductImage, {
						src: category.imageUrl,
						alt: "",
						className: "h-full w-full object-cover!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV(Icon, {
						name: "grid",
						className: "h-10 w-10 sm:h-12 sm:w-12"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "w-full break-words text-sm font-semibold leading-5 text-fg",
					children: formatCategoryName(category.name)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 13
				}, this)]
			}, category.categoryID, true, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_s(HomeCategorySection, "DsUgbW24WG43qZve/B+bLN8mnE0=");
_c = HomeCategorySection;
var _c;
$RefreshReg$(_c, "HomeCategorySection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Home/components/HomeCategorySection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeCategorySection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeCategorySection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeCategorySection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsWUFBWTtBQUNyQixTQUFTLGNBQWM7QUFDdkIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsb0JBQW9CO0FBRTdCLFNBQVMsb0JBQW9COzs7O0FBRTdCLE1BQU0sSUFBSSxhQUFhO0FBRXZCLE9BQU8sU0FBUyxvQkFBb0IsRUFDbEMsY0FHQzs7Q0FDRCxNQUFNLFlBQVksT0FBdUIsSUFBSTtDQUM3QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0scUJBQXFCLFdBQVcsUUFBUSxhQUFhLENBQUMsU0FBUyxNQUFNO0NBRTNFLGdCQUFnQjtFQUNkLE1BQU0sVUFBVSxVQUFVO0VBQzFCLElBQUksQ0FBQyxTQUFTO0VBRWQsTUFBTSx1QkFBdUI7R0FDM0IsZUFBZSxRQUFRLGNBQWMsUUFBUSxjQUFjLENBQUM7RUFDOUQ7RUFDQSxlQUFlO0VBQ2YsTUFBTSxXQUFXLElBQUksZUFBZSxjQUFjO0VBQ2xELFNBQVMsUUFBUSxPQUFPO0VBQ3hCLGFBQWEsU0FBUyxXQUFXO0NBQ25DLEdBQUcsQ0FBQyxtQkFBbUIsTUFBTSxDQUFDO0NBRTlCLElBQUksQ0FBQyxtQkFBbUIsUUFBUSxPQUFPO0NBRXZDLFNBQVMsaUJBQWlCLFdBQW1CO0VBQzNDLE1BQU0sVUFBVSxVQUFVO0VBQzFCLElBQUksQ0FBQyxTQUFTO0VBQ2QsUUFBUSxTQUFTO0dBQ2YsTUFBTSxZQUFZLFFBQVEsY0FBYztHQUN4QyxVQUFVLE9BQU8sV0FBVyxrQ0FBa0MsQ0FBQyxDQUFDLFVBQzVELFNBQ0E7RUFDTixDQUFDO0NBQ0g7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxtQkFBZ0I7WUFBekIsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7SUFDRSxJQUFHO0lBQ0gsV0FBVTtjQUVULEVBQUU7R0FDRDs7OzthQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQThCLEVBQUU7R0FBdUI7Ozs7V0FDakU7Ozs7YUFDSixlQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGNBQVksRUFBRTtLQUNkLGVBQWUsaUJBQWlCLENBQUMsQ0FBQztLQUNsQyxXQUFVO2VBRVYsd0JBQUMsTUFBRDtNQUFNLE1BQUs7TUFBUSxXQUFVO0tBQXNCOzs7OztJQUM3Qzs7OztjQUNSLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsY0FBWSxFQUFFO0tBQ2QsZUFBZSxpQkFBaUIsQ0FBQztLQUNqQyxXQUFVO2VBRVYsd0JBQUMsTUFBRDtNQUFNLE1BQUs7TUFBUSxXQUFVO0tBQVc7Ozs7O0lBQ2xDOzs7O1lBQ0w7Ozs7O1dBRUo7Ozs7O1lBQ0wsd0JBQUMsT0FBRDtHQUNFLEtBQUs7R0FDTCxVQUFVO0dBQ1YsY0FBWSxFQUFFO0dBQ2QsV0FBVTthQUVULG1CQUFtQixLQUFLLGFBQ3ZCLHdCQUFDLE1BQUQ7SUFFRSxJQUFJLEdBQUcsT0FBTyxTQUFTLFlBQVksbUJBQW1CLFNBQVMsVUFBVTtJQUN6RSxXQUFVO2NBSFosQ0FLRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNiLFNBQVMsV0FDUix3QkFBQyxjQUFEO01BQ0UsS0FBSyxTQUFTO01BQ2QsS0FBSTtNQUNKLFdBQVU7S0FDWDs7OztnQkFFRCx3QkFBQyxNQUFEO01BQU0sTUFBSztNQUFPLFdBQVU7S0FBNkI7Ozs7O0lBRXZEOzs7O2NBQ04sd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDYixtQkFBbUIsU0FBUyxJQUFJO0lBQzdCOzs7O1lBQ0Y7TUFsQkMsU0FBUzs7OztVQWtCVixDQUNQO0VBQ0U7Ozs7VUFDRTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZUNhdGVnb3J5U2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZm9ybWF0Q2F0ZWdvcnlOYW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvY2F0ZWdvcnknO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9JY29uJztcclxuaW1wb3J0IHsgUHJvZHVjdEltYWdlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJvZHVjdEltYWdlJztcclxuaW1wb3J0IHR5cGUgeyBDYXRlZ29yeSB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL2NhdGVnb3J5LnR5cGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuXHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuc3RvcmVmcm9udDtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBIb21lQ2F0ZWdvcnlTZWN0aW9uKHtcclxuICBjYXRlZ29yaWVzLFxyXG59OiB7XHJcbiAgY2F0ZWdvcmllczogQ2F0ZWdvcnlbXTtcclxufSkge1xyXG4gIGNvbnN0IHNjcm9sbFJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgW2hhc092ZXJmbG93LCBzZXRIYXNPdmVyZmxvd10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgdG9wTGV2ZWxDYXRlZ29yaWVzID0gY2F0ZWdvcmllcy5maWx0ZXIoKGNhdGVnb3J5KSA9PiAhY2F0ZWdvcnkucGFyZW50KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGVsZW1lbnQgPSBzY3JvbGxSZWYuY3VycmVudDtcclxuICAgIGlmICghZWxlbWVudCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IHVwZGF0ZU92ZXJmbG93ID0gKCkgPT4ge1xyXG4gICAgICBzZXRIYXNPdmVyZmxvdyhlbGVtZW50LnNjcm9sbFdpZHRoID4gZWxlbWVudC5jbGllbnRXaWR0aCArIDEpO1xyXG4gICAgfTtcclxuICAgIHVwZGF0ZU92ZXJmbG93KCk7XHJcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcih1cGRhdGVPdmVyZmxvdyk7XHJcbiAgICBvYnNlcnZlci5vYnNlcnZlKGVsZW1lbnQpO1xyXG4gICAgcmV0dXJuICgpID0+IG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcclxuICB9LCBbdG9wTGV2ZWxDYXRlZ29yaWVzLmxlbmd0aF0pO1xyXG5cclxuICBpZiAoIXRvcExldmVsQ2F0ZWdvcmllcy5sZW5ndGgpIHJldHVybiBudWxsO1xyXG5cclxuICBmdW5jdGlvbiBzY3JvbGxDYXRlZ29yaWVzKGRpcmVjdGlvbjogLTEgfCAxKSB7XHJcbiAgICBjb25zdCBlbGVtZW50ID0gc2Nyb2xsUmVmLmN1cnJlbnQ7XHJcbiAgICBpZiAoIWVsZW1lbnQpIHJldHVybjtcclxuICAgIGVsZW1lbnQuc2Nyb2xsQnkoe1xyXG4gICAgICBsZWZ0OiBkaXJlY3Rpb24gKiBlbGVtZW50LmNsaWVudFdpZHRoICogMC43NSxcclxuICAgICAgYmVoYXZpb3I6IHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKScpLm1hdGNoZXNcclxuICAgICAgICA/ICdhdXRvJ1xyXG4gICAgICAgIDogJ3Ntb290aCcsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJob21lLWNhdGVnb3JpZXMtaGVhZGluZ1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDJcclxuICAgICAgICAgICAgaWQ9XCJob21lLWNhdGVnb3JpZXMtaGVhZGluZ1wiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mZ1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LmNhdGVnb3JpZXN9XHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5jYXRlZ29yeURlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7aGFzT3ZlcmZsb3cgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dC5wcmV2aW91c0NhdGVnb3J5fVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNjcm9sbENhdGVnb3JpZXMoLTEpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMTEgdy0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSB0ZXh0LWZnLXNlY29uZGFyeSBob3ZlcjpiZy1wYWdlXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzTmFtZT1cImgtNCB3LTQgcm90YXRlLTE4MFwiIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dC5uZXh0Q2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2Nyb2xsQ2F0ZWdvcmllcygxKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTExIHctMTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgdGV4dC1mZy1zZWNvbmRhcnkgaG92ZXI6YmctcGFnZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYXJyb3dcIiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIHJlZj17c2Nyb2xsUmVmfVxyXG4gICAgICAgIHRhYkluZGV4PXswfVxyXG4gICAgICAgIGFyaWEtbGFiZWw9e3QuY2F0ZWdvcmllc31cclxuICAgICAgICBjbGFzc05hbWU9XCJtdC02IGZsZXggZ2FwLTQgb3ZlcmZsb3cteC1hdXRvIG92ZXJzY3JvbGwteC1jb250YWluIHB5LTJcIlxyXG4gICAgICA+XHJcbiAgICAgICAge3RvcExldmVsQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICBrZXk9e2NhdGVnb3J5LmNhdGVnb3J5SUR9XHJcbiAgICAgICAgICAgIHRvPXtgJHtST1VURVMucHJvZHVjdHN9P2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5LmNhdGVnb3J5SUQpfWB9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGZsZXggdy0yOCBzaHJpbmstMCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1zbSB0ZXh0LWNlbnRlciBzbTp3LTM2XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBhc3BlY3Qtc3F1YXJlIHctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWxpbmUtc3VidGxlIGJnLXByaW1hcnktc3VidGxlIHRleHQtZmctbGluayBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnMgZ3JvdXAtaG92ZXI6Ym9yZGVyLXByaW1hcnkgZ3JvdXAtZm9jdXMtdmlzaWJsZTpib3JkZXItcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeS5pbWFnZVVybCA/IChcclxuICAgICAgICAgICAgICAgIDxQcm9kdWN0SW1hZ2VcclxuICAgICAgICAgICAgICAgICAgc3JjPXtjYXRlZ29yeS5pbWFnZVVybH1cclxuICAgICAgICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY292ZXIhXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJncmlkXCIgY2xhc3NOYW1lPVwiaC0xMCB3LTEwIHNtOmgtMTIgc206dy0xMlwiIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LWZ1bGwgYnJlYWstd29yZHMgdGV4dC1zbSBmb250LXNlbWlib2xkIGxlYWRpbmctNSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAge2Zvcm1hdENhdGVnb3J5TmFtZShjYXRlZ29yeS5uYW1lKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==