import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/feedback/ProductGridSkeleton.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Skeleton } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ProductGridSkeleton.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function ProductGridSkeleton({ count = 8 }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		"aria-label": "Loading products",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: "Loading products…"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 5,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-6 xl:grid-cols-4",
			children: Array.from({ length: count }, (_, index) => /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line-subtle bg-surface p-3",
				children: [
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mb-4 aspect-square w-full" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-3 w-1/3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-3 h-4 w-full" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-2 h-4 w-2/3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-5 h-5 w-3/4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-4 h-10 w-full" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 13
					}, this)
				]
			}, index, true, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 5
	}, this);
}
_c = ProductGridSkeleton;
var _c;
$RefreshReg$(_c, "ProductGridSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/feedback/ProductGridSkeleton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ProductGridSkeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ProductGridSkeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/ProductGridSkeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7OztBQUN6QixPQUFPLFNBQVMsb0JBQW9CLEVBQUUsUUFBUSxLQUF5QjtDQUNyRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxNQUFLO0VBQVMsY0FBVztZQUE5QixDQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQVU7RUFBdUI7Ozs7WUFDakQsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixNQUFNLEtBQUssRUFBRSxRQUFRLE1BQU0sSUFBSSxHQUFHLFVBQ2pDLHdCQUFDLE9BQUQ7SUFFRSxXQUFVO2NBRlo7S0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw0QkFBNkI7Ozs7O0tBQ2pELHdCQUFDLFVBQUQsRUFBVSxXQUFVLFlBQWE7Ozs7O0tBQ2pDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGtCQUFtQjs7Ozs7S0FDdkMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsaUJBQWtCOzs7OztLQUN0Qyx3QkFBQyxVQUFELEVBQVUsV0FBVSxpQkFBa0I7Ozs7O0tBQ3RDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLG1CQUFvQjs7Ozs7SUFDckM7TUFURTs7OztVQVNGLENBQ047RUFDRTs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0R3JpZFNrZWxldG9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJy4uL3VpL0ZlZWRiYWNrJztcclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RHcmlkU2tlbGV0b24oeyBjb3VudCA9IDggfTogeyBjb3VudD86IG51bWJlciB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgcm9sZT1cInN0YXR1c1wiIGFyaWEtbGFiZWw9XCJMb2FkaW5nIHByb2R1Y3RzXCI+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5Mb2FkaW5nIHByb2R1Y3Rz4oCmPC9zcGFuPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbWQ6Z3JpZC1jb2xzLTMgbWQ6Z2FwLTYgeGw6Z3JpZC1jb2xzLTRcIj5cclxuICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogY291bnQgfSwgKF8sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lLXN1YnRsZSBiZy1zdXJmYWNlIHAtM1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJtYi00IGFzcGVjdC1zcXVhcmUgdy1mdWxsXCIgLz5cclxuICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMyB3LTEvM1wiIC8+XHJcbiAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJtdC0zIGgtNCB3LWZ1bGxcIiAvPlxyXG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwibXQtMiBoLTQgdy0yLzNcIiAvPlxyXG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwibXQtNSBoLTUgdy0zLzRcIiAvPlxyXG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwibXQtNCBoLTEwIHctZnVsbFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==