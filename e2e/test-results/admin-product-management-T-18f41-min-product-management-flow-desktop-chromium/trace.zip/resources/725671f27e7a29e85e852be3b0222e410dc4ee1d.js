import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Orders/components/OrderDetails.tsx");const useRef = __vite__cjsImport8_react["useRef"]; const useState = __vite__cjsImport8_react["useState"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport15_react_jsxDevRuntime["Fragment"];import { RatingPlate } from "/src/components/common/RatingPlate.tsx";
import { CopyReference } from "/src/components/common/CopyReference.tsx";
import { OrderProgress } from "/src/components/ui/OrderProgress.tsx";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { formatDate } from "/src/utils/date.ts";
import { translations } from "/src/utils/translations.ts";
import { OrderStatusBadge } from "/src/pages/Customer/Orders/components/OrderStatusBadge.tsx";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { OrderTimeline } from "/src/components/common/OrderTimeline.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { cancelOrder } from "/src/services/orderService.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { commerceText as c } from "/src/utils/commerceText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderDetails.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.orders;
export function OrderDetails({ order, refresh }) {
	_s();
	const delivery = order.delivery;
	const [confirmCancel, setConfirmCancel] = useState(false);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState("");
	const working = useRef(false);
	const cancellable = order.status === "PENDING_PAYMENT" || order.status === "CONFIRMED" && order.paymentMethod === "CASH_ON_DELIVERY";
	async function cancel() {
		if (working.current) return;
		working.current = true;
		setBusy(true);
		setError("");
		try {
			await cancelOrder(order.id);
			setConfirmCancel(false);
			refresh();
		} catch (err) {
			setError(getApiError(err, c.cancelError));
		} finally {
			working.current = false;
			setBusy(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(RatingPlate, {
			title: `Order #${order.id.slice(0, 8).toUpperCase()}`,
			rows: [
				{
					label: "Order number",
					value: /* @__PURE__ */ _jsxDEV("span", {
						className: "flex items-center gap-2 break-all",
						children: [order.id, /* @__PURE__ */ _jsxDEV(CopyReference, { value: order.id }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 15
					}, this)
				},
				{
					label: "Placed",
					value: /* @__PURE__ */ _jsxDEV("time", {
						dateTime: order.createdAt,
						children: formatDate(order.createdAt)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 15
					}, this)
				},
				{
					label: "Status",
					value: /* @__PURE__ */ _jsxDEV(OrderStatusBadge, { status: order.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 20
					}, this)
				},
				{
					label: "Total",
					value: formatCurrency(order.total)
				}
			]
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(OrderProgress, {
			status: order.status,
			paymentMethod: order.paymentMethod
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 7
		}, this),
		!["DELIVERED", "CANCELLED"].includes(order.status) && /* @__PURE__ */ _jsxDEV("p", {
			className: "text-sm text-fg-muted",
			children: c.tracking
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(OrderTimeline, { history: order.history }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "ui-panel flex flex-wrap items-center justify-between gap-4 p-5",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-2 text-sm",
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: [
						c.method,
						":",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: order.paymentMethod === "CASH_ON_DELIVERY" ? c.cod : order.paymentMethod === "LOYALTY" ? c.loyalty : c.payHere }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 11
					}, this),
					order.paymentMethod === "CASH_ON_DELIVERY" && order.status !== "CANCELLED" && /* @__PURE__ */ _jsxDEV("p", { children: [
						order.status === "DELIVERED" ? c.paid : c.cashDue,
						":",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: formatCurrency(order.total) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 17
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						c.earned,
						":",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: formatCurrency(order.loyaltyEarned ?? "0.00") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 9
			}, this), cancellable && /* @__PURE__ */ _jsxDEV(Button, {
				variant: "secondary",
				onClick: () => setConfirmCancel(true),
				children: c.cancelOrder
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Dialog, {
			open: confirmCancel,
			onClose: () => setConfirmCancel(false),
			title: c.cancelOrder,
			description: c.cancelConfirm,
			busy,
			children: [error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "ui-alert ui-tone-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-5 flex flex-wrap justify-end gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Button, {
					variant: "secondary",
					disabled: busy,
					onClick: () => setConfirmCancel(false),
					children: "Keep order"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					variant: "danger",
					busy,
					onClick: () => void cancel(),
					children: c.cancelOrder
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 129,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "order-items",
				className: "min-w-0 rounded-md border border-line bg-surface ",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "order-items",
						className: "border-b border-line p-4 text-xl font-semibold text-fg sm:px-6",
						children: t.items
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("ul", {
						className: "divide-y divide-line",
						children: order.items.map((item) => /* @__PURE__ */ _jsxDEV("li", {
							className: "p-4 sm:p-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
									src: item.images[0],
									alt: item.name,
									className: "h-20 w-20 shrink-0 rounded-sm border border-line-subtle"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "break-words font-semibold text-fg",
										children: item.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 break-all text-xs text-fg-muted",
										children: item.SKU
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("dl", {
								className: "mt-4 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
										className: "text-fg-muted",
										children: translations.cart.quantity
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("dd", {
										className: "mt-1 text-fg",
										children: item.quantity
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
										className: "text-fg-muted",
										children: translations.cart.unitPrice
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("dd", {
										className: "mt-1 break-words text-fg",
										children: formatCurrency(item.unitPrice)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
										className: "text-fg-muted",
										children: translations.cart.lineTotal
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("dd", {
										className: "mt-1 break-words font-semibold text-fg",
										children: formatCurrency(item.lineTotal)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 17
							}, this)]
						}, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("dl", {
						className: "space-y-3 border-t border-line p-4 text-sm sm:p-6",
						children: [
							order.loyaltyRedeemed && order.loyaltyRedeemed !== "0.00" && /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap justify-between gap-2 text-success",
								children: [/* @__PURE__ */ _jsxDEV("dt", { children: c.creditUsed }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ["−", formatCurrency(order.loyaltyRedeemed)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap justify-between gap-2 text-fg-secondary",
								children: [/* @__PURE__ */ _jsxDEV("dt", { children: translations.cart.subtotal }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatCurrency(order.subtotal) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap justify-between gap-2 text-base font-semibold text-fg",
								children: [/* @__PURE__ */ _jsxDEV("dt", { children: t.total }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 210,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatCurrency(order.total) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "order-delivery",
				className: "min-w-0 rounded-md border border-line bg-surface p-4  sm:p-6",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "order-delivery",
					className: "text-xl font-semibold text-fg",
					children: t.delivery
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 11
				}, this), delivery ? /* @__PURE__ */ _jsxDEV("address", {
					className: "mt-4 space-y-2 break-words text-sm not-italic text-fg-secondary",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "font-medium text-fg",
							children: [
								delivery.firstName,
								" ",
								delivery.lastName
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: delivery.addressLine1 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 15
						}, this),
						delivery.addressLine2 && /* @__PURE__ */ _jsxDEV("p", { children: delivery.addressLine2 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 228,
							columnNumber: 41
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: [
							delivery.city,
							" ",
							delivery.postalCode
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: delivery.countryCode }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: delivery.phone }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: delivery.email }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 223,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-4 text-sm text-fg-muted",
					children: t.noDelivery
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 237,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
}
_s(OrderDetails, "Uoyn9E6lmcXtL8lOvtrCFZVexK0=");
_c = OrderDetails;
var _c;
$RefreshReg$(_c, "OrderDetails");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Orders/components/OrderDetails.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderDetails.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrderDetails.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFFOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxRQUFRLGdCQUFnQjtBQUNqQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsZ0JBQWdCLFNBQVM7Ozs7QUFDbEMsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGFBQWEsRUFDM0IsT0FDQSxXQUlDOztDQUNELE1BQU0sV0FBVyxNQUFNO0NBQ3ZCLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxVQUFVLE9BQU8sS0FBSztDQUM1QixNQUFNLGNBQ0osTUFBTSxXQUFXLHFCQUNoQixNQUFNLFdBQVcsZUFDaEIsTUFBTSxrQkFBa0I7Q0FDNUIsZUFBZSxTQUFTO0VBQ3RCLElBQUksUUFBUSxTQUFTO0VBQ3JCLFFBQVEsVUFBVTtFQUNsQixRQUFRLElBQUk7RUFDWixTQUFTLEVBQUU7RUFDWCxJQUFJO0dBQ0YsTUFBTSxZQUFZLE1BQU0sRUFBRTtHQUMxQixpQkFBaUIsS0FBSztHQUN0QixRQUFRO0VBQ1YsU0FBUyxLQUFLO0dBQ1osU0FBUyxZQUFZLEtBQUssRUFBRSxXQUFXLENBQUM7RUFDMUMsVUFBVTtHQUNSLFFBQVEsVUFBVTtHQUNsQixRQUFRLEtBQUs7RUFDZjtDQUNGO0NBQ0EsT0FDRTtFQUNFLHdCQUFDLGFBQUQ7R0FDRSxPQUFPLFVBQVUsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZO0dBQ2xELE1BQU07SUFDSjtLQUNFLE9BQU87S0FDUCxPQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNHLE1BQU0sSUFDUCx3QkFBQyxlQUFELEVBQWUsT0FBTyxNQUFNLEdBQUs7Ozs7Y0FDN0I7Ozs7OztJQUVWO0lBQ0E7S0FDRSxPQUFPO0tBQ1AsT0FDRSx3QkFBQyxRQUFEO01BQU0sVUFBVSxNQUFNO2dCQUNuQixXQUFXLE1BQU0sU0FBUztLQUN2Qjs7Ozs7SUFFVjtJQUNBO0tBQ0UsT0FBTztLQUNQLE9BQU8sd0JBQUMsa0JBQUQsRUFBa0IsUUFBUSxNQUFNLE9BQVM7Ozs7O0lBQ2xEO0lBQ0E7S0FBRSxPQUFPO0tBQVMsT0FBTyxlQUFlLE1BQU0sS0FBSztJQUFFO0dBQ3ZEO0VBQ0Q7Ozs7O0VBQ0Qsd0JBQUMsZUFBRDtHQUNFLFFBQVEsTUFBTTtHQUNkLGVBQWUsTUFBTTtFQUN0Qjs7Ozs7RUFDQSxDQUFDLENBQUMsYUFBYSxXQUFXLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFBTSxLQUNoRCx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUF5QixFQUFFO0VBQVk7Ozs7O0VBRXRELHdCQUFDLGVBQUQsRUFBZSxTQUFTLE1BQU0sUUFBVTs7Ozs7RUFDeEMsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkIsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsS0FBRDtNQUNHLEVBQUU7TUFBTztNQUFFO01BQ1osd0JBQUMsVUFBRCxZQUNHLE1BQU0sa0JBQWtCLHFCQUNyQixFQUFFLE1BQ0YsTUFBTSxrQkFBa0IsWUFDdEIsRUFBRSxVQUNGLEVBQUUsUUFDRjs7Ozs7S0FDUDs7Ozs7S0FDRixNQUFNLGtCQUFrQixzQkFDdkIsTUFBTSxXQUFXLGVBQ2Ysd0JBQUMsS0FBRDtNQUNHLE1BQU0sV0FBVyxjQUFjLEVBQUUsT0FBTyxFQUFFO01BQVE7TUFBRTtNQUNyRCx3QkFBQyxVQUFELFlBQVMsZUFBZSxNQUFNLEtBQUssRUFBVTs7Ozs7S0FDNUM7Ozs7O0tBRVAsd0JBQUMsS0FBRDtNQUNHLEVBQUU7TUFBTztNQUFFO01BQ1osd0JBQUMsVUFBRCxZQUFTLGVBQWUsTUFBTSxpQkFBaUIsTUFBTSxFQUFVOzs7OztLQUM5RDs7Ozs7SUFDQTs7Ozs7YUFDSixlQUNDLHdCQUFDLFFBQUQ7SUFBUSxTQUFRO0lBQVksZUFBZSxpQkFBaUIsSUFBSTtjQUM3RCxFQUFFO0dBQ0c7Ozs7V0FFSDs7Ozs7O0VBQ1Qsd0JBQUMsUUFBRDtHQUNFLE1BQU07R0FDTixlQUFlLGlCQUFpQixLQUFLO0dBQ3JDLE9BQU8sRUFBRTtHQUNULGFBQWEsRUFBRTtHQUNUO2FBTFIsQ0FPRyxTQUNDLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVEsV0FBVTtjQUN2QjtHQUNBOzs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FDRSxTQUFRO0tBQ1IsVUFBVTtLQUNWLGVBQWUsaUJBQWlCLEtBQUs7ZUFDdEM7SUFFTzs7OztjQUNSLHdCQUFDLFFBQUQ7S0FBUSxTQUFRO0tBQWU7S0FBTSxlQUFlLEtBQUssT0FBTztlQUM3RCxFQUFFO0lBQ0c7Ozs7WUFDTDs7Ozs7V0FDQzs7Ozs7O0VBQ1Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFdBQUQ7SUFDRSxtQkFBZ0I7SUFDaEIsV0FBVTtjQUZaO0tBSUUsd0JBQUMsTUFBRDtNQUNFLElBQUc7TUFDSCxXQUFVO2dCQUVULEVBQUU7S0FDRDs7Ozs7S0FDSix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxNQUFNLE1BQU0sS0FBSyxTQUNoQix3QkFBQyxNQUFEO09BQWtCLFdBQVU7aUJBQTVCLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxjQUFEO1NBQ0UsS0FBSyxLQUFLLE9BQU87U0FDakIsS0FBSyxLQUFLO1NBQ1YsV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsS0FBSztTQUNKOzs7O21CQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLEtBQUs7U0FDTDs7OztpQkFDQTs7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLGFBQWEsS0FBSztTQUNqQjs7OzttQkFDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZ0IsS0FBSztTQUFhOzs7O2lCQUM3Qzs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsYUFBYSxLQUFLO1NBQ2pCOzs7O21CQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLGVBQWUsS0FBSyxTQUFTO1NBQzVCOzs7O2lCQUNEOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxhQUFhLEtBQUs7U0FDakI7Ozs7bUJBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsZUFBZSxLQUFLLFNBQVM7U0FDNUI7Ozs7aUJBQ0Q7Ozs7O1FBQ0g7Ozs7O2VBQ0Y7U0F4Q0ssS0FBSzs7OzthQXdDVixDQUNMO0tBQ0M7Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FDRyxNQUFNLG1CQUFtQixNQUFNLG9CQUFvQixVQUNsRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSyxFQUFFLFdBQWU7Ozs7a0JBQ3RCLHdCQUFDLE1BQUQsYUFBSSxLQUFFLGVBQWUsTUFBTSxlQUFlLENBQU07Ozs7Z0JBQzdDOzs7Ozs7T0FFUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSyxhQUFhLEtBQUssU0FBYTs7OztrQkFDcEMsd0JBQUMsTUFBRCxZQUFLLGVBQWUsTUFBTSxRQUFRLEVBQU07Ozs7Z0JBQ3JDOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSyxFQUFFLE1BQVU7Ozs7a0JBQ2pCLHdCQUFDLE1BQUQsWUFBSyxlQUFlLE1BQU0sS0FBSyxFQUFNOzs7O2dCQUNsQzs7Ozs7O01BQ0g7Ozs7OztJQUNHOzs7OzthQUNULHdCQUFDLFdBQUQ7SUFDRSxtQkFBZ0I7SUFDaEIsV0FBVTtjQUZaLENBSUUsd0JBQUMsTUFBRDtLQUFJLElBQUc7S0FBaUIsV0FBVTtlQUMvQixFQUFFO0lBQ0Q7Ozs7Y0FDSCxXQUNDLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFDRyxTQUFTO1FBQVU7UUFBRSxTQUFTO09BQzlCOzs7Ozs7TUFDSCx3QkFBQyxLQUFELFlBQUksU0FBUyxhQUFnQjs7Ozs7TUFDNUIsU0FBUyxnQkFBZ0Isd0JBQUMsS0FBRCxZQUFJLFNBQVMsYUFBZ0I7Ozs7O01BQ3ZELHdCQUFDLEtBQUQ7T0FDRyxTQUFTO09BQUs7T0FBRSxTQUFTO01BQ3pCOzs7OztNQUNILHdCQUFDLEtBQUQsWUFBSSxTQUFTLFlBQWU7Ozs7O01BQzVCLHdCQUFDLEtBQUQsWUFBSSxTQUFTLE1BQVM7Ozs7O01BQ3RCLHdCQUFDLEtBQUQsWUFBSSxTQUFTLE1BQVM7Ozs7O0tBQ2Y7Ozs7O2VBRVQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEIsRUFBRTtJQUFjOzs7O1lBRXREOzs7OztXQUNOOzs7Ozs7Q0FDTDs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPcmRlckRldGFpbHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJhdGluZ1BsYXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmF0aW5nUGxhdGUnO1xyXG5pbXBvcnQgeyBDb3B5UmVmZXJlbmNlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vQ29weVJlZmVyZW5jZSc7XHJcbmltcG9ydCB7IE9yZGVyUHJvZ3Jlc3MgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL09yZGVyUHJvZ3Jlc3MnO1xyXG5pbXBvcnQgdHlwZSB7IE9yZGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvb3JkZXIudHlwZXMnO1xyXG5pbXBvcnQgeyBQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0SW1hZ2UnO1xyXG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGUnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBPcmRlclN0YXR1c0JhZGdlIH0gZnJvbSAnLi9PcmRlclN0YXR1c0JhZGdlJztcclxuaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgT3JkZXJUaW1lbGluZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL09yZGVyVGltZWxpbmUnO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0J1dHRvbic7XHJcbmltcG9ydCB7IERpYWxvZyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgY2FuY2VsT3JkZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9zZXJ2aWNlcy9vcmRlclNlcnZpY2UnO1xyXG5pbXBvcnQgeyBnZXRBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2FwaUVycm9ycyc7XHJcbmltcG9ydCB7IGNvbW1lcmNlVGV4dCBhcyBjIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvY29tbWVyY2VUZXh0JztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5vcmRlcnM7XHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlckRldGFpbHMoe1xyXG4gIG9yZGVyLFxyXG4gIHJlZnJlc2gsXHJcbn06IHtcclxuICBvcmRlcjogT3JkZXI7XHJcbiAgcmVmcmVzaDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IGRlbGl2ZXJ5ID0gb3JkZXIuZGVsaXZlcnk7XHJcbiAgY29uc3QgW2NvbmZpcm1DYW5jZWwsIHNldENvbmZpcm1DYW5jZWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCB3b3JraW5nID0gdXNlUmVmKGZhbHNlKTtcclxuICBjb25zdCBjYW5jZWxsYWJsZSA9XHJcbiAgICBvcmRlci5zdGF0dXMgPT09ICdQRU5ESU5HX1BBWU1FTlQnIHx8XHJcbiAgICAob3JkZXIuc3RhdHVzID09PSAnQ09ORklSTUVEJyAmJlxyXG4gICAgICBvcmRlci5wYXltZW50TWV0aG9kID09PSAnQ0FTSF9PTl9ERUxJVkVSWScpO1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGNhbmNlbCgpIHtcclxuICAgIGlmICh3b3JraW5nLmN1cnJlbnQpIHJldHVybjtcclxuICAgIHdvcmtpbmcuY3VycmVudCA9IHRydWU7XHJcbiAgICBzZXRCdXN5KHRydWUpO1xyXG4gICAgc2V0RXJyb3IoJycpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgY2FuY2VsT3JkZXIob3JkZXIuaWQpO1xyXG4gICAgICBzZXRDb25maXJtQ2FuY2VsKGZhbHNlKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKGdldEFwaUVycm9yKGVyciwgYy5jYW5jZWxFcnJvcikpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgd29ya2luZy5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPFJhdGluZ1BsYXRlXHJcbiAgICAgICAgdGl0bGU9e2BPcmRlciAjJHtvcmRlci5pZC5zbGljZSgwLCA4KS50b1VwcGVyQ2FzZSgpfWB9XHJcbiAgICAgICAgcm93cz17W1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogJ09yZGVyIG51bWJlcicsXHJcbiAgICAgICAgICAgIHZhbHVlOiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYnJlYWstYWxsXCI+XHJcbiAgICAgICAgICAgICAgICB7b3JkZXIuaWR9XHJcbiAgICAgICAgICAgICAgICA8Q29weVJlZmVyZW5jZSB2YWx1ZT17b3JkZXIuaWR9IC8+XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6ICdQbGFjZWQnLFxyXG4gICAgICAgICAgICB2YWx1ZTogKFxyXG4gICAgICAgICAgICAgIDx0aW1lIGRhdGVUaW1lPXtvcmRlci5jcmVhdGVkQXR9PlxyXG4gICAgICAgICAgICAgICAge2Zvcm1hdERhdGUob3JkZXIuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICA8L3RpbWU+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogJ1N0YXR1cycsXHJcbiAgICAgICAgICAgIHZhbHVlOiA8T3JkZXJTdGF0dXNCYWRnZSBzdGF0dXM9e29yZGVyLnN0YXR1c30gLz4sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogJ1RvdGFsJywgdmFsdWU6IGZvcm1hdEN1cnJlbmN5KG9yZGVyLnRvdGFsKSB9LFxyXG4gICAgICAgIF19XHJcbiAgICAgIC8+XHJcbiAgICAgIDxPcmRlclByb2dyZXNzXHJcbiAgICAgICAgc3RhdHVzPXtvcmRlci5zdGF0dXN9XHJcbiAgICAgICAgcGF5bWVudE1ldGhvZD17b3JkZXIucGF5bWVudE1ldGhvZH1cclxuICAgICAgLz5cclxuICAgICAgeyFbJ0RFTElWRVJFRCcsICdDQU5DRUxMRUQnXS5pbmNsdWRlcyhvcmRlci5zdGF0dXMpICYmIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57Yy50cmFja2luZ308L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIDxPcmRlclRpbWVsaW5lIGhpc3Rvcnk9e29yZGVyLmhpc3Rvcnl9IC8+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInVpLXBhbmVsIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcC01XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgIHtjLm1ldGhvZH06eycgJ31cclxuICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICB7b3JkZXIucGF5bWVudE1ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknXHJcbiAgICAgICAgICAgICAgICA/IGMuY29kXHJcbiAgICAgICAgICAgICAgICA6IG9yZGVyLnBheW1lbnRNZXRob2QgPT09ICdMT1lBTFRZJ1xyXG4gICAgICAgICAgICAgICAgICA/IGMubG95YWx0eVxyXG4gICAgICAgICAgICAgICAgICA6IGMucGF5SGVyZX1cclxuICAgICAgICAgICAgPC9zdHJvbmc+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICB7b3JkZXIucGF5bWVudE1ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknICYmXHJcbiAgICAgICAgICAgIG9yZGVyLnN0YXR1cyAhPT0gJ0NBTkNFTExFRCcgJiYgKFxyXG4gICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAge29yZGVyLnN0YXR1cyA9PT0gJ0RFTElWRVJFRCcgPyBjLnBhaWQgOiBjLmNhc2hEdWV9OnsnICd9XHJcbiAgICAgICAgICAgICAgICA8c3Ryb25nPntmb3JtYXRDdXJyZW5jeShvcmRlci50b3RhbCl9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgIHtjLmVhcm5lZH06eycgJ31cclxuICAgICAgICAgICAgPHN0cm9uZz57Zm9ybWF0Q3VycmVuY3kob3JkZXIubG95YWx0eUVhcm5lZCA/PyAnMC4wMCcpfTwvc3Ryb25nPlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtjYW5jZWxsYWJsZSAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtQ2FuY2VsKHRydWUpfT5cclxuICAgICAgICAgICAge2MuY2FuY2VsT3JkZXJ9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDxEaWFsb2dcclxuICAgICAgICBvcGVuPXtjb25maXJtQ2FuY2VsfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldENvbmZpcm1DYW5jZWwoZmFsc2UpfVxyXG4gICAgICAgIHRpdGxlPXtjLmNhbmNlbE9yZGVyfVxyXG4gICAgICAgIGRlc2NyaXB0aW9uPXtjLmNhbmNlbENvbmZpcm19XHJcbiAgICAgICAgYnVzeT17YnVzeX1cclxuICAgICAgPlxyXG4gICAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ1aS1hbGVydCB1aS10b25lLWRhbmdlclwiPlxyXG4gICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgZmxleCBmbGV4LXdyYXAganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtQ2FuY2VsKGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgS2VlcCBvcmRlclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYW5nZXJcIiBidXN5PXtidXN5fSBvbkNsaWNrPXsoKSA9PiB2b2lkIGNhbmNlbCgpfT5cclxuICAgICAgICAgICAge2MuY2FuY2VsT3JkZXJ9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EaWFsb2c+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNiBsZzpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfMjJyZW1dXCI+XHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cIm9yZGVyLWl0ZW1zXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTAgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxoMlxyXG4gICAgICAgICAgICBpZD1cIm9yZGVyLWl0ZW1zXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWxpbmUgcC00IHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnIHNtOnB4LTZcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dC5pdGVtc31cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLWxpbmVcIj5cclxuICAgICAgICAgICAge29yZGVyLml0ZW1zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0uaWR9IGNsYXNzTmFtZT1cInAtNCBzbTpwLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8UHJvZHVjdEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgc3JjPXtpdGVtLmltYWdlc1swXX1cclxuICAgICAgICAgICAgICAgICAgICBhbHQ9e2l0ZW0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTIwIHctMjAgc2hyaW5rLTAgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUtc3VidGxlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJicmVhay13b3JkcyBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIGJyZWFrLWFsbCB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLlNLVX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdyaWQtY29scy0yIGdhcC00IHRleHQtc20gc206Z3JpZC1jb2xzLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jYXJ0LnF1YW50aXR5fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1mZ1wiPntpdGVtLnF1YW50aXR5fTwvZGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmNhcnQudW5pdFByaWNlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgYnJlYWstd29yZHMgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGl0ZW0udW5pdFByaWNlKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5jYXJ0LmxpbmVUb3RhbH1cclxuICAgICAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIGJyZWFrLXdvcmRzIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGl0ZW0ubGluZVRvdGFsKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cInNwYWNlLXktMyBib3JkZXItdCBib3JkZXItbGluZSBwLTQgdGV4dC1zbSBzbTpwLTZcIj5cclxuICAgICAgICAgICAge29yZGVyLmxveWFsdHlSZWRlZW1lZCAmJiBvcmRlci5sb3lhbHR5UmVkZWVtZWQgIT09ICcwLjAwJyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC1zdWNjZXNzXCI+XHJcbiAgICAgICAgICAgICAgICA8ZHQ+e2MuY3JlZGl0VXNlZH08L2R0PlxyXG4gICAgICAgICAgICAgICAgPGRkPuKIkntmb3JtYXRDdXJyZW5jeShvcmRlci5sb3lhbHR5UmVkZWVtZWQpfTwvZGQ+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAganVzdGlmeS1iZXR3ZWVuIGdhcC0yIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgPGR0Pnt0cmFuc2xhdGlvbnMuY2FydC5zdWJ0b3RhbH08L2R0PlxyXG4gICAgICAgICAgICAgIDxkZD57Zm9ybWF0Q3VycmVuY3kob3JkZXIuc3VidG90YWwpfTwvZGQ+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktYmV0d2VlbiBnYXAtMiB0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgPGR0Pnt0LnRvdGFsfTwvZHQ+XHJcbiAgICAgICAgICAgICAgPGRkPntmb3JtYXRDdXJyZW5jeShvcmRlci50b3RhbCl9PC9kZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2RsPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8c2VjdGlvblxyXG4gICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwib3JkZXItZGVsaXZlcnlcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctMCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNCAgc206cC02XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8aDIgaWQ9XCJvcmRlci1kZWxpdmVyeVwiIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgIHt0LmRlbGl2ZXJ5fVxyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIHtkZWxpdmVyeSA/IChcclxuICAgICAgICAgICAgPGFkZHJlc3MgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTIgYnJlYWstd29yZHMgdGV4dC1zbSBub3QtaXRhbGljIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge2RlbGl2ZXJ5LmZpcnN0TmFtZX0ge2RlbGl2ZXJ5Lmxhc3ROYW1lfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cD57ZGVsaXZlcnkuYWRkcmVzc0xpbmUxfTwvcD5cclxuICAgICAgICAgICAgICB7ZGVsaXZlcnkuYWRkcmVzc0xpbmUyICYmIDxwPntkZWxpdmVyeS5hZGRyZXNzTGluZTJ9PC9wPn1cclxuICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgIHtkZWxpdmVyeS5jaXR5fSB7ZGVsaXZlcnkucG9zdGFsQ29kZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHA+e2RlbGl2ZXJ5LmNvdW50cnlDb2RlfTwvcD5cclxuICAgICAgICAgICAgICA8cD57ZGVsaXZlcnkucGhvbmV9PC9wPlxyXG4gICAgICAgICAgICAgIDxwPntkZWxpdmVyeS5lbWFpbH08L3A+XHJcbiAgICAgICAgICAgIDwvYWRkcmVzcz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3Qubm9EZWxpdmVyeX08L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdfQ==