import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/ProtectedRoute.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/auth/ProtectedRoute.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function ProtectedRoute({ roles, children }) {
	_s();
	const { user, loading, error, refresh } = useAuth();
	const location = useLocation();
	if (loading) return /* @__PURE__ */ _jsxDEV(LoadingState, {
		label: translations.auth.checkingSession,
		compact: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 7
	}, this);
	if (error) return /* @__PURE__ */ _jsxDEV("div", {
		role: "alert",
		className: "mx-auto max-w-xl p-10",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			className: "auth-primary mt-4",
			onClick: () => void refresh(),
			children: translations.common.retry
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 7
	}, this);
	if (!user) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: ROUTES.login,
		state: { from: location.pathname + location.search },
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 7
	}, this);
	if (roles && !roles.includes(user.role)) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: ROUTES.forbidden,
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 12
	}, this);
	return children ?? /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 22
	}, this);
}
_s(ProtectedRoute, "aPpnAmJhdKmz/2dDFIjDvUJo5UQ=", false, function() {
	return [useAuth, useLocation];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/ProtectedRoute.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/auth/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/auth/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/auth/ProtectedRoute.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBRTdCLFNBQVMsVUFBVSxRQUFRLG1CQUFtQjtBQUM5QyxTQUFTLGVBQWU7Ozs7QUFHeEIsT0FBTyxTQUFTLGVBQWUsRUFDN0IsT0FDQSxZQUlDOztDQUNELE1BQU0sRUFBRSxNQUFNLFNBQVMsT0FBTyxZQUFZLFFBQVE7Q0FDbEQsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsSUFBSSxTQUNGLE9BQ0Usd0JBQUMsY0FBRDtFQUFjLE9BQU8sYUFBYSxLQUFLO0VBQWlCLFNBQVM7Q0FBTzs7Ozs7Q0FFNUUsSUFBSSxPQUNGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLE1BQUs7RUFBUSxXQUFVO1lBQTVCLENBQ0Usd0JBQUMsS0FBRCxZQUFJLE1BQVM7Ozs7WUFDYix3QkFBQyxVQUFEO0dBQVEsV0FBVTtHQUFvQixlQUFlLEtBQUssUUFBUTthQUMvRCxhQUFhLE9BQU87RUFDZjs7OztVQUNMOzs7Ozs7Q0FFVCxJQUFJLENBQUMsTUFDSCxPQUNFLHdCQUFDLFVBQUQ7RUFDRSxJQUFJLE9BQU87RUFDWCxPQUFPLEVBQUUsTUFBTSxTQUFTLFdBQVcsU0FBUyxPQUFPO0VBQ25EO0NBQ0Q7Ozs7O0NBRUwsSUFBSSxTQUFTLENBQUMsTUFBTSxTQUFTLEtBQUssSUFBSSxHQUNwQyxPQUFPLHdCQUFDLFVBQUQ7RUFBVSxJQUFJLE9BQU87RUFBVztDQUFTOzs7OztDQUNsRCxPQUFPLFlBQVksd0JBQUMsUUFBRCxDQUFTOzs7OztBQUM5QiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm90ZWN0ZWRSb3V0ZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vdWkvRmVlZGJhY2snO1xuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOYXZpZ2F0ZSwgT3V0bGV0LCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xuaW1wb3J0IHR5cGUgeyBVc2VyUm9sZSB9IGZyb20gJy4uLy4uL3R5cGVzL2F1dGgudHlwZXMnO1xuXG5leHBvcnQgZnVuY3Rpb24gUHJvdGVjdGVkUm91dGUoe1xuICByb2xlcyxcbiAgY2hpbGRyZW4sXG59OiB7XG4gIHJvbGVzPzogVXNlclJvbGVbXTtcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59KSB7XG4gIGNvbnN0IHsgdXNlciwgbG9hZGluZywgZXJyb3IsIHJlZnJlc2ggfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICBpZiAobG9hZGluZylcbiAgICByZXR1cm4gKFxuICAgICAgPExvYWRpbmdTdGF0ZSBsYWJlbD17dHJhbnNsYXRpb25zLmF1dGguY2hlY2tpbmdTZXNzaW9ufSBjb21wYWN0PXt0cnVlfSAvPlxuICAgICk7XG4gIGlmIChlcnJvcilcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LXhsIHAtMTBcIj5cbiAgICAgICAgPHA+e2Vycm9yfTwvcD5cbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnkgbXQtNFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgcmVmcmVzaCgpfT5cbiAgICAgICAgICB7dHJhbnNsYXRpb25zLmNvbW1vbi5yZXRyeX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICBpZiAoIXVzZXIpXG4gICAgcmV0dXJuIChcbiAgICAgIDxOYXZpZ2F0ZVxuICAgICAgICB0bz17Uk9VVEVTLmxvZ2lufVxuICAgICAgICBzdGF0ZT17eyBmcm9tOiBsb2NhdGlvbi5wYXRobmFtZSArIGxvY2F0aW9uLnNlYXJjaCB9fVxuICAgICAgICByZXBsYWNlXG4gICAgICAvPlxuICAgICk7XG4gIGlmIChyb2xlcyAmJiAhcm9sZXMuaW5jbHVkZXModXNlci5yb2xlKSlcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPXtST1VURVMuZm9yYmlkZGVufSByZXBsYWNlIC8+O1xuICByZXR1cm4gY2hpbGRyZW4gPz8gPE91dGxldCAvPjtcbn1cbiJdfQ==