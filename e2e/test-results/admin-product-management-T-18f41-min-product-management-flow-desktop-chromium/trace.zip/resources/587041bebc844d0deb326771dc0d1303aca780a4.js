import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Orders/index.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { useAuth } from "/src/hooks/useAuth.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { useOrdersPage } from "/src/pages/Customer/Orders/hooks/useOrdersPage.ts";
import { OrdersShell } from "/src/pages/Customer/Orders/components/OrdersShell.tsx";
import { OrderList } from "/src/pages/Customer/Orders/components/OrderList.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export default function OrdersPage() {
	_s();
	const { user } = useAuth();
	return user ? /* @__PURE__ */ _jsxDEV(OrdersContent, {}, user.id, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 17
	}, this) : null;
}
_s(OrdersPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = OrdersPage;
function OrdersContent() {
	_s2();
	const page = useOrdersPage();
	return /* @__PURE__ */ _jsxDEV(OrdersShell, {
		refresh: page.refresh,
		loading: page.loading,
		children: [/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
			loading: page.loading,
			error: page.error,
			retry: page.refresh
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this), !page.loading && !page.error && /* @__PURE__ */ _jsxDEV(OrderList, { orders: page.data }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 40
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s2(OrdersContent, "1YbIMycOVZtF0WErg5hZHU8BUcg=", false, function() {
	return [useOrdersPage];
});
_c2 = OrdersContent;
var _c, _c2;
$RefreshReg$(_c, "OrdersPage");
$RefreshReg$(_c2, "OrdersContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Orders/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsaUJBQWlCOzs7O0FBQzFCLGVBQWUsU0FBUyxhQUFhOztDQUNuQyxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE9BQU8sT0FBTyx3QkFBQyxlQUFELENBQThCLEdBQVYsS0FBSzs7OztRQUFLLElBQUk7QUFDbEQ7Ozs7O0FBQ0EsU0FBUyxnQkFBZ0I7O0NBQ3ZCLE1BQU0sT0FBTyxjQUFjO0NBQzNCLE9BQ0Usd0JBQUMsYUFBRDtFQUFhLFNBQVMsS0FBSztFQUFTLFNBQVMsS0FBSztZQUFsRCxDQUNFLHdCQUFDLGlCQUFEO0dBQ0UsU0FBUyxLQUFLO0dBQ2QsT0FBTyxLQUFLO0dBQ1osT0FBTyxLQUFLO0VBQ2I7Ozs7WUFDQSxDQUFDLEtBQUssV0FBVyxDQUFDLEtBQUssU0FBUyx3QkFBQyxXQUFELEVBQVcsUUFBUSxLQUFLLEtBQU87Ozs7VUFDckQ7Ozs7OztBQUVqQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xuaW1wb3J0IHsgQ2F0YWxvZ0ZlZWRiYWNrIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9mZWVkYmFjay9DYXRhbG9nRmVlZGJhY2snO1xuaW1wb3J0IHsgdXNlT3JkZXJzUGFnZSB9IGZyb20gJy4vaG9va3MvdXNlT3JkZXJzUGFnZSc7XG5pbXBvcnQgeyBPcmRlcnNTaGVsbCB9IGZyb20gJy4vY29tcG9uZW50cy9PcmRlcnNTaGVsbCc7XG5pbXBvcnQgeyBPcmRlckxpc3QgfSBmcm9tICcuL2NvbXBvbmVudHMvT3JkZXJMaXN0JztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE9yZGVyc1BhZ2UoKSB7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xuICByZXR1cm4gdXNlciA/IDxPcmRlcnNDb250ZW50IGtleT17dXNlci5pZH0gLz4gOiBudWxsO1xufVxuZnVuY3Rpb24gT3JkZXJzQ29udGVudCgpIHtcbiAgY29uc3QgcGFnZSA9IHVzZU9yZGVyc1BhZ2UoKTtcbiAgcmV0dXJuIChcbiAgICA8T3JkZXJzU2hlbGwgcmVmcmVzaD17cGFnZS5yZWZyZXNofSBsb2FkaW5nPXtwYWdlLmxvYWRpbmd9PlxuICAgICAgPENhdGFsb2dGZWVkYmFja1xuICAgICAgICBsb2FkaW5nPXtwYWdlLmxvYWRpbmd9XG4gICAgICAgIGVycm9yPXtwYWdlLmVycm9yfVxuICAgICAgICByZXRyeT17cGFnZS5yZWZyZXNofVxuICAgICAgLz5cbiAgICAgIHshcGFnZS5sb2FkaW5nICYmICFwYWdlLmVycm9yICYmIDxPcmRlckxpc3Qgb3JkZXJzPXtwYWdlLmRhdGF9IC8+fVxuICAgIDwvT3JkZXJzU2hlbGw+XG4gICk7XG59XG4iXX0=