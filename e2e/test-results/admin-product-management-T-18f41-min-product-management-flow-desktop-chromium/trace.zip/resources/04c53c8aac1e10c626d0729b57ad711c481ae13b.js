import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Categories/components/CategoryTable.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
import { translations } from "/src/utils/translations.ts";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryTable.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.admin;
export function CategoryTable({ page }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "overflow-hidden rounded-md border border-line bg-surface ",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "border-b border-line p-5 text-xl font-semibold text-fg",
			children: [
				t.categoryList,
				" (",
				page.categories.length,
				")"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this), page.categories.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
			className: "p-6 text-sm text-fg-muted",
			children: t.noCategories
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "ui-table ui-card-table w-full text-left text-sm",
				children: [/* @__PURE__ */ _jsxDEV("thead", {
					className: "bg-page text-fg-secondary",
					children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						t.categoryName,
						t.parentCategory,
						t.actions
					].map((label) => /* @__PURE__ */ _jsxDEV("th", {
						scope: "col",
						className: "px-5 py-3 font-medium",
						children: label
					}, label, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 19
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: page.categories.map((category) => /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.categoryName,
							className: "px-5 py-4 font-medium text-fg",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: [
									category.imageUrl && /* @__PURE__ */ _jsxDEV(ProductImage, {
										src: category.imageUrl,
										alt: category.name,
										className: "mb-2 h-14 w-14 rounded-sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 39,
										columnNumber: 25
									}, this),
									category.name,
									/* @__PURE__ */ _jsxDEV(StatusBadge, {
										status: category.isActive ? "ACTIVE" : "INACTIVE",
										children: category.isActive ? t.active : t.inactive
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 46,
										columnNumber: 23
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.parentCategory,
							className: "px-5 py-4 text-fg-secondary",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: category.parent?.name ?? t.topLevel
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.actions,
							className: "px-5 py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									disabled: page.busy,
									className: "auth-secondary mr-2",
									onClick: () => page.edit(category),
									children: translations.experience.editCategory
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									className: "auth-secondary",
									disabled: page.updating !== null,
									onClick: () => void page.toggle(category),
									children: page.updating === category.categoryID ? t.saving : category.isActive ? t.deactivate : t.activate
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 70,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 19
						}, this)
					]
				}, category.categoryID, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 17
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = CategoryTable;
var _c;
$RefreshReg$(_c, "CategoryTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Categories/components/CategoryTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Categories/components/CategoryTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFFNUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsY0FBYyxFQUM1QixRQUdDO0NBQ0QsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQixDQUNFLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWQ7SUFDRyxFQUFFO0lBQWE7SUFBRyxLQUFLLFdBQVc7SUFBTztHQUN4Qzs7Ozs7WUFDSCxLQUFLLFdBQVcsV0FBVyxJQUMxQix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUE2QixFQUFFO0VBQWdCOzs7O2FBRTVELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakIsQ0FDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUNmLHdCQUFDLE1BQUQsWUFDRztNQUFDLEVBQUU7TUFBYyxFQUFFO01BQWdCLEVBQUU7S0FBTyxDQUFDLENBQUMsS0FBSyxVQUNsRCx3QkFBQyxNQUFEO01BQWdCLE9BQU07TUFBTSxXQUFVO2dCQUNuQztLQUNDLEdBRks7Ozs7WUFFTCxDQUNMLEVBQ0M7Ozs7O0lBQ0M7Ozs7Y0FDUCx3QkFBQyxTQUFELFlBQ0csS0FBSyxXQUFXLEtBQUssYUFDcEIsd0JBQUMsTUFBRDtLQUE4QixXQUFVO2VBQXhDO01BQ0Usd0JBQUMsTUFBRDtPQUNFLGNBQVksRUFBRTtPQUNkLFdBQVU7aUJBRVYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRyxTQUFTLFlBQ1Isd0JBQUMsY0FBRDtVQUNFLEtBQUssU0FBUztVQUNkLEtBQUssU0FBUztVQUNkLFdBQVU7U0FDWDs7Ozs7U0FFRixTQUFTO1NBQ1Ysd0JBQUMsYUFBRDtVQUNFLFFBQVEsU0FBUyxXQUFXLFdBQVc7b0JBRXRDLFNBQVMsV0FBVyxFQUFFLFNBQVMsRUFBRTtTQUN2Qjs7Ozs7UUFDVjs7Ozs7O01BQ0g7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUNFLGNBQVksRUFBRTtPQUNkLFdBQVU7aUJBRVYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osU0FBUyxRQUFRLFFBQVEsRUFBRTtPQUN6Qjs7Ozs7TUFDSDs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksY0FBWSxFQUFFO09BQVMsV0FBVTtpQkFDbkMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsVUFBVSxLQUFLO1NBQ2YsV0FBVTtTQUNWLGVBQWUsS0FBSyxLQUFLLFFBQVE7bUJBRWhDLGFBQWEsV0FBVztRQUNuQjs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsV0FBVTtTQUNWLFVBQVUsS0FBSyxhQUFhO1NBQzVCLGVBQWUsS0FBSyxLQUFLLE9BQU8sUUFBUTttQkFFdkMsS0FBSyxhQUFhLFNBQVMsYUFDeEIsRUFBRSxTQUNGLFNBQVMsV0FDUCxFQUFFLGFBQ0YsRUFBRTtRQUNGOzs7O2dCQUNMOzs7Ozs7TUFDSDs7Ozs7S0FDRjtPQW5ESyxTQUFTOzs7O1dBbURkLENBQ0wsRUFDSTs7OztZQUNGOzs7Ozs7RUFDSjs7OztVQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDYXRlZ29yeVRhYmxlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdGF0dXNCYWRnZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvU3RhdHVzQmFkZ2UnO1xyXG5pbXBvcnQgdHlwZSB7IHVzZUNhdGVnb3JpZXNQYWdlIH0gZnJvbSAnLi4vaG9va3MvdXNlQ2F0ZWdvcmllc1BhZ2UnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0SW1hZ2UnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmFkbWluO1xyXG5leHBvcnQgZnVuY3Rpb24gQ2F0ZWdvcnlUYWJsZSh7XHJcbiAgcGFnZSxcclxufToge1xyXG4gIHBhZ2U6IFJldHVyblR5cGU8dHlwZW9mIHVzZUNhdGVnb3JpZXNQYWdlPjtcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIHAtNSB0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgIHt0LmNhdGVnb3J5TGlzdH0gKHtwYWdlLmNhdGVnb3JpZXMubGVuZ3RofSlcclxuICAgICAgPC9oMj5cclxuICAgICAge3BhZ2UuY2F0ZWdvcmllcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicC02IHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPnt0Lm5vQ2F0ZWdvcmllc308L3A+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ1aS10YWJsZSB1aS1jYXJkLXRhYmxlIHctZnVsbCB0ZXh0LWxlZnQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctcGFnZSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIHtbdC5jYXRlZ29yeU5hbWUsIHQucGFyZW50Q2F0ZWdvcnksIHQuYWN0aW9uc10ubWFwKChsYWJlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dGgga2V5PXtsYWJlbH0gc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC01IHB5LTMgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAge3BhZ2UuY2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtjYXRlZ29yeS5jYXRlZ29yeUlEfSBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItbGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLWxhYmVsPXt0LmNhdGVnb3J5TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTQgZm9udC1tZWRpdW0gdGV4dC1mZ1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5pbWFnZVVybCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQcm9kdWN0SW1hZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2NhdGVnb3J5LmltYWdlVXJsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17Y2F0ZWdvcnkubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0yIGgtMTQgdy0xNCByb3VuZGVkLXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM9e2NhdGVnb3J5LmlzQWN0aXZlID8gJ0FDVElWRScgOiAnSU5BQ1RJVkUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuaXNBY3RpdmUgPyB0LmFjdGl2ZSA6IHQuaW5hY3RpdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLWxhYmVsPXt0LnBhcmVudENhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktNCB0ZXh0LWZnLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5wYXJlbnQ/Lm5hbWUgPz8gdC50b3BMZXZlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9e3QuYWN0aW9uc30gY2xhc3NOYW1lPVwicHgtNSBweS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLmJ1c3l9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5IG1yLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwYWdlLmVkaXQoY2F0ZWdvcnkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmV4cGVyaWVuY2UuZWRpdENhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UudXBkYXRpbmcgIT09IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgcGFnZS50b2dnbGUoY2F0ZWdvcnkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGFnZS51cGRhdGluZyA9PT0gY2F0ZWdvcnkuY2F0ZWdvcnlJRFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gdC5zYXZpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGNhdGVnb3J5LmlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHQuZGVhY3RpdmF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0LmFjdGl2YXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==