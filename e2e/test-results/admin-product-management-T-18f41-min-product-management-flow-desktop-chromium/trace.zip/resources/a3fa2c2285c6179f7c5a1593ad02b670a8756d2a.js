import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/StoreSearch.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useId = __vite__cjsImport0_react["useId"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { generatePath, Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { getProductCatalog } from "/src/services/productService.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/StoreSearch.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function StoreSearch({ onSearch, autoFocus = false }) {
	_s();
	const id = useId();
	const [query, setQuery] = useState("");
	const [open, setOpen] = useState(false);
	const [results, setResults] = useState([]);
	const [pending, setPending] = useState(false);
	const [error, setError] = useState(false);
	const [recent, setRecent] = useState(() => {
		try {
			const saved = JSON.parse(localStorage.getItem("al-searches") ?? "[]");
			return Array.isArray(saved) ? saved.filter((item) => typeof item === "string").slice(0, 5) : [];
		} catch {
			return [];
		}
	});
	const [selected, setSelected] = useState(-1);
	const host = useRef(null);
	const navigate = useNavigate();
	useEffect(() => {
		if (query.trim().length < 2) return;
		const controller = new AbortController();
		const timer = window.setTimeout(() => {
			setPending(true);
			setError(false);
			void getProductCatalog({
				q: query.trim(),
				sort: "name",
				limit: 5,
				page: 1
			}, controller.signal).then((data) => {
				if (!controller.signal.aborted) setResults(data.items);
			}).catch(() => {
				if (!controller.signal.aborted) setError(true);
			}).finally(() => {
				if (!controller.signal.aborted) setPending(false);
			});
		}, 200);
		return () => {
			clearTimeout(timer);
			controller.abort();
		};
	}, [query]);
	useEffect(() => {
		function outside(event) {
			if (!host.current?.contains(event.target)) setOpen(false);
		}
		document.addEventListener("pointerdown", outside);
		return () => document.removeEventListener("pointerdown", outside);
	}, []);
	function search(value = query) {
		const clean = value.trim();
		if (clean) {
			const next = [clean, ...recent.filter((item) => item !== clean)].slice(0, 5);
			setRecent(next);
			try {
				localStorage.setItem("al-searches", JSON.stringify(next));
			} catch {}
		}
		setOpen(false);
		onSearch?.();
		navigate(ROUTES.products + (clean ? "?q=" + encodeURIComponent(clean) : ""));
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "store-search",
		ref: host,
		onBlur: (event) => {
			if (!event.currentTarget.contains(event.relatedTarget)) setOpen(false);
		},
		children: [/* @__PURE__ */ _jsxDEV("form", {
			role: "search",
			onSubmit: (event) => {
				event.preventDefault();
				search();
			},
			className: "search-field",
			children: [
				/* @__PURE__ */ _jsxDEV(Icon, { name: "search" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `${id}-input`,
					className: "sr-only",
					children: "Search products"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: `${id}-input`,
					autoFocus,
					autoComplete: "off",
					value: query,
					placeholder: "Search phones, appliances, accessories…",
					onFocus: () => setOpen(true),
					onChange: (event) => {
						setQuery(event.target.value);
						setResults([]);
						setPending(event.target.value.trim().length >= 2);
						setSelected(-1);
						setOpen(true);
					},
					onKeyDown: (event) => {
						if (event.key === "Escape") {
							setOpen(false);
							return;
						}
						if (event.key === "ArrowDown" || event.key === "ArrowUp") {
							event.preventDefault();
							setSelected((value) => Math.max(-1, Math.min(results.length - 1, value + (event.key === "ArrowDown" ? 1 : -1))));
						}
						if (event.key === "Enter" && open && selected >= 0 && results[selected]) {
							event.preventDefault();
							setOpen(false);
							onSearch?.();
							navigate(generatePath(ROUTES.productDetail, { id: results[selected].productID }));
						}
					},
					"aria-expanded": open,
					"aria-controls": `${id}-suggestions`,
					"aria-activedescendant": selected >= 0 ? `${id}-suggestion-${selected}` : undefined,
					role: "combobox",
					"aria-autocomplete": "list"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					"aria-label": "Search products",
					className: "search-submit",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "hidden lg:inline",
						children: "Search"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Icon, {
						name: "arrow",
						className: "h-4 w-4 lg:hidden"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 167,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 100,
			columnNumber: 7
		}, this), open && /* @__PURE__ */ _jsxDEV("div", {
			id: `${id}-suggestions`,
			className: "search-suggestions",
			role: "listbox",
			"aria-label": "Search suggestions",
			children: query.trim().length < 2 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "px-3 pb-2 text-xs text-fg-muted",
					children: recent.length ? "Recent searches" : "Find your next everyday essential"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 15
				}, this),
				recent.map((item) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					role: "option",
					"aria-selected": false,
					onClick: () => {
						setQuery(item);
						search(item);
					},
					className: "search-option",
					children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "search" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 19
					}, this), item]
				}, item, true, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 17
				}, this)),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					role: "option",
					"aria-selected": false,
					className: "search-option",
					onClick: () => search(""),
					children: ["Browse all products", /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 206,
					columnNumber: 15
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 13
			}, this) : pending ? /* @__PURE__ */ _jsxDEV("p", {
				className: "p-3 text-sm text-fg-muted",
				role: "status",
				children: "Finding products…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 218,
				columnNumber: 13
			}, this) : error ? /* @__PURE__ */ _jsxDEV("p", {
				className: "p-3 text-sm text-fg-muted",
				children: "Suggestions unavailable. Press Enter to search."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 222,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [results.map((product, index) => /* @__PURE__ */ _jsxDEV(Link, {
				id: `${id}-suggestion-${index}`,
				role: "option",
				"aria-selected": selected === index,
				className: `search-option ${selected === index ? "bg-primary-subtle" : ""}`,
				to: generatePath(ROUTES.productDetail, { id: product.productID }),
				onClick: () => {
					setOpen(false);
					onSearch?.();
				},
				children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
					src: product.images[0],
					alt: "",
					className: "h-10 w-10 rounded bg-well"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 242,
					columnNumber: 19
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "block truncate font-medium",
						children: product.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 248,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs text-fg-muted",
						children: formatCurrency(product.price)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 247,
					columnNumber: 19
				}, this)]
			}, product.productID, true, {
				fileName: _jsxFileName,
				lineNumber: 228,
				columnNumber: 17
			}, this)), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				role: "option",
				"aria-selected": false,
				className: "search-option text-fg-link",
				onClick: () => search(),
				children: [
					"See all results for “",
					query,
					"”",
					/* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 46
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 257,
				columnNumber: 15
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 226,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 93,
		columnNumber: 5
	}, this);
}
_s(StoreSearch, "h4nqQh8Oi89mC6lZlooRMv/1y88=", false, function() {
	return [useNavigate];
});
_c = StoreSearch;
var _c;
$RefreshReg$(_c, "StoreSearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/StoreSearch.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/StoreSearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/StoreSearch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/StoreSearch.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLE9BQU8sUUFBUSxnQkFBZ0I7QUFDbkQsU0FBUyxjQUFjLE1BQU0sbUJBQW1CO0FBQ2hELFNBQVMseUJBQXlCO0FBRWxDLFNBQVMsY0FBYztBQUN2QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFlBQVk7QUFDckIsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsT0FBTyxTQUFTLFlBQVksRUFDMUIsVUFDQSxZQUFZLFNBSVg7O0NBQ0QsTUFBTSxLQUFLLE1BQU07Q0FDakIsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFvQixDQUFDLENBQUM7Q0FDcEQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEtBQUs7Q0FDeEMsTUFBTSxDQUFDLFFBQVEsYUFBYSxlQUF5QjtFQUNuRCxJQUFJO0dBQ0YsTUFBTSxRQUFpQixLQUFLLE1BQzFCLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFDekM7R0FDQSxPQUFPLE1BQU0sUUFBUSxLQUFLLElBQ3RCLE1BQ0csUUFBUSxTQUF5QixPQUFPLFNBQVMsUUFBUSxDQUFDLENBQzFELE1BQU0sR0FBRyxDQUFDLElBQ2IsQ0FBQztFQUNQLFFBQVE7R0FDTixPQUFPLENBQUM7RUFDVjtDQUNGLENBQUM7Q0FDRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQyxDQUFDO0NBQzNDLE1BQU0sT0FBTyxPQUF1QixJQUFJO0NBQ3hDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLGdCQUFnQjtFQUNkLElBQUksTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTLEdBQUc7RUFDN0IsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBQ3ZDLE1BQU0sUUFBUSxPQUFPLGlCQUFpQjtHQUNwQyxXQUFXLElBQUk7R0FDZixTQUFTLEtBQUs7R0FDZCxLQUFLLGtCQUNIO0lBQUUsR0FBRyxNQUFNLEtBQUs7SUFBRyxNQUFNO0lBQVEsT0FBTztJQUFHLE1BQU07R0FBRSxHQUNuRCxXQUFXLE1BQ2IsQ0FBQyxDQUNFLE1BQU0sU0FBUztJQUNkLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUssS0FBSztHQUN2RCxDQUFDLENBQUMsQ0FDRCxZQUFZO0lBQ1gsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTLFNBQVMsSUFBSTtHQUMvQyxDQUFDLENBQUMsQ0FDRCxjQUFjO0lBQ2IsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztHQUNsRCxDQUFDO0VBQ0wsR0FBRyxHQUFHO0VBQ04sYUFBYTtHQUNYLGFBQWEsS0FBSztHQUNsQixXQUFXLE1BQU07RUFDbkI7Q0FDRixHQUFHLENBQUMsS0FBSyxDQUFDO0NBQ1YsZ0JBQWdCO0VBQ2QsU0FBUyxRQUFRLE9BQXFCO0dBQ3BDLElBQUksQ0FBQyxLQUFLLFNBQVMsU0FBUyxNQUFNLE1BQWMsR0FBRyxRQUFRLEtBQUs7RUFDbEU7RUFDQSxTQUFTLGlCQUFpQixlQUFlLE9BQU87RUFDaEQsYUFBYSxTQUFTLG9CQUFvQixlQUFlLE9BQU87Q0FDbEUsR0FBRyxDQUFDLENBQUM7Q0FDTCxTQUFTLE9BQU8sUUFBUSxPQUFPO0VBQzdCLE1BQU0sUUFBUSxNQUFNLEtBQUs7RUFDekIsSUFBSSxPQUFPO0dBQ1QsTUFBTSxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sUUFBUSxTQUFTLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUMvRCxHQUNBLENBQ0Y7R0FDQSxVQUFVLElBQUk7R0FDZCxJQUFJO0lBQ0YsYUFBYSxRQUFRLGVBQWUsS0FBSyxVQUFVLElBQUksQ0FBQztHQUMxRCxRQUFRLENBRVI7RUFDRjtFQUNBLFFBQVEsS0FBSztFQUNiLFdBQVc7RUFDWCxTQUNFLE9BQU8sWUFBWSxRQUFRLFFBQVEsbUJBQW1CLEtBQUssSUFBSSxHQUNqRTtDQUNGO0NBQ0EsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsV0FBVTtFQUNWLEtBQUs7RUFDTCxTQUFTLFVBQVU7R0FDakIsSUFBSSxDQUFDLE1BQU0sY0FBYyxTQUFTLE1BQU0sYUFBYSxHQUFHLFFBQVEsS0FBSztFQUN2RTtZQUxGLENBT0Usd0JBQUMsUUFBRDtHQUNFLE1BQUs7R0FDTCxXQUFXLFVBQVU7SUFDbkIsTUFBTSxlQUFlO0lBQ3JCLE9BQU87R0FDVDtHQUNBLFdBQVU7YUFOWjtJQVFFLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFNBQVU7Ozs7O0lBQ3JCLHdCQUFDLFNBQUQ7S0FBTyxTQUFTLEdBQUcsR0FBRztLQUFTLFdBQVU7ZUFBVTtJQUU1Qzs7Ozs7SUFDUCx3QkFBQyxTQUFEO0tBQ0UsSUFBSSxHQUFHLEdBQUc7S0FDQztLQUNYLGNBQWE7S0FDYixPQUFPO0tBQ1AsYUFBWTtLQUNaLGVBQWUsUUFBUSxJQUFJO0tBQzNCLFdBQVcsVUFBVTtNQUNuQixTQUFTLE1BQU0sT0FBTyxLQUFLO01BQzNCLFdBQVcsQ0FBQyxDQUFDO01BQ2IsV0FBVyxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUM7TUFDaEQsWUFBWSxDQUFDLENBQUM7TUFDZCxRQUFRLElBQUk7S0FDZDtLQUNBLFlBQVksVUFBVTtNQUNwQixJQUFJLE1BQU0sUUFBUSxVQUFVO09BQzFCLFFBQVEsS0FBSztPQUNiO01BQ0Y7TUFDQSxJQUFJLE1BQU0sUUFBUSxlQUFlLE1BQU0sUUFBUSxXQUFXO09BQ3hELE1BQU0sZUFBZTtPQUNyQixhQUFhLFVBQ1gsS0FBSyxJQUNILENBQUMsR0FDRCxLQUFLLElBQ0gsUUFBUSxTQUFTLEdBQ2pCLFNBQVMsTUFBTSxRQUFRLGNBQWMsSUFBSSxDQUFDLEVBQzVDLENBQ0YsQ0FDRjtNQUNGO01BQ0EsSUFDRSxNQUFNLFFBQVEsV0FDZCxRQUNBLFlBQVksS0FDWixRQUFRLFdBQ1I7T0FDQSxNQUFNLGVBQWU7T0FDckIsUUFBUSxLQUFLO09BQ2IsV0FBVztPQUNYLFNBQ0UsYUFBYSxPQUFPLGVBQWUsRUFDakMsSUFBSSxRQUFRLFNBQVMsQ0FBQyxVQUN4QixDQUFDLENBQ0g7TUFDRjtLQUNGO0tBQ0EsaUJBQWU7S0FDZixpQkFBZSxHQUFHLEdBQUc7S0FDckIseUJBQ0UsWUFBWSxJQUFJLEdBQUcsR0FBRyxjQUFjLGFBQWE7S0FFbkQsTUFBSztLQUNMLHFCQUFrQjtJQUNuQjs7Ozs7SUFDRCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGNBQVc7S0FDWCxXQUFVO2VBSFosQ0FLRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBbUI7S0FBWTs7OztlQUMvQyx3QkFBQyxNQUFEO01BQU0sTUFBSztNQUFRLFdBQVU7S0FBcUI7Ozs7YUFDNUM7Ozs7OztHQUNKOzs7OztZQUNMLFFBQ0Msd0JBQUMsT0FBRDtHQUNFLElBQUksR0FBRyxHQUFHO0dBQ1YsV0FBVTtHQUNWLE1BQUs7R0FDTCxjQUFXO2FBRVYsTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTLElBQ3JCO0lBQ0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixPQUFPLFNBQ0osb0JBQ0E7SUFDSDs7Ozs7SUFDRixPQUFPLEtBQUssU0FDWCx3QkFBQyxVQUFEO0tBRUUsTUFBSztLQUNMLE1BQUs7S0FDTCxpQkFBZTtLQUNmLGVBQWU7TUFDYixTQUFTLElBQUk7TUFDYixPQUFPLElBQUk7S0FDYjtLQUNBLFdBQVU7ZUFUWixDQVdFLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFNBQVU7Ozs7ZUFDcEIsSUFDSztPQVpEOzs7O1dBWUMsQ0FDVDtJQUNELHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsTUFBSztLQUNMLGlCQUFlO0tBQ2YsV0FBVTtLQUNWLGVBQWUsT0FBTyxFQUFFO2VBTDFCLENBTUMsdUJBRUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OzthQUNkOzs7Ozs7R0FDUjs7OztjQUNBLFVBQ0Ysd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBNEIsTUFBSztjQUFTO0dBRXBEOzs7O2NBQ0QsUUFDRix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUE0QjtHQUV0Qzs7OztjQUVILGdEQUNHLFFBQVEsS0FBSyxTQUFTLFVBQ3JCLHdCQUFDLE1BQUQ7SUFFRSxJQUFJLEdBQUcsR0FBRyxjQUFjO0lBQ3hCLE1BQUs7SUFDTCxpQkFBZSxhQUFhO0lBQzVCLFdBQVcsaUJBQWlCLGFBQWEsUUFBUSxzQkFBc0I7SUFDdkUsSUFBSSxhQUFhLE9BQU8sZUFBZSxFQUNyQyxJQUFJLFFBQVEsVUFDZCxDQUFDO0lBQ0QsZUFBZTtLQUNiLFFBQVEsS0FBSztLQUNiLFdBQVc7SUFDYjtjQVpGLENBY0Usd0JBQUMsY0FBRDtLQUNFLEtBQUssUUFBUSxPQUFPO0tBQ3BCLEtBQUk7S0FDSixXQUFVO0lBQ1g7Ozs7Y0FDRCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLFFBQVE7S0FDTDs7OztlQUNOLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLGVBQWUsUUFBUSxLQUFLO0tBQ3pCOzs7O2FBQ0Y7Ozs7O1lBQ0Y7TUExQkMsUUFBUTs7OztVQTBCVCxDQUNQLEdBQ0Qsd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxNQUFLO0lBQ0wsaUJBQWU7SUFDZixXQUFVO0lBQ1YsZUFBZSxPQUFPO2NBTHhCO0tBTUM7S0FDdUI7S0FBTTtLQUFDLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O0lBQzNDOzs7OztXQUNSOzs7OztFQUVEOzs7O1VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN0b3JlU2VhcmNoLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZUlkLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBnZW5lcmF0ZVBhdGgsIExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IGdldFByb2R1Y3RDYXRhbG9nIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvcHJvZHVjdFNlcnZpY2UnO1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi90eXBlcy9wcm9kdWN0LnR5cGVzJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vdXRpbHMvY3VycmVuY3knO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi9jb21tb24vUHJvZHVjdEltYWdlJztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdG9yZVNlYXJjaCh7XHJcbiAgb25TZWFyY2gsXHJcbiAgYXV0b0ZvY3VzID0gZmFsc2UsXHJcbn06IHtcclxuICBvblNlYXJjaD86ICgpID0+IHZvaWQ7XHJcbiAgYXV0b0ZvY3VzPzogYm9vbGVhbjtcclxufSkge1xyXG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcclxuICBjb25zdCBbcXVlcnksIHNldFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Jlc3VsdHMsIHNldFJlc3VsdHNdID0gdXNlU3RhdGU8UHJvZHVjdFtdPihbXSk7XHJcbiAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZWNlbnQsIHNldFJlY2VudF0gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc2F2ZWQ6IHVua25vd24gPSBKU09OLnBhcnNlKFxyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhbC1zZWFyY2hlcycpID8/ICdbXScsXHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiBBcnJheS5pc0FycmF5KHNhdmVkKVxyXG4gICAgICAgID8gc2F2ZWRcclxuICAgICAgICAgICAgLmZpbHRlcigoaXRlbSk6IGl0ZW0gaXMgc3RyaW5nID0+IHR5cGVvZiBpdGVtID09PSAnc3RyaW5nJylcclxuICAgICAgICAgICAgLnNsaWNlKDAsIDUpXHJcbiAgICAgICAgOiBbXTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcbiAgfSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZSgtMSk7XHJcbiAgY29uc3QgaG9zdCA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocXVlcnkudHJpbSgpLmxlbmd0aCA8IDIpIHJldHVybjtcclxuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbiAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0UGVuZGluZyh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IoZmFsc2UpO1xyXG4gICAgICB2b2lkIGdldFByb2R1Y3RDYXRhbG9nKFxyXG4gICAgICAgIHsgcTogcXVlcnkudHJpbSgpLCBzb3J0OiAnbmFtZScsIGxpbWl0OiA1LCBwYWdlOiAxIH0sXHJcbiAgICAgICAgY29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgIClcclxuICAgICAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSBzZXRSZXN1bHRzKGRhdGEuaXRlbXMpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgc2V0RXJyb3IodHJ1ZSk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuZmluYWxseSgoKSA9PiB7XHJcbiAgICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHNldFBlbmRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSwgMjAwKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoKTtcclxuICAgIH07XHJcbiAgfSwgW3F1ZXJ5XSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZ1bmN0aW9uIG91dHNpZGUoZXZlbnQ6IFBvaW50ZXJFdmVudCkge1xyXG4gICAgICBpZiAoIWhvc3QuY3VycmVudD8uY29udGFpbnMoZXZlbnQudGFyZ2V0IGFzIE5vZGUpKSBzZXRPcGVuKGZhbHNlKTtcclxuICAgIH1cclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJkb3duJywgb3V0c2lkZSk7XHJcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9pbnRlcmRvd24nLCBvdXRzaWRlKTtcclxuICB9LCBbXSk7XHJcbiAgZnVuY3Rpb24gc2VhcmNoKHZhbHVlID0gcXVlcnkpIHtcclxuICAgIGNvbnN0IGNsZWFuID0gdmFsdWUudHJpbSgpO1xyXG4gICAgaWYgKGNsZWFuKSB7XHJcbiAgICAgIGNvbnN0IG5leHQgPSBbY2xlYW4sIC4uLnJlY2VudC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0gIT09IGNsZWFuKV0uc2xpY2UoXHJcbiAgICAgICAgMCxcclxuICAgICAgICA1LFxyXG4gICAgICApO1xyXG4gICAgICBzZXRSZWNlbnQobmV4dCk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2FsLXNlYXJjaGVzJywgSlNPTi5zdHJpbmdpZnkobmV4dCkpO1xyXG4gICAgICB9IGNhdGNoIHtcclxuICAgICAgICAvKiBTZWFyY2ggd29ya3Mgd2l0aG91dCBzdG9yYWdlLiAqL1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgIG9uU2VhcmNoPy4oKTtcclxuICAgIG5hdmlnYXRlKFxyXG4gICAgICBST1VURVMucHJvZHVjdHMgKyAoY2xlYW4gPyAnP3E9JyArIGVuY29kZVVSSUNvbXBvbmVudChjbGVhbikgOiAnJyksXHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJzdG9yZS1zZWFyY2hcIlxyXG4gICAgICByZWY9e2hvc3R9XHJcbiAgICAgIG9uQmx1cj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgaWYgKCFldmVudC5jdXJyZW50VGFyZ2V0LmNvbnRhaW5zKGV2ZW50LnJlbGF0ZWRUYXJnZXQpKSBzZXRPcGVuKGZhbHNlKTtcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPGZvcm1cclxuICAgICAgICByb2xlPVwic2VhcmNoXCJcclxuICAgICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgc2VhcmNoKCk7XHJcbiAgICAgICAgfX1cclxuICAgICAgICBjbGFzc05hbWU9XCJzZWFyY2gtZmllbGRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPEljb24gbmFtZT1cInNlYXJjaFwiIC8+XHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2Ake2lkfS1pbnB1dGB9IGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cclxuICAgICAgICAgIFNlYXJjaCBwcm9kdWN0c1xyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD17YCR7aWR9LWlucHV0YH1cclxuICAgICAgICAgIGF1dG9Gb2N1cz17YXV0b0ZvY3VzfVxyXG4gICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcclxuICAgICAgICAgIHZhbHVlPXtxdWVyeX1cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHBob25lcywgYXBwbGlhbmNlcywgYWNjZXNzb3JpZXPigKZcIlxyXG4gICAgICAgICAgb25Gb2N1cz17KCkgPT4gc2V0T3Blbih0cnVlKX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgc2V0UXVlcnkoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgc2V0UmVzdWx0cyhbXSk7XHJcbiAgICAgICAgICAgIHNldFBlbmRpbmcoZXZlbnQudGFyZ2V0LnZhbHVlLnRyaW0oKS5sZW5ndGggPj0gMik7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkKC0xKTtcclxuICAgICAgICAgICAgc2V0T3Blbih0cnVlKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBvbktleURvd249eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykge1xyXG4gICAgICAgICAgICAgIHNldE9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnQXJyb3dEb3duJyB8fCBldmVudC5rZXkgPT09ICdBcnJvd1VwJykge1xyXG4gICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWQoKHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgTWF0aC5tYXgoXHJcbiAgICAgICAgICAgICAgICAgIC0xLFxyXG4gICAgICAgICAgICAgICAgICBNYXRoLm1pbihcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHRzLmxlbmd0aCAtIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWUgKyAoZXZlbnQua2V5ID09PSAnQXJyb3dEb3duJyA/IDEgOiAtMSksXHJcbiAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgIGV2ZW50LmtleSA9PT0gJ0VudGVyJyAmJlxyXG4gICAgICAgICAgICAgIG9wZW4gJiZcclxuICAgICAgICAgICAgICBzZWxlY3RlZCA+PSAwICYmXHJcbiAgICAgICAgICAgICAgcmVzdWx0c1tzZWxlY3RlZF1cclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgICBvblNlYXJjaD8uKCk7XHJcbiAgICAgICAgICAgICAgbmF2aWdhdGUoXHJcbiAgICAgICAgICAgICAgICBnZW5lcmF0ZVBhdGgoUk9VVEVTLnByb2R1Y3REZXRhaWwsIHtcclxuICAgICAgICAgICAgICAgICAgaWQ6IHJlc3VsdHNbc2VsZWN0ZWRdLnByb2R1Y3RJRCxcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBhcmlhLWV4cGFuZGVkPXtvcGVufVxyXG4gICAgICAgICAgYXJpYS1jb250cm9scz17YCR7aWR9LXN1Z2dlc3Rpb25zYH1cclxuICAgICAgICAgIGFyaWEtYWN0aXZlZGVzY2VuZGFudD17XHJcbiAgICAgICAgICAgIHNlbGVjdGVkID49IDAgPyBgJHtpZH0tc3VnZ2VzdGlvbi0ke3NlbGVjdGVkfWAgOiB1bmRlZmluZWRcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJvbGU9XCJjb21ib2JveFwiXHJcbiAgICAgICAgICBhcmlhLWF1dG9jb21wbGV0ZT1cImxpc3RcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VhcmNoIHByb2R1Y3RzXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInNlYXJjaC1zdWJtaXRcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBsZzppbmxpbmVcIj5TZWFyY2g8L3NwYW4+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiYXJyb3dcIiBjbGFzc05hbWU9XCJoLTQgdy00IGxnOmhpZGRlblwiIC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAge29wZW4gJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGlkPXtgJHtpZH0tc3VnZ2VzdGlvbnNgfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwic2VhcmNoLXN1Z2dlc3Rpb25zXCJcclxuICAgICAgICAgIHJvbGU9XCJsaXN0Ym94XCJcclxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2ggc3VnZ2VzdGlvbnNcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtxdWVyeS50cmltKCkubGVuZ3RoIDwgMiA/IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweC0zIHBiLTIgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICB7cmVjZW50Lmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICA/ICdSZWNlbnQgc2VhcmNoZXMnXHJcbiAgICAgICAgICAgICAgICAgIDogJ0ZpbmQgeW91ciBuZXh0IGV2ZXJ5ZGF5IGVzc2VudGlhbCd9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIHtyZWNlbnQubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbX1cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIHJvbGU9XCJvcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFF1ZXJ5KGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHNlYXJjaChpdGVtKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2VhcmNoLW9wdGlvblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJzZWFyY2hcIiAvPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgcm9sZT1cIm9wdGlvblwiXHJcbiAgICAgICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNlYXJjaC1vcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2VhcmNoKCcnKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBCcm93c2UgYWxsIHByb2R1Y3RzXHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYXJyb3dcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICkgOiBwZW5kaW5nID8gKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLTMgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgICAgICAgIEZpbmRpbmcgcHJvZHVjdHPigKZcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKSA6IGVycm9yID8gKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLTMgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgU3VnZ2VzdGlvbnMgdW5hdmFpbGFibGUuIFByZXNzIEVudGVyIHRvIHNlYXJjaC5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICB7cmVzdWx0cy5tYXAoKHByb2R1Y3QsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICBrZXk9e3Byb2R1Y3QucHJvZHVjdElEfVxyXG4gICAgICAgICAgICAgICAgICBpZD17YCR7aWR9LXN1Z2dlc3Rpb24tJHtpbmRleH1gfVxyXG4gICAgICAgICAgICAgICAgICByb2xlPVwib3B0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1zZWxlY3RlZD17c2VsZWN0ZWQgPT09IGluZGV4fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BzZWFyY2gtb3B0aW9uICR7c2VsZWN0ZWQgPT09IGluZGV4ID8gJ2JnLXByaW1hcnktc3VidGxlJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgIHRvPXtnZW5lcmF0ZVBhdGgoUk9VVEVTLnByb2R1Y3REZXRhaWwsIHtcclxuICAgICAgICAgICAgICAgICAgICBpZDogcHJvZHVjdC5wcm9kdWN0SUQsXHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgb25TZWFyY2g/LigpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8UHJvZHVjdEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgc3JjPXtwcm9kdWN0LmltYWdlc1swXX1cclxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTAgdy0xMCByb3VuZGVkIGJnLXdlbGxcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIHJvbGU9XCJvcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1zZWxlY3RlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFyY2gtb3B0aW9uIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWFyY2goKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTZWUgYWxsIHJlc3VsdHMgZm9yIOKAnHtxdWVyeX3igJ08SWNvbiBuYW1lPVwiYXJyb3dcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==