import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthProvider.tsx");const useCallback = __vite__cjsImport1_react["useCallback"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import axios from "/node_modules/.vite/deps/axios.js?v=50079ced";
import apiClient from "/src/api/apiClient.ts";
import * as authService from "/src/services/authService.ts";
import { AuthContext } from "/src/context/auth-context.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/AuthProvider.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s2 = $RefreshSig$();
export function AuthProvider({ children }) {
	_s2();
	var _s = $RefreshSig$();
	const [user, setUser] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const generation = useRef(0);
	const refresh = useCallback(async (background = false) => {
		const current = ++generation.current;
		if (!background) setLoading(true);
		setError(null);
		try {
			const profile = await authService.getProfile();
			if (current === generation.current) setUser(profile);
		} catch (err) {
			if (current !== generation.current) return;
			setUser(null);
			if (!axios.isAxiosError(err) || err.response?.status !== 401) setError(translations.auth.sessionError);
		} finally {
			if (current === generation.current) setLoading(false);
		}
	}, []);
	_s(useEffect(_s(() => {
		_s();
		// Restore server-managed session state when the provider mounts.
		// eslint-disable-next-line react-hooks/set-state-in-effect
		void refresh();
		const id = apiClient.interceptors.response.use((response) => response, (err) => {
			if (err.response?.status === 401 && !err.config?.url?.match(/auth\/(login|register|profile)/)) {
				generation.current++;
				setLoading(false);
				setUser(null);
			}
			return Promise.reject(err);
		});
		const onFocus = () => {
			void refresh(true);
		};
		window.addEventListener("focus", onFocus);
		return () => {
			apiClient.interceptors.response.eject(id);
			window.removeEventListener("focus", onFocus);
		};
	}, "wY8XjDbIcDrFmML9/F50F3oQK90="), [refresh]), "wY8XjDbIcDrFmML9/F50F3oQK90=");
	async function signIn(input) {
		generation.current++;
		const authenticatedUser = await authService.login(input);
		setUser(authenticatedUser);
		setError(null);
		return authenticatedUser;
	}
	async function signUp(input) {
		generation.current++;
		const result = await authService.register(input);
		setUser(null);
		setError(null);
		return result;
	}
	async function signOut() {
		await authService.logout();
		generation.current++;
		setUser(null);
	}
	function hasRole(...roles) {
		return !!user && roles.includes(user.role);
	}
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			user,
			loading,
			error,
			refresh,
			signIn,
			signUp,
			signOut,
			hasRole
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 89,
		columnNumber: 5
	}, this);
}
_s2(AuthProvider, "pw++okNyKteWRjLbeu0hkQeYVC4=");
_c = AuthProvider;
var _c;
$RefreshReg$(_c, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthProvider.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/AuthProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/AuthProvider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/context/AuthProvider.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxhQUFhLFdBQVcsUUFBUSxnQkFBZ0I7QUFFekQsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sZUFBZTtBQUN0QixZQUFZLGlCQUFpQjtBQU83QixTQUFTLG1CQUFtQjs7OztBQUU1QixPQUFPLFNBQVMsYUFBYSxFQUFFLFlBQXFDOzs7Q0FDbEUsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUEwQixJQUFJO0NBQ3RELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUN0RCxNQUFNLGFBQWEsT0FBTyxDQUFDO0NBQzNCLE1BQU0sVUFBVSxZQUFZLE9BQU8sYUFBYSxVQUFVO0VBQ3hELE1BQU0sVUFBVSxFQUFFLFdBQVc7RUFDN0IsSUFBSSxDQUFDLFlBQVksV0FBVyxJQUFJO0VBQ2hDLFNBQVMsSUFBSTtFQUNiLElBQUk7R0FDRixNQUFNLFVBQVUsTUFBTSxZQUFZLFdBQVc7R0FDN0MsSUFBSSxZQUFZLFdBQVcsU0FBUyxRQUFRLE9BQU87RUFDckQsU0FBUyxLQUFLO0dBQ1osSUFBSSxZQUFZLFdBQVcsU0FBUztHQUNwQyxRQUFRLElBQUk7R0FDWixJQUFJLENBQUMsTUFBTSxhQUFhLEdBQUcsS0FBSyxJQUFJLFVBQVUsV0FBVyxLQUN2RCxTQUFTLGFBQWEsS0FBSyxZQUFZO0VBQzNDLFVBQVU7R0FDUixJQUFJLFlBQVksV0FBVyxTQUFTLFdBQVcsS0FBSztFQUN0RDtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsc0JBQWdCOzs7O0VBR2QsS0FBSyxRQUFRO0VBQ2IsTUFBTSxLQUFLLFVBQVUsYUFBYSxTQUFTLEtBQ3hDLGFBQWEsV0FDYixRQUFRO0dBQ1AsSUFDRSxJQUFJLFVBQVUsV0FBVyxPQUN6QixDQUFDLElBQUksUUFBUSxLQUFLLE1BQU0sZ0NBQWdDLEdBQ3hEO0lBQ0EsV0FBVztJQUNYLFdBQVcsS0FBSztJQUNoQixRQUFRLElBQUk7R0FDZDtHQUNBLE9BQU8sUUFBUSxPQUFPLEdBQUc7RUFDM0IsQ0FDRjtFQUNBLE1BQU0sZ0JBQWdCO0dBQ3BCLEtBQUssUUFBUSxJQUFJO0VBQ25CO0VBQ0EsT0FBTyxpQkFBaUIsU0FBUyxPQUFPO0VBQ3hDLGFBQWE7R0FDWCxVQUFVLGFBQWEsU0FBUyxNQUFNLEVBQUU7R0FDeEMsT0FBTyxvQkFBb0IsU0FBUyxPQUFPO0VBQzdDO0NBQ0Ysb0NBQUcsQ0FBQyxPQUFPLENBQUM7Q0FFWixlQUFlLE9BQU8sT0FBbUI7RUFDdkMsV0FBVztFQUNYLE1BQU0sb0JBQW9CLE1BQU0sWUFBWSxNQUFNLEtBQUs7RUFDdkQsUUFBUSxpQkFBaUI7RUFDekIsU0FBUyxJQUFJO0VBQ2IsT0FBTztDQUNUO0NBQ0EsZUFBZSxPQUFPLE9BQXNCO0VBQzFDLFdBQVc7RUFDWCxNQUFNLFNBQVMsTUFBTSxZQUFZLFNBQVMsS0FBSztFQUMvQyxRQUFRLElBQUk7RUFDWixTQUFTLElBQUk7RUFDYixPQUFPO0NBQ1Q7Q0FDQSxlQUFlLFVBQVU7RUFDdkIsTUFBTSxZQUFZLE9BQU87RUFDekIsV0FBVztFQUNYLFFBQVEsSUFBSTtDQUNkO0NBQ0EsU0FBUyxRQUFRLEdBQUcsT0FBbUI7RUFDckMsT0FBTyxDQUFDLENBQUMsUUFBUSxNQUFNLFNBQVMsS0FBSyxJQUFJO0NBQzNDO0NBRUEsT0FDRSx3QkFBQyxZQUFZLFVBQWI7RUFDRSxPQUFPO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBRUM7Q0FDbUI7Ozs7O0FBRTFCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dGhQcm92aWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XHJcbmltcG9ydCBhcGlDbGllbnQgZnJvbSAnLi4vYXBpL2FwaUNsaWVudCc7XHJcbmltcG9ydCAqIGFzIGF1dGhTZXJ2aWNlIGZyb20gJy4uL3NlcnZpY2VzL2F1dGhTZXJ2aWNlJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIEF1dGhVc2VyLFxyXG4gIExvZ2luSW5wdXQsXHJcbiAgUmVnaXN0ZXJJbnB1dCxcclxuICBVc2VyUm9sZSxcclxufSBmcm9tICcuLi90eXBlcy9hdXRoLnR5cGVzJztcclxuaW1wb3J0IHsgQXV0aENvbnRleHQgfSBmcm9tICcuL2F1dGgtY29udGV4dCc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZTxBdXRoVXNlciB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgZ2VuZXJhdGlvbiA9IHVzZVJlZigwKTtcclxuICBjb25zdCByZWZyZXNoID0gdXNlQ2FsbGJhY2soYXN5bmMgKGJhY2tncm91bmQgPSBmYWxzZSkgPT4ge1xyXG4gICAgY29uc3QgY3VycmVudCA9ICsrZ2VuZXJhdGlvbi5jdXJyZW50O1xyXG4gICAgaWYgKCFiYWNrZ3JvdW5kKSBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwcm9maWxlID0gYXdhaXQgYXV0aFNlcnZpY2UuZ2V0UHJvZmlsZSgpO1xyXG4gICAgICBpZiAoY3VycmVudCA9PT0gZ2VuZXJhdGlvbi5jdXJyZW50KSBzZXRVc2VyKHByb2ZpbGUpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChjdXJyZW50ICE9PSBnZW5lcmF0aW9uLmN1cnJlbnQpIHJldHVybjtcclxuICAgICAgc2V0VXNlcihudWxsKTtcclxuICAgICAgaWYgKCFheGlvcy5pc0F4aW9zRXJyb3IoZXJyKSB8fCBlcnIucmVzcG9uc2U/LnN0YXR1cyAhPT0gNDAxKVxyXG4gICAgICAgIHNldEVycm9yKHRyYW5zbGF0aW9ucy5hdXRoLnNlc3Npb25FcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpZiAoY3VycmVudCA9PT0gZ2VuZXJhdGlvbi5jdXJyZW50KSBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBSZXN0b3JlIHNlcnZlci1tYW5hZ2VkIHNlc3Npb24gc3RhdGUgd2hlbiB0aGUgcHJvdmlkZXIgbW91bnRzLlxyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3NldC1zdGF0ZS1pbi1lZmZlY3RcclxuICAgIHZvaWQgcmVmcmVzaCgpO1xyXG4gICAgY29uc3QgaWQgPSBhcGlDbGllbnQuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLnVzZShcclxuICAgICAgKHJlc3BvbnNlKSA9PiByZXNwb25zZSxcclxuICAgICAgKGVycikgPT4ge1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgIGVyci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDEgJiZcclxuICAgICAgICAgICFlcnIuY29uZmlnPy51cmw/Lm1hdGNoKC9hdXRoXFwvKGxvZ2lufHJlZ2lzdGVyfHByb2ZpbGUpLylcclxuICAgICAgICApIHtcclxuICAgICAgICAgIGdlbmVyYXRpb24uY3VycmVudCsrO1xyXG4gICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICBzZXRVc2VyKG51bGwpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyKTtcclxuICAgICAgfSxcclxuICAgICk7XHJcbiAgICBjb25zdCBvbkZvY3VzID0gKCkgPT4ge1xyXG4gICAgICB2b2lkIHJlZnJlc2godHJ1ZSk7XHJcbiAgICB9O1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2ZvY3VzJywgb25Gb2N1cyk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBhcGlDbGllbnQuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLmVqZWN0KGlkKTtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2ZvY3VzJywgb25Gb2N1cyk7XHJcbiAgICB9O1xyXG4gIH0sIFtyZWZyZXNoXSk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIHNpZ25JbihpbnB1dDogTG9naW5JbnB1dCkge1xyXG4gICAgZ2VuZXJhdGlvbi5jdXJyZW50Kys7XHJcbiAgICBjb25zdCBhdXRoZW50aWNhdGVkVXNlciA9IGF3YWl0IGF1dGhTZXJ2aWNlLmxvZ2luKGlucHV0KTtcclxuICAgIHNldFVzZXIoYXV0aGVudGljYXRlZFVzZXIpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICByZXR1cm4gYXV0aGVudGljYXRlZFVzZXI7XHJcbiAgfVxyXG4gIGFzeW5jIGZ1bmN0aW9uIHNpZ25VcChpbnB1dDogUmVnaXN0ZXJJbnB1dCkge1xyXG4gICAgZ2VuZXJhdGlvbi5jdXJyZW50Kys7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhdXRoU2VydmljZS5yZWdpc3RlcihpbnB1dCk7XHJcbiAgICBzZXRVc2VyKG51bGwpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG4gIH1cclxuICBhc3luYyBmdW5jdGlvbiBzaWduT3V0KCkge1xyXG4gICAgYXdhaXQgYXV0aFNlcnZpY2UubG9nb3V0KCk7XHJcbiAgICBnZW5lcmF0aW9uLmN1cnJlbnQrKztcclxuICAgIHNldFVzZXIobnVsbCk7XHJcbiAgfVxyXG4gIGZ1bmN0aW9uIGhhc1JvbGUoLi4ucm9sZXM6IFVzZXJSb2xlW10pIHtcclxuICAgIHJldHVybiAhIXVzZXIgJiYgcm9sZXMuaW5jbHVkZXModXNlci5yb2xlKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8QXV0aENvbnRleHQuUHJvdmlkZXJcclxuICAgICAgdmFsdWU9e3tcclxuICAgICAgICB1c2VyLFxyXG4gICAgICAgIGxvYWRpbmcsXHJcbiAgICAgICAgZXJyb3IsXHJcbiAgICAgICAgcmVmcmVzaCxcclxuICAgICAgICBzaWduSW4sXHJcbiAgICAgICAgc2lnblVwLFxyXG4gICAgICAgIHNpZ25PdXQsXHJcbiAgICAgICAgaGFzUm9sZSxcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59XHJcbiJdfQ==