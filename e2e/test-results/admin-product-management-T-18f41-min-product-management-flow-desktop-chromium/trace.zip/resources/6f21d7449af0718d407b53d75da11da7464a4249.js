import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Orders/components/OrdersShell.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrdersShell.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.orders;
export function OrdersShell({ details = false, children, refresh, loading }) {
	_s();
	const title = details ? t.detailsTitle : t.title;
	useEffect(() => {
		const previous = document.title;
		document.title = `${title} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, [title]);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-[1200px] space-y-8",
			children: [
				details && /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.orders,
					className: "text-sm font-medium text-fg-link hover:text-fg-link",
					children: ["← ", t.back]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title text-fg",
						children: title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: details ? t.snapshot : t.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: refresh,
						disabled: loading,
						className: "auth-secondary ",
						children: details ? t.refreshDetails : t.refresh
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this),
				children
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_s(OrdersShell, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = OrdersShell;
var _c;
$RefreshReg$(_c, "OrdersShell");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Orders/components/OrdersShell.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrdersShell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrdersShell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Orders/components/OrdersShell.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUM7QUFDMUMsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjs7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsWUFBWSxFQUMxQixVQUFVLE9BQ1YsVUFDQSxTQUNBLFdBTUM7O0NBQ0QsTUFBTSxRQUFRLFVBQVUsRUFBRSxlQUFlLEVBQUU7Q0FDM0MsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLFNBQVM7RUFDMUIsU0FBUyxRQUFRLEdBQUcsTUFBTSxLQUFLLGFBQWEsT0FBTztFQUNuRCxhQUFhO0dBQ1gsU0FBUyxRQUFRO0VBQ25CO0NBQ0YsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUNWLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0csV0FDQyx3QkFBQyxNQUFEO0tBQ0UsSUFBSSxPQUFPO0tBQ1gsV0FBVTtlQUZaLENBR0MsTUFDUyxFQUFFLElBQ047Ozs7OztJQUVSLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCO0tBQVU7Ozs7ZUFDakQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsVUFBVSxFQUFFLFdBQVcsRUFBRTtLQUN6Qjs7OzthQUNBOzs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxTQUFTO01BQ1QsVUFBVTtNQUNWLFdBQVU7Z0JBRVQsVUFBVSxFQUFFLGlCQUFpQixFQUFFO0tBQzFCOzs7O2FBQ0w7Ozs7OztJQUNKO0dBQ0U7Ozs7OztDQUNEOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk9yZGVyc1NoZWxsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLm9yZGVycztcclxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyc1NoZWxsKHtcclxuICBkZXRhaWxzID0gZmFsc2UsXHJcbiAgY2hpbGRyZW4sXHJcbiAgcmVmcmVzaCxcclxuICBsb2FkaW5nLFxyXG59OiB7XHJcbiAgZGV0YWlscz86IGJvb2xlYW47XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxuICByZWZyZXNoOiAoKSA9PiB2b2lkO1xyXG4gIGxvYWRpbmc6IGJvb2xlYW47XHJcbn0pIHtcclxuICBjb25zdCB0aXRsZSA9IGRldGFpbHMgPyB0LmRldGFpbHNUaXRsZSA6IHQudGl0bGU7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHByZXZpb3VzID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICBkb2N1bWVudC50aXRsZSA9IGAke3RpdGxlfSB8ICR7dHJhbnNsYXRpb25zLmNvbW1vbi5zdG9yZU5hbWV9YDtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGRvY3VtZW50LnRpdGxlID0gcHJldmlvdXM7XHJcbiAgICB9O1xyXG4gIH0sIFt0aXRsZV0pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LVsxMjAwcHhdIHNwYWNlLXktOFwiPlxyXG4gICAgICAgIHtkZXRhaWxzICYmIChcclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMub3JkZXJzfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICAmbGFycjsge3QuYmFja31cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+e3RpdGxlfTwvaDE+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAge2RldGFpbHMgPyB0LnNuYXBzaG90IDogdC5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtyZWZyZXNofVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnkgXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2RldGFpbHMgPyB0LnJlZnJlc2hEZXRhaWxzIDogdC5yZWZyZXNofVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==