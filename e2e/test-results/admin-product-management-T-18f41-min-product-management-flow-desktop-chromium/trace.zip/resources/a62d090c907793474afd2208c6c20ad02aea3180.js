import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Home/components/HomeProductSection.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { CatalogProductCard } from "/src/pages/Products/components/CatalogProductCard.tsx";
import { EmptyState } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeProductSection.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function HomeProductSection({ products, title }) {
	return /* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "mb-6 flex items-end justify-between gap-4",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-xl font-semibold tracking-tight text-fg md:text-2xl",
			children: title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(Link, {
			to: ROUTES.products,
			className: "shrink-0 py-2 text-sm font-medium text-fg-link",
			children: [translations.storefront.viewAll, " →"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 7
	}, this), !products.length ? /* @__PURE__ */ _jsxDEV(EmptyState, { title: translations.storefront.empty }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 9
	}, this) : /* @__PURE__ */ _jsxDEV("div", {
		className: "grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-6 xl:grid-cols-4",
		children: products.map((product) => /* @__PURE__ */ _jsxDEV(CatalogProductCard, { product }, product.productID, false, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 13
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_c = HomeProductSection;
var _c;
$RefreshReg$(_c, "HomeProductSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Home/components/HomeProductSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeProductSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeProductSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/components/HomeProductSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUV2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLGtCQUFrQjs7O0FBQzNCLE9BQU8sU0FBUyxtQkFBbUIsRUFDakMsVUFDQSxTQUlDO0NBQ0QsT0FDRSx3QkFBQyxXQUFELGFBQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQ1g7RUFDQzs7OztZQUNKLHdCQUFDLE1BQUQ7R0FDRSxJQUFJLE9BQU87R0FDWCxXQUFVO2FBRlosQ0FJRyxhQUFhLFdBQVcsU0FBUSxJQUM3Qjs7Ozs7VUFDSDs7Ozs7V0FDSixDQUFDLFNBQVMsU0FDVCx3QkFBQyxZQUFELEVBQVksT0FBTyxhQUFhLFdBQVcsTUFBUTs7OztZQUVuRCx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNaLFNBQVMsS0FBSyxZQUNiLHdCQUFDLG9CQUFELEVBQXFELFFBQVUsR0FBdEMsUUFBUTs7OztTQUE4QixDQUNoRTtDQUNFOzs7O1NBRUE7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZVByb2R1Y3RTZWN0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9wcm9kdWN0LnR5cGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgQ2F0YWxvZ1Byb2R1Y3RDYXJkIH0gZnJvbSAnLi4vLi4vLi4vUHJvZHVjdHMvY29tcG9uZW50cy9DYXRhbG9nUHJvZHVjdENhcmQnO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmV4cG9ydCBmdW5jdGlvbiBIb21lUHJvZHVjdFNlY3Rpb24oe1xyXG4gIHByb2R1Y3RzLFxyXG4gIHRpdGxlLFxyXG59OiB7XHJcbiAgcHJvZHVjdHM6IFByb2R1Y3RbXTtcclxuICB0aXRsZTogc3RyaW5nO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWZnIG1kOnRleHQtMnhsXCI+XHJcbiAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgPC9oMj5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5wcm9kdWN0c31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0cmFuc2xhdGlvbnMuc3RvcmVmcm9udC52aWV3QWxsfSAmcmFycjtcclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7IXByb2R1Y3RzLmxlbmd0aCA/IChcclxuICAgICAgICA8RW1wdHlTdGF0ZSB0aXRsZT17dHJhbnNsYXRpb25zLnN0b3JlZnJvbnQuZW1wdHl9IC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIG1kOmdyaWQtY29scy0zIG1kOmdhcC02IHhsOmdyaWQtY29scy00XCI+XHJcbiAgICAgICAgICB7cHJvZHVjdHMubWFwKChwcm9kdWN0KSA9PiAoXHJcbiAgICAgICAgICAgIDxDYXRhbG9nUHJvZHVjdENhcmQga2V5PXtwcm9kdWN0LnByb2R1Y3RJRH0gcHJvZHVjdD17cHJvZHVjdH0gLz5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19