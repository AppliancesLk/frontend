import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { useNavigate, Link, generatePath } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { formatDate } from "/src/utils/date.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { RepairStatusBadge } from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function CustomerRepairsTable({ repairs }) {
	_s();
	const navigate = useNavigate();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "overflow-hidden rounded-md border border-line bg-surface",
		children: /* @__PURE__ */ _jsxDEV("table", {
			className: "ui-table ui-card-table customer-repairs-table",
			children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
				/* @__PURE__ */ _jsxDEV("th", { children: "Reference" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("th", { children: "Device" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("th", { children: "Status" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("th", { children: "Updated" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("th", { children: /* @__PURE__ */ _jsxDEV("span", {
					className: "sr-only",
					children: "View repair"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: repairs.map((repair) => {
				const url = generatePath(ROUTES.repairDetail, { id: repair.id });
				return /* @__PURE__ */ _jsxDEV("tr", {
					className: "cursor-pointer",
					onClick: (event) => {
						if (!event.target.closest("a")) navigate(url);
					},
					children: [
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": "Reference",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: /* @__PURE__ */ _jsxDEV(Link, {
									className: "font-semibold tabular-nums text-fg-link",
									to: url,
									children: repair.reference
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 37,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": "Device",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value flex items-start gap-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "hidden h-9 w-9 shrink-0 items-center justify-center rounded-full bg-subtle lg:flex",
									children: /* @__PURE__ */ _jsxDEV(Icon, {
										name: "appliance",
										className: "h-5 w-5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 48,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 47,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-medium text-fg",
									children: [
										repair.device.brand,
										" ",
										repair.device.model
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 line-clamp-1 max-w-xs text-xs text-fg-muted",
									children: repair.problemDescription
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 54,
									columnNumber: 23
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": "Status",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: /* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status: repair.status }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": "Updated",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value text-xs text-fg-muted",
								children: /* @__PURE__ */ _jsxDEV("time", {
									dateTime: repair.updatedAt,
									children: formatDate(repair.updatedAt)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": "",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value text-fg-muted",
								"aria-hidden": "true",
								children: "›"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 17
						}, this)
					]
				}, repair.id, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 15
				}, this);
			}) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_s(CustomerRepairsTable, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
	return [useNavigate];
});
_c = CustomerRepairsTable;
var _c;
$RefreshReg$(_c, "CustomerRepairsTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/components/CustomerRepairsTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLE1BQU0sb0JBQW9CO0FBQ2hELFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGNBQWM7QUFFdkIsU0FBUyx5QkFBeUI7Ozs7QUFDbEMsT0FBTyxTQUFTLHFCQUFxQixFQUFFLFdBQXdDOztDQUM3RSxNQUFNLFdBQVcsWUFBWTtDQUM3QixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsU0FBRDtHQUFPLFdBQVU7YUFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtJQUNFLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7OztJQUNqQix3QkFBQyxNQUFELFlBQUksU0FBVTs7Ozs7SUFDZCx3QkFBQyxNQUFELFlBQUksU0FBVTs7Ozs7SUFDZCx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7SUFDZix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBVTtJQUFpQjs7OzthQUN6Qzs7Ozs7R0FDRjs7OztZQUNDOzs7O2FBQ1Asd0JBQUMsU0FBRCxZQUNHLFFBQVEsS0FBSyxXQUFXO0lBQ3ZCLE1BQU0sTUFBTSxhQUFhLE9BQU8sY0FBYyxFQUFFLElBQUksT0FBTyxHQUFHLENBQUM7SUFDL0QsT0FDRSx3QkFBQyxNQUFEO0tBRUUsV0FBVTtLQUNWLFVBQVUsVUFBVTtNQUNsQixJQUFJLENBQUUsTUFBTSxPQUF1QixRQUFRLEdBQUcsR0FDNUMsU0FBUyxHQUFHO0tBQ2hCO2VBTkY7TUFRRSx3QkFBQyxNQUFEO09BQUksY0FBVztpQkFDYix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxNQUFEO1NBQ0UsV0FBVTtTQUNWLElBQUk7bUJBRUgsT0FBTztRQUNKOzs7OztPQUNIOzs7OztNQUNIOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxjQUFXO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2Qsd0JBQUMsTUFBRDtVQUFNLE1BQUs7VUFBWSxXQUFVO1NBQVc7Ozs7O1FBQ3hDOzs7O2tCQUNOLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUNHLE9BQU8sT0FBTztVQUFNO1VBQUUsT0FBTyxPQUFPO1NBQ3BDOzs7OztrQkFDSCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixPQUFPO1FBQ1A7Ozs7Z0JBQ0E7Ozs7Z0JBQ0Y7Ozs7OztNQUNIOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxjQUFXO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLG1CQUFELEVBQW1CLFFBQVEsT0FBTyxPQUFTOzs7OztPQUN4Qzs7Ozs7TUFDSDs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksY0FBVztpQkFDYix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxRQUFEO1NBQU0sVUFBVSxPQUFPO21CQUNwQixXQUFXLE9BQU8sU0FBUztRQUN4Qjs7Ozs7T0FDSDs7Ozs7TUFDSDs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksY0FBVztpQkFDYix3QkFBQyxPQUFEO1FBQ0UsV0FBVTtRQUNWLGVBQVk7a0JBQ2I7T0FFSTs7Ozs7TUFDSDs7Ozs7S0FDRjtPQXBERyxPQUFPOzs7O1dBb0RWO0dBRVIsQ0FBQyxFQUNJOzs7O1dBQ0Y7Ozs7OztDQUNKOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyUmVwYWlyc1RhYmxlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTGluaywgZ2VuZXJhdGVQYXRoIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IGZvcm1hdERhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9kYXRlJztcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHR5cGUgeyBSZXBhaXJUaWNrZXQgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9yZXBhaXIudHlwZXMnO1xyXG5pbXBvcnQgeyBSZXBhaXJTdGF0dXNCYWRnZSB9IGZyb20gJy4uLy4uLy4uL0FkbWluL1JlcGFpcnMvY29tcG9uZW50cy9SZXBhaXJTdGF0dXNCYWRnZSc7XHJcbmV4cG9ydCBmdW5jdGlvbiBDdXN0b21lclJlcGFpcnNUYWJsZSh7IHJlcGFpcnMgfTogeyByZXBhaXJzOiBSZXBhaXJUaWNrZXRbXSB9KSB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlXCI+XHJcbiAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ1aS10YWJsZSB1aS1jYXJkLXRhYmxlIGN1c3RvbWVyLXJlcGFpcnMtdGFibGVcIj5cclxuICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgIDx0aD5SZWZlcmVuY2U8L3RoPlxyXG4gICAgICAgICAgICA8dGg+RGV2aWNlPC90aD5cclxuICAgICAgICAgICAgPHRoPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgIDx0aD5VcGRhdGVkPC90aD5cclxuICAgICAgICAgICAgPHRoPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5WaWV3IHJlcGFpcjwvc3Bhbj5cclxuICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICB7cmVwYWlycy5tYXAoKHJlcGFpcikgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB1cmwgPSBnZW5lcmF0ZVBhdGgoUk9VVEVTLnJlcGFpckRldGFpbCwgeyBpZDogcmVwYWlyLmlkIH0pO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAga2V5PXtyZXBhaXIuaWR9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKCEoZXZlbnQudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5jbG9zZXN0KCdhJykpXHJcbiAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUodXJsKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9XCJSZWZlcmVuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0bz17dXJsfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZXBhaXIucmVmZXJlbmNlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9XCJEZXZpY2VcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gaC05IHctOSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXN1YnRsZSBsZzpmbGV4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYXBwbGlhbmNlXCIgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZXBhaXIuZGV2aWNlLmJyYW5kfSB7cmVwYWlyLmRldmljZS5tb2RlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgbGluZS1jbGFtcC0xIG1heC13LXhzIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVwYWlyLnByb2JsZW1EZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9XCJTdGF0dXNcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJlcGFpclN0YXR1c0JhZGdlIHN0YXR1cz17cmVwYWlyLnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9XCJVcGRhdGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktY2VsbC12YWx1ZSB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGltZSBkYXRlVGltZT17cmVwYWlyLnVwZGF0ZWRBdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShyZXBhaXIudXBkYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3RpbWU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlIHRleHQtZmctbXV0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICDigLpcclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L3Rib2R5PlxyXG4gICAgICA8L3RhYmxlPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=