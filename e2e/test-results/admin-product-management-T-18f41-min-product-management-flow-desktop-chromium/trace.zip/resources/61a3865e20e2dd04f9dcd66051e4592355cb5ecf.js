import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Loyalty/index.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import { generatePath, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { formatDate } from "/src/utils/date.ts";
import { commerceText as t } from "/src/utils/commerceText.ts";
import { useLoyaltyPage } from "/src/pages/Customer/Loyalty/hooks/useLoyaltyPage.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Loyalty/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function LoyaltyPage() {
	_s();
	const page = useLoyaltyPage();
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto max-w-3xl px-4 py-8 sm:px-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title",
				children: t.loyalty
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-sm leading-6 text-fg-secondary",
				children: t.loyaltyDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "secondary",
				className: "mt-5",
				onClick: page.refresh,
				busy: page.loading,
				children: t.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			page.loading && /* @__PURE__ */ _jsxDEV(LoadingState, { label: t.loyalty }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 24
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "ui-alert ui-tone-warning mt-6",
				children: page.error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this),
			page.data && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "mt-6 rounded-lg border border-line bg-primary-subtle p-6 sm:p-8",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-medium text-fg-secondary",
						children: t.loyaltyBalance
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 font-display text-4xl font-semibold text-fg-link",
						children: formatCurrency(page.data.balance)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 13
					}, this),
					!page.data.entries.length && /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm text-fg-secondary",
						children: t.noCredit
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.products,
						className: "ui-button ui-button-primary mt-5",
						children: "Continue shopping"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("section", {
				className: "mt-6 rounded-lg border border-line bg-surface p-5 sm:p-6",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl font-semibold",
					children: t.recentActivity
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 13
				}, this), !page.data.entries.length ? /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-4 text-sm text-fg-muted",
					children: t.noActivity
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV("ul", {
					className: "mt-4 divide-y divide-line",
					children: page.data.entries.map((entry) => /* @__PURE__ */ _jsxDEV("li", {
						className: "flex flex-wrap items-start justify-between gap-3 py-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm font-medium",
								children: entry.kind === "EARN" ? t.earned : entry.kind === "REFUND" ? t.refunded : t.redeemed
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 23
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								className: "mt-1 block text-sm text-fg-link underline",
								to: generatePath(ROUTES.orderDetail, { id: entry.orderId }),
								children: ["Order #", entry.orderId.slice(0, 8).toUpperCase()]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 23
							}, this),
							/* @__PURE__ */ _jsxDEV("time", {
								className: "mt-1 block text-xs text-fg-muted",
								dateTime: entry.createdAt,
								children: formatDate(entry.createdAt)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 23
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: `font-semibold ${entry.kind === "REDEEM" ? "text-fg" : "text-success"}`,
							children: [entry.kind === "REDEEM" ? "−" : "+", formatCurrency(entry.amount.replace(/^-/, ""))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 21
						}, this)]
					}, entry.id, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 19
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_s(LoyaltyPage, "w0FJ2eP2t+yhgZbHxbiAJXosNbU=", false, function() {
	return [useLoyaltyPage];
});
_c = LoyaltyPage;
var _c;
$RefreshReg$(_c, "LoyaltyPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Loyalty/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Loyalty/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Loyalty/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Loyalty/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjLFlBQVk7QUFDbkMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsY0FBYztBQUN2QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGdCQUFnQixTQUFTO0FBQ2xDLFNBQVMsc0JBQXNCOzs7O0FBQy9CLGVBQWUsU0FBUyxjQUFjOztDQUNwQyxNQUFNLE9BQU8sZUFBZTtDQUM1QixPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCO0dBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBaUIsRUFBRTtHQUFZOzs7OztHQUM3Qyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNWLEVBQUU7R0FDRjs7Ozs7R0FDSCx3QkFBQyxRQUFEO0lBQ0UsU0FBUTtJQUNSLFdBQVU7SUFDVixTQUFTLEtBQUs7SUFDZCxNQUFNLEtBQUs7Y0FFVixFQUFFO0dBQ0c7Ozs7O0dBQ1AsS0FBSyxXQUFXLHdCQUFDLGNBQUQsRUFBYyxPQUFPLEVBQUUsUUFBVTs7Ozs7R0FDakQsS0FBSyxTQUNKLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVEsV0FBVTtjQUN2QixLQUFLO0dBQ0w7Ozs7O0dBRUosS0FBSyxRQUNKLGdEQUNFLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsRUFBRTtLQUNEOzs7OztLQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLGVBQWUsS0FBSyxLQUFLLE9BQU87S0FDaEM7Ozs7O0tBQ0YsQ0FBQyxLQUFLLEtBQUssUUFBUSxVQUNsQix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBa0MsRUFBRTtLQUFZOzs7OztLQUUvRCx3QkFBQyxNQUFEO01BQ0UsSUFBSSxPQUFPO01BQ1gsV0FBVTtnQkFDWDtLQUVLOzs7OztJQUNDOzs7OzthQUNULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFtQjs7OztjQUMzRCxDQUFDLEtBQUssS0FBSyxRQUFRLFNBQ2xCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCLEVBQUU7SUFBYzs7OztlQUUzRCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLEtBQUssS0FBSyxRQUFRLEtBQUssVUFDdEIsd0JBQUMsTUFBRDtNQUVFLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsTUFBTSxTQUFTLFNBQ1osRUFBRSxTQUNGLE1BQU0sU0FBUyxXQUNiLEVBQUUsV0FDRixFQUFFO09BQ1A7Ozs7O09BQ0gsd0JBQUMsTUFBRDtRQUNFLFdBQVU7UUFDVixJQUFJLGFBQWEsT0FBTyxhQUFhLEVBQ25DLElBQUksTUFBTSxRQUNaLENBQUM7a0JBSkgsQ0FLQyxXQUNTLE1BQU0sUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUMxQzs7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUNFLFdBQVU7UUFDVixVQUFVLE1BQU07a0JBRWYsV0FBVyxNQUFNLFNBQVM7T0FDdkI7Ozs7O01BQ0g7Ozs7Z0JBQ0wsd0JBQUMsUUFBRDtPQUNFLFdBQVcsaUJBQWlCLE1BQU0sU0FBUyxXQUFXLFlBQVk7aUJBRHBFLENBR0csTUFBTSxTQUFTLFdBQVcsTUFBTSxLQUNoQyxlQUFlLE1BQU0sT0FBTyxRQUFRLE1BQU0sRUFBRSxDQUFDLENBQzFDOzs7OztjQUNKO1FBaENHLE1BQU07Ozs7WUFnQ1QsQ0FDTDtJQUNDOzs7O1lBRUM7Ozs7O1dBQ1Q7Ozs7O0VBRUE7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZW5lcmF0ZVBhdGgsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY3VycmVuY3knO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IGNvbW1lcmNlVGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY29tbWVyY2VUZXh0JztcclxuaW1wb3J0IHsgdXNlTG95YWx0eVBhZ2UgfSBmcm9tICcuL2hvb2tzL3VzZUxveWFsdHlQYWdlJztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTG95YWx0eVBhZ2UoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZUxveWFsdHlQYWdlKCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctM3hsIHB4LTQgcHktOCBzbTpweC02XCI+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlXCI+e3QubG95YWx0eX08L2gxPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAge3QubG95YWx0eURlc2NyaXB0aW9ufVxyXG4gICAgICA8L3A+XHJcbiAgICAgIDxCdXR0b25cclxuICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcclxuICAgICAgICBjbGFzc05hbWU9XCJtdC01XCJcclxuICAgICAgICBvbkNsaWNrPXtwYWdlLnJlZnJlc2h9XHJcbiAgICAgICAgYnVzeT17cGFnZS5sb2FkaW5nfVxyXG4gICAgICA+XHJcbiAgICAgICAge3QucmVmcmVzaH1cclxuICAgICAgPC9CdXR0b24+XHJcbiAgICAgIHtwYWdlLmxvYWRpbmcgJiYgPExvYWRpbmdTdGF0ZSBsYWJlbD17dC5sb3lhbHR5fSAvPn1cclxuICAgICAge3BhZ2UuZXJyb3IgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtd2FybmluZyBtdC02XCI+XHJcbiAgICAgICAgICB7cGFnZS5lcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIHtwYWdlLmRhdGEgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtdC02IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXByaW1hcnktc3VidGxlIHAtNiBzbTpwLThcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICB7dC5sb3lhbHR5QmFsYW5jZX1cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyBmb250LWRpc3BsYXkgdGV4dC00eGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnLWxpbmtcIj5cclxuICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kocGFnZS5kYXRhLmJhbGFuY2UpfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIHshcGFnZS5kYXRhLmVudHJpZXMubGVuZ3RoICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj57dC5ub0NyZWRpdH08L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89e1JPVVRFUy5wcm9kdWN0c31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgbXQtNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDb250aW51ZSBzaG9wcGluZ1xyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtdC02IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IHNtOnAtNlwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+e3QucmVjZW50QWN0aXZpdHl9PC9oMj5cclxuICAgICAgICAgICAgeyFwYWdlLmRhdGEuZW50cmllcy5sZW5ndGggPyAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5ub0FjdGl2aXR5fTwvcD5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibXQtNCBkaXZpZGUteSBkaXZpZGUtbGluZVwiPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UuZGF0YS5lbnRyaWVzLm1hcCgoZW50cnkpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtlbnRyeS5pZH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcHktNFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW50cnkua2luZCA9PT0gJ0VBUk4nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0LmVhcm5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZW50cnkua2luZCA9PT0gJ1JFRlVORCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdC5yZWZ1bmRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0LnJlZGVlbWVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB0ZXh0LXNtIHRleHQtZmctbGluayB1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0bz17Z2VuZXJhdGVQYXRoKFJPVVRFUy5vcmRlckRldGFpbCwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBlbnRyeS5vcmRlcklkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgT3JkZXIgI3tlbnRyeS5vcmRlcklkLnNsaWNlKDAsIDgpLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGltZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVUaW1lPXtlbnRyeS5jcmVhdGVkQXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKGVudHJ5LmNyZWF0ZWRBdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RpbWU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtc2VtaWJvbGQgJHtlbnRyeS5raW5kID09PSAnUkVERUVNJyA/ICd0ZXh0LWZnJyA6ICd0ZXh0LXN1Y2Nlc3MnfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VudHJ5LmtpbmQgPT09ICdSRURFRU0nID8gJ+KIkicgOiAnKyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koZW50cnkuYW1vdW50LnJlcGxhY2UoL14tLywgJycpKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl19