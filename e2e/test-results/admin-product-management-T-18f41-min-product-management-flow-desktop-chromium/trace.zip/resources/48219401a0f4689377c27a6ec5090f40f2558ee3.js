import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Banners/components/BannerSectionEditor.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { saveBanner, uploadBannerImage, bannerImageUrl } from "/src/services/bannerService.ts";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/components/BannerSectionEditor.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.storefront;
const fields = [
	"imageUrl",
	"alt",
	"title",
	"description",
	"buttonText",
	"href"
];
const labels = {
	imageUrl: t.image,
	alt: t.alt,
	title: t.headline,
	description: t.description,
	buttonText: t.button,
	href: t.destination
};
export function BannerSectionEditor({ section }) {
	_s();
	const [draft, setDraft] = useState(section);
	const [saving, setSaving] = useState(false);
	const [uploading, setUploading] = useState(null);
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const busy = saving || uploading !== null;
	const limit = section.position === "top" ? 4 : 1;
	function update(index, field, value) {
		setMessage("");
		setDraft((current) => ({
			...current,
			slides: current.slides.map((slide, i) => i === index ? {
				...slide,
				[field]: value
			} : slide)
		}));
	}
	async function upload(index, file) {
		if (!file) return;
		setError("");
		setMessage("");
		if (file.size > 5 * 1024 * 1024 || ![
			"image/png",
			"image/jpeg",
			"image/webp"
		].includes(file.type)) {
			setError(t.uploadError);
			return;
		}
		setUploading(index);
		try {
			update(index, "imageUrl", await uploadBannerImage(file));
		} catch {
			setError(t.uploadError);
		} finally {
			setUploading(null);
		}
	}
	async function save() {
		setSaving(true);
		setError("");
		setMessage("");
		try {
			const saved = await saveBanner(draft.position, {
				visible: draft.visible,
				slides: draft.slides
			});
			setDraft(saved);
			setMessage(t.saved);
		} catch {
			setError(t.saveError);
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: (event) => {
			event.preventDefault();
			void save();
		},
		className: "rounded-md border border-line bg-surface p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("fieldset", {
				disabled: busy,
				className: "min-w-0 ",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-semibold text-fg",
							children: t.positions[draft.position]
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-3 text-sm font-medium text-fg-secondary",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								className: "h-5 w-5 accent-primary",
								checked: draft.visible,
								onChange: (event) => {
									setDraft({
										...draft,
										visible: event.target.checked
									});
									setMessage("");
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 13
							}, this), t.visible]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm leading-6 text-fg-muted",
						children: t.imageHelp
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 9
					}, this),
					!draft.slides.length && /* @__PURE__ */ _jsxDEV("p", {
						className: "my-5 text-sm text-fg-muted",
						children: ["0 / ", limit]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-5 space-y-6",
						children: draft.slides.map((slide, index) => /* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-md border border-line bg-page p-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-4 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-medium",
										children: [
											index + 1,
											" / ",
											limit
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "rounded-sm px-3 py-2 text-sm text-danger hover:bg-danger-bg",
										onClick: () => {
											setDraft({
												...draft,
												slides: draft.slides.filter((_, i) => i !== index)
											});
											setMessage("");
										},
										children: t.remove
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 15
								}, this),
								slide.imageUrl && /* @__PURE__ */ _jsxDEV(ProductImage, {
									src: bannerImageUrl(slide.imageUrl),
									alt: slide.alt || t.image,
									className: "mb-4 aspect-[8/3] w-full rounded-sm bg-surface"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("label", {
									className: "mb-5 block text-sm font-medium text-fg-secondary",
									children: [uploading === index ? t.uploading : t.upload, /* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/png,image/jpeg,image/webp",
										className: "mt-2 block w-full text-sm file:mr-3 file:rounded-sm file:border-0 file:bg-primary-subtle file:px-4 file:py-2 file:text-fg-link",
										onChange: (event) => {
											void upload(index, event.target.files?.[0]);
											event.target.value = "";
										}
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid gap-4 sm:grid-cols-2",
									children: fields.map((field) => /* @__PURE__ */ _jsxDEV("label", {
										className: `block text-sm font-medium text-fg-secondary ${field === "description" || field === "imageUrl" ? "sm:col-span-2" : ""}`,
										children: [labels[field], /* @__PURE__ */ _jsxDEV("input", {
											required: field === "imageUrl" || field === "alt" || field === "href" && Boolean(slide.buttonText) || field === "buttonText" && Boolean(slide.href),
											maxLength: field === "alt" ? 200 : field === "title" ? 100 : field === "description" ? 300 : field === "buttonText" ? 40 : 2048,
											value: slide[field],
											onChange: (event) => update(index, field, event.target.value),
											className: "ui-field mt-2 min-h-11 w-full rounded-sm border border-line bg-surface px-3 text-sm font-normal focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 166,
											columnNumber: 21
										}, this)]
									}, field, true, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 15
								}, this),
								draft.slides.length > 1 && /* @__PURE__ */ _jsxDEV("div", {
									className: "mt-4 flex gap-3",
									children: [-1, 1].map((direction) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: index + direction < 0 || index + direction >= draft.slides.length,
										"aria-label": direction < 0 ? "Move image up" : "Move image down",
										className: "ui-button ui-button-secondary rounded-sm border border-line px-4 py-2 disabled:text-fg-disabled",
										onClick: () => {
											const slides = [...draft.slides];
											[slides[index], slides[index + direction]] = [slides[index + direction], slides[index]];
											setDraft({
												...draft,
												slides
											});
											setMessage("");
										},
										children: direction < 0 ? "↑" : "↓"
									}, direction, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 17
								}, this)
							]
						}, index, true, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-5 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							disabled: draft.slides.length >= limit,
							onClick: () => {
								setDraft({
									...draft,
									slides: [...draft.slides, {
										imageUrl: "",
										alt: "",
										title: "",
										description: "",
										buttonText: "",
										href: ""
									}]
								});
								setMessage("");
							},
							className: "ui-button ui-button-secondary rounded-sm border border-line px-4 py-2 text-sm font-medium disabled:text-fg-disabled",
							children: [
								t.addSlide,
								" (",
								draft.slides.length,
								"/",
								limit,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "ui-button ui-button-primary rounded-sm bg-primary px-4 py-2 text-sm font-medium text-primary-on hover:bg-primary-hover",
							children: [saving && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 24
							}, this), saving ? t.saving : t.save]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 250,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mt-4 rounded-sm bg-danger-bg p-3 text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 257,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "mt-4 rounded-sm bg-success-bg p-3 text-sm text-success",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 265,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 87,
		columnNumber: 5
	}, this);
}
_s(BannerSectionEditor, "r9rUWfH47e3C1C/19tSR538gRjE=");
_c = BannerSectionEditor;
var _c;
$RefreshReg$(_c, "BannerSectionEditor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Banners/components/BannerSectionEditor.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/components/BannerSectionEditor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/components/BannerSectionEditor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/components/BannerSectionEditor.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBS3pCLFNBQ0UsWUFDQSxtQkFDQSxzQkFDSztBQUNQLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9COzs7O0FBQzdCLE1BQU0sSUFBSSxhQUFhO0FBRXZCLE1BQU0sU0FBUztDQUNiO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBQ0EsTUFBTSxTQUFTO0NBQ2IsVUFBVSxFQUFFO0NBQ1osS0FBSyxFQUFFO0NBQ1AsT0FBTyxFQUFFO0NBQ1QsYUFBYSxFQUFFO0NBQ2YsWUFBWSxFQUFFO0NBQ2QsTUFBTSxFQUFFO0FBQ1Y7QUFDQSxPQUFPLFNBQVMsb0JBQW9CLEVBQUUsV0FBdUM7O0NBQzNFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxPQUFPO0NBQzFDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixJQUFJO0NBQzlELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sT0FBTyxVQUFVLGNBQWM7Q0FDckMsTUFBTSxRQUFRLFFBQVEsYUFBYSxRQUFRLElBQUk7Q0FDL0MsU0FBUyxPQUFPLE9BQWUsT0FBMEIsT0FBZTtFQUN0RSxXQUFXLEVBQUU7RUFDYixVQUFVLGFBQWE7R0FDckIsR0FBRztHQUNILFFBQVEsUUFBUSxPQUFPLEtBQUssT0FBTyxNQUNqQyxNQUFNLFFBQVE7SUFBRSxHQUFHO0tBQVEsUUFBUTtHQUFNLElBQUksS0FDL0M7RUFDRixFQUFFO0NBQ0o7Q0FDQSxlQUFlLE9BQU8sT0FBZSxNQUFhO0VBQ2hELElBQUksQ0FBQyxNQUFNO0VBQ1gsU0FBUyxFQUFFO0VBQ1gsV0FBVyxFQUFFO0VBQ2IsSUFDRSxLQUFLLE9BQU8sSUFBSSxPQUFPLFFBQ3ZCLENBQUM7R0FBQztHQUFhO0dBQWM7RUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLElBQUksR0FDN0Q7R0FDQSxTQUFTLEVBQUUsV0FBVztHQUN0QjtFQUNGO0VBQ0EsYUFBYSxLQUFLO0VBQ2xCLElBQUk7R0FDRixPQUFPLE9BQU8sWUFBWSxNQUFNLGtCQUFrQixJQUFJLENBQUM7RUFDekQsUUFBUTtHQUNOLFNBQVMsRUFBRSxXQUFXO0VBQ3hCLFVBQVU7R0FDUixhQUFhLElBQUk7RUFDbkI7Q0FDRjtDQUNBLGVBQWUsT0FBTztFQUNwQixVQUFVLElBQUk7RUFDZCxTQUFTLEVBQUU7RUFDWCxXQUFXLEVBQUU7RUFDYixJQUFJO0dBQ0YsTUFBTSxRQUFRLE1BQU0sV0FBVyxNQUFNLFVBQVU7SUFDN0MsU0FBUyxNQUFNO0lBQ2YsUUFBUSxNQUFNO0dBQ2hCLENBQUM7R0FDRCxTQUFTLEtBQUs7R0FDZCxXQUFXLEVBQUUsS0FBSztFQUNwQixRQUFRO0dBQ04sU0FBUyxFQUFFLFNBQVM7RUFDdEIsVUFBVTtHQUNSLFVBQVUsS0FBSztFQUNqQjtDQUNGO0NBQ0EsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyxVQUFVO0dBQ25CLE1BQU0sZUFBZTtHQUNyQixLQUFLLEtBQUs7RUFDWjtFQUNBLFdBQVU7WUFMWjtHQU9FLHdCQUFDLFlBQUQ7SUFBVSxVQUFVO0lBQU0sV0FBVTtjQUFwQztLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsRUFBRSxVQUFVLE1BQU07TUFDakI7Ozs7Z0JBQ0osd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO1FBQ1YsU0FBUyxNQUFNO1FBQ2YsV0FBVyxVQUFVO1NBQ25CLFNBQVM7VUFBRSxHQUFHO1VBQU8sU0FBUyxNQUFNLE9BQU87U0FBUSxDQUFDO1NBQ3BELFdBQVcsRUFBRTtRQUNmO09BQ0Q7Ozs7aUJBQ0EsRUFBRSxPQUNFOzs7OztjQUNKOzs7Ozs7S0FDTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBd0MsRUFBRTtLQUFhOzs7OztLQUNuRSxDQUFDLE1BQU0sT0FBTyxVQUNiLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiLENBQTBDLFFBQUssS0FBUzs7Ozs7O0tBRTFELHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLE1BQU0sT0FBTyxLQUFLLE9BQU8sVUFDeEIsd0JBQUMsT0FBRDtPQUVFLFdBQVU7aUJBRlo7UUFJRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkO1dBQ0csUUFBUTtXQUFFO1dBQUk7VUFDYjs7Ozs7bUJBQ0osd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxXQUFVO1VBQ1YsZUFBZTtXQUNiLFNBQVM7WUFDUCxHQUFHO1lBQ0gsUUFBUSxNQUFNLE9BQU8sUUFBUSxHQUFHLE1BQU0sTUFBTSxLQUFLO1dBQ25ELENBQUM7V0FDRCxXQUFXLEVBQUU7VUFDZjtvQkFFQyxFQUFFO1NBQ0c7Ozs7aUJBQ0w7Ozs7OztRQUNKLE1BQU0sWUFDTCx3QkFBQyxjQUFEO1NBQ0UsS0FBSyxlQUFlLE1BQU0sUUFBUTtTQUNsQyxLQUFLLE1BQU0sT0FBTyxFQUFFO1NBQ3BCLFdBQVU7UUFDWDs7Ozs7UUFFSCx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDRyxjQUFjLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFDdkMsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxRQUFPO1VBQ1AsV0FBVTtVQUNWLFdBQVcsVUFBVTtXQUNuQixLQUFLLE9BQU8sT0FBTyxNQUFNLE9BQU8sUUFBUSxFQUFFO1dBQzFDLE1BQU0sT0FBTyxRQUFRO1VBQ3ZCO1NBQ0Q7Ozs7aUJBQ0k7Ozs7OztRQUNQLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLE9BQU8sS0FBSyxVQUNYLHdCQUFDLFNBQUQ7VUFFRSxXQUFXLCtDQUErQyxVQUFVLGlCQUFpQixVQUFVLGFBQWEsa0JBQWtCO29CQUZoSSxDQUlHLE9BQU8sUUFDUix3QkFBQyxTQUFEO1dBQ0UsVUFDRSxVQUFVLGNBQ1YsVUFBVSxTQUNULFVBQVUsVUFBVSxRQUFRLE1BQU0sVUFBVSxLQUM1QyxVQUFVLGdCQUFnQixRQUFRLE1BQU0sSUFBSTtXQUUvQyxXQUNFLFVBQVUsUUFDTixNQUNBLFVBQVUsVUFDUixNQUNBLFVBQVUsZ0JBQ1IsTUFDQSxVQUFVLGVBQ1IsS0FDQTtXQUVaLE9BQU8sTUFBTTtXQUNiLFdBQVcsVUFDVCxPQUFPLE9BQU8sT0FBTyxNQUFNLE9BQU8sS0FBSztXQUV6QyxXQUFVO1VBQ1g7Ozs7a0JBQ0k7WUE1QkE7Ozs7Z0JBNEJBLENBQ1I7UUFDRTs7Ozs7UUFDSixNQUFNLE9BQU8sU0FBUyxLQUNyQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLGNBQ1osd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFFTCxVQUNFLFFBQVEsWUFBWSxLQUNwQixRQUFRLGFBQWEsTUFBTSxPQUFPO1VBRXBDLGNBQ0UsWUFBWSxJQUFJLGtCQUFrQjtVQUVwQyxXQUFVO1VBQ1YsZUFBZTtXQUNiLE1BQU0sU0FBUyxDQUFDLEdBQUcsTUFBTSxNQUFNO1dBQy9CLENBQUMsT0FBTyxRQUFRLE9BQU8sUUFBUSxjQUFjLENBQzNDLE9BQU8sUUFBUSxZQUNmLE9BQU8sTUFDVDtXQUNBLFNBQVM7WUFBRSxHQUFHO1lBQU87V0FBTyxDQUFDO1dBQzdCLFdBQVcsRUFBRTtVQUNmO29CQUVDLFlBQVksSUFBSSxNQUFNO1NBQ2pCLEdBcEJEOzs7O2dCQW9CQyxDQUNUO1FBQ0U7Ozs7O09BRUo7U0F2R0U7Ozs7YUF1R0YsQ0FDTjtLQUNFOzs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVLE1BQU0sT0FBTyxVQUFVO09BQ2pDLGVBQWU7UUFDYixTQUFTO1NBQ1AsR0FBRztTQUNILFFBQVEsQ0FDTixHQUFHLE1BQU0sUUFDVDtVQUNFLFVBQVU7VUFDVixLQUFLO1VBQ0wsT0FBTztVQUNQLGFBQWE7VUFDYixZQUFZO1VBQ1osTUFBTTtTQUNSLENBQ0Y7UUFDRixDQUFDO1FBQ0QsV0FBVyxFQUFFO09BQ2Y7T0FDQSxXQUFVO2lCQXBCWjtRQXNCRyxFQUFFO1FBQVM7UUFBRyxNQUFNLE9BQU87UUFBTztRQUFFO1FBQU07T0FDckM7Ozs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO2lCQUFsQixDQUNHLFVBQVUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsT0FBUTs7OztpQkFDckMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUNqQjs7Ozs7Y0FDTDs7Ozs7O0lBQ0c7Ozs7OztHQUNULFNBQ0Msd0JBQUMsS0FBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO2NBRVQ7R0FDQTs7Ozs7R0FFSixXQUNDLHdCQUFDLEtBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtjQUVUO0dBQ0E7Ozs7O0VBRUQ7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJhbm5lclNlY3Rpb25FZGl0b3IudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBCYW5uZXJTZWN0aW9uLFxyXG4gIEJhbm5lclNsaWRlLFxyXG59IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL2Jhbm5lci50eXBlcyc7XHJcbmltcG9ydCB7XHJcbiAgc2F2ZUJhbm5lcixcclxuICB1cGxvYWRCYW5uZXJJbWFnZSxcclxuICBiYW5uZXJJbWFnZVVybCxcclxufSBmcm9tICcuLi8uLi8uLi8uLi9zZXJ2aWNlcy9iYW5uZXJTZXJ2aWNlJztcclxuaW1wb3J0IHsgUHJvZHVjdEltYWdlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJvZHVjdEltYWdlJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5zdG9yZWZyb250O1xyXG5cclxuY29uc3QgZmllbGRzID0gW1xyXG4gICdpbWFnZVVybCcsXHJcbiAgJ2FsdCcsXHJcbiAgJ3RpdGxlJyxcclxuICAnZGVzY3JpcHRpb24nLFxyXG4gICdidXR0b25UZXh0JyxcclxuICAnaHJlZicsXHJcbl0gYXMgY29uc3Q7XHJcbmNvbnN0IGxhYmVscyA9IHtcclxuICBpbWFnZVVybDogdC5pbWFnZSxcclxuICBhbHQ6IHQuYWx0LFxyXG4gIHRpdGxlOiB0LmhlYWRsaW5lLFxyXG4gIGRlc2NyaXB0aW9uOiB0LmRlc2NyaXB0aW9uLFxyXG4gIGJ1dHRvblRleHQ6IHQuYnV0dG9uLFxyXG4gIGhyZWY6IHQuZGVzdGluYXRpb24sXHJcbn07XHJcbmV4cG9ydCBmdW5jdGlvbiBCYW5uZXJTZWN0aW9uRWRpdG9yKHsgc2VjdGlvbiB9OiB7IHNlY3Rpb246IEJhbm5lclNlY3Rpb24gfSkge1xyXG4gIGNvbnN0IFtkcmFmdCwgc2V0RHJhZnRdID0gdXNlU3RhdGUoc2VjdGlvbik7XHJcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdXBsb2FkaW5nLCBzZXRVcGxvYWRpbmddID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IGJ1c3kgPSBzYXZpbmcgfHwgdXBsb2FkaW5nICE9PSBudWxsO1xyXG4gIGNvbnN0IGxpbWl0ID0gc2VjdGlvbi5wb3NpdGlvbiA9PT0gJ3RvcCcgPyA0IDogMTtcclxuICBmdW5jdGlvbiB1cGRhdGUoaW5kZXg6IG51bWJlciwgZmllbGQ6IGtleW9mIEJhbm5lclNsaWRlLCB2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICBzZXRNZXNzYWdlKCcnKTtcclxuICAgIHNldERyYWZ0KChjdXJyZW50KSA9PiAoe1xyXG4gICAgICAuLi5jdXJyZW50LFxyXG4gICAgICBzbGlkZXM6IGN1cnJlbnQuc2xpZGVzLm1hcCgoc2xpZGUsIGkpID0+XHJcbiAgICAgICAgaSA9PT0gaW5kZXggPyB7IC4uLnNsaWRlLCBbZmllbGRdOiB2YWx1ZSB9IDogc2xpZGUsXHJcbiAgICAgICksXHJcbiAgICB9KSk7XHJcbiAgfVxyXG4gIGFzeW5jIGZ1bmN0aW9uIHVwbG9hZChpbmRleDogbnVtYmVyLCBmaWxlPzogRmlsZSkge1xyXG4gICAgaWYgKCFmaWxlKSByZXR1cm47XHJcbiAgICBzZXRFcnJvcignJyk7XHJcbiAgICBzZXRNZXNzYWdlKCcnKTtcclxuICAgIGlmIChcclxuICAgICAgZmlsZS5zaXplID4gNSAqIDEwMjQgKiAxMDI0IHx8XHJcbiAgICAgICFbJ2ltYWdlL3BuZycsICdpbWFnZS9qcGVnJywgJ2ltYWdlL3dlYnAnXS5pbmNsdWRlcyhmaWxlLnR5cGUpXHJcbiAgICApIHtcclxuICAgICAgc2V0RXJyb3IodC51cGxvYWRFcnJvcik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldFVwbG9hZGluZyhpbmRleCk7XHJcbiAgICB0cnkge1xyXG4gICAgICB1cGRhdGUoaW5kZXgsICdpbWFnZVVybCcsIGF3YWl0IHVwbG9hZEJhbm5lckltYWdlKGZpbGUpKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBzZXRFcnJvcih0LnVwbG9hZEVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFVwbG9hZGluZyhudWxsKTtcclxuICAgIH1cclxuICB9XHJcbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZSgpIHtcclxuICAgIHNldFNhdmluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKCcnKTtcclxuICAgIHNldE1lc3NhZ2UoJycpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc2F2ZWQgPSBhd2FpdCBzYXZlQmFubmVyKGRyYWZ0LnBvc2l0aW9uLCB7XHJcbiAgICAgICAgdmlzaWJsZTogZHJhZnQudmlzaWJsZSxcclxuICAgICAgICBzbGlkZXM6IGRyYWZ0LnNsaWRlcyxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldERyYWZ0KHNhdmVkKTtcclxuICAgICAgc2V0TWVzc2FnZSh0LnNhdmVkKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBzZXRFcnJvcih0LnNhdmVFcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm1cclxuICAgICAgb25TdWJtaXQ9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgdm9pZCBzYXZlKCk7XHJcbiAgICAgIH19XHJcbiAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IHNtOnAtNlwiXHJcbiAgICA+XHJcbiAgICAgIDxmaWVsZHNldCBkaXNhYmxlZD17YnVzeX0gY2xhc3NOYW1lPVwibWluLXctMCBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICB7dC5wb3NpdGlvbnNbZHJhZnQucG9zaXRpb25dfVxyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC01IHctNSBhY2NlbnQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17ZHJhZnQudmlzaWJsZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXREcmFmdCh7IC4uLmRyYWZ0LCB2aXNpYmxlOiBldmVudC50YXJnZXQuY2hlY2tlZCB9KTtcclxuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UoJycpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHt0LnZpc2libGV9XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1mZy1tdXRlZFwiPnt0LmltYWdlSGVscH08L3A+XHJcbiAgICAgICAgeyFkcmFmdC5zbGlkZXMubGVuZ3RoICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm15LTUgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+MCAvIHtsaW1pdH08L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgc3BhY2UteS02XCI+XHJcbiAgICAgICAgICB7ZHJhZnQuc2xpZGVzLm1hcCgoc2xpZGUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXBhZ2UgcC00XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICB7aW5kZXggKyAxfSAvIHtsaW1pdH1cclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZGFuZ2VyIGhvdmVyOmJnLWRhbmdlci1iZ1wiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXREcmFmdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5kcmFmdCxcclxuICAgICAgICAgICAgICAgICAgICAgIHNsaWRlczogZHJhZnQuc2xpZGVzLmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UoJycpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dC5yZW1vdmV9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7c2xpZGUuaW1hZ2VVcmwgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFByb2R1Y3RJbWFnZVxyXG4gICAgICAgICAgICAgICAgICBzcmM9e2Jhbm5lckltYWdlVXJsKHNsaWRlLmltYWdlVXJsKX1cclxuICAgICAgICAgICAgICAgICAgYWx0PXtzbGlkZS5hbHQgfHwgdC5pbWFnZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItNCBhc3BlY3QtWzgvM10gdy1mdWxsIHJvdW5kZWQtc20gYmctc3VyZmFjZVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTUgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAge3VwbG9hZGluZyA9PT0gaW5kZXggPyB0LnVwbG9hZGluZyA6IHQudXBsb2FkfVxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvcG5nLGltYWdlL2pwZWcsaW1hZ2Uvd2VicFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgYmxvY2sgdy1mdWxsIHRleHQtc20gZmlsZTptci0zIGZpbGU6cm91bmRlZC1zbSBmaWxlOmJvcmRlci0wIGZpbGU6YmctcHJpbWFyeS1zdWJ0bGUgZmlsZTpweC00IGZpbGU6cHktMiBmaWxlOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB2b2lkIHVwbG9hZChpbmRleCwgZXZlbnQudGFyZ2V0LmZpbGVzPy5bMF0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LnRhcmdldC52YWx1ZSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBzbTpncmlkLWNvbHMtMlwiPlxyXG4gICAgICAgICAgICAgICAge2ZpZWxkcy5tYXAoKGZpZWxkKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17ZmllbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLXNlY29uZGFyeSAke2ZpZWxkID09PSAnZGVzY3JpcHRpb24nIHx8IGZpZWxkID09PSAnaW1hZ2VVcmwnID8gJ3NtOmNvbC1zcGFuLTInIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtsYWJlbHNbZmllbGRdfVxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZCA9PT0gJ2ltYWdlVXJsJyB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZCA9PT0gJ2FsdCcgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGZpZWxkID09PSAnaHJlZicgJiYgQm9vbGVhbihzbGlkZS5idXR0b25UZXh0KSkgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGZpZWxkID09PSAnYnV0dG9uVGV4dCcgJiYgQm9vbGVhbihzbGlkZS5ocmVmKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkID09PSAnYWx0J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gMjAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZCA9PT0gJ3RpdGxlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAxMDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogZmllbGQgPT09ICdkZXNjcmlwdGlvbidcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAzMDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZCA9PT0gJ2J1dHRvblRleHQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA0MFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogMjA0OFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NsaWRlW2ZpZWxkXX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZShpbmRleCwgZmllbGQsIGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIG10LTIgbWluLWgtMTEgdy1mdWxsIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcHgtMyB0ZXh0LXNtIGZvbnQtbm9ybWFsIGZvY3VzOmJvcmRlci1wcmltYXJ5IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2RyYWZ0LnNsaWRlcy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbLTEsIDFdLm1hcCgoZGlyZWN0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2RpcmVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggKyBkaXJlY3Rpb24gPCAwIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ICsgZGlyZWN0aW9uID49IGRyYWZ0LnNsaWRlcy5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3Rpb24gPCAwID8gJ01vdmUgaW1hZ2UgdXAnIDogJ01vdmUgaW1hZ2UgZG93bidcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tc2Vjb25kYXJ5IHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIHB4LTQgcHktMiBkaXNhYmxlZDp0ZXh0LWZnLWRpc2FibGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2xpZGVzID0gWy4uLmRyYWZ0LnNsaWRlc107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtzbGlkZXNbaW5kZXhdLCBzbGlkZXNbaW5kZXggKyBkaXJlY3Rpb25dXSA9IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzbGlkZXNbaW5kZXggKyBkaXJlY3Rpb25dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNsaWRlc1tpbmRleF0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERyYWZ0KHsgLi4uZHJhZnQsIHNsaWRlcyB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0TWVzc2FnZSgnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtkaXJlY3Rpb24gPCAwID8gJ+KGkScgOiAn4oaTJ31cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBmbGV4IGZsZXgtd3JhcCBnYXAtM1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2RyYWZ0LnNsaWRlcy5sZW5ndGggPj0gbGltaXR9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXREcmFmdCh7XHJcbiAgICAgICAgICAgICAgICAuLi5kcmFmdCxcclxuICAgICAgICAgICAgICAgIHNsaWRlczogW1xyXG4gICAgICAgICAgICAgICAgICAuLi5kcmFmdC5zbGlkZXMsXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBpbWFnZVVybDogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgYWx0OiAnJyxcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvblRleHQ6ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgIGhyZWY6ICcnLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICBzZXRNZXNzYWdlKCcnKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gZGlzYWJsZWQ6dGV4dC1mZy1kaXNhYmxlZFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0LmFkZFNsaWRlfSAoe2RyYWZ0LnNsaWRlcy5sZW5ndGh9L3tsaW1pdH0pXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1wcmltYXJ5IHJvdW5kZWQtc20gYmctcHJpbWFyeSBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlclwiPlxyXG4gICAgICAgICAgICB7c2F2aW5nICYmIDxTcGlubmVyIGNsYXNzTmFtZT1cIm1yLTJcIiAvPn1cclxuICAgICAgICAgICAge3NhdmluZyA/IHQuc2F2aW5nIDogdC5zYXZlfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZmllbGRzZXQ+XHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IHJvdW5kZWQtc20gYmctZGFuZ2VyLWJnIHAtMyB0ZXh0LXNtIHRleHQtZGFuZ2VyXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICB7bWVzc2FnZSAmJiAoXHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLXNtIGJnLXN1Y2Nlc3MtYmcgcC0zIHRleHQtc20gdGV4dC1zdWNjZXNzXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7bWVzc2FnZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICA8L2Zvcm0+XHJcbiAgKTtcclxufVxyXG4iXX0=