import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/StatusBadge.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/StatusBadge.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const statuses = {
	SUCCESS: "success",
	PAID: "success",
	DELIVERED: "success",
	COMPLETED: "success",
	APPROVED: "special",
	IN_STOCK: "success",
	ONLINE: "success",
	OPEN: "special",
	PENDING: "warning",
	PENDING_PAYMENT: "warning",
	PROCESSING: "info",
	AWAITING_PARTS: "warning",
	LOW_STOCK: "warning",
	IN_PROGRESS: "info",
	SHIPPED: "info",
	ACTIVE: "info",
	CONFIRMED: "info",
	FAILED: "danger",
	REJECTED: "danger",
	CANCELLED: "danger",
	OUT_OF_STOCK: "danger",
	ERROR: "danger",
	ASSIGNED: "special",
	READY_FOR_COLLECTION: "success",
	AWAITING_REVIEW: "special"
};
export function StatusBadge({ status, children, tone }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `ui-badge ui-tone-${tone ?? statuses[status ?? ""] ?? "neutral"}`,
		children: [/* @__PURE__ */ _jsxDEV("span", {
			"aria-hidden": "true",
			className: "h-1.5 w-1.5 shrink-0 rounded-full bg-current"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_c = StatusBadge;
var _c;
$RefreshReg$(_c, "StatusBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/StatusBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/StatusBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/StatusBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/StatusBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFHQSxNQUFNLFdBQXFDO0NBQ3pDLFNBQVM7Q0FDVCxNQUFNO0NBQ04sV0FBVztDQUNYLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsVUFBVTtDQUNWLFFBQVE7Q0FDUixNQUFNO0NBQ04sU0FBUztDQUNULGlCQUFpQjtDQUNqQixZQUFZO0NBQ1osZ0JBQWdCO0NBQ2hCLFdBQVc7Q0FDWCxhQUFhO0NBQ2IsU0FBUztDQUNULFFBQVE7Q0FDUixXQUFXO0NBQ1gsUUFBUTtDQUNSLFVBQVU7Q0FDVixXQUFXO0NBQ1gsY0FBYztDQUNkLE9BQU87Q0FDUCxVQUFVO0NBQ1Ysc0JBQXNCO0NBQ3RCLGlCQUFpQjtBQUNuQjtBQUNBLE9BQU8sU0FBUyxZQUFZLEVBQzFCLFFBQ0EsVUFDQSxRQUtDO0NBQ0QsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyxvQkFBb0IsUUFBUSxTQUFTLFVBQVUsT0FBTztZQURuRSxDQUdFLHdCQUFDLFFBQUQ7R0FDRSxlQUFZO0dBQ1osV0FBVTtFQUNYOzs7O1lBQ0EsUUFDRzs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RhdHVzQmFkZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xyXG5leHBvcnQgdHlwZSBTZXZlcml0eSA9XHJcbiAgJ3N1Y2Nlc3MnIHwgJ3dhcm5pbmcnIHwgJ2RhbmdlcicgfCAnaW5mbycgfCAnbmV1dHJhbCcgfCAnc3BlY2lhbCc7XHJcbmNvbnN0IHN0YXR1c2VzOiBSZWNvcmQ8c3RyaW5nLCBTZXZlcml0eT4gPSB7XHJcbiAgU1VDQ0VTUzogJ3N1Y2Nlc3MnLFxyXG4gIFBBSUQ6ICdzdWNjZXNzJyxcclxuICBERUxJVkVSRUQ6ICdzdWNjZXNzJyxcclxuICBDT01QTEVURUQ6ICdzdWNjZXNzJyxcclxuICBBUFBST1ZFRDogJ3NwZWNpYWwnLFxyXG4gIElOX1NUT0NLOiAnc3VjY2VzcycsXHJcbiAgT05MSU5FOiAnc3VjY2VzcycsXHJcbiAgT1BFTjogJ3NwZWNpYWwnLFxyXG4gIFBFTkRJTkc6ICd3YXJuaW5nJyxcclxuICBQRU5ESU5HX1BBWU1FTlQ6ICd3YXJuaW5nJyxcclxuICBQUk9DRVNTSU5HOiAnaW5mbycsXHJcbiAgQVdBSVRJTkdfUEFSVFM6ICd3YXJuaW5nJyxcclxuICBMT1dfU1RPQ0s6ICd3YXJuaW5nJyxcclxuICBJTl9QUk9HUkVTUzogJ2luZm8nLFxyXG4gIFNISVBQRUQ6ICdpbmZvJyxcclxuICBBQ1RJVkU6ICdpbmZvJyxcclxuICBDT05GSVJNRUQ6ICdpbmZvJyxcclxuICBGQUlMRUQ6ICdkYW5nZXInLFxyXG4gIFJFSkVDVEVEOiAnZGFuZ2VyJyxcclxuICBDQU5DRUxMRUQ6ICdkYW5nZXInLFxyXG4gIE9VVF9PRl9TVE9DSzogJ2RhbmdlcicsXHJcbiAgRVJST1I6ICdkYW5nZXInLFxyXG4gIEFTU0lHTkVEOiAnc3BlY2lhbCcsXHJcbiAgUkVBRFlfRk9SX0NPTExFQ1RJT046ICdzdWNjZXNzJyxcclxuICBBV0FJVElOR19SRVZJRVc6ICdzcGVjaWFsJyxcclxufTtcclxuZXhwb3J0IGZ1bmN0aW9uIFN0YXR1c0JhZGdlKHtcclxuICBzdGF0dXMsXHJcbiAgY2hpbGRyZW4sXHJcbiAgdG9uZSxcclxufToge1xyXG4gIHN0YXR1cz86IHN0cmluZztcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG4gIHRvbmU/OiBTZXZlcml0eTtcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9e2B1aS1iYWRnZSB1aS10b25lLSR7dG9uZSA/PyBzdGF0dXNlc1tzdGF0dXMgPz8gJyddID8/ICduZXV0cmFsJ31gfVxyXG4gICAgPlxyXG4gICAgICA8c3BhblxyXG4gICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgc2hyaW5rLTAgcm91bmRlZC1mdWxsIGJnLWN1cnJlbnRcIlxyXG4gICAgICAvPlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufVxyXG4iXX0=