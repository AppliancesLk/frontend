import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ThemeToggle.tsx");const useSyncExternalStore = __vite__cjsImport0_react["useSyncExternalStore"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ThemeToggle.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const subscribe = (callback) => {
	window.addEventListener("al-theme-change", callback);
	window.addEventListener("storage", callback);
	return () => {
		window.removeEventListener("al-theme-change", callback);
		window.removeEventListener("storage", callback);
	};
};
function getTheme() {
	try {
		const saved = localStorage.getItem("al-theme");
		return saved === "light" || saved === "dark" ? saved : "system";
	} catch {
		const applied = document.documentElement.getAttribute("data-theme");
		return applied === "dark" || applied === "light" ? applied : "system";
	}
}
export function ThemeToggle() {
	_s();
	const theme = useSyncExternalStore(subscribe, getTheme, () => "system");
	function choose(next) {
		if (next === "system") document.documentElement.removeAttribute("data-theme");
		else document.documentElement.setAttribute("data-theme", next);
		try {
			localStorage.setItem("al-theme", next);
		} catch {}
		window.dispatchEvent(new Event("al-theme-change"));
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "theme-control",
		role: "group",
		"aria-label": "Color theme",
		children: [
			"system",
			"light",
			"dark"
		].map((option) => /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-pressed": theme === option,
			onClick: () => choose(option),
			children: option.charAt(0).toUpperCase() + option.slice(1)
		}, option, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
}
_s(ThemeToggle, "HbqBb6oWjpQSXathj5kEm7mskTM=");
_c = ThemeToggle;
var _c;
$RefreshReg$(_c, "ThemeToggle");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/ThemeToggle.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ThemeToggle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ThemeToggle.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/ThemeToggle.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyw0QkFBNEI7Ozs7QUFHckMsTUFBTSxhQUFhLGFBQXlCO0NBQzFDLE9BQU8saUJBQWlCLG1CQUFtQixRQUFRO0NBQ25ELE9BQU8saUJBQWlCLFdBQVcsUUFBUTtDQUMzQyxhQUFhO0VBQ1gsT0FBTyxvQkFBb0IsbUJBQW1CLFFBQVE7RUFDdEQsT0FBTyxvQkFBb0IsV0FBVyxRQUFRO0NBQ2hEO0FBQ0Y7QUFDQSxTQUFTLFdBQWtCO0NBQ3pCLElBQUk7RUFDRixNQUFNLFFBQVEsYUFBYSxRQUFRLFVBQVU7RUFDN0MsT0FBTyxVQUFVLFdBQVcsVUFBVSxTQUFTLFFBQVE7Q0FDekQsUUFBUTtFQUNOLE1BQU0sVUFBVSxTQUFTLGdCQUFnQixhQUFhLFlBQVk7RUFDbEUsT0FBTyxZQUFZLFVBQVUsWUFBWSxVQUFVLFVBQVU7Q0FDL0Q7QUFDRjtBQUNBLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLFFBQVEscUJBQ1osV0FDQSxnQkFDTSxRQUNSO0NBQ0EsU0FBUyxPQUFPLE1BQWE7RUFDM0IsSUFBSSxTQUFTLFVBQ1gsU0FBUyxnQkFBZ0IsZ0JBQWdCLFlBQVk7T0FDbEQsU0FBUyxnQkFBZ0IsYUFBYSxjQUFjLElBQUk7RUFDN0QsSUFBSTtHQUNGLGFBQWEsUUFBUSxZQUFZLElBQUk7RUFDdkMsUUFBUSxDQUVSO0VBQ0EsT0FBTyxjQUFjLElBQUksTUFBTSxpQkFBaUIsQ0FBQztDQUNuRDtDQUNBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBZ0IsTUFBSztFQUFRLGNBQVc7WUFDbkQ7R0FBQztHQUFVO0dBQVM7RUFBTSxDQUFDLENBQVcsS0FBSyxXQUMzQyx3QkFBQyxVQUFEO0dBQ0UsTUFBSztHQUVMLGdCQUFjLFVBQVU7R0FDeEIsZUFBZSxPQUFPLE1BQU07YUFFM0IsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxPQUFPLE1BQU0sQ0FBQztFQUMxQyxHQUxEOzs7O1NBS0MsQ0FDVDtDQUNFOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRoZW1lVG9nZ2xlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTeW5jRXh0ZXJuYWxTdG9yZSB9IGZyb20gJ3JlYWN0JztcclxuXHJcbnR5cGUgVGhlbWUgPSAnc3lzdGVtJyB8ICdsaWdodCcgfCAnZGFyayc7XHJcbmNvbnN0IHN1YnNjcmliZSA9IChjYWxsYmFjazogKCkgPT4gdm9pZCkgPT4ge1xyXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdhbC10aGVtZS1jaGFuZ2UnLCBjYWxsYmFjayk7XHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3N0b3JhZ2UnLCBjYWxsYmFjayk7XHJcbiAgcmV0dXJuICgpID0+IHtcclxuICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdhbC10aGVtZS1jaGFuZ2UnLCBjYWxsYmFjayk7XHJcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc3RvcmFnZScsIGNhbGxiYWNrKTtcclxuICB9O1xyXG59O1xyXG5mdW5jdGlvbiBnZXRUaGVtZSgpOiBUaGVtZSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2FsLXRoZW1lJyk7XHJcbiAgICByZXR1cm4gc2F2ZWQgPT09ICdsaWdodCcgfHwgc2F2ZWQgPT09ICdkYXJrJyA/IHNhdmVkIDogJ3N5c3RlbSc7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICBjb25zdCBhcHBsaWVkID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS10aGVtZScpO1xyXG4gICAgcmV0dXJuIGFwcGxpZWQgPT09ICdkYXJrJyB8fCBhcHBsaWVkID09PSAnbGlnaHQnID8gYXBwbGllZCA6ICdzeXN0ZW0nO1xyXG4gIH1cclxufVxyXG5leHBvcnQgZnVuY3Rpb24gVGhlbWVUb2dnbGUoKSB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShcclxuICAgIHN1YnNjcmliZSxcclxuICAgIGdldFRoZW1lLFxyXG4gICAgKCkgPT4gJ3N5c3RlbScgYXMgY29uc3QsXHJcbiAgKTtcclxuICBmdW5jdGlvbiBjaG9vc2UobmV4dDogVGhlbWUpIHtcclxuICAgIGlmIChuZXh0ID09PSAnc3lzdGVtJylcclxuICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS10aGVtZScpO1xyXG4gICAgZWxzZSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2V0QXR0cmlidXRlKCdkYXRhLXRoZW1lJywgbmV4dCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYWwtdGhlbWUnLCBuZXh0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvKiBUaGVtZSBzdGlsbCBhcHBsaWVzIGZvciB0aGlzIHZpc2l0LiAqL1xyXG4gICAgfVxyXG4gICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KCdhbC10aGVtZS1jaGFuZ2UnKSk7XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRoZW1lLWNvbnRyb2xcIiByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiQ29sb3IgdGhlbWVcIj5cclxuICAgICAgeyhbJ3N5c3RlbScsICdsaWdodCcsICdkYXJrJ10gYXMgY29uc3QpLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBrZXk9e29wdGlvbn1cclxuICAgICAgICAgIGFyaWEtcHJlc3NlZD17dGhlbWUgPT09IG9wdGlvbn1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNob29zZShvcHRpb24pfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtvcHRpb24uY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBvcHRpb24uc2xpY2UoMSl9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=