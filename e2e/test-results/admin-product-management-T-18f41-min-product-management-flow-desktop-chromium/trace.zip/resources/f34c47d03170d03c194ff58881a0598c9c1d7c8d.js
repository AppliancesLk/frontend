import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/feedback/CatalogFeedback.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { LoadingState, ErrorState } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/CatalogFeedback.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function CatalogFeedback({ loading, error, retry }) {
	if (loading) return /* @__PURE__ */ _jsxDEV(LoadingState, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 23
	}, this);
	if (error) return /* @__PURE__ */ _jsxDEV(ErrorState, {
		message: error,
		retry
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 21
	}, this);
	return null;
}
_c = CatalogFeedback;
var _c;
$RefreshReg$(_c, "CatalogFeedback");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/feedback/CatalogFeedback.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/CatalogFeedback.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/CatalogFeedback.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/CatalogFeedback.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjLGtCQUFrQjs7O0FBQ3pDLE9BQU8sU0FBUyxnQkFBZ0IsRUFDOUIsU0FDQSxPQUNBLFNBS0M7Q0FDRCxJQUFJLFNBQVMsT0FBTyx3QkFBQyxjQUFELENBQWU7Ozs7O0NBQ25DLElBQUksT0FBTyxPQUFPLHdCQUFDLFlBQUQ7RUFBWSxTQUFTO0VBQWM7Q0FBUTs7Ozs7Q0FDN0QsT0FBTztBQUNUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dGZWVkYmFjay50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTG9hZGluZ1N0YXRlLCBFcnJvclN0YXRlIH0gZnJvbSAnLi4vdWkvRmVlZGJhY2snO1xuZXhwb3J0IGZ1bmN0aW9uIENhdGFsb2dGZWVkYmFjayh7XG4gIGxvYWRpbmcsXG4gIGVycm9yLFxuICByZXRyeSxcbn06IHtcbiAgbG9hZGluZzogYm9vbGVhbjtcbiAgZXJyb3I6IHN0cmluZztcbiAgcmV0cnk6ICgpID0+IHZvaWQ7XG59KSB7XG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTdGF0ZSAvPjtcbiAgaWYgKGVycm9yKSByZXR1cm4gPEVycm9yU3RhdGUgbWVzc2FnZT17ZXJyb3J9IHJldHJ5PXtyZXRyeX0gLz47XG4gIHJldHVybiBudWxsO1xufVxuIl19