import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/components/ProductTable.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
import { generatePath, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { formatCurrency } from "/src/utils/currency.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductTable.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.admin;
export function ProductTable({ page }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "overflow-hidden rounded-md border border-line bg-surface ",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center justify-between gap-4 border-b border-line p-5",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-semibold text-fg",
				children: [
					t.catalog,
					" (",
					page.products.length,
					")"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("input", {
				"aria-label": t.search,
				placeholder: t.search,
				className: "ui-field auth-input max-w-xs",
				value: page.search,
				onChange: (event) => page.setSearch(event.target.value)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this), page.filtered.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
			className: "p-6 text-sm text-fg-muted",
			children: page.products.length === 0 ? t.noProducts : translations.common.noMatches
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "ui-table ui-card-table w-full text-left text-sm",
				children: [/* @__PURE__ */ _jsxDEV("thead", {
					className: "bg-page text-fg-secondary",
					children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						t.productName,
						t.sku,
						t.category,
						t.price,
						t.stock,
						t.actions
					].map((label) => /* @__PURE__ */ _jsxDEV("th", {
						scope: "col",
						className: "px-5 py-3 font-medium",
						children: label
					}, label, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 19
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: page.filtered.map((product) => /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.productName,
							className: "px-5 py-4 font-medium text-fg",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: [product.name, /* @__PURE__ */ _jsxDEV(StatusBadge, {
									status: product.isActive ? "ACTIVE" : "INACTIVE",
									children: product.isActive ? t.active : t.inactive
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.sku,
							className: "px-5 py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: product.SKU
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.category,
							className: "px-5 py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: product.category.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.price,
							className: "xl:whitespace-nowrap px-5 py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: formatCurrency(product.price)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.stock,
							className: "px-5 py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: product.stockQty
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							"data-label": t.actions,
							className: "px-5 py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "ui-cell-value",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV(Link, {
											to: generatePath(ROUTES.adminProductEdit, { id: product.productID }),
											className: "auth-secondary",
											"aria-label": `${translations.productEdit.title}: ${product.name}`,
											children: translations.productEdit.editLabel
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 88,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											className: "auth-secondary",
											disabled: page.updating !== null,
											onClick: () => void page.toggle(product),
											children: page.updating === product.productID ? t.saving : product.isActive ? t.deactivate : t.activate
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 97,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											className: "auth-secondary text-danger",
											disabled: page.updating !== null,
											onClick: () => void page.remove(product),
											children: "Delete"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 108,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 19
						}, this)
					]
				}, product.productID, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 17
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = ProductTable;
var _c;
$RefreshReg$(_c, "ProductTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/components/ProductTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/components/ProductTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxjQUFjLFlBQVk7QUFDbkMsU0FBUyxjQUFjO0FBRXZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsc0JBQXNCOzs7QUFDL0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGFBQWEsRUFDM0IsUUFHQztDQUNELE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkIsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZDtLQUNHLEVBQUU7S0FBUTtLQUFHLEtBQUssU0FBUztLQUFPO0lBQ2pDOzs7OzthQUNKLHdCQUFDLFNBQUQ7SUFDRSxjQUFZLEVBQUU7SUFDZCxhQUFhLEVBQUU7SUFDZixXQUFVO0lBQ1YsT0FBTyxLQUFLO0lBQ1osV0FBVyxVQUFVLEtBQUssVUFBVSxNQUFNLE9BQU8sS0FBSztHQUN2RDs7OztXQUNFOzs7OztZQUNKLEtBQUssU0FBUyxXQUFXLElBQ3hCLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQ1YsS0FBSyxTQUFTLFdBQVcsSUFDdEIsRUFBRSxhQUNGLGFBQWEsT0FBTztFQUN2Qjs7OzthQUVILHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakIsQ0FDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUNmLHdCQUFDLE1BQUQsWUFDRztNQUNDLEVBQUU7TUFDRixFQUFFO01BQ0YsRUFBRTtNQUNGLEVBQUU7TUFDRixFQUFFO01BQ0YsRUFBRTtLQUNKLENBQUMsQ0FBQyxLQUFLLFVBQ0wsd0JBQUMsTUFBRDtNQUFnQixPQUFNO01BQU0sV0FBVTtnQkFDbkM7S0FDQyxHQUZLOzs7O1lBRUwsQ0FDTCxFQUNDOzs7OztJQUNDOzs7O2NBQ1Asd0JBQUMsU0FBRCxZQUNHLEtBQUssU0FBUyxLQUFLLFlBQ2xCLHdCQUFDLE1BQUQ7S0FBNEIsV0FBVTtlQUF0QztNQUNFLHdCQUFDLE1BQUQ7T0FDRSxjQUFZLEVBQUU7T0FDZCxXQUFVO2lCQUVWLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0csUUFBUSxNQUNULHdCQUFDLGFBQUQ7U0FDRSxRQUFRLFFBQVEsV0FBVyxXQUFXO21CQUVyQyxRQUFRLFdBQVcsRUFBRSxTQUFTLEVBQUU7UUFDdEI7Ozs7Z0JBQ1Y7Ozs7OztNQUNIOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxjQUFZLEVBQUU7T0FBSyxXQUFVO2lCQUMvQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBaUIsUUFBUTtPQUFTOzs7OztNQUMvQzs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksY0FBWSxFQUFFO09BQVUsV0FBVTtpQkFDcEMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWlCLFFBQVEsU0FBUztPQUFVOzs7OztNQUN6RDs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQ0UsY0FBWSxFQUFFO09BQ2QsV0FBVTtpQkFFVix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixlQUFlLFFBQVEsS0FBSztPQUMxQjs7Ozs7TUFDSDs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksY0FBWSxFQUFFO09BQU8sV0FBVTtpQkFDakMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWlCLFFBQVE7T0FBYzs7Ozs7TUFDcEQ7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUFJLGNBQVksRUFBRTtPQUFTLFdBQVU7aUJBQ25DLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsTUFBRDtXQUNFLElBQUksYUFBYSxPQUFPLGtCQUFrQixFQUN4QyxJQUFJLFFBQVEsVUFDZCxDQUFDO1dBQ0QsV0FBVTtXQUNWLGNBQVksR0FBRyxhQUFhLFlBQVksTUFBTSxJQUFJLFFBQVE7cUJBRXpELGFBQWEsWUFBWTtVQUN0Qjs7Ozs7VUFDTix3QkFBQyxVQUFEO1dBQ0UsV0FBVTtXQUNWLFVBQVUsS0FBSyxhQUFhO1dBQzVCLGVBQWUsS0FBSyxLQUFLLE9BQU8sT0FBTztxQkFFdEMsS0FBSyxhQUFhLFFBQVEsWUFDdkIsRUFBRSxTQUNGLFFBQVEsV0FDTixFQUFFLGFBQ0YsRUFBRTtVQUNGOzs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDRSxXQUFVO1dBQ1YsVUFBVSxLQUFLLGFBQWE7V0FDNUIsZUFBZSxLQUFLLEtBQUssT0FBTyxPQUFPO3FCQUN4QztVQUVPOzs7OztTQUNMOzs7Ozs7T0FDRjs7Ozs7TUFDSDs7Ozs7S0FDRjtPQWhFSyxRQUFROzs7O1dBZ0ViLENBQ0wsRUFDSTs7OztZQUNGOzs7Ozs7RUFDSjs7OztVQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0VGFibGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9TdGF0dXNCYWRnZSc7XHJcbmltcG9ydCB7IGdlbmVyYXRlUGF0aCwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHR5cGUgeyB1c2VQcm9kdWN0c1BhZ2UgfSBmcm9tICcuLi9ob29rcy91c2VQcm9kdWN0c1BhZ2UnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pbjtcclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RUYWJsZSh7XHJcbiAgcGFnZSxcclxufToge1xyXG4gIHBhZ2U6IFJldHVyblR5cGU8dHlwZW9mIHVzZVByb2R1Y3RzUGFnZT47XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBib3JkZXItYiBib3JkZXItbGluZSBwLTVcIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICAgIHt0LmNhdGFsb2d9ICh7cGFnZS5wcm9kdWN0cy5sZW5ndGh9KVxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXt0LnNlYXJjaH1cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPXt0LnNlYXJjaH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkIGF1dGgtaW5wdXQgbWF4LXcteHNcIlxyXG4gICAgICAgICAgdmFsdWU9e3BhZ2Uuc2VhcmNofVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gcGFnZS5zZXRTZWFyY2goZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge3BhZ2UuZmlsdGVyZWQubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInAtNiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHtwYWdlLnByb2R1Y3RzLmxlbmd0aCA9PT0gMFxyXG4gICAgICAgICAgICA/IHQubm9Qcm9kdWN0c1xyXG4gICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5jb21tb24ubm9NYXRjaGVzfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInVpLXRhYmxlIHVpLWNhcmQtdGFibGUgdy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1wYWdlIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgdC5wcm9kdWN0TmFtZSxcclxuICAgICAgICAgICAgICAgICAgdC5za3UsXHJcbiAgICAgICAgICAgICAgICAgIHQuY2F0ZWdvcnksXHJcbiAgICAgICAgICAgICAgICAgIHQucHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgIHQuc3RvY2ssXHJcbiAgICAgICAgICAgICAgICAgIHQuYWN0aW9ucyxcclxuICAgICAgICAgICAgICAgIF0ubWFwKChsYWJlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dGgga2V5PXtsYWJlbH0gc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC01IHB5LTMgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAge3BhZ2UuZmlsdGVyZWQubWFwKChwcm9kdWN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtwcm9kdWN0LnByb2R1Y3RJRH0gY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWxpbmVcIj5cclxuICAgICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17dC5wcm9kdWN0TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTQgZm9udC1tZWRpdW0gdGV4dC1mZ1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzPXtwcm9kdWN0LmlzQWN0aXZlID8gJ0FDVElWRScgOiAnSU5BQ1RJVkUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdC5pc0FjdGl2ZSA/IHQuYWN0aXZlIDogdC5pbmFjdGl2ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU3RhdHVzQmFkZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPXt0LnNrdX0gY2xhc3NOYW1lPVwicHgtNSBweS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+e3Byb2R1Y3QuU0tVfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgZGF0YS1sYWJlbD17dC5jYXRlZ29yeX0gY2xhc3NOYW1lPVwicHgtNSBweS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+e3Byb2R1Y3QuY2F0ZWdvcnkubmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17dC5wcmljZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ4bDp3aGl0ZXNwYWNlLW5vd3JhcCBweC01IHB5LTRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPXt0LnN0b2NrfSBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj57cHJvZHVjdC5zdG9ja1F0eX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9e3QuYWN0aW9uc30gY2xhc3NOYW1lPVwicHgtNSBweS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2dlbmVyYXRlUGF0aChST1VURVMuYWRtaW5Qcm9kdWN0RWRpdCwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHByb2R1Y3QucHJvZHVjdElELFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHt0cmFuc2xhdGlvbnMucHJvZHVjdEVkaXQudGl0bGV9OiAke3Byb2R1Y3QubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5wcm9kdWN0RWRpdC5lZGl0TGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS51cGRhdGluZyAhPT0gbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UudG9nZ2xlKHByb2R1Y3QpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3BhZ2UudXBkYXRpbmcgPT09IHByb2R1Y3QucHJvZHVjdElEXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHQuc2F2aW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHByb2R1Y3QuaXNBY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0LmRlYWN0aXZhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0LmFjdGl2YXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5IHRleHQtZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS51cGRhdGluZyAhPT0gbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVtb3ZlKHByb2R1Y3QpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==