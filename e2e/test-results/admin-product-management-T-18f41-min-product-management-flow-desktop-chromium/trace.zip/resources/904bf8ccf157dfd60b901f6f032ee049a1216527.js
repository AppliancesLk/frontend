import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Themes/index.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { seasonalPresets, seasonalText as t } from "/src/utils/seasonalText.ts";
import { formatDate } from "/src/utils/date.ts";
import { Button } from "/src/components/ui/Button.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { useThemesPage } from "/src/pages/Admin/Themes/hooks/useThemesPage.ts";
import { ThemePreview } from "/src/pages/Admin/Themes/components/ThemePreview.tsx";
import { ThemeChoices } from "/src/pages/Admin/Themes/components/ThemeChoices.tsx";
import { ThemeConfiguration } from "/src/pages/Admin/Themes/components/ThemeConfiguration.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/index.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function ThemesPage() {
	_s();
	const page = useThemesPage();
	const errorRef = useRef(null);
	useEffect(() => {
		if (page.error) errorRef.current?.focus();
	}, [page.error]);
	const draft = page.draft;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "mx-auto max-w-7xl space-y-7",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title",
					children: t.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-3 max-w-2xl text-sm leading-6 text-fg-secondary",
					children: t.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this), page.settings && /* @__PURE__ */ _jsxDEV("span", {
					className: "rounded-full border border-line bg-surface px-4 py-2 text-xs font-medium",
					children: [
						t.current,
						": ",
						seasonalPresets[page.active.theme].name
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			page.loading && /* @__PURE__ */ _jsxDEV(LoadingState, { label: t.title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 24
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("div", {
				ref: errorRef,
				tabIndex: -1,
				role: "alert",
				className: "ui-alert ui-tone-danger",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: page.error }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					className: "mt-3",
					variant: "secondary",
					onClick: page.reload,
					disabled: page.saving,
					children: "Reload settings"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 9
			}, this),
			page.success && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "ui-alert ui-tone-success",
				children: page.success
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 9
			}, this),
			draft && !page.loading && /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (event) => {
					event.preventDefault();
					void page.save();
				},
				className: "space-y-7",
				"aria-busy": page.saving,
				children: [/* @__PURE__ */ _jsxDEV(ThemeChoices, {
					draft,
					saving: page.saving,
					onChange: page.setDraft
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(340px,0.9fr)]",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV(ThemeConfiguration, {
								draft,
								saving: page.saving,
								onChange: page.setDraft
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV(Button, {
									type: "submit",
									busy: page.saving,
									className: "min-w-36",
									children: page.saving ? t.saving : t.save
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 83,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									variant: "secondary",
									disabled: page.saving,
									onClick: () => page.setConfirmReset(true),
									children: t.reset
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 15
							}, this),
							page.settings?.startsAt && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-fg-muted",
								children: [
									t.startsAt,
									": ",
									formatDate(page.settings.startsAt),
									page.settings.endsAt ? ` · ${t.endsAt}: ${formatDate(page.settings.endsAt)}` : ""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("aside", {
						className: "min-w-0 xl:sticky xl:top-24",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3 flex flex-wrap items-center justify-between gap-3",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-semibold",
									children: t.preview
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex rounded-full border border-line bg-surface p-1",
									role: "group",
									"aria-label": "Preview color theme",
									children: [false, true].map((dark) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										"aria-pressed": page.darkPreview === dark,
										onClick: () => page.setDarkPreview(dark),
										className: `min-h-9 rounded-full px-3 text-xs font-medium ${page.darkPreview === dark ? "bg-primary text-primary-on" : "text-fg-secondary"}`,
										children: dark ? t.darkPreview : t.lightPreview
									}, String(dark), false, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(ThemePreview, {
								draft,
								dark: page.darkPreview
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-3 text-xs text-fg-muted",
								children: t.previewHint
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: page.confirmReset,
				onClose: () => page.setConfirmReset(false),
				title: t.restoreTitle,
				description: t.restoreDescription,
				busy: page.saving,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex flex-wrap justify-end gap-3",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: page.saving,
						onClick: () => page.setConfirmReset(false),
						children: "Keep current theme"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						busy: page.saving,
						onClick: () => void page.save(true),
						children: t.reset
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
}
_s(ThemesPage, "zub7WQlnwtbw2nixkJYJ5HehQM4=", false, function() {
	return [useThemesPage];
});
_c = ThemesPage;
var _c;
$RefreshReg$(_c, "ThemesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Themes/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGNBQWM7QUFDbEMsU0FDRSxpQkFDQSxnQkFBZ0IsU0FDWDtBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUywwQkFBMEI7Ozs7QUFFbkMsZUFBZSxTQUFTLGFBQWE7O0NBQ25DLE1BQU0sT0FBTyxjQUFjO0NBQzNCLE1BQU0sV0FBVyxPQUF1QixJQUFJO0NBQzVDLGdCQUFnQjtFQUNkLElBQUksS0FBSyxPQUFPLFNBQVMsU0FBUyxNQUFNO0NBQzFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssQ0FBQztDQUNmLE1BQU0sUUFBUSxLQUFLO0NBQ25CLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFpQixFQUFFO0lBQVU7Ozs7Y0FDM0Msd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixFQUFFO0lBQ0Y7Ozs7WUFDQTs7OztjQUNKLEtBQUssWUFDSix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUNHLEVBQUU7TUFBUTtNQUFHLGdCQUFnQixLQUFLLE9BQU8sTUFBTSxDQUFDO0tBQzdDOzs7OztZQUVGOzs7Ozs7R0FDUCxLQUFLLFdBQVcsd0JBQUMsY0FBRCxFQUFjLE9BQU8sRUFBRSxNQUFROzs7OztHQUMvQyxLQUFLLFNBQ0osd0JBQUMsT0FBRDtJQUNFLEtBQUs7SUFDTCxVQUFVLENBQUM7SUFDWCxNQUFLO0lBQ0wsV0FBVTtjQUpaLENBTUUsd0JBQUMsS0FBRCxZQUFJLEtBQUssTUFBUzs7OztjQUNsQix3QkFBQyxRQUFEO0tBQ0UsV0FBVTtLQUNWLFNBQVE7S0FDUixTQUFTLEtBQUs7S0FDZCxVQUFVLEtBQUs7ZUFDaEI7SUFFTzs7OztZQUNMOzs7Ozs7R0FFTixLQUFLLFdBQ0osd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUyxXQUFVO2NBQ3hCLEtBQUs7R0FDTDs7Ozs7R0FFSixTQUFTLENBQUMsS0FBSyxXQUNkLHdCQUFDLFFBQUQ7SUFDRSxXQUFXLFVBQVU7S0FDbkIsTUFBTSxlQUFlO0tBQ3JCLEtBQUssS0FBSyxLQUFLO0lBQ2pCO0lBQ0EsV0FBVTtJQUNWLGFBQVcsS0FBSztjQU5sQixDQVFFLHdCQUFDLGNBQUQ7S0FDUztLQUNQLFFBQVEsS0FBSztLQUNiLFVBQVUsS0FBSztJQUNoQjs7OztjQUNELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLG9CQUFEO1FBQ1M7UUFDUCxRQUFRLEtBQUs7UUFDYixVQUFVLEtBQUs7T0FDaEI7Ozs7O09BQ0Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQVEsTUFBSztTQUFTLE1BQU0sS0FBSztTQUFRLFdBQVU7bUJBQ2hELEtBQUssU0FBUyxFQUFFLFNBQVMsRUFBRTtRQUN0Qjs7OztrQkFDUix3QkFBQyxRQUFEO1NBQ0UsU0FBUTtTQUNSLFVBQVUsS0FBSztTQUNmLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSTttQkFFdkMsRUFBRTtRQUNHOzs7O2dCQUNMOzs7Ozs7T0FDSixLQUFLLFVBQVUsWUFDZCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNHLEVBQUU7U0FBUztTQUFHLFdBQVcsS0FBSyxTQUFTLFFBQVE7U0FDL0MsS0FBSyxTQUFTLFNBQ1gsTUFBTSxFQUFFLE9BQU8sSUFBSSxXQUFXLEtBQUssU0FBUyxNQUFNLE1BQ2xEO1FBQ0g7Ozs7OztNQUVGOzs7OztlQUNMLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlCLEVBQUU7UUFBWTs7OztrQkFDckQsd0JBQUMsT0FBRDtTQUNFLFdBQVU7U0FDVixNQUFLO1NBQ0wsY0FBVzttQkFFVixDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsS0FBSyxTQUNsQix3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLGdCQUFjLEtBQUssZ0JBQWdCO1VBQ25DLGVBQWUsS0FBSyxlQUFlLElBQUk7VUFDdkMsV0FBVyxpREFBaUQsS0FBSyxnQkFBZ0IsT0FBTywrQkFBK0I7b0JBRXRILE9BQU8sRUFBRSxjQUFjLEVBQUU7U0FDcEIsR0FQRCxPQUFPLElBQUk7Ozs7Z0JBT1YsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7Ozs7T0FDTCx3QkFBQyxjQUFEO1FBQXFCO1FBQU8sTUFBTSxLQUFLO09BQWM7Ozs7O09BQ3JELHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QixFQUFFO09BQWU7Ozs7O01BQ3ZEOzs7OzthQUNKOzs7OztZQUNEOzs7Ozs7R0FFUix3QkFBQyxRQUFEO0lBQ0UsTUFBTSxLQUFLO0lBQ1gsZUFBZSxLQUFLLGdCQUFnQixLQUFLO0lBQ3pDLE9BQU8sRUFBRTtJQUNULGFBQWEsRUFBRTtJQUNmLE1BQU0sS0FBSztjQUVYLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQ0UsU0FBUTtNQUNSLFVBQVUsS0FBSztNQUNmLGVBQWUsS0FBSyxnQkFBZ0IsS0FBSztnQkFDMUM7S0FFTzs7OztlQUNSLHdCQUFDLFFBQUQ7TUFBUSxNQUFNLEtBQUs7TUFBUSxlQUFlLEtBQUssS0FBSyxLQUFLLElBQUk7Z0JBQzFELEVBQUU7S0FDRzs7OzthQUNMOzs7Ozs7R0FDQzs7Ozs7RUFDRDs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQge1xyXG4gIHNlYXNvbmFsUHJlc2V0cyxcclxuICBzZWFzb25hbFRleHQgYXMgdCxcclxufSBmcm9tICcuLi8uLi8uLi91dGlscy9zZWFzb25hbFRleHQnO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgRGlhbG9nIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9EaWFsb2cnO1xyXG5pbXBvcnQgeyBMb2FkaW5nU3RhdGUgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlVGhlbWVzUGFnZSB9IGZyb20gJy4vaG9va3MvdXNlVGhlbWVzUGFnZSc7XHJcbmltcG9ydCB7IFRoZW1lUHJldmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9UaGVtZVByZXZpZXcnO1xyXG5pbXBvcnQgeyBUaGVtZUNob2ljZXMgfSBmcm9tICcuL2NvbXBvbmVudHMvVGhlbWVDaG9pY2VzJztcclxuaW1wb3J0IHsgVGhlbWVDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9jb21wb25lbnRzL1RoZW1lQ29uZmlndXJhdGlvbic7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUaGVtZXNQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VUaGVtZXNQYWdlKCk7XHJcbiAgY29uc3QgZXJyb3JSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocGFnZS5lcnJvcikgZXJyb3JSZWYuY3VycmVudD8uZm9jdXMoKTtcclxuICB9LCBbcGFnZS5lcnJvcl0pO1xyXG4gIGNvbnN0IGRyYWZ0ID0gcGFnZS5kcmFmdDtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy03eGwgc3BhY2UteS03XCI+XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlXCI+e3QudGl0bGV9PC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgbWF4LXctMnhsIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgIHt0LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtwYWdlLnNldHRpbmdzICYmIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBweC00IHB5LTIgdGV4dC14cyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICB7dC5jdXJyZW50fToge3NlYXNvbmFsUHJlc2V0c1twYWdlLmFjdGl2ZS50aGVtZV0ubmFtZX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAge3BhZ2UubG9hZGluZyAmJiA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LnRpdGxlfSAvPn1cclxuICAgICAge3BhZ2UuZXJyb3IgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJlZj17ZXJyb3JSZWZ9XHJcbiAgICAgICAgICB0YWJJbmRleD17LTF9XHJcbiAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktYWxlcnQgdWktdG9uZS1kYW5nZXJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwPntwYWdlLmVycm9yfTwvcD5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtM1wiXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtwYWdlLnJlbG9hZH1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2Uuc2F2aW5nfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBSZWxvYWQgc2V0dGluZ3NcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICB7cGFnZS5zdWNjZXNzICYmIChcclxuICAgICAgICA8cCByb2xlPVwic3RhdHVzXCIgY2xhc3NOYW1lPVwidWktYWxlcnQgdWktdG9uZS1zdWNjZXNzXCI+XHJcbiAgICAgICAgICB7cGFnZS5zdWNjZXNzfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2RyYWZ0ICYmICFwYWdlLmxvYWRpbmcgJiYgKFxyXG4gICAgICAgIDxmb3JtXHJcbiAgICAgICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgIHZvaWQgcGFnZS5zYXZlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS03XCJcclxuICAgICAgICAgIGFyaWEtYnVzeT17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFRoZW1lQ2hvaWNlc1xyXG4gICAgICAgICAgICBkcmFmdD17ZHJhZnR9XHJcbiAgICAgICAgICAgIHNhdmluZz17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtwYWdlLnNldERyYWZ0fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNiB4bDpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfbWlubWF4KDM0MHB4LDAuOWZyKV1cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICA8VGhlbWVDb25maWd1cmF0aW9uXHJcbiAgICAgICAgICAgICAgICBkcmFmdD17ZHJhZnR9XHJcbiAgICAgICAgICAgICAgICBzYXZpbmc9e3BhZ2Uuc2F2aW5nfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3BhZ2Uuc2V0RHJhZnR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgYnVzeT17cGFnZS5zYXZpbmd9IGNsYXNzTmFtZT1cIm1pbi13LTM2XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlLnNhdmluZyA/IHQuc2F2aW5nIDogdC5zYXZlfVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHBhZ2Uuc2V0Q29uZmlybVJlc2V0KHRydWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dC5yZXNldH1cclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHtwYWdlLnNldHRpbmdzPy5zdGFydHNBdCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAge3Quc3RhcnRzQXR9OiB7Zm9ybWF0RGF0ZShwYWdlLnNldHRpbmdzLnN0YXJ0c0F0KX1cclxuICAgICAgICAgICAgICAgICAge3BhZ2Uuc2V0dGluZ3MuZW5kc0F0XHJcbiAgICAgICAgICAgICAgICAgICAgPyBgIMK3ICR7dC5lbmRzQXR9OiAke2Zvcm1hdERhdGUocGFnZS5zZXR0aW5ncy5lbmRzQXQpfWBcclxuICAgICAgICAgICAgICAgICAgICA6ICcnfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwibWluLXctMCB4bDpzdGlja3kgeGw6dG9wLTI0XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj57dC5wcmV2aWV3fTwvaDI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtMVwiXHJcbiAgICAgICAgICAgICAgICAgIHJvbGU9XCJncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJQcmV2aWV3IGNvbG9yIHRoZW1lXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tmYWxzZSwgdHJ1ZV0ubWFwKChkYXJrKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtTdHJpbmcoZGFyayl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17cGFnZS5kYXJrUHJldmlldyA9PT0gZGFya31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHBhZ2Uuc2V0RGFya1ByZXZpZXcoZGFyayl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtaW4taC05IHJvdW5kZWQtZnVsbCBweC0zIHRleHQteHMgZm9udC1tZWRpdW0gJHtwYWdlLmRhcmtQcmV2aWV3ID09PSBkYXJrID8gJ2JnLXByaW1hcnkgdGV4dC1wcmltYXJ5LW9uJyA6ICd0ZXh0LWZnLXNlY29uZGFyeSd9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZGFyayA/IHQuZGFya1ByZXZpZXcgOiB0LmxpZ2h0UHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8VGhlbWVQcmV2aWV3IGRyYWZ0PXtkcmFmdH0gZGFyaz17cGFnZS5kYXJrUHJldmlld30gLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPnt0LnByZXZpZXdIaW50fTwvcD5cclxuICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgKX1cclxuICAgICAgPERpYWxvZ1xyXG4gICAgICAgIG9wZW49e3BhZ2UuY29uZmlybVJlc2V0fVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHBhZ2Uuc2V0Q29uZmlybVJlc2V0KGZhbHNlKX1cclxuICAgICAgICB0aXRsZT17dC5yZXN0b3JlVGl0bGV9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3QucmVzdG9yZURlc2NyaXB0aW9ufVxyXG4gICAgICAgIGJ1c3k9e3BhZ2Uuc2F2aW5nfVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggZmxleC13cmFwIGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5zYXZpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHBhZ2Uuc2V0Q29uZmlybVJlc2V0KGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgS2VlcCBjdXJyZW50IHRoZW1lXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b24gYnVzeT17cGFnZS5zYXZpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgcGFnZS5zYXZlKHRydWUpfT5cclxuICAgICAgICAgICAge3QucmVzZXR9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EaWFsb2c+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=