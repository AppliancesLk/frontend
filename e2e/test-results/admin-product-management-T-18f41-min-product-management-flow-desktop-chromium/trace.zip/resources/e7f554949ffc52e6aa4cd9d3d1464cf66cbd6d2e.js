import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Checkout/index.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport12_react_jsxDevRuntime["Fragment"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { EmptyCart } from "/src/components/feedback/EmptyCart.tsx";
import { useCheckoutPage } from "/src/pages/Customer/Checkout/hooks/useCheckoutPage.ts";
import { DeliveryForm } from "/src/pages/Customer/Checkout/components/DeliveryForm.tsx";
import { OrderSummary } from "/src/pages/Customer/Checkout/components/OrderSummary.tsx";
import { PreparedCheckout } from "/src/pages/Customer/Checkout/components/PreparedCheckout.tsx";
import { PaymentAction } from "/src/pages/Customer/Checkout/components/PaymentAction.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/index.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const t = translations.checkout;
export default function CheckoutPage() {
	_s();
	const { user } = useAuth();
	return user ? /* @__PURE__ */ _jsxDEV(CheckoutContent, { email: user.email }, user.id, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 17
	}, this) : null;
}
_s(CheckoutPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = CheckoutPage;
function CheckoutContent({ email }) {
	_s2();
	const page = useCheckoutPage(email);
	const errorFocus = useRef(null);
	const successFocus = useRef(null);
	useEffect(() => {
		if (page.error) errorFocus.current?.focus();
	}, [page.error]);
	useEffect(() => {
		if (page.summary) successFocus.current?.focus();
	}, [page.summary]);
	const blocked = page.cart?.items.some((item) => !item.isAvailable);
	useEffect(() => {
		const previous = document.title;
		document.title = `${t.title} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-[1200px] space-y-6",
			children: [
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": translations.productDetails.breadcrumb,
					className: "text-sm",
					children: /* @__PURE__ */ _jsxDEV("ol", {
						className: "flex flex-wrap items-center gap-2 text-fg-muted",
						children: [
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.cart,
								className: "font-medium text-fg-link hover:text-fg-link",
								children: translations.cart.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-hidden": "true",
								children: "/"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								"aria-current": "page",
								children: t.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title text-fg",
						children: t.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: t.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.cart,
						className: "auth-secondary",
						children: t.backToCart
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				page.error && /* @__PURE__ */ _jsxDEV("div", {
					ref: errorFocus,
					tabIndex: -1,
					role: "alert",
					className: "rounded-md border border-danger/25 bg-danger-bg p-4 text-sm text-danger outline-none focus-visible:ring-2 focus-visible:ring-danger",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: page.error }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: page.saving || page.loading,
						onClick: () => void page.refresh(),
						className: "mt-2 min-min-h-11 rounded-sm px-2 font-semibold underline underline-offset-4 ",
						children: t.refreshCart
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this),
				page.summary && /* @__PURE__ */ _jsxDEV("div", {
					ref: successFocus,
					tabIndex: -1,
					role: "status",
					className: "rounded-md border border-success/25 bg-success-bg p-5 text-success outline-none focus-visible:ring-2 focus-visible:ring-success",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-semibold",
							children: t.ready
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm leading-6",
							children: t.readyDescription
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-xs leading-5",
							children: t.preparationNotice
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 11
				}, this),
				(page.changes.pricesChanged || page.changes.itemsChanged) && /* @__PURE__ */ _jsxDEV("p", {
					role: "status",
					className: "rounded-md border border-warning/25 bg-warning-bg p-4 text-sm text-warning",
					children: page.changes.pricesChanged ? t.pricesChanged : t.itemsChanged
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this),
				page.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: t.loading }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 11
				}, this) : page.cart && (page.cart.items.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyCart, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [blocked && !page.summary && /* @__PURE__ */ _jsxDEV("div", {
					role: "alert",
					className: "rounded-md border border-warning/25 bg-warning-bg p-4 text-sm text-warning",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: t.cartBlocked }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.cart,
						className: "mt-2 inline-block font-semibold underline underline-offset-4",
						children: t.fixCart
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_25rem] lg:gap-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0 space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV(DeliveryForm, { page }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 19
							}, this),
							page.summary && /* @__PURE__ */ _jsxDEV(PreparedCheckout, { summary: page.summary }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 36
							}, this),
							page.summary && /* @__PURE__ */ _jsxDEV(PaymentAction, { page }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 36
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV(OrderSummary, {
						cart: page.cart,
						summary: page.summary,
						preview: page.latestSummary,
						credit: page.creditPreview,
						amountDue: page.amountDue
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 13
				}, this))
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s2(CheckoutContent, "PxFhR3JU4d0qgpCmkqxz2+Wy00c=", false, function() {
	return [useCheckoutPage];
});
_c2 = CheckoutContent;
var _c, _c2;
$RefreshReg$(_c, "CheckoutPage");
$RefreshReg$(_c2, "CheckoutContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Checkout/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxXQUFXLGNBQWM7QUFDbEMsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZTtBQUN4QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxxQkFBcUI7Ozs7QUFDOUIsTUFBTSxJQUFJLGFBQWE7QUFDdkIsZUFBZSxTQUFTLGVBQWU7O0NBQ3JDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FBTyxPQUFPLHdCQUFDLGlCQUFELEVBQStCLE9BQU8sS0FBSyxNQUFRLEdBQTdCLEtBQUs7Ozs7UUFBd0IsSUFBSTtBQUN2RTs7Ozs7QUFDQSxTQUFTLGdCQUFnQixFQUFFLFNBQTRCOztDQUNyRCxNQUFNLE9BQU8sZ0JBQWdCLEtBQUs7Q0FDbEMsTUFBTSxhQUFhLE9BQXVCLElBQUk7Q0FDOUMsTUFBTSxlQUFlLE9BQXVCLElBQUk7Q0FDaEQsZ0JBQWdCO0VBQ2QsSUFBSSxLQUFLLE9BQU8sV0FBVyxTQUFTLE1BQU07Q0FDNUMsR0FBRyxDQUFDLEtBQUssS0FBSyxDQUFDO0NBQ2YsZ0JBQWdCO0VBQ2QsSUFBSSxLQUFLLFNBQVMsYUFBYSxTQUFTLE1BQU07Q0FDaEQsR0FBRyxDQUFDLEtBQUssT0FBTyxDQUFDO0NBQ2pCLE1BQU0sVUFBVSxLQUFLLE1BQU0sTUFBTSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVc7Q0FDakUsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLFNBQVM7RUFDMUIsU0FBUyxRQUFRLEdBQUcsRUFBRSxNQUFNLEtBQUssYUFBYSxPQUFPO0VBQ3JELGFBQWE7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUNMLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUNFLGNBQVksYUFBYSxlQUFlO0tBQ3hDLFdBQVU7ZUFFVix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPO1FBQ1gsV0FBVTtrQkFFVCxhQUFhLEtBQUs7T0FDZjs7OztnQkFDSjs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksZUFBWTtrQkFBTztPQUFLOzs7OztPQUM1Qix3QkFBQyxNQUFEO1FBQUksZ0JBQWE7a0JBQVEsRUFBRTtPQUFVOzs7OztNQUNuQzs7Ozs7O0lBQ0Q7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBeUIsRUFBRTtLQUFVOzs7O2VBQ25ELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE4QixFQUFFO0tBQWU7Ozs7YUFDekQ7Ozs7ZUFDTCx3QkFBQyxNQUFEO01BQU0sSUFBSSxPQUFPO01BQU0sV0FBVTtnQkFDOUIsRUFBRTtLQUNDOzs7O2FBQ0g7Ozs7OztJQUNKLEtBQUssU0FDSix3QkFBQyxPQUFEO0tBQ0UsS0FBSztLQUNMLFVBQVUsQ0FBQztLQUNYLE1BQUs7S0FDTCxXQUFVO2VBSlosQ0FNRSx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7O2VBQ2xCLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsVUFBVSxLQUFLLFVBQVUsS0FBSztNQUM5QixlQUFlLEtBQUssS0FBSyxRQUFRO01BQ2pDLFdBQVU7Z0JBRVQsRUFBRTtLQUNHOzs7O2FBQ0w7Ozs7OztJQUVOLEtBQUssV0FDSix3QkFBQyxPQUFEO0tBQ0UsS0FBSztLQUNMLFVBQVUsQ0FBQztLQUNYLE1BQUs7S0FDTCxXQUFVO2VBSlo7TUFNRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBeUIsRUFBRTtNQUFVOzs7OztNQUNuRCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBMEIsRUFBRTtNQUFvQjs7Ozs7TUFDN0Qsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTBCLEVBQUU7TUFBcUI7Ozs7O0tBQzNEOzs7Ozs7S0FFTCxLQUFLLFFBQVEsaUJBQWlCLEtBQUssUUFBUSxpQkFDM0Msd0JBQUMsS0FBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO2VBRVQsS0FBSyxRQUFRLGdCQUFnQixFQUFFLGdCQUFnQixFQUFFO0lBQ2pEOzs7OztJQUVKLEtBQUssVUFDSix3QkFBQyxjQUFELEVBQWMsT0FBTyxFQUFFLFFBQVU7Ozs7ZUFFakMsS0FBSyxTQUNKLEtBQUssS0FBSyxNQUFNLFdBQVcsSUFDMUIsd0JBQUMsV0FBRCxDQUFZOzs7O2VBRVosZ0RBQ0csV0FBVyxDQUFDLEtBQUssV0FDaEIsd0JBQUMsT0FBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO2VBRlosQ0FJRSx3QkFBQyxLQUFELFlBQUksRUFBRSxZQUFlOzs7O2VBQ3JCLHdCQUFDLE1BQUQ7TUFDRSxJQUFJLE9BQU87TUFDWCxXQUFVO2dCQUVULEVBQUU7S0FDQzs7OzthQUNIOzs7OztjQUVQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLGNBQUQsRUFBb0IsS0FBTzs7Ozs7T0FDMUIsS0FBSyxXQUFXLHdCQUFDLGtCQUFELEVBQWtCLFNBQVMsS0FBSyxRQUFVOzs7OztPQUMxRCxLQUFLLFdBQVcsd0JBQUMsZUFBRCxFQUFxQixLQUFPOzs7OztNQUMxQzs7Ozs7ZUFDTCx3QkFBQyxjQUFEO01BQ0UsTUFBTSxLQUFLO01BQ1gsU0FBUyxLQUFLO01BQ2QsU0FBUyxLQUFLO01BQ2QsUUFBUSxLQUFLO01BQ2IsV0FBVyxLQUFLO0tBQ2pCOzs7O2FBQ0U7Ozs7O1lBQ0w7Ozs7O0dBR0g7Ozs7OztDQUNEOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMb2FkaW5nU3RhdGUgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgRW1wdHlDYXJ0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9mZWVkYmFjay9FbXB0eUNhcnQnO1xyXG5pbXBvcnQgeyB1c2VDaGVja291dFBhZ2UgfSBmcm9tICcuL2hvb2tzL3VzZUNoZWNrb3V0UGFnZSc7XHJcbmltcG9ydCB7IERlbGl2ZXJ5Rm9ybSB9IGZyb20gJy4vY29tcG9uZW50cy9EZWxpdmVyeUZvcm0nO1xyXG5pbXBvcnQgeyBPcmRlclN1bW1hcnkgfSBmcm9tICcuL2NvbXBvbmVudHMvT3JkZXJTdW1tYXJ5JztcclxuaW1wb3J0IHsgUHJlcGFyZWRDaGVja291dCB9IGZyb20gJy4vY29tcG9uZW50cy9QcmVwYXJlZENoZWNrb3V0JztcclxuaW1wb3J0IHsgUGF5bWVudEFjdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9QYXltZW50QWN0aW9uJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5jaGVja291dDtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2hlY2tvdXRQYWdlKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIHJldHVybiB1c2VyID8gPENoZWNrb3V0Q29udGVudCBrZXk9e3VzZXIuaWR9IGVtYWlsPXt1c2VyLmVtYWlsfSAvPiA6IG51bGw7XHJcbn1cclxuZnVuY3Rpb24gQ2hlY2tvdXRDb250ZW50KHsgZW1haWwgfTogeyBlbWFpbDogc3RyaW5nIH0pIHtcclxuICBjb25zdCBwYWdlID0gdXNlQ2hlY2tvdXRQYWdlKGVtYWlsKTtcclxuICBjb25zdCBlcnJvckZvY3VzID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuICBjb25zdCBzdWNjZXNzRm9jdXMgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocGFnZS5lcnJvcikgZXJyb3JGb2N1cy5jdXJyZW50Py5mb2N1cygpO1xyXG4gIH0sIFtwYWdlLmVycm9yXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChwYWdlLnN1bW1hcnkpIHN1Y2Nlc3NGb2N1cy5jdXJyZW50Py5mb2N1cygpO1xyXG4gIH0sIFtwYWdlLnN1bW1hcnldKTtcclxuICBjb25zdCBibG9ja2VkID0gcGFnZS5jYXJ0Py5pdGVtcy5zb21lKChpdGVtKSA9PiAhaXRlbS5pc0F2YWlsYWJsZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHByZXZpb3VzID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICBkb2N1bWVudC50aXRsZSA9IGAke3QudGl0bGV9IHwgJHt0cmFuc2xhdGlvbnMuY29tbW9uLnN0b3JlTmFtZX1gO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJiZy1wYWdlIHB4LTQgcHktNiBzbTpweC02IG1kOnB5LTggbGc6cHgtOFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzEyMDBweF0gc3BhY2UteS02XCI+XHJcbiAgICAgICAgPG5hdlxyXG4gICAgICAgICAgYXJpYS1sYWJlbD17dHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLmJyZWFkY3J1bWJ9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLmNhcnR9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmsgaG92ZXI6dGV4dC1mZy1saW5rXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmNhcnQudGl0bGV9XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICA8bGkgYXJpYS1oaWRkZW49XCJ0cnVlXCI+LzwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBhcmlhLWN1cnJlbnQ9XCJwYWdlXCI+e3QudGl0bGV9PC9saT5cclxuICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIHRleHQtZmdcIj57dC50aXRsZX08L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPnt0LmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPExpbmsgdG89e1JPVVRFUy5jYXJ0fSBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICB7dC5iYWNrVG9DYXJ0fVxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtwYWdlLmVycm9yICYmIChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgcmVmPXtlcnJvckZvY3VzfVxyXG4gICAgICAgICAgICB0YWJJbmRleD17LTF9XHJcbiAgICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1kYW5nZXIvMjUgYmctZGFuZ2VyLWJnIHAtNCB0ZXh0LXNtIHRleHQtZGFuZ2VyIG91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctZGFuZ2VyXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHA+e3BhZ2UuZXJyb3J9PC9wPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2Uuc2F2aW5nIHx8IHBhZ2UubG9hZGluZ31cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVmcmVzaCgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgbWluLW1pbi1oLTExIHJvdW5kZWQtc20gcHgtMiBmb250LXNlbWlib2xkIHVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTQgXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHt0LnJlZnJlc2hDYXJ0fVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge3BhZ2Uuc3VtbWFyeSAmJiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHJlZj17c3VjY2Vzc0ZvY3VzfVxyXG4gICAgICAgICAgICB0YWJJbmRleD17LTF9XHJcbiAgICAgICAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc3VjY2Vzcy8yNSBiZy1zdWNjZXNzLWJnIHAtNSB0ZXh0LXN1Y2Nlc3Mgb3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1zdWNjZXNzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPnt0LnJlYWR5fTwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSBsZWFkaW5nLTZcIj57dC5yZWFkeURlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGxlYWRpbmctNVwiPnt0LnByZXBhcmF0aW9uTm90aWNlfTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgeyhwYWdlLmNoYW5nZXMucHJpY2VzQ2hhbmdlZCB8fCBwYWdlLmNoYW5nZXMuaXRlbXNDaGFuZ2VkKSAmJiAoXHJcbiAgICAgICAgICA8cFxyXG4gICAgICAgICAgICByb2xlPVwic3RhdHVzXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXdhcm5pbmcvMjUgYmctd2FybmluZy1iZyBwLTQgdGV4dC1zbSB0ZXh0LXdhcm5pbmdcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7cGFnZS5jaGFuZ2VzLnByaWNlc0NoYW5nZWQgPyB0LnByaWNlc0NoYW5nZWQgOiB0Lml0ZW1zQ2hhbmdlZH1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtwYWdlLmxvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LmxvYWRpbmd9IC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIHBhZ2UuY2FydCAmJlxyXG4gICAgICAgICAgKHBhZ2UuY2FydC5pdGVtcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgIDxFbXB0eUNhcnQgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAge2Jsb2NrZWQgJiYgIXBhZ2Uuc3VtbWFyeSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci13YXJuaW5nLzI1IGJnLXdhcm5pbmctYmcgcC00IHRleHQtc20gdGV4dC13YXJuaW5nXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHA+e3QuY2FydEJsb2NrZWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuY2FydH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIGlubGluZS1ibG9jayBmb250LXNlbWlib2xkIHVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3QuZml4Q2FydH1cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgaXRlbXMtc3RhcnQgZ2FwLTYgbGc6Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpXzI1cmVtXSBsZzpnYXAtOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RGVsaXZlcnlGb3JtIHBhZ2U9e3BhZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlLnN1bW1hcnkgJiYgPFByZXBhcmVkQ2hlY2tvdXQgc3VtbWFyeT17cGFnZS5zdW1tYXJ5fSAvPn1cclxuICAgICAgICAgICAgICAgICAge3BhZ2Uuc3VtbWFyeSAmJiA8UGF5bWVudEFjdGlvbiBwYWdlPXtwYWdlfSAvPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPE9yZGVyU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICBjYXJ0PXtwYWdlLmNhcnR9XHJcbiAgICAgICAgICAgICAgICAgIHN1bW1hcnk9e3BhZ2Uuc3VtbWFyeX1cclxuICAgICAgICAgICAgICAgICAgcHJldmlldz17cGFnZS5sYXRlc3RTdW1tYXJ5fVxyXG4gICAgICAgICAgICAgICAgICBjcmVkaXQ9e3BhZ2UuY3JlZGl0UHJldmlld31cclxuICAgICAgICAgICAgICAgICAgYW1vdW50RHVlPXtwYWdlLmFtb3VudER1ZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKSlcclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==