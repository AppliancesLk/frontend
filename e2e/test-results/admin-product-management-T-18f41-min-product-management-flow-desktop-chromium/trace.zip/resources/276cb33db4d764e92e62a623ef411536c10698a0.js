import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/chat/ChatConnection.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { chatText as t } from "/src/utils/chatText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConnection.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function ChatConnection({ state, reconnect }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-wrap items-center gap-3 text-sm",
		children: [
			/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: state === "connected" ? "text-success" : "text-fg-muted",
				children: state === "connected" ? t.connected : state === "connecting" ? t.connecting : t.disconnected
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this),
			state !== "connected" && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: reconnect,
				className: "rounded text-fg-link underline focus-visible:outline-2 focus-visible:outline-primary",
				children: t.reconnect
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 9
			}, this),
			state === "error" && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "text-danger",
				children: t.connectionError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_c = ChatConnection;
var _c;
$RefreshReg$(_c, "ChatConnection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/chat/ChatConnection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConnection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConnection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/chat/ChatConnection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLFNBQVM7OztBQUM5QixPQUFPLFNBQVMsZUFBZSxFQUM3QixPQUNBLGFBSUM7Q0FDRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxLQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVcsVUFBVSxjQUFjLGlCQUFpQjtjQUVuRCxVQUFVLGNBQ1AsRUFBRSxZQUNGLFVBQVUsZUFDUixFQUFFLGFBQ0YsRUFBRTtHQUNQOzs7OztHQUNGLFVBQVUsZUFDVCx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFNBQVM7SUFDVCxXQUFVO2NBRVQsRUFBRTtHQUNHOzs7OztHQUVULFVBQVUsV0FDVCx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFRLFdBQVU7Y0FDdkIsRUFBRTtHQUNGOzs7OztFQUVGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGF0Q29ubmVjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY2hhdFRleHQgYXMgdCB9IGZyb20gJy4uLy4uL3V0aWxzL2NoYXRUZXh0JztcclxuZXhwb3J0IGZ1bmN0aW9uIENoYXRDb25uZWN0aW9uKHtcclxuICBzdGF0ZSxcclxuICByZWNvbm5lY3QsXHJcbn06IHtcclxuICBzdGF0ZTogJ2Nvbm5lY3RpbmcnIHwgJ2Nvbm5lY3RlZCcgfCAnZGlzY29ubmVjdGVkJyB8ICdlcnJvcic7XHJcbiAgcmVjb25uZWN0OiAoKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc21cIj5cclxuICAgICAgPHBcclxuICAgICAgICByb2xlPVwic3RhdHVzXCJcclxuICAgICAgICBjbGFzc05hbWU9e3N0YXRlID09PSAnY29ubmVjdGVkJyA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtZmctbXV0ZWQnfVxyXG4gICAgICA+XHJcbiAgICAgICAge3N0YXRlID09PSAnY29ubmVjdGVkJ1xyXG4gICAgICAgICAgPyB0LmNvbm5lY3RlZFxyXG4gICAgICAgICAgOiBzdGF0ZSA9PT0gJ2Nvbm5lY3RpbmcnXHJcbiAgICAgICAgICAgID8gdC5jb25uZWN0aW5nXHJcbiAgICAgICAgICAgIDogdC5kaXNjb25uZWN0ZWR9XHJcbiAgICAgIDwvcD5cclxuICAgICAge3N0YXRlICE9PSAnY29ubmVjdGVkJyAmJiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtyZWNvbm5lY3R9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHRleHQtZmctbGluayB1bmRlcmxpbmUgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLXByaW1hcnlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0LnJlY29ubmVjdH1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgKX1cclxuICAgICAge3N0YXRlID09PSAnZXJyb3InICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ0ZXh0LWRhbmdlclwiPlxyXG4gICAgICAgICAge3QuY29ubmVjdGlvbkVycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19