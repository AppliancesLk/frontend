import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Feedback.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/components/common/Icon.tsx";
import { uiText } from "/src/utils/uiText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Feedback.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function Spinner({ className = "" }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		"aria-hidden": "true",
		className: `ui-spinner ${className}`
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 10
	}, this);
}
_c = Spinner;
export function Skeleton({ className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"aria-hidden": "true",
		className: `ui-skeleton ${className}`
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 10
	}, this);
}
_c2 = Skeleton;
export function LoadingState({ label = uiText.loading, compact = false }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		"aria-live": "polite",
		className: `ui-loading ${compact ? "ui-loading-compact" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			!compact && /* @__PURE__ */ _jsxDEV("div", {
				"aria-hidden": "true",
				className: "mt-3 grid w-full max-w-lg gap-3",
				children: [
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-3 w-2/3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-3 w-4/5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_c3 = LoadingState;
export function Alert({ children, severity = "danger", className = "" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		role: severity === "danger" ? "alert" : "status",
		className: `ui-alert ui-tone-${severity} ${className}`,
		children: [/* @__PURE__ */ _jsxDEV(Icon, {
			name: severity === "success" ? "check" : "info",
			className: "mt-0.5 h-5 w-5 shrink-0"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "min-w-0",
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
}
_c4 = Alert;
export function ErrorState({ message, retry, title = uiText.error }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		role: "alert",
		className: "ui-state",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "ui-state-icon bg-danger-bg text-danger",
				children: /* @__PURE__ */ _jsxDEV(Icon, { name: "info" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "mt-4 text-lg font-semibold text-fg",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm leading-6 text-fg-secondary",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 7
			}, this),
			retry && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "ui-button ui-button-secondary mt-5",
				onClick: retry,
				children: uiText.retry
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
}
_c5 = ErrorState;
export function EmptyState({ title = uiText.empty, description, action, icon = "bag", headingAs = "h2" }) {
	const Heading = headingAs;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "ui-state",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "ui-state-icon bg-primary-subtle text-fg-link",
				children: /* @__PURE__ */ _jsxDEV(Icon, {
					name: icon,
					className: "h-6 w-6"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Heading, {
				className: "mt-4 text-lg font-semibold text-fg",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 7
			}, this),
			description && /* @__PURE__ */ _jsxDEV("p", {
				className: "mx-auto mt-2 max-w-md text-sm leading-6 text-fg-secondary",
				children: description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 9
			}, this),
			action && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6",
				children: action
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 111,
				columnNumber: 18
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 101,
		columnNumber: 5
	}, this);
}
_c6 = EmptyState;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "Spinner");
$RefreshReg$(_c2, "Skeleton");
$RefreshReg$(_c3, "LoadingState");
$RefreshReg$(_c4, "Alert");
$RefreshReg$(_c5, "ErrorState");
$RefreshReg$(_c6, "EmptyState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/Feedback.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Feedback.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Feedback.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/Feedback.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxZQUEyQjtBQUNwQyxTQUFTLGNBQWM7OztBQUV2QixPQUFPLFNBQVMsUUFBUSxFQUFFLFlBQVksTUFBOEI7Q0FDbEUsT0FBTyx3QkFBQyxRQUFEO0VBQU0sZUFBWTtFQUFPLFdBQVcsY0FBYztDQUFjOzs7OztBQUN6RTs7QUFDQSxPQUFPLFNBQVMsU0FBUyxFQUFFLFlBQVksTUFBOEI7Q0FDbkUsT0FBTyx3QkFBQyxPQUFEO0VBQUssZUFBWTtFQUFPLFdBQVcsZUFBZTtDQUFjOzs7OztBQUN6RTs7QUFDQSxPQUFPLFNBQVMsYUFBYSxFQUMzQixRQUFRLE9BQU8sU0FDZixVQUFVLFNBSVQ7Q0FDRCxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxNQUFLO0VBQ0wsYUFBVTtFQUNWLFdBQVcsY0FBYyxVQUFVLHVCQUF1QjtZQUg1RDtHQUtFLHdCQUFDLFNBQUQsQ0FBVTs7Ozs7R0FDVix3QkFBQyxRQUFELFlBQU8sTUFBWTs7Ozs7R0FDbEIsQ0FBQyxXQUNBLHdCQUFDLE9BQUQ7SUFBSyxlQUFZO0lBQU8sV0FBVTtjQUFsQztLQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFlBQWE7Ozs7O0tBQ2pDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLE1BQU87Ozs7O0tBQzNCLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFlBQWE7Ozs7O0lBQzlCOzs7Ozs7RUFFSjs7Ozs7O0FBRVQ7O0FBQ0EsT0FBTyxTQUFTLE1BQU0sRUFDcEIsVUFDQSxXQUFXLFVBQ1gsWUFBWSxNQUtYO0NBQ0QsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsTUFBTSxhQUFhLFdBQVcsVUFBVTtFQUN4QyxXQUFXLG9CQUFvQixTQUFTLEdBQUc7WUFGN0MsQ0FJRSx3QkFBQyxNQUFEO0dBQ0UsTUFBTSxhQUFhLFlBQVksVUFBVTtHQUN6QyxXQUFVO0VBQ1g7Ozs7WUFDRCx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFXO0VBQWM7Ozs7VUFDckM7Ozs7OztBQUVUOztBQUNBLE9BQU8sU0FBUyxXQUFXLEVBQ3pCLFNBQ0EsT0FDQSxRQUFRLE9BQU8sU0FLZDtDQUNELE9BQ0Usd0JBQUMsV0FBRDtFQUFTLE1BQUs7RUFBUSxXQUFVO1lBQWhDO0dBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7OztHQUNmOzs7OztHQUNOLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXNDO0dBQVU7Ozs7O0dBQzlELHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTRDO0dBQVc7Ozs7O0dBQ25FLFNBQ0Msd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO0lBQ1YsU0FBUztjQUVSLE9BQU87R0FDRjs7Ozs7RUFFSDs7Ozs7O0FBRWI7O0FBQ0EsT0FBTyxTQUFTLFdBQVcsRUFDekIsUUFBUSxPQUFPLE9BQ2YsYUFDQSxRQUNBLE9BQU8sT0FDUCxZQUFZLFFBT1g7Q0FDRCxNQUFNLFVBQVU7Q0FDaEIsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ2Qsd0JBQUMsTUFBRDtLQUFNLE1BQU07S0FBTSxXQUFVO0lBQVc7Ozs7O0dBQ25DOzs7OztHQUNOLHdCQUFDLFNBQUQ7SUFBUyxXQUFVO2NBQXNDO0dBQWU7Ozs7O0dBQ3ZFLGVBQ0Msd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVjtHQUNBOzs7OztHQUVKLFVBQVUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBUTtHQUFZOzs7OztFQUN2Qzs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRmVlZGJhY2sudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBJY29uLCB0eXBlIEljb25OYW1lIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyB1aVRleHQgfSBmcm9tICcuLi8uLi91dGlscy91aVRleHQnO1xyXG5pbXBvcnQgdHlwZSB7IFNldmVyaXR5IH0gZnJvbSAnLi9TdGF0dXNCYWRnZSc7XHJcbmV4cG9ydCBmdW5jdGlvbiBTcGlubmVyKHsgY2xhc3NOYW1lID0gJycgfTogeyBjbGFzc05hbWU/OiBzdHJpbmcgfSkge1xyXG4gIHJldHVybiA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9e2B1aS1zcGlubmVyICR7Y2xhc3NOYW1lfWB9IC8+O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBTa2VsZXRvbih7IGNsYXNzTmFtZSA9ICcnIH06IHsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcclxuICByZXR1cm4gPGRpdiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9e2B1aS1za2VsZXRvbiAke2NsYXNzTmFtZX1gfSAvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gTG9hZGluZ1N0YXRlKHtcclxuICBsYWJlbCA9IHVpVGV4dC5sb2FkaW5nLFxyXG4gIGNvbXBhY3QgPSBmYWxzZSxcclxufToge1xyXG4gIGxhYmVsPzogc3RyaW5nO1xyXG4gIGNvbXBhY3Q/OiBib29sZWFuO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgcm9sZT1cInN0YXR1c1wiXHJcbiAgICAgIGFyaWEtbGl2ZT1cInBvbGl0ZVwiXHJcbiAgICAgIGNsYXNzTmFtZT17YHVpLWxvYWRpbmcgJHtjb21wYWN0ID8gJ3VpLWxvYWRpbmctY29tcGFjdCcgOiAnJ31gfVxyXG4gICAgPlxyXG4gICAgICA8U3Bpbm5lciAvPlxyXG4gICAgICA8c3Bhbj57bGFiZWx9PC9zcGFuPlxyXG4gICAgICB7IWNvbXBhY3QgJiYgKFxyXG4gICAgICAgIDxkaXYgYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwibXQtMyBncmlkIHctZnVsbCBtYXgtdy1sZyBnYXAtM1wiPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMyB3LTIvM1wiIC8+XHJcbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0zXCIgLz5cclxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTMgdy00LzVcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gQWxlcnQoe1xyXG4gIGNoaWxkcmVuLFxyXG4gIHNldmVyaXR5ID0gJ2RhbmdlcicsXHJcbiAgY2xhc3NOYW1lID0gJycsXHJcbn06IHtcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG4gIHNldmVyaXR5PzogU2V2ZXJpdHk7XHJcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgcm9sZT17c2V2ZXJpdHkgPT09ICdkYW5nZXInID8gJ2FsZXJ0JyA6ICdzdGF0dXMnfVxyXG4gICAgICBjbGFzc05hbWU9e2B1aS1hbGVydCB1aS10b25lLSR7c2V2ZXJpdHl9ICR7Y2xhc3NOYW1lfWB9XHJcbiAgICA+XHJcbiAgICAgIDxJY29uXHJcbiAgICAgICAgbmFtZT17c2V2ZXJpdHkgPT09ICdzdWNjZXNzJyA/ICdjaGVjaycgOiAnaW5mbyd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibXQtMC41IGgtNSB3LTUgc2hyaW5rLTBcIlxyXG4gICAgICAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj57Y2hpbGRyZW59PC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBFcnJvclN0YXRlKHtcclxuICBtZXNzYWdlLFxyXG4gIHJldHJ5LFxyXG4gIHRpdGxlID0gdWlUZXh0LmVycm9yLFxyXG59OiB7XHJcbiAgbWVzc2FnZTogc3RyaW5nO1xyXG4gIHJldHJ5PzogKCkgPT4gdm9pZDtcclxuICB0aXRsZT86IHN0cmluZztcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ1aS1zdGF0ZVwiPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1aS1zdGF0ZS1pY29uIGJnLWRhbmdlci1iZyB0ZXh0LWRhbmdlclwiPlxyXG4gICAgICAgIDxJY29uIG5hbWU9XCJpbmZvXCIgLz5cclxuICAgICAgPC9zcGFuPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt0aXRsZX08L2gyPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctc2Vjb25kYXJ5XCI+e21lc3NhZ2V9PC9wPlxyXG4gICAgICB7cmV0cnkgJiYgKFxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgbXQtNVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtyZXRyeX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7dWlUZXh0LnJldHJ5fVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIEVtcHR5U3RhdGUoe1xyXG4gIHRpdGxlID0gdWlUZXh0LmVtcHR5LFxyXG4gIGRlc2NyaXB0aW9uLFxyXG4gIGFjdGlvbixcclxuICBpY29uID0gJ2JhZycsXHJcbiAgaGVhZGluZ0FzID0gJ2gyJyxcclxufToge1xyXG4gIHRpdGxlPzogc3RyaW5nO1xyXG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xyXG4gIGFjdGlvbj86IFJlYWN0Tm9kZTtcclxuICBpY29uPzogSWNvbk5hbWU7XHJcbiAgaGVhZGluZ0FzPzogJ2gxJyB8ICdoMic7XHJcbn0pIHtcclxuICBjb25zdCBIZWFkaW5nID0gaGVhZGluZ0FzO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ1aS1zdGF0ZVwiPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1aS1zdGF0ZS1pY29uIGJnLXByaW1hcnktc3VidGxlIHRleHQtZmctbGlua1wiPlxyXG4gICAgICAgIDxJY29uIG5hbWU9e2ljb259IGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPlxyXG4gICAgICA8L3NwYW4+XHJcbiAgICAgIDxIZWFkaW5nIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZmdcIj57dGl0bGV9PC9IZWFkaW5nPlxyXG4gICAgICB7ZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm14LWF1dG8gbXQtMiBtYXgtdy1tZCB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAge2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2FjdGlvbiAmJiA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj57YWN0aW9ufTwvZGl2Pn1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==