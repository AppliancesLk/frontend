import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Products/components/CategoryIcon.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CategoryIcon.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function CategoryIcon({ name, className = "h-5 w-5" }) {
	let icon = "grid";
	if (/phone|mobile|tablet/i.test(name)) icon = "phone";
	else if (/laptop|computer/i.test(name)) icon = "laptop";
	else if (/audio|headphone|earbud|accessor/i.test(name)) icon = "headphones";
	else if (/watch/i.test(name)) icon = "watch";
	else if (/appliance|kitchen|laundry/i.test(name)) icon = "appliance";
	return /* @__PURE__ */ _jsxDEV(Icon, {
		name: icon,
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 10
	}, this);
}
_c = CategoryIcon;
var _c;
$RefreshReg$(_c, "CategoryIcon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Products/components/CategoryIcon.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CategoryIcon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CategoryIcon.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CategoryIcon.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUEyQjs7O0FBQ3BDLE9BQU8sU0FBUyxhQUFhLEVBQzNCLE1BQ0EsWUFBWSxhQUlYO0NBQ0QsSUFBSSxPQUFpQjtDQUNyQixJQUFJLHVCQUF1QixLQUFLLElBQUksR0FBRyxPQUFPO01BQ3pDLElBQUksbUJBQW1CLEtBQUssSUFBSSxHQUFHLE9BQU87TUFDMUMsSUFBSSxtQ0FBbUMsS0FBSyxJQUFJLEdBQUcsT0FBTztNQUMxRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEdBQUcsT0FBTztNQUNoQyxJQUFJLDZCQUE2QixLQUFLLElBQUksR0FBRyxPQUFPO0NBQ3pELE9BQU8sd0JBQUMsTUFBRDtFQUFNLE1BQU07RUFBaUI7Q0FBWTs7Ozs7QUFDbEQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2F0ZWdvcnlJY29uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJY29uLCB0eXBlIEljb25OYW1lIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XG5leHBvcnQgZnVuY3Rpb24gQ2F0ZWdvcnlJY29uKHtcbiAgbmFtZSxcbiAgY2xhc3NOYW1lID0gJ2gtNSB3LTUnLFxufToge1xuICBuYW1lOiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn0pIHtcbiAgbGV0IGljb246IEljb25OYW1lID0gJ2dyaWQnO1xuICBpZiAoL3Bob25lfG1vYmlsZXx0YWJsZXQvaS50ZXN0KG5hbWUpKSBpY29uID0gJ3Bob25lJztcbiAgZWxzZSBpZiAoL2xhcHRvcHxjb21wdXRlci9pLnRlc3QobmFtZSkpIGljb24gPSAnbGFwdG9wJztcbiAgZWxzZSBpZiAoL2F1ZGlvfGhlYWRwaG9uZXxlYXJidWR8YWNjZXNzb3IvaS50ZXN0KG5hbWUpKSBpY29uID0gJ2hlYWRwaG9uZXMnO1xuICBlbHNlIGlmICgvd2F0Y2gvaS50ZXN0KG5hbWUpKSBpY29uID0gJ3dhdGNoJztcbiAgZWxzZSBpZiAoL2FwcGxpYW5jZXxraXRjaGVufGxhdW5kcnkvaS50ZXN0KG5hbWUpKSBpY29uID0gJ2FwcGxpYW5jZSc7XG4gIHJldHVybiA8SWNvbiBuYW1lPXtpY29ufSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG59XG4iXX0=