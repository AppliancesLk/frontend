import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Repairer/Dashboard/index.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { uiText } from "/src/utils/uiText.ts";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { AccountDetails } from "/src/components/common/AccountDetails.tsx";
import { translations } from "/src/utils/translations.ts";
import { ROUTES } from "/src/constants/routes.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Dashboard/index.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function RepairerDashboardPage() {
	_s();
	const { user } = useAuth();
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "mx-auto max-w-3xl space-y-6",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "ui-page-title mt-3    text-fg",
						children: [
							translations.auth.hello,
							", ",
							user?.username
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-fg-muted",
						children: uiText.repairerDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.repairerRepairs,
						className: "group rounded-md border border-line bg-surface p-6  transition-all hover:border-primary ",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-semibold text-fg group-hover:text-fg-link",
								children: uiText.assignedRepairs
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 26,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("svg", {
								className: "h-5 w-5 text-fg-muted transition-transform group-hover:translate-x-1 group-hover:text-fg-link",
								fill: "none",
								viewBox: "0 0 24 24",
								stroke: "currentColor",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: 2,
									d: "M9 5l7 7-7 7"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 35,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 29,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm text-fg-muted",
							children: uiText.assignedDescription
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: uiText.account
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(AccountDetails, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_s(RepairerDashboardPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = RepairerDashboardPage;
var _c;
$RefreshReg$(_c, "RepairerDashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Repairer/Dashboard/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Dashboard/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Dashboard/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Dashboard/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjOzs7O0FBRXZCLGVBQWUsU0FBUyx3QkFBd0I7O0NBQzlDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUNkLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQ0csYUFBYSxLQUFLO09BQU07T0FBRyxNQUFNO01BQ2hDOzs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFzQixPQUFPO0tBQXVCOzs7O2FBQzlEOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE1BQUQ7TUFDRSxJQUFJLE9BQU87TUFDWCxXQUFVO2dCQUZaLENBSUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxPQUFPO09BQ047Ozs7aUJBQ0osd0JBQUMsT0FBRDtRQUNFLFdBQVU7UUFDVixNQUFLO1FBQ0wsU0FBUTtRQUNSLFFBQU87a0JBRVAsd0JBQUMsUUFBRDtTQUNFLGVBQWM7U0FDZCxnQkFBZTtTQUNmLGFBQWE7U0FDYixHQUFFO1FBQ0g7Ozs7O09BQ0U7Ozs7ZUFDRjs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsT0FBTztNQUNQOzs7O2NBQ0M7Ozs7OztJQUNIOzs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBaUMsT0FBTztLQUFZOzs7O2VBQ2xFLHdCQUFDLGdCQUFELENBQWlCOzs7O2FBQ2Q7Ozs7OztHQUNFOzs7Ozs7Q0FDTDs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdWlUZXh0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdWlUZXh0JztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IEFjY291bnREZXRhaWxzIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vQWNjb3VudERldGFpbHMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlcGFpcmVyRGFzaGJvYXJkUGFnZSgpIHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYmctcGFnZSBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy0zeGwgc3BhY2UteS02XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIG10LTMgICAgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICB7dHJhbnNsYXRpb25zLmF1dGguaGVsbG99LCB7dXNlcj8udXNlcm5hbWV9XHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWZnLW11dGVkXCI+e3VpVGV4dC5yZXBhaXJlckRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IHNtOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz17Uk9VVEVTLnJlcGFpcmVyUmVwYWlyc31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTYgIHRyYW5zaXRpb24tYWxsIGhvdmVyOmJvcmRlci1wcmltYXJ5IFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnIGdyb3VwLWhvdmVyOnRleHQtZmctbGlua1wiPlxyXG4gICAgICAgICAgICAgICAge3VpVGV4dC5hc3NpZ25lZFJlcGFpcnN9XHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtZmctbXV0ZWQgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSBncm91cC1ob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgZD1cIk05IDVsNyA3LTcgN1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICB7dWlUZXh0LmFzc2lnbmVkRGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPnt1aVRleHQuYWNjb3VudH08L2gyPlxyXG4gICAgICAgICAgPEFjY291bnREZXRhaWxzIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==