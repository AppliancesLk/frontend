import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/components/PromotionBadge.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { promotionText as t } from "/src/utils/promotionText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/PromotionBadge.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function PromotionBadge({ status }) {
	const tone = status === "SENT" ? "bg-success-bg text-success" : status === "FAILED" || status === "UNKNOWN" ? "bg-danger-bg text-danger" : status === "PARTIAL" ? "bg-warning-bg text-warning" : "bg-subtle text-fg-secondary";
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${tone}`,
		children: status ? t.statuses[status] : t.draft
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_c = PromotionBadge;
var _c;
$RefreshReg$(_c, "PromotionBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/components/PromotionBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/PromotionBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/PromotionBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/PromotionBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsU0FBUzs7O0FBQ25DLE9BQU8sU0FBUyxlQUFlLEVBQzdCLFVBR0M7Q0FDRCxNQUFNLE9BQ0osV0FBVyxTQUNQLCtCQUNBLFdBQVcsWUFBWSxXQUFXLFlBQ2hDLDZCQUNBLFdBQVcsWUFDVCwrQkFDQTtDQUNWLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLFdBQVcsNERBQTREO1lBRXRFLFNBQVMsRUFBRSxTQUFTLFVBQVUsRUFBRTtDQUM3Qjs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9tb3Rpb25CYWRnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcHJvbW90aW9uVGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvcHJvbW90aW9uVGV4dCc7XHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9tb3Rpb25CYWRnZSh7XHJcbiAgc3RhdHVzLFxyXG59OiB7XHJcbiAgc3RhdHVzPzoga2V5b2YgdHlwZW9mIHQuc3RhdHVzZXM7XHJcbn0pIHtcclxuICBjb25zdCB0b25lID1cclxuICAgIHN0YXR1cyA9PT0gJ1NFTlQnXHJcbiAgICAgID8gJ2JnLXN1Y2Nlc3MtYmcgdGV4dC1zdWNjZXNzJ1xyXG4gICAgICA6IHN0YXR1cyA9PT0gJ0ZBSUxFRCcgfHwgc3RhdHVzID09PSAnVU5LTk9XTidcclxuICAgICAgICA/ICdiZy1kYW5nZXItYmcgdGV4dC1kYW5nZXInXHJcbiAgICAgICAgOiBzdGF0dXMgPT09ICdQQVJUSUFMJ1xyXG4gICAgICAgICAgPyAnYmctd2FybmluZy1iZyB0ZXh0LXdhcm5pbmcnXHJcbiAgICAgICAgICA6ICdiZy1zdWJ0bGUgdGV4dC1mZy1zZWNvbmRhcnknO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSAke3RvbmV9YH1cclxuICAgID5cclxuICAgICAge3N0YXR1cyA/IHQuc3RhdHVzZXNbc3RhdHVzXSA6IHQuZHJhZnR9XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufVxyXG4iXX0=