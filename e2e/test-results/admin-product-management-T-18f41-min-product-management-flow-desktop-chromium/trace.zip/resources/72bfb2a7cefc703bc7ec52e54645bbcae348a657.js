import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { translations } from "/src/utils/translations.ts";
import { useRelatedProducts } from "/src/pages/Customer/ProductDetails/hooks/useRelatedProducts.ts";
import { CatalogProductCard } from "/src/pages/Products/components/CatalogProductCard.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.productDetails;
export function RelatedProducts({ product }) {
	_s();
	const related = useRelatedProducts(product);
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "related-title",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-5",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				id: "related-title",
				className: "text-xl font-semibold text-fg",
				children: t.related
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-2 text-sm text-fg-muted",
				children: t.relatedDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this), related.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, {
			label: t.relatedLoading,
			compact: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 9
		}, this) : related.error ? /* @__PURE__ */ _jsxDEV("div", {
			role: "alert",
			className: "rounded-md border border-line bg-surface p-6",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "mb-3 text-sm text-fg-secondary",
				children: t.relatedError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "auth-secondary",
				onClick: related.retry,
				children: translations.common.retry
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 9
		}, this) : !related.products.length ? /* @__PURE__ */ _jsxDEV("p", {
			className: "rounded-md border border-line bg-surface p-6 text-sm text-fg-muted",
			children: t.relatedEmpty
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 gap-3 md:gap-6 xl:grid-cols-4",
			children: related.products.map((item) => /* @__PURE__ */ _jsxDEV(CatalogProductCard, { product: item }, item.productID, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_s(RelatedProducts, "trSN4MHNTNdPy654itqH6i0jeqU=", false, function() {
	return [useRelatedProducts];
});
_c = RelatedProducts;
var _c;
$RefreshReg$(_c, "RelatedProducts");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/RelatedProducts.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFFN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUywwQkFBMEI7QUFDbkMsU0FBUywwQkFBMEI7Ozs7QUFDbkMsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGdCQUFnQixFQUFFLFdBQWlDOztDQUNqRSxNQUFNLFVBQVUsbUJBQW1CLE9BQU87Q0FDMUMsT0FDRSx3QkFBQyxXQUFEO0VBQVMsbUJBQWdCO1lBQXpCLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE1BQUQ7SUFBSSxJQUFHO0lBQWdCLFdBQVU7Y0FDOUIsRUFBRTtHQUNEOzs7O2FBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBOEIsRUFBRTtHQUFzQjs7OztXQUNoRTs7Ozs7WUFDSixRQUFRLFVBQ1Asd0JBQUMsY0FBRDtHQUFjLE9BQU8sRUFBRTtHQUFnQixTQUFTO0VBQU87Ozs7YUFDckQsUUFBUSxRQUNWLHdCQUFDLE9BQUQ7R0FDRSxNQUFLO0dBQ0wsV0FBVTthQUZaLENBSUUsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBa0MsRUFBRTtHQUFnQjs7OzthQUNqRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFpQixTQUFTLFFBQVE7Y0FDakQsYUFBYSxPQUFPO0dBQ2Y7Ozs7V0FDTDs7Ozs7YUFDSCxDQUFDLFFBQVEsU0FBUyxTQUNwQix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUNWLEVBQUU7RUFDRjs7OzthQUVILHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osUUFBUSxTQUFTLEtBQUssU0FDckIsd0JBQUMsb0JBQUQsRUFBeUMsU0FBUyxLQUFPLEdBQWhDLEtBQUs7Ozs7VUFBMkIsQ0FDMUQ7RUFDRTs7OztVQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZWxhdGVkUHJvZHVjdHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi8uLi8uLi90eXBlcy9wcm9kdWN0LnR5cGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgdXNlUmVsYXRlZFByb2R1Y3RzIH0gZnJvbSAnLi4vaG9va3MvdXNlUmVsYXRlZFByb2R1Y3RzJztcclxuaW1wb3J0IHsgQ2F0YWxvZ1Byb2R1Y3RDYXJkIH0gZnJvbSAnLi4vLi4vLi4vUHJvZHVjdHMvY29tcG9uZW50cy9DYXRhbG9nUHJvZHVjdENhcmQnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzO1xyXG5leHBvcnQgZnVuY3Rpb24gUmVsYXRlZFByb2R1Y3RzKHsgcHJvZHVjdCB9OiB7IHByb2R1Y3Q6IFByb2R1Y3QgfSkge1xyXG4gIGNvbnN0IHJlbGF0ZWQgPSB1c2VSZWxhdGVkUHJvZHVjdHMocHJvZHVjdCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cInJlbGF0ZWQtdGl0bGVcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbiAgICAgICAgPGgyIGlkPVwicmVsYXRlZC10aXRsZVwiIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICB7dC5yZWxhdGVkfVxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5yZWxhdGVkRGVzY3JpcHRpb259PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge3JlbGF0ZWQubG9hZGluZyA/IChcclxuICAgICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LnJlbGF0ZWRMb2FkaW5nfSBjb21wYWN0PXt0cnVlfSAvPlxyXG4gICAgICApIDogcmVsYXRlZC5lcnJvciA/IChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTZcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTMgdGV4dC1zbSB0ZXh0LWZnLXNlY29uZGFyeVwiPnt0LnJlbGF0ZWRFcnJvcn08L3A+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCIgb25DbGljaz17cmVsYXRlZC5yZXRyeX0+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLnJldHJ5fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAhcmVsYXRlZC5wcm9kdWN0cy5sZW5ndGggPyAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTYgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICB7dC5yZWxhdGVkRW1wdHl9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBtZDpnYXAtNiB4bDpncmlkLWNvbHMtNFwiPlxyXG4gICAgICAgICAge3JlbGF0ZWQucHJvZHVjdHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgIDxDYXRhbG9nUHJvZHVjdENhcmQga2V5PXtpdGVtLnByb2R1Y3RJRH0gcHJvZHVjdD17aXRlbX0gLz5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl19