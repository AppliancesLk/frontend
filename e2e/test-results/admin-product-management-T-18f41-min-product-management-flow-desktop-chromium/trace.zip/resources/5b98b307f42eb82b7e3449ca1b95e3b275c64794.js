import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { aiText } from "/src/utils/aiText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function AiChatMessage({ message }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: message.role === "USER" ? "ml-8 rounded-md bg-primary-subtle p-3" : "mr-4 rounded-md border border-line bg-surface p-3",
		children: [/* @__PURE__ */ _jsxDEV("p", {
			className: "mb-1 text-xs font-semibold text-fg-muted",
			children: message.role === "USER" ? aiText.you : aiText.assistant
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "whitespace-pre-wrap break-words text-sm leading-6 text-fg",
			children: message.content
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = AiChatMessage;
var _c;
$RefreshReg$(_c, "AiChatMessage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductAiAssistant/AiChatMessage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxjQUFjOzs7QUFFdkIsT0FBTyxTQUFTLGNBQWMsRUFBRSxXQUFpQztDQUMvRCxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUNFLFFBQVEsU0FBUyxTQUNiLDBDQUNBO1lBSlIsQ0FPRSx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUNWLFFBQVEsU0FBUyxTQUFTLE9BQU8sTUFBTSxPQUFPO0VBQzlDOzs7O1lBQ0gsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFDVixRQUFRO0VBQ1I7Ozs7VUFDQTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWlDaGF0TWVzc2FnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBaUNoYXRNZXNzYWdlIGFzIE1lc3NhZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi90eXBlcy9haS50eXBlcyc7XHJcbmltcG9ydCB7IGFpVGV4dCB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3V0aWxzL2FpVGV4dCc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQWlDaGF0TWVzc2FnZSh7IG1lc3NhZ2UgfTogeyBtZXNzYWdlOiBNZXNzYWdlIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgIG1lc3NhZ2Uucm9sZSA9PT0gJ1VTRVInXHJcbiAgICAgICAgICA/ICdtbC04IHJvdW5kZWQtbWQgYmctcHJpbWFyeS1zdWJ0bGUgcC0zJ1xyXG4gICAgICAgICAgOiAnbXItNCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtMydcclxuICAgICAgfVxyXG4gICAgPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtYi0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAge21lc3NhZ2Uucm9sZSA9PT0gJ1VTRVInID8gYWlUZXh0LnlvdSA6IGFpVGV4dC5hc3Npc3RhbnR9XHJcbiAgICAgIDwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1wcmUtd3JhcCBicmVhay13b3JkcyB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnXCI+XHJcbiAgICAgICAge21lc3NhZ2UuY29udGVudH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=