import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductGallery.tsx");const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { getProductImages } from "/src/pages/Customer/ProductDetails/helpers/product-details.helpers.ts";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductGallery.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.productDetails;
export function ProductGallery({ images, name }) {
	_s();
	const items = getProductImages(images);
	const [selected, setSelected] = useState(0);
	const index = selected < items.length ? selected : 0;
	const dialog = useRef(null);
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-label": t.gallery,
		tabIndex: 0,
		onKeyDown: (event) => {
			if (items.length > 1 && (event.key === "ArrowRight" || event.key === "ArrowLeft")) {
				event.preventDefault();
				setSelected((index + (event.key === "ArrowRight" ? 1 : items.length - 1)) % items.length);
			}
		},
		className: "product-gallery min-w-0",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: `grid gap-3 ${items.length > 1 ? "sm:grid-cols-[4rem_minmax(0,1fr)]" : ""}`,
			children: [items.length > 1 && /* @__PURE__ */ _jsxDEV("div", {
				className: "order-2 flex gap-2 overflow-x-auto p-0.5 sm:order-none sm:max-h-[26rem] sm:flex-col sm:overflow-y-auto sm:overflow-x-hidden",
				children: items.map((src, i) => /* @__PURE__ */ _jsxDEV("button", {
					"aria-label": `${t.viewImage} ${i + 1}: ${name}`,
					"aria-pressed": i === index,
					onClick: () => setSelected(i),
					className: `h-16 w-16 shrink-0 rounded-sm border-2 bg-well p-1 ${i === index ? "border-primary" : "border-line-subtle hover:border-primary"}`,
					children: /* @__PURE__ */ _jsxDEV(ProductImage, {
						src,
						alt: "",
						className: "h-full w-full"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 17
					}, this)
				}, src, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "relative min-w-0 rounded-lg bg-well p-3",
				children: [
					/* @__PURE__ */ _jsxDEV(ProductImage, {
						src: items[index],
						alt: `${name}${items.length > 1 ? ` - ${t.image} ${index + 1}` : ""}`,
						eager: true,
						className: "aspect-square w-full p-3"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this),
					items.length > 1 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
						"aria-label": t.previousImage,
						onClick: () => setSelected((index + items.length - 1) % items.length),
						className: "absolute left-1 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-line-subtle bg-surface ",
						children: "←"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						"aria-label": t.nextImage,
						onClick: () => setSelected((index + 1) % items.length),
						className: "absolute right-1 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-line-subtle bg-surface ",
						children: "→"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this),
					items.length > 0 && /* @__PURE__ */ _jsxDEV("button", {
						"aria-label": translations.experience.zoom,
						onClick: () => dialog.current?.showModal(),
						className: "absolute bottom-2 right-2 flex min-h-11 w-11 items-center justify-center rounded-full border border-line bg-surface text-xl text-fg-link ",
						children: "⤢"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						"aria-live": "polite",
						className: "mt-3 text-center text-xs text-fg-muted",
						children: items.length ? `${t.image} ${index + 1} ${t.of} ${items.length}` : t.noImage
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("dialog", {
			ref: dialog,
			"aria-label": translations.experience.zoom,
			className: "ui-dialog max-w-4xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-3 flex justify-end",
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => dialog.current?.close(),
					className: "ui-button ui-button-secondary rounded-sm border border-line px-4 py-2 text-sm",
					children: translations.experience.close
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(ProductImage, {
				src: items[index],
				alt: name,
				className: "max-h-[75vh] w-full"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_s(ProductGallery, "F8iEgHDBsFCuj65702Ga54XeO48=");
_c = ProductGallery;
var _c;
$RefreshReg$(_c, "ProductGallery");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductGallery.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductGallery.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductGallery.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductGallery.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLGdCQUFnQjtBQUNqQyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjs7OztBQUM3QixNQUFNLElBQUksYUFBYTtBQUN2QixPQUFPLFNBQVMsZUFBZSxFQUM3QixRQUNBLFFBSUM7O0NBQ0QsTUFBTSxRQUFRLGlCQUFpQixNQUFNO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDO0NBQzFDLE1BQU0sUUFBUSxXQUFXLE1BQU0sU0FBUyxXQUFXO0NBQ25ELE1BQU0sU0FBUyxPQUEwQixJQUFJO0NBQzdDLE9BQ0Usd0JBQUMsV0FBRDtFQUNFLGNBQVksRUFBRTtFQUNkLFVBQVU7RUFDVixZQUFZLFVBQVU7R0FDcEIsSUFDRSxNQUFNLFNBQVMsTUFDZCxNQUFNLFFBQVEsZ0JBQWdCLE1BQU0sUUFBUSxjQUM3QztJQUNBLE1BQU0sZUFBZTtJQUNyQixhQUNHLFNBQVMsTUFBTSxRQUFRLGVBQWUsSUFBSSxNQUFNLFNBQVMsTUFDeEQsTUFBTSxNQUNWO0dBQ0Y7RUFDRjtFQUNBLFdBQVU7WUFmWixDQWlCRSx3QkFBQyxPQUFEO0dBQ0UsV0FBVyxjQUFjLE1BQU0sU0FBUyxJQUFJLHNDQUFzQzthQURwRixDQUdHLE1BQU0sU0FBUyxLQUNkLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osTUFBTSxLQUFLLEtBQUssTUFDZix3QkFBQyxVQUFEO0tBRUUsY0FBWSxHQUFHLEVBQUUsVUFBVSxHQUFHLElBQUksRUFBRSxJQUFJO0tBQ3hDLGdCQUFjLE1BQU07S0FDcEIsZUFBZSxZQUFZLENBQUM7S0FDNUIsV0FBVyxzREFBc0QsTUFBTSxRQUFRLG1CQUFtQjtlQUVsRyx3QkFBQyxjQUFEO01BQW1CO01BQUssS0FBSTtNQUFHLFdBQVU7S0FBaUI7Ozs7O0lBQ3BELEdBUEQ7Ozs7V0FPQyxDQUNUO0dBQ0U7Ozs7YUFFUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsY0FBRDtNQUNFLEtBQUssTUFBTTtNQUNYLEtBQUssR0FBRyxPQUFPLE1BQU0sU0FBUyxJQUFJLE1BQU0sRUFBRSxNQUFNLEdBQUcsUUFBUSxNQUFNO01BQ2pFO01BQ0EsV0FBVTtLQUNYOzs7OztLQUNBLE1BQU0sU0FBUyxLQUNkLGdEQUNFLHdCQUFDLFVBQUQ7TUFDRSxjQUFZLEVBQUU7TUFDZCxlQUNFLGFBQWEsUUFBUSxNQUFNLFNBQVMsS0FBSyxNQUFNLE1BQU07TUFFdkQsV0FBVTtnQkFDWDtLQUVPOzs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNFLGNBQVksRUFBRTtNQUNkLGVBQWUsYUFBYSxRQUFRLEtBQUssTUFBTSxNQUFNO01BQ3JELFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNSOzs7OztLQUVILE1BQU0sU0FBUyxLQUNkLHdCQUFDLFVBQUQ7TUFDRSxjQUFZLGFBQWEsV0FBVztNQUNwQyxlQUFlLE9BQU8sU0FBUyxVQUFVO01BQ3pDLFdBQVU7Z0JBQ1g7S0FFTzs7Ozs7S0FFVix3QkFBQyxLQUFEO01BQ0UsYUFBVTtNQUNWLFdBQVU7Z0JBRVQsTUFBTSxTQUNILEdBQUcsRUFBRSxNQUFNLEdBQUcsUUFBUSxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsTUFBTSxXQUN6QyxFQUFFO0tBQ0w7Ozs7O0lBQ0E7Ozs7O1dBQ0Y7Ozs7O1lBQ0wsd0JBQUMsVUFBRDtHQUNFLEtBQUs7R0FDTCxjQUFZLGFBQWEsV0FBVztHQUNwQyxXQUFVO2FBSFosQ0FLRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLE9BQU8sU0FBUyxNQUFNO0tBQ3JDLFdBQVU7ZUFFVCxhQUFhLFdBQVc7SUFDbkI7Ozs7O0dBQ0w7Ozs7YUFDTCx3QkFBQyxjQUFEO0lBQ0UsS0FBSyxNQUFNO0lBQ1gsS0FBSztJQUNMLFdBQVU7R0FDWDs7OztXQUNLOzs7OztVQUNEOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9kdWN0R2FsbGVyeS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgZ2V0UHJvZHVjdEltYWdlcyB9IGZyb20gJy4uL2hlbHBlcnMvcHJvZHVjdC1kZXRhaWxzLmhlbHBlcnMnO1xyXG5pbXBvcnQgeyBQcm9kdWN0SW1hZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0SW1hZ2UnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzO1xyXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdEdhbGxlcnkoe1xyXG4gIGltYWdlcyxcclxuICBuYW1lLFxyXG59OiB7XHJcbiAgaW1hZ2VzOiBzdHJpbmdbXTtcclxuICBuYW1lOiBzdHJpbmc7XHJcbn0pIHtcclxuICBjb25zdCBpdGVtcyA9IGdldFByb2R1Y3RJbWFnZXMoaW1hZ2VzKTtcclxuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IGluZGV4ID0gc2VsZWN0ZWQgPCBpdGVtcy5sZW5ndGggPyBzZWxlY3RlZCA6IDA7XHJcbiAgY29uc3QgZGlhbG9nID0gdXNlUmVmPEhUTUxEaWFsb2dFbGVtZW50PihudWxsKTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb25cclxuICAgICAgYXJpYS1sYWJlbD17dC5nYWxsZXJ5fVxyXG4gICAgICB0YWJJbmRleD17MH1cclxuICAgICAgb25LZXlEb3duPXsoZXZlbnQpID0+IHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBpdGVtcy5sZW5ndGggPiAxICYmXHJcbiAgICAgICAgICAoZXZlbnQua2V5ID09PSAnQXJyb3dSaWdodCcgfHwgZXZlbnQua2V5ID09PSAnQXJyb3dMZWZ0JylcclxuICAgICAgICApIHtcclxuICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZChcclxuICAgICAgICAgICAgKGluZGV4ICsgKGV2ZW50LmtleSA9PT0gJ0Fycm93UmlnaHQnID8gMSA6IGl0ZW1zLmxlbmd0aCAtIDEpKSAlXHJcbiAgICAgICAgICAgICAgaXRlbXMubGVuZ3RoLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgIH19XHJcbiAgICAgIGNsYXNzTmFtZT1cInByb2R1Y3QtZ2FsbGVyeSBtaW4tdy0wXCJcclxuICAgID5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YGdyaWQgZ2FwLTMgJHtpdGVtcy5sZW5ndGggPiAxID8gJ3NtOmdyaWQtY29scy1bNHJlbV9taW5tYXgoMCwxZnIpXScgOiAnJ31gfVxyXG4gICAgICA+XHJcbiAgICAgICAge2l0ZW1zLmxlbmd0aCA+IDEgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcmRlci0yIGZsZXggZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHAtMC41IHNtOm9yZGVyLW5vbmUgc206bWF4LWgtWzI2cmVtXSBzbTpmbGV4LWNvbCBzbTpvdmVyZmxvdy15LWF1dG8gc206b3ZlcmZsb3cteC1oaWRkZW5cIj5cclxuICAgICAgICAgICAge2l0ZW1zLm1hcCgoc3JjLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAga2V5PXtzcmN9XHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHt0LnZpZXdJbWFnZX0gJHtpICsgMX06ICR7bmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtpID09PSBpbmRleH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKGkpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC0xNiB3LTE2IHNocmluay0wIHJvdW5kZWQtc20gYm9yZGVyLTIgYmctd2VsbCBwLTEgJHtpID09PSBpbmRleCA/ICdib3JkZXItcHJpbWFyeScgOiAnYm9yZGVyLWxpbmUtc3VidGxlIGhvdmVyOmJvcmRlci1wcmltYXJ5J31gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxQcm9kdWN0SW1hZ2Ugc3JjPXtzcmN9IGFsdD1cIlwiIGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGxcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4tdy0wIHJvdW5kZWQtbGcgYmctd2VsbCBwLTNcIj5cclxuICAgICAgICAgIDxQcm9kdWN0SW1hZ2VcclxuICAgICAgICAgICAgc3JjPXtpdGVtc1tpbmRleF19XHJcbiAgICAgICAgICAgIGFsdD17YCR7bmFtZX0ke2l0ZW1zLmxlbmd0aCA+IDEgPyBgIC0gJHt0LmltYWdlfSAke2luZGV4ICsgMX1gIDogJyd9YH1cclxuICAgICAgICAgICAgZWFnZXJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGwgcC0zXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7aXRlbXMubGVuZ3RoID4gMSAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dC5wcmV2aW91c0ltYWdlfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWQoKGluZGV4ICsgaXRlbXMubGVuZ3RoIC0gMSkgJSBpdGVtcy5sZW5ndGgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTEgdG9wLTEvMiBmbGV4IGgtMTEgdy0xMSAtdHJhbnNsYXRlLXktMS8yIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1saW5lLXN1YnRsZSBiZy1zdXJmYWNlIFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAg4oaQXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dC5uZXh0SW1hZ2V9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZCgoaW5kZXggKyAxKSAlIGl0ZW1zLmxlbmd0aCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0xIHRvcC0xLzIgZmxleCBoLTExIHctMTEgLXRyYW5zbGF0ZS15LTEvMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItbGluZS1zdWJ0bGUgYmctc3VyZmFjZSBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIOKGklxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICB7aXRlbXMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt0cmFuc2xhdGlvbnMuZXhwZXJpZW5jZS56b29tfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRpYWxvZy5jdXJyZW50Py5zaG93TW9kYWwoKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMiByaWdodC0yIGZsZXggbWluLWgtMTEgdy0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHRleHQteGwgdGV4dC1mZy1saW5rIFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICDipKJcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPHBcclxuICAgICAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7aXRlbXMubGVuZ3RoXHJcbiAgICAgICAgICAgICAgPyBgJHt0LmltYWdlfSAke2luZGV4ICsgMX0gJHt0Lm9mfSAke2l0ZW1zLmxlbmd0aH1gXHJcbiAgICAgICAgICAgICAgOiB0Lm5vSW1hZ2V9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGlhbG9nXHJcbiAgICAgICAgcmVmPXtkaWFsb2d9XHJcbiAgICAgICAgYXJpYS1sYWJlbD17dHJhbnNsYXRpb25zLmV4cGVyaWVuY2Uuem9vbX1cclxuICAgICAgICBjbGFzc05hbWU9XCJ1aS1kaWFsb2cgbWF4LXctNHhsXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRpYWxvZy5jdXJyZW50Py5jbG9zZSgpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXNlY29uZGFyeSByb3VuZGVkLXNtIGJvcmRlciBib3JkZXItbGluZSBweC00IHB5LTIgdGV4dC1zbVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuZXhwZXJpZW5jZS5jbG9zZX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxQcm9kdWN0SW1hZ2VcclxuICAgICAgICAgIHNyYz17aXRlbXNbaW5kZXhdfVxyXG4gICAgICAgICAgYWx0PXtuYW1lfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzc1dmhdIHctZnVsbFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaWFsb2c+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=