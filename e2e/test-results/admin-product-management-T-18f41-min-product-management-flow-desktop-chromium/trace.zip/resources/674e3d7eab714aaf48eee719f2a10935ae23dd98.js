import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/AdminLayout.tsx");const useState = __vite__cjsImport2_react["useState"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import { BrandLogo } from "/src/components/common/BrandLogo.tsx";
import { ThemeToggle } from "/src/components/common/ThemeToggle.tsx";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { chatText } from "/src/utils/chatText.ts";
import { uiText } from "/src/utils/uiText.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { useAuth } from "/src/hooks/useAuth.ts";
import { accountText } from "/src/utils/accountText.ts";
import { seasonalText } from "/src/utils/seasonalText.ts";
import { promotionText } from "/src/utils/promotionText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/AdminLayout.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const links = [
	{
		path: ROUTES.admin,
		label: translations.auth.dashboard,
		icon: "grid"
	},
	{
		path: ROUTES.adminThemes,
		label: seasonalText.title,
		icon: "grid"
	},
	{
		path: ROUTES.adminPromotions,
		label: promotionText.title,
		icon: "mail"
	},
	{
		path: ROUTES.adminReports,
		label: "Reports",
		icon: "orders"
	},
	{
		path: ROUTES.adminUsers,
		label: accountText.usersTitle,
		icon: "user"
	},
	{
		path: ROUTES.adminProducts,
		label: translations.admin.products,
		icon: "bag"
	},
	{
		path: ROUTES.adminCategories,
		label: translations.admin.categories,
		icon: "grid"
	},
	{
		path: ROUTES.adminInventory,
		label: translations.admin.inventory,
		icon: "appliance"
	},
	{
		path: ROUTES.adminOrders,
		label: translations.adminOrders.title,
		icon: "orders"
	},
	{
		path: ROUTES.adminRepairs,
		label: translations.adminRepairs.title,
		icon: "repair"
	},
	{
		path: ROUTES.adminChat,
		label: chatText.adminTitle,
		icon: "chat"
	},
	{
		path: ROUTES.adminBanners,
		label: translations.storefront.banners,
		icon: "laptop"
	}
];
function WorkspaceNav({ onNavigate }) {
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": translations.auth.adminNavigation,
		className: "space-y-1",
		children: links.map((item) => /* @__PURE__ */ _jsxDEV(NavLink, {
			end: item.path === ROUTES.admin,
			to: item.path,
			onClick: onNavigate,
			className: ({ isActive }) => "workspace-link flex min-h-12 items-center gap-3 rounded-sm border-l-2 px-4 text-sm font-medium transition-colors " + (isActive ? "is-active border-primary bg-inverse text-primary-on" : "border-transparent text-fg-disabled hover:bg-inverse hover:text-primary-on"),
			children: [/* @__PURE__ */ _jsxDEV(Icon, {
				name: item.icon,
				className: "h-4 w-4"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 11
			}, this), item.label]
		}, item.path, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
}
_c = WorkspaceNav;
export function AdminLayout() {
	_s();
	const [menuOpen, setMenuOpen] = useState(false);
	const { user, signOut } = useAuth();
	const navigate = useNavigate();
	const [logoutError, setLogoutError] = useState("");
	const [logoutBusy, setLogoutBusy] = useState(false);
	const location = useLocation();
	const current = links.find((item) => item.path !== ROUTES.admin && location.pathname.startsWith(item.path)) ?? links[0];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-dvh bg-page lg:flex",
		children: [
			/* @__PURE__ */ _jsxDEV("a", {
				href: "#main-content",
				className: "ui-skip",
				children: uiText.skip
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("aside", {
				className: "workspace-sidebar fixed inset-y-0 left-0 z-30 hidden w-64 flex-col overflow-y-auto p-5 lg:flex",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.home,
						className: "px-3 py-5 text-2xl font-bold tracking-tight text-primary-on",
						children: /* @__PURE__ */ _jsxDEV(BrandLogo, { inverse: true }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mb-4 mt-6 px-4 text-xs font-semibold tracking-normal text-fg-muted",
						children: uiText.workspace
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(WorkspaceNav, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.home,
						className: "mt-auto flex min-h-12 items-center gap-3 border-t border-line-strong px-4 pt-4 text-sm text-fg-disabled hover:text-primary-on",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "arrow",
							className: "h-4 w-4 rotate-180"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 11
						}, this), uiText.backToStore]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "min-w-0 flex-1 lg:ml-64",
				children: [/* @__PURE__ */ _jsxDEV("header", {
					className: "sticky top-0 z-20 flex min-h-18 items-center justify-between gap-3 border-b border-line bg-surface px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex min-w-0 items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-label": uiText.menu,
							"aria-expanded": menuOpen,
							onClick: () => setMenuOpen(true),
							className: "ui-icon-button -ml-2 lg:hidden",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "menu" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "truncate text-sm font-medium text-fg-secondary",
							children: [
								translations.auth.adminWorkspace,
								/* @__PURE__ */ _jsxDEV("span", {
									className: "mx-3 text-fg-disabled",
									children: "/"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-fg",
									children: current.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex shrink-0 items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "hidden sm:block",
								children: /* @__PURE__ */ _jsxDEV(ThemeToggle, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.account,
								className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary-subtle text-sm font-semibold text-fg-link",
								"aria-label": translations.storefront.profile,
								children: user?.username.slice(0, 2).toUpperCase()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: logoutBusy,
								"aria-busy": logoutBusy,
								className: "ui-button ui-button-ghost",
								onClick: () => {
									setLogoutBusy(true);
									void signOut().then(() => navigate(ROUTES.login)).catch(() => setLogoutError(translations.auth.logoutError)).finally(() => setLogoutBusy(false));
								},
								children: logoutBusy ? translations.auth.signingOut : translations.auth.signOut
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					id: "main-content",
					tabIndex: -1,
					className: "mx-auto max-w-[100rem] px-4 py-6 outline-none sm:px-6 md:py-8 lg:px-8 lg:py-10",
					children: [logoutError && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "ui-alert ui-tone-danger mb-4",
						children: logoutError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 166,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: menuOpen,
				onClose: () => setMenuOpen(false),
				title: translations.auth.adminWorkspace,
				drawer: true,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "-mx-5 -mb-5 workspace-sidebar min-h-[calc(100dvh-6rem)] p-4 sm:-mx-6 sm:-mb-6",
					children: [/* @__PURE__ */ _jsxDEV(WorkspaceNav, { onNavigate: () => setMenuOpen(false) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.home,
						onClick: () => setMenuOpen(false),
						className: "mt-6 block px-4 py-3 text-sm text-fg-disabled",
						children: uiText.backToStore
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 95,
		columnNumber: 5
	}, this);
}
_s(AdminLayout, "1Sf77jNFupJjLumuyPhZK9f83EE=", false, function() {
	return [
		useAuth,
		useNavigate,
		useLocation
	];
});
_c2 = AdminLayout;
var _c, _c2;
$RefreshReg$(_c, "WorkspaceNav");
$RefreshReg$(_c2, "AdminLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/AdminLayout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/AdminLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/AdminLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/AdminLayout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FDRSxNQUNBLFNBQ0EsUUFDQSxhQUNBLG1CQUNLO0FBQ1AsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsY0FBYztBQUN2QixTQUFTLFlBQTJCO0FBQ3BDLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxxQkFBcUI7Ozs7QUFDOUIsTUFBTSxRQUEyRDtDQUMvRDtFQUFFLE1BQU0sT0FBTztFQUFPLE9BQU8sYUFBYSxLQUFLO0VBQVcsTUFBTTtDQUFPO0NBQ3ZFO0VBQUUsTUFBTSxPQUFPO0VBQWEsT0FBTyxhQUFhO0VBQU8sTUFBTTtDQUFPO0NBQ3BFO0VBQUUsTUFBTSxPQUFPO0VBQWlCLE9BQU8sY0FBYztFQUFPLE1BQU07Q0FBTztDQUN6RTtFQUFFLE1BQU0sT0FBTztFQUFjLE9BQU87RUFBVyxNQUFNO0NBQVM7Q0FDOUQ7RUFBRSxNQUFNLE9BQU87RUFBWSxPQUFPLFlBQVk7RUFBWSxNQUFNO0NBQU87Q0FDdkU7RUFDRSxNQUFNLE9BQU87RUFDYixPQUFPLGFBQWEsTUFBTTtFQUMxQixNQUFNO0NBQ1I7Q0FDQTtFQUNFLE1BQU0sT0FBTztFQUNiLE9BQU8sYUFBYSxNQUFNO0VBQzFCLE1BQU07Q0FDUjtDQUNBO0VBQ0UsTUFBTSxPQUFPO0VBQ2IsT0FBTyxhQUFhLE1BQU07RUFDMUIsTUFBTTtDQUNSO0NBQ0E7RUFDRSxNQUFNLE9BQU87RUFDYixPQUFPLGFBQWEsWUFBWTtFQUNoQyxNQUFNO0NBQ1I7Q0FDQTtFQUNFLE1BQU0sT0FBTztFQUNiLE9BQU8sYUFBYSxhQUFhO0VBQ2pDLE1BQU07Q0FDUjtDQUNBO0VBQUUsTUFBTSxPQUFPO0VBQVcsT0FBTyxTQUFTO0VBQVksTUFBTTtDQUFPO0NBQ25FO0VBQ0UsTUFBTSxPQUFPO0VBQ2IsT0FBTyxhQUFhLFdBQVc7RUFDL0IsTUFBTTtDQUNSO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsRUFBRSxjQUEyQztDQUNqRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxjQUFZLGFBQWEsS0FBSztFQUFpQixXQUFVO1lBQzNELE1BQU0sS0FBSyxTQUNWLHdCQUFDLFNBQUQ7R0FFRSxLQUFLLEtBQUssU0FBUyxPQUFPO0dBQzFCLElBQUksS0FBSztHQUNULFNBQVM7R0FDVCxZQUFZLEVBQUUsZUFDWix1SEFDQyxXQUNHLHdEQUNBO2FBVFIsQ0FZRSx3QkFBQyxNQUFEO0lBQU0sTUFBTSxLQUFLO0lBQU0sV0FBVTtHQUFXOzs7O2FBQzNDLEtBQUssS0FDQztLQWJGLEtBQUs7Ozs7U0FhSCxDQUNWO0NBQ0U7Ozs7O0FBRVQ7O0FBQ0EsT0FBTyxTQUFTLGNBQWM7O0NBQzVCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sRUFBRSxNQUFNLFlBQVksUUFBUTtDQUNsQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxVQUNKLE1BQU0sTUFDSCxTQUNDLEtBQUssU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLFdBQVcsS0FBSyxJQUFJLENBQ3hFLEtBQUssTUFBTTtDQUNiLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQWdCLFdBQVU7Y0FDL0IsT0FBTztHQUNQOzs7OztHQUNILHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWpCO0tBQ0Usd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTztNQUNYLFdBQVU7Z0JBRVYsd0JBQUMsV0FBRCxFQUFXLGNBQVM7Ozs7O0tBQ2hCOzs7OztLQUNOLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLE9BQU87S0FDUDs7Ozs7S0FDSCx3QkFBQyxjQUFELENBQWU7Ozs7O0tBQ2Ysd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTztNQUNYLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxNQUFEO09BQU0sTUFBSztPQUFRLFdBQVU7TUFBc0I7Ozs7Z0JBQ2xELE9BQU8sV0FDSjs7Ozs7O0lBQ0Q7Ozs7OztHQUNQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUFsQixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxjQUFZLE9BQU87T0FDbkIsaUJBQWU7T0FDZixlQUFlLFlBQVksSUFBSTtPQUMvQixXQUFVO2lCQUVWLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7O01BQ2I7Ozs7Z0JBQ1Isd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFDRyxhQUFhLEtBQUs7UUFDbkIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXdCO1FBQU87Ozs7O1FBQy9DLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFXLFFBQVE7UUFBWTs7Ozs7T0FDOUM7Ozs7O2NBQ0E7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxhQUFELENBQWM7Ozs7O09BQ1g7Ozs7O09BQ0wsd0JBQUMsTUFBRDtRQUNFLElBQUksT0FBTztRQUNYLFdBQVU7UUFDVixjQUFZLGFBQWEsV0FBVztrQkFFbkMsTUFBTSxTQUFTLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZO09BQ3BDOzs7OztPQUNOLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLGFBQVc7UUFDWCxXQUFVO1FBQ1YsZUFBZTtTQUNiLGNBQWMsSUFBSTtTQUNsQixLQUFLLFFBQVEsQ0FBQyxDQUNYLFdBQVcsU0FBUyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQ2xDLFlBQVksZUFBZSxhQUFhLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FDMUQsY0FBYyxjQUFjLEtBQUssQ0FBQztRQUN2QztrQkFFQyxhQUNHLGFBQWEsS0FBSyxhQUNsQixhQUFhLEtBQUs7T0FDaEI7Ozs7O01BQ0w7Ozs7O2FBQ0M7Ozs7O2NBQ1Isd0JBQUMsUUFBRDtLQUNFLElBQUc7S0FDSCxVQUFVLENBQUM7S0FDWCxXQUFVO2VBSFosQ0FLRyxlQUNDLHdCQUFDLEtBQUQ7TUFBRyxNQUFLO01BQVEsV0FBVTtnQkFDdkI7S0FDQTs7OztlQUVMLHdCQUFDLFFBQUQsQ0FBUzs7OzthQUNMOzs7OztZQUNIOzs7Ozs7R0FDTCx3QkFBQyxRQUFEO0lBQ0UsTUFBTTtJQUNOLGVBQWUsWUFBWSxLQUFLO0lBQ2hDLE9BQU8sYUFBYSxLQUFLO0lBQ3pCO2NBRUEsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxrQkFBa0IsWUFBWSxLQUFLLEVBQUk7Ozs7ZUFDckQsd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTztNQUNYLGVBQWUsWUFBWSxLQUFLO01BQ2hDLFdBQVU7Z0JBRVQsT0FBTztLQUNKOzs7O2FBQ0g7Ozs7OztHQUNDOzs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBZG1pbkxheW91dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnJhbmRMb2dvIH0gZnJvbSAnLi4vY29tbW9uL0JyYW5kTG9nbyc7XHJcbmltcG9ydCB7IFRoZW1lVG9nZ2xlIH0gZnJvbSAnLi4vY29tbW9uL1RoZW1lVG9nZ2xlJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7XHJcbiAgTGluayxcclxuICBOYXZMaW5rLFxyXG4gIE91dGxldCxcclxuICB1c2VMb2NhdGlvbixcclxuICB1c2VOYXZpZ2F0ZSxcclxufSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IGNoYXRUZXh0IH0gZnJvbSAnLi4vLi4vdXRpbHMvY2hhdFRleHQnO1xyXG5pbXBvcnQgeyB1aVRleHQgfSBmcm9tICcuLi8uLi91dGlscy91aVRleHQnO1xyXG5pbXBvcnQgeyBJY29uLCB0eXBlIEljb25OYW1lIH0gZnJvbSAnLi4vY29tbW9uL0ljb24nO1xyXG5pbXBvcnQgeyBEaWFsb2cgfSBmcm9tICcuLi91aS9EaWFsb2cnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlQXV0aCc7XHJcbmltcG9ydCB7IGFjY291bnRUZXh0IH0gZnJvbSAnLi4vLi4vdXRpbHMvYWNjb3VudFRleHQnO1xyXG5pbXBvcnQgeyBzZWFzb25hbFRleHQgfSBmcm9tICcuLi8uLi91dGlscy9zZWFzb25hbFRleHQnO1xyXG5pbXBvcnQgeyBwcm9tb3Rpb25UZXh0IH0gZnJvbSAnLi4vLi4vdXRpbHMvcHJvbW90aW9uVGV4dCc7XHJcbmNvbnN0IGxpbmtzOiB7IHBhdGg6IHN0cmluZzsgbGFiZWw6IHN0cmluZzsgaWNvbjogSWNvbk5hbWUgfVtdID0gW1xyXG4gIHsgcGF0aDogUk9VVEVTLmFkbWluLCBsYWJlbDogdHJhbnNsYXRpb25zLmF1dGguZGFzaGJvYXJkLCBpY29uOiAnZ3JpZCcgfSxcclxuICB7IHBhdGg6IFJPVVRFUy5hZG1pblRoZW1lcywgbGFiZWw6IHNlYXNvbmFsVGV4dC50aXRsZSwgaWNvbjogJ2dyaWQnIH0sXHJcbiAgeyBwYXRoOiBST1VURVMuYWRtaW5Qcm9tb3Rpb25zLCBsYWJlbDogcHJvbW90aW9uVGV4dC50aXRsZSwgaWNvbjogJ21haWwnIH0sXHJcbiAgeyBwYXRoOiBST1VURVMuYWRtaW5SZXBvcnRzLCBsYWJlbDogJ1JlcG9ydHMnLCBpY29uOiAnb3JkZXJzJyB9LFxyXG4gIHsgcGF0aDogUk9VVEVTLmFkbWluVXNlcnMsIGxhYmVsOiBhY2NvdW50VGV4dC51c2Vyc1RpdGxlLCBpY29uOiAndXNlcicgfSxcclxuICB7XHJcbiAgICBwYXRoOiBST1VURVMuYWRtaW5Qcm9kdWN0cyxcclxuICAgIGxhYmVsOiB0cmFuc2xhdGlvbnMuYWRtaW4ucHJvZHVjdHMsXHJcbiAgICBpY29uOiAnYmFnJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFJPVVRFUy5hZG1pbkNhdGVnb3JpZXMsXHJcbiAgICBsYWJlbDogdHJhbnNsYXRpb25zLmFkbWluLmNhdGVnb3JpZXMsXHJcbiAgICBpY29uOiAnZ3JpZCcsXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBST1VURVMuYWRtaW5JbnZlbnRvcnksXHJcbiAgICBsYWJlbDogdHJhbnNsYXRpb25zLmFkbWluLmludmVudG9yeSxcclxuICAgIGljb246ICdhcHBsaWFuY2UnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogUk9VVEVTLmFkbWluT3JkZXJzLFxyXG4gICAgbGFiZWw6IHRyYW5zbGF0aW9ucy5hZG1pbk9yZGVycy50aXRsZSxcclxuICAgIGljb246ICdvcmRlcnMnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogUk9VVEVTLmFkbWluUmVwYWlycyxcclxuICAgIGxhYmVsOiB0cmFuc2xhdGlvbnMuYWRtaW5SZXBhaXJzLnRpdGxlLFxyXG4gICAgaWNvbjogJ3JlcGFpcicsXHJcbiAgfSxcclxuICB7IHBhdGg6IFJPVVRFUy5hZG1pbkNoYXQsIGxhYmVsOiBjaGF0VGV4dC5hZG1pblRpdGxlLCBpY29uOiAnY2hhdCcgfSxcclxuICB7XHJcbiAgICBwYXRoOiBST1VURVMuYWRtaW5CYW5uZXJzLFxyXG4gICAgbGFiZWw6IHRyYW5zbGF0aW9ucy5zdG9yZWZyb250LmJhbm5lcnMsXHJcbiAgICBpY29uOiAnbGFwdG9wJyxcclxuICB9LFxyXG5dO1xyXG5mdW5jdGlvbiBXb3Jrc3BhY2VOYXYoeyBvbk5hdmlnYXRlIH06IHsgb25OYXZpZ2F0ZT86ICgpID0+IHZvaWQgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8bmF2IGFyaWEtbGFiZWw9e3RyYW5zbGF0aW9ucy5hdXRoLmFkbWluTmF2aWdhdGlvbn0gY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbiAgICAgIHtsaW5rcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAga2V5PXtpdGVtLnBhdGh9XHJcbiAgICAgICAgICBlbmQ9e2l0ZW0ucGF0aCA9PT0gUk9VVEVTLmFkbWlufVxyXG4gICAgICAgICAgdG89e2l0ZW0ucGF0aH1cclxuICAgICAgICAgIG9uQ2xpY2s9e29uTmF2aWdhdGV9XHJcbiAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XHJcbiAgICAgICAgICAgICd3b3Jrc3BhY2UtbGluayBmbGV4IG1pbi1oLTEyIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLXNtIGJvcmRlci1sLTIgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzICcgK1xyXG4gICAgICAgICAgICAoaXNBY3RpdmVcclxuICAgICAgICAgICAgICA/ICdpcy1hY3RpdmUgYm9yZGVyLXByaW1hcnkgYmctaW52ZXJzZSB0ZXh0LXByaW1hcnktb24nXHJcbiAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZmctZGlzYWJsZWQgaG92ZXI6YmctaW52ZXJzZSBob3Zlcjp0ZXh0LXByaW1hcnktb24nKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9e2l0ZW0uaWNvbn0gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICB7aXRlbS5sYWJlbH1cclxuICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICkpfVxyXG4gICAgPC9uYXY+XHJcbiAgKTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gQWRtaW5MYXlvdXQoKSB7XHJcbiAgY29uc3QgW21lbnVPcGVuLCBzZXRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgeyB1c2VyLCBzaWduT3V0IH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtsb2dvdXRFcnJvciwgc2V0TG9nb3V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtsb2dvdXRCdXN5LCBzZXRMb2dvdXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgY3VycmVudCA9XHJcbiAgICBsaW5rcy5maW5kKFxyXG4gICAgICAoaXRlbSkgPT5cclxuICAgICAgICBpdGVtLnBhdGggIT09IFJPVVRFUy5hZG1pbiAmJiBsb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKGl0ZW0ucGF0aCksXHJcbiAgICApID8/IGxpbmtzWzBdO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLWR2aCBiZy1wYWdlIGxnOmZsZXhcIj5cclxuICAgICAgPGEgaHJlZj1cIiNtYWluLWNvbnRlbnRcIiBjbGFzc05hbWU9XCJ1aS1za2lwXCI+XHJcbiAgICAgICAge3VpVGV4dC5za2lwfVxyXG4gICAgICA8L2E+XHJcbiAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJ3b3Jrc3BhY2Utc2lkZWJhciBmaXhlZCBpbnNldC15LTAgbGVmdC0wIHotMzAgaGlkZGVuIHctNjQgZmxleC1jb2wgb3ZlcmZsb3cteS1hdXRvIHAtNSBsZzpmbGV4XCI+XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMuaG9tZX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktNSB0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1wcmltYXJ5LW9uXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8QnJhbmRMb2dvIGludmVyc2UgLz5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNCBtdC02IHB4LTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYWNraW5nLW5vcm1hbCB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICB7dWlUZXh0LndvcmtzcGFjZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPFdvcmtzcGFjZU5hdiAvPlxyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICB0bz17Uk9VVEVTLmhvbWV9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtdC1hdXRvIGZsZXggbWluLWgtMTIgaXRlbXMtY2VudGVyIGdhcC0zIGJvcmRlci10IGJvcmRlci1saW5lLXN0cm9uZyBweC00IHB0LTQgdGV4dC1zbSB0ZXh0LWZnLWRpc2FibGVkIGhvdmVyOnRleHQtcHJpbWFyeS1vblwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cImFycm93XCIgY2xhc3NOYW1lPVwiaC00IHctNCByb3RhdGUtMTgwXCIgLz5cclxuICAgICAgICAgIHt1aVRleHQuYmFja1RvU3RvcmV9XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2FzaWRlPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIGxnOm1sLTY0XCI+XHJcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgei0yMCBmbGV4IG1pbi1oLTE4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBweC00IHNtOnB4LTYgbGc6cHgtOFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi13LTAgaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt1aVRleHQubWVudX1cclxuICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXttZW51T3Blbn1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3Blbih0cnVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1pY29uLWJ1dHRvbiAtbWwtMiBsZzpoaWRkZW5cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIm1lbnVcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYXV0aC5hZG1pbldvcmtzcGFjZX1cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC0zIHRleHQtZmctZGlzYWJsZWRcIj4vPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZmdcIj57Y3VycmVudC5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9ja1wiPlxyXG4gICAgICAgICAgICAgIDxUaGVtZVRvZ2dsZSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz17Uk9VVEVTLmFjY291bnR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLTExIHctMTEgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1wcmltYXJ5LXN1YnRsZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mZy1saW5rXCJcclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt0cmFuc2xhdGlvbnMuc3RvcmVmcm9udC5wcm9maWxlfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3VzZXI/LnVzZXJuYW1lLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtsb2dvdXRCdXN5fVxyXG4gICAgICAgICAgICAgIGFyaWEtYnVzeT17bG9nb3V0QnVzeX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLWdob3N0XCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRMb2dvdXRCdXN5KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgdm9pZCBzaWduT3V0KClcclxuICAgICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4gbmF2aWdhdGUoUk9VVEVTLmxvZ2luKSlcclxuICAgICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHNldExvZ291dEVycm9yKHRyYW5zbGF0aW9ucy5hdXRoLmxvZ291dEVycm9yKSlcclxuICAgICAgICAgICAgICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9nb3V0QnVzeShmYWxzZSkpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7bG9nb3V0QnVzeVxyXG4gICAgICAgICAgICAgICAgPyB0cmFuc2xhdGlvbnMuYXV0aC5zaWduaW5nT3V0XHJcbiAgICAgICAgICAgICAgICA6IHRyYW5zbGF0aW9ucy5hdXRoLnNpZ25PdXR9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcbiAgICAgICAgPG1haW5cclxuICAgICAgICAgIGlkPVwibWFpbi1jb250ZW50XCJcclxuICAgICAgICAgIHRhYkluZGV4PXstMX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzEwMHJlbV0gcHgtNCBweS02IG91dGxpbmUtbm9uZSBzbTpweC02IG1kOnB5LTggbGc6cHgtOCBsZzpweS0xMFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2xvZ291dEVycm9yICYmIChcclxuICAgICAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwidWktYWxlcnQgdWktdG9uZS1kYW5nZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgIHtsb2dvdXRFcnJvcn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxPdXRsZXQgLz5cclxuICAgICAgICA8L21haW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8RGlhbG9nXHJcbiAgICAgICAgb3Blbj17bWVudU9wZW59XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TWVudU9wZW4oZmFsc2UpfVxyXG4gICAgICAgIHRpdGxlPXt0cmFuc2xhdGlvbnMuYXV0aC5hZG1pbldvcmtzcGFjZX1cclxuICAgICAgICBkcmF3ZXJcclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiLW14LTUgLW1iLTUgd29ya3NwYWNlLXNpZGViYXIgbWluLWgtW2NhbGMoMTAwZHZoLTZyZW0pXSBwLTQgc206LW14LTYgc206LW1iLTZcIj5cclxuICAgICAgICAgIDxXb3Jrc3BhY2VOYXYgb25OYXZpZ2F0ZT17KCkgPT4gc2V0TWVudU9wZW4oZmFsc2UpfSAvPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5ob21lfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbihmYWxzZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTYgYmxvY2sgcHgtNCBweS0zIHRleHQtc20gdGV4dC1mZy1kaXNhYmxlZFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt1aVRleHQuYmFja1RvU3RvcmV9XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=