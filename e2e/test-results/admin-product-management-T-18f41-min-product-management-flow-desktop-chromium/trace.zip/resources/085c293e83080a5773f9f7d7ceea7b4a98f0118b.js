import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/OrderProgress.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
import { uiText } from "/src/utils/uiText.ts";
import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/OrderProgress.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const onlineSteps = [
	"PENDING_PAYMENT",
	"CONFIRMED",
	"PROCESSING",
	"SHIPPED",
	"DELIVERED"
];
export function OrderProgress({ status, paymentMethod = "PAYHERE" }) {
	if (status === "CANCELLED") return null;
	const steps = paymentMethod === "PAYHERE" ? onlineSteps : onlineSteps.filter((step) => step !== "PENDING_PAYMENT");
	const current = steps.indexOf(status);
	return /* @__PURE__ */ _jsxDEV("ol", {
		"aria-label": uiText.orderProgress,
		className: `ui-panel grid grid-cols-2 gap-4 p-5 sm:p-6 ${steps.length === 5 ? "sm:grid-cols-5" : "sm:grid-cols-4"}`,
		children: steps.map((step, index) => /* @__PURE__ */ _jsxDEV("li", {
			"aria-current": step === status ? "step" : undefined,
			className: "flex items-center gap-3 sm:flex-col sm:items-start",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold " + (index < current ? "bg-success-bg text-success" : index === current ? "bg-primary text-primary-on" : "bg-subtle text-fg-muted"),
				children: index < current ? /* @__PURE__ */ _jsxDEV(Icon, {
					name: "check",
					className: "h-4 w-4"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 15
				}, this) : index + 1
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs font-medium leading-5 " + (index === current ? "text-fg-link" : "text-fg-secondary"),
				children: translations.orders.statuses[step]
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 11
			}, this)]
		}, step, true, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_c = OrderProgress;
var _c;
$RefreshReg$(_c, "OrderProgress");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/OrderProgress.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/OrderProgress.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/OrderProgress.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/ui/OrderProgress.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsWUFBWTs7O0FBQ3JCLE1BQU0sY0FBYztDQUNsQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFDQSxPQUFPLFNBQVMsY0FBYyxFQUM1QixRQUNBLGdCQUFnQixhQUlmO0NBQ0QsSUFBSSxXQUFXLGFBQWEsT0FBTztDQUNuQyxNQUFNLFFBQ0osa0JBQWtCLFlBQ2QsY0FDQSxZQUFZLFFBQVEsU0FBUyxTQUFTLGlCQUFpQjtDQUM3RCxNQUFNLFVBQVUsTUFBTSxRQUFRLE1BQU07Q0FDcEMsT0FDRSx3QkFBQyxNQUFEO0VBQ0UsY0FBWSxPQUFPO0VBQ25CLFdBQVcsOENBQThDLE1BQU0sV0FBVyxJQUFJLG1CQUFtQjtZQUVoRyxNQUFNLEtBQUssTUFBTSxVQUNoQix3QkFBQyxNQUFEO0dBRUUsZ0JBQWMsU0FBUyxTQUFTLFNBQVM7R0FDekMsV0FBVTthQUhaLENBS0Usd0JBQUMsUUFBRDtJQUNFLFdBQ0UsMkZBQ0MsUUFBUSxVQUNMLCtCQUNBLFVBQVUsVUFDUiwrQkFDQTtjQUdQLFFBQVEsVUFDUCx3QkFBQyxNQUFEO0tBQU0sTUFBSztLQUFRLFdBQVU7SUFBVzs7OztlQUV4QyxRQUFRO0dBRU47Ozs7YUFDTix3QkFBQyxRQUFEO0lBQ0UsV0FDRSxvQ0FDQyxVQUFVLFVBQVUsaUJBQWlCO2NBR3ZDLGFBQWEsT0FBTyxTQUFTO0dBQzFCOzs7O1dBQ0o7S0E1Qkc7Ozs7U0E0QkgsQ0FDTDtDQUNDOzs7OztBQUVSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk9yZGVyUHJvZ3Jlc3MudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgT3JkZXJTdGF0dXMsIFBheW1lbnRNZXRob2QgfSBmcm9tICcuLi8uLi90eXBlcy9vcmRlci50eXBlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IHVpVGV4dCB9IGZyb20gJy4uLy4uL3V0aWxzL3VpVGV4dCc7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tICcuLi9jb21tb24vSWNvbic7XHJcbmNvbnN0IG9ubGluZVN0ZXBzID0gW1xyXG4gICdQRU5ESU5HX1BBWU1FTlQnLFxyXG4gICdDT05GSVJNRUQnLFxyXG4gICdQUk9DRVNTSU5HJyxcclxuICAnU0hJUFBFRCcsXHJcbiAgJ0RFTElWRVJFRCcsXHJcbl0gYXMgY29uc3Q7XHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlclByb2dyZXNzKHtcclxuICBzdGF0dXMsXHJcbiAgcGF5bWVudE1ldGhvZCA9ICdQQVlIRVJFJyxcclxufToge1xyXG4gIHN0YXR1czogT3JkZXJTdGF0dXM7XHJcbiAgcGF5bWVudE1ldGhvZD86IFBheW1lbnRNZXRob2Q7XHJcbn0pIHtcclxuICBpZiAoc3RhdHVzID09PSAnQ0FOQ0VMTEVEJykgcmV0dXJuIG51bGw7XHJcbiAgY29uc3Qgc3RlcHM6IHJlYWRvbmx5IE9yZGVyU3RhdHVzW10gPVxyXG4gICAgcGF5bWVudE1ldGhvZCA9PT0gJ1BBWUhFUkUnXHJcbiAgICAgID8gb25saW5lU3RlcHNcclxuICAgICAgOiBvbmxpbmVTdGVwcy5maWx0ZXIoKHN0ZXApID0+IHN0ZXAgIT09ICdQRU5ESU5HX1BBWU1FTlQnKTtcclxuICBjb25zdCBjdXJyZW50ID0gc3RlcHMuaW5kZXhPZihzdGF0dXMpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8b2xcclxuICAgICAgYXJpYS1sYWJlbD17dWlUZXh0Lm9yZGVyUHJvZ3Jlc3N9XHJcbiAgICAgIGNsYXNzTmFtZT17YHVpLXBhbmVsIGdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgcC01IHNtOnAtNiAke3N0ZXBzLmxlbmd0aCA9PT0gNSA/ICdzbTpncmlkLWNvbHMtNScgOiAnc206Z3JpZC1jb2xzLTQnfWB9XHJcbiAgICA+XHJcbiAgICAgIHtzdGVwcy5tYXAoKHN0ZXAsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgPGxpXHJcbiAgICAgICAgICBrZXk9e3N0ZXB9XHJcbiAgICAgICAgICBhcmlhLWN1cnJlbnQ9e3N0ZXAgPT09IHN0YXR1cyA/ICdzdGVwJyA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNtOmZsZXgtY29sIHNtOml0ZW1zLXN0YXJ0XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICdmbGV4IGgtOCB3LTggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgJyArXHJcbiAgICAgICAgICAgICAgKGluZGV4IDwgY3VycmVudFxyXG4gICAgICAgICAgICAgICAgPyAnYmctc3VjY2Vzcy1iZyB0ZXh0LXN1Y2Nlc3MnXHJcbiAgICAgICAgICAgICAgICA6IGluZGV4ID09PSBjdXJyZW50XHJcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXByaW1hcnkgdGV4dC1wcmltYXJ5LW9uJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zdWJ0bGUgdGV4dC1mZy1tdXRlZCcpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2luZGV4IDwgY3VycmVudCA/IChcclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiY2hlY2tcIiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICBpbmRleCArIDFcclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgJ3RleHQteHMgZm9udC1tZWRpdW0gbGVhZGluZy01ICcgK1xyXG4gICAgICAgICAgICAgIChpbmRleCA9PT0gY3VycmVudCA/ICd0ZXh0LWZnLWxpbmsnIDogJ3RleHQtZmctc2Vjb25kYXJ5JylcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7dHJhbnNsYXRpb25zLm9yZGVycy5zdGF0dXNlc1tzdGVwXX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICApKX1cclxuICAgIDwvb2w+XHJcbiAgKTtcclxufVxyXG4iXX0=