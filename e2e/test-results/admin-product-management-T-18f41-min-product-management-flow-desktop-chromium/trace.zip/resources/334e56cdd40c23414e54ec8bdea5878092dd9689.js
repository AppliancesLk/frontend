import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Products/ProductsPage.tsx");const useState = __vite__cjsImport6_react["useState"];const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"];import { formatCategoryName } from "/src/utils/category.ts";
import { EmptyState } from "/src/components/ui/Feedback.tsx";
import { ProductGridSkeleton } from "/src/components/feedback/ProductGridSkeleton.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { uiText } from "/src/utils/uiText.ts";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { CATALOG_SORTS } from "/src/types/catalog.types.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { useProductsCatalog } from "/src/pages/Products/hooks/useProductsCatalog.ts";
import { CatalogProductCard } from "/src/pages/Products/components/CatalogProductCard.tsx";
import { CatalogFilters } from "/src/pages/Products/components/CatalogFilters.tsx";
import { CatalogPagination } from "/src/pages/Products/components/CatalogPagination.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/ProductsPage.tsx";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.catalog;
export default function ProductsPage() {
	_s();
	const [filtersOpen, setFiltersOpen] = useState(false);
	const page = useProductsCatalog();
	const { data, query } = page;
	const selectedCategory = data?.facets.categories.find((category) => category.categoryID === query?.categoryId);
	const chips = [
		...query?.q ? [{
			label: `“${query.q}”`,
			clear: () => page.update({ q: undefined })
		}] : [],
		...query?.categoryId ? [{
			label: selectedCategory?.name ?? t.categories,
			clear: () => page.update({ category: undefined })
		}] : [],
		...query?.brands?.split(",").map((brand) => ({
			label: brand,
			clear: () => page.update({ brands: query.brands?.split(",").filter((value) => value !== brand).join(",") || undefined })
		})) ?? [],
		...query?.minPrice !== undefined ? [{
			label: `${t.minPrice}: ${formatCurrency(query.minPrice)}`,
			clear: () => page.update({ minPrice: undefined })
		}] : [],
		...query?.maxPrice !== undefined ? [{
			label: `${t.maxPrice}: ${formatCurrency(query.maxPrice)}`,
			clear: () => page.update({ maxPrice: undefined })
		}] : []
	];
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "shell-wide py-6 md:py-8",
		children: [
			/* @__PURE__ */ _jsxDEV("nav", {
				"aria-label": t.breadcrumb,
				className: "mb-4 flex items-center gap-2 text-xs text-fg-muted",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.home,
						className: "hover:text-fg-link",
						children: t.home
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": "true",
						children: "›"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						"aria-current": "page",
						children: t.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "sr-only",
				children: selectedCategory ? formatCategoryName(selectedCategory.name) : t.title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 7
			}, this),
			page.loading && !data && /* @__PURE__ */ _jsxDEV(ProductGridSkeleton, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 33
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-danger/25 bg-danger-bg p-6",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-danger",
					children: page.error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex gap-3",
					children: [query && /* @__PURE__ */ _jsxDEV("button", {
						onClick: page.retry,
						className: "ui-button ui-button-primary rounded-sm bg-primary px-4 py-2 text-sm font-medium text-primary-on",
						children: t.retry
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: page.clear,
						className: "ui-button ui-button-secondary rounded-sm border border-line bg-surface px-4 py-2 text-sm text-fg-secondary",
						children: t.clear
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 9
			}, this),
			data && query && /* @__PURE__ */ _jsxDEV("div", {
				"aria-busy": page.loading,
				className: "grid items-start gap-5 lg:grid-cols-[17.5rem_minmax(0,1fr)] xl:gap-6",
				children: [/* @__PURE__ */ _jsxDEV("aside", {
					"aria-label": t.filters,
					className: "min-w-0",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							"aria-expanded": filtersOpen,
							"aria-controls": "catalog-filters",
							onClick: () => setFiltersOpen((value) => !value),
							className: "ui-button ui-button-secondary mb-3 flex min-h-11 w-full items-center gap-2 rounded-sm border border-line bg-surface px-4 text-sm font-semibold text-fg-secondary lg:hidden",
							children: [
								/* @__PURE__ */ _jsxDEV(Icon, { name: "filter" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 15
								}, this),
								t.filters,
								/* @__PURE__ */ _jsxDEV("span", {
									className: "ml-auto text-xs font-normal",
									children: [
										chips.length || "",
										" ",
										filtersOpen ? "−" : "+"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							id: "catalog-filters",
							className: "hidden lg:block",
							children: /* @__PURE__ */ _jsxDEV(CatalogFilters, {
								facets: data.facets,
								query,
								update: page.update,
								clear: page.clear
							}, "desktop-" + query.minPrice + ":" + query.maxPrice, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Dialog, {
							open: filtersOpen,
							onClose: () => setFiltersOpen(false),
							title: uiText.filters,
							drawer: true,
							children: [/* @__PURE__ */ _jsxDEV(CatalogFilters, {
								facets: data.facets,
								query,
								update: page.update,
								clear: page.clear
							}, "mobile-" + query.minPrice + ":" + query.maxPrice, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "ui-button ui-button-primary mt-5 w-full",
								onClick: () => setFiltersOpen(false),
								children: uiText.applyFilters
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("section", {
					"aria-label": t.title,
					className: "min-w-0",
					children: [
						chips.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							"aria-label": t.active,
							className: "mb-4 flex flex-wrap items-center gap-2",
							children: chips.map((chip) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: chip.clear,
								"aria-label": `${t.remove}: ${chip.label}`,
								className: "max-w-full rounded-sm border border-primary bg-primary-subtle px-3 py-2 text-xs text-fg-link",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "break-words",
									children: chip.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": "true",
									className: "ml-2",
									children: "×"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 21
								}, this)]
							}, chip.label, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-4 flex flex-wrap items-center justify-between gap-4",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								className: "text-sm text-fg-muted",
								children: [
									t.showing,
									" ",
									data.total ? (data.page - 1) * data.limit + 1 : 0,
									"–",
									Math.min(data.page * data.limit, data.total),
									" ",
									t.of,
									" ",
									data.total.toLocaleString(),
									" ",
									data.total === 1 ? t.product : t.products
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("label", {
								className: "flex items-center gap-3 whitespace-nowrap text-sm font-medium text-fg-secondary",
								children: [t.sort, /* @__PURE__ */ _jsxDEV("select", {
									"aria-label": t.sort,
									value: query.sort,
									onChange: (event) => page.update({ sort: event.target.value }),
									className: "ui-field min-h-11 w-auto rounded-sm border border-line bg-surface px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20",
									children: CATALOG_SORTS.map((sort) => /* @__PURE__ */ _jsxDEV("option", {
										value: sort,
										children: t.sorts[sort]
									}, sort, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 185,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 13
						}, this),
						!data.items.length ? /* @__PURE__ */ _jsxDEV(EmptyState, {
							title: t.empty,
							description: t.emptyDescription,
							action: /* @__PURE__ */ _jsxDEV("button", {
								onClick: page.clear,
								className: "ui-button ui-button-primary mt-5 rounded-sm bg-primary px-4 py-2 text-sm font-medium text-primary-on",
								children: t.clear
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 19
							}, this),
							icon: "bag"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-6 lg:grid-cols-3 xl:grid-cols-4",
							children: data.items.map((product) => /* @__PURE__ */ _jsxDEV(CatalogProductCard, { product }, product.productID, false, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(CatalogPagination, {
							page: data.page,
							totalPages: data.totalPages,
							onChange: (number) => {
								page.update({ page: String(number) });
								window.scrollTo({
									top: 0,
									behavior: "instant"
								});
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
}
_s(ProductsPage, "BsZEP9Vel5o1PpuasOwDOrz0cPQ=", false, function() {
	return [useProductsCatalog];
});
_c = ProductsPage;
var _c;
$RefreshReg$(_c, "ProductsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Products/ProductsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/ProductsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/ProductsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/ProductsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsY0FBYztBQUN2QixTQUFTLFlBQVk7QUFDckIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsWUFBWTtBQUNyQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLHlCQUF5Qjs7OztBQUNsQyxNQUFNLElBQUksYUFBYTtBQUN2QixlQUFlLFNBQVMsZUFBZTs7Q0FDckMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLE9BQU8sbUJBQW1CO0NBQ2hDLE1BQU0sRUFBRSxNQUFNLFVBQVU7Q0FDeEIsTUFBTSxtQkFBbUIsTUFBTSxPQUFPLFdBQVcsTUFDOUMsYUFBYSxTQUFTLGVBQWUsT0FBTyxVQUMvQztDQUNBLE1BQU0sUUFBUTtFQUNaLEdBQUksT0FBTyxJQUNQLENBQUM7R0FBRSxPQUFPLElBQUksTUFBTSxFQUFFO0dBQUksYUFBYSxLQUFLLE9BQU8sRUFBRSxHQUFHLFVBQVUsQ0FBQztFQUFFLENBQUMsSUFDdEUsQ0FBQztFQUNMLEdBQUksT0FBTyxhQUNQLENBQ0U7R0FDRSxPQUFPLGtCQUFrQixRQUFRLEVBQUU7R0FDbkMsYUFBYSxLQUFLLE9BQU8sRUFBRSxVQUFVLFVBQVUsQ0FBQztFQUNsRCxDQUNGLElBQ0EsQ0FBQztFQUNMLEdBQUksT0FBTyxRQUFRLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxXQUFXO0dBQzVDLE9BQU87R0FDUCxhQUNFLEtBQUssT0FBTyxFQUNWLFFBQ0UsTUFBTSxRQUNGLE1BQU0sR0FBRyxDQUFDLENBQ1gsUUFBUSxVQUFVLFVBQVUsS0FBSyxDQUFDLENBQ2xDLEtBQUssR0FBRyxLQUFLLFVBQ3BCLENBQUM7RUFDTCxFQUFFLEtBQUssQ0FBQztFQUNSLEdBQUksT0FBTyxhQUFhLFlBQ3BCLENBQ0U7R0FDRSxPQUFPLEdBQUcsRUFBRSxTQUFTLElBQUksZUFBZSxNQUFNLFFBQVE7R0FDdEQsYUFBYSxLQUFLLE9BQU8sRUFBRSxVQUFVLFVBQVUsQ0FBQztFQUNsRCxDQUNGLElBQ0EsQ0FBQztFQUNMLEdBQUksT0FBTyxhQUFhLFlBQ3BCLENBQ0U7R0FDRSxPQUFPLEdBQUcsRUFBRSxTQUFTLElBQUksZUFBZSxNQUFNLFFBQVE7R0FDdEQsYUFBYSxLQUFLLE9BQU8sRUFBRSxVQUFVLFVBQVUsQ0FBQztFQUNsRCxDQUNGLElBQ0EsQ0FBQztDQUNQO0NBQ0EsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNFLHdCQUFDLE9BQUQ7SUFDRSxjQUFZLEVBQUU7SUFDZCxXQUFVO2NBRlo7S0FJRSx3QkFBQyxNQUFEO01BQU0sSUFBSSxPQUFPO01BQU0sV0FBVTtnQkFDOUIsRUFBRTtLQUNDOzs7OztLQUNOLHdCQUFDLFFBQUQ7TUFBTSxlQUFZO2dCQUFPO0tBQU87Ozs7O0tBQ2hDLHdCQUFDLFFBQUQ7TUFBTSxnQkFBYTtnQkFBUSxFQUFFO0tBQVk7Ozs7O0lBQ3RDOzs7Ozs7R0FDTCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLG1CQUFtQixtQkFBbUIsaUJBQWlCLElBQUksSUFBSSxFQUFFO0dBQ2hFOzs7OztHQUNILEtBQUssV0FBVyxDQUFDLFFBQVEsd0JBQUMscUJBQUQsQ0FBc0I7Ozs7O0dBQy9DLEtBQUssU0FDSix3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FGWixDQUlFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXVCLEtBQUs7SUFBUzs7OztjQUNsRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0csU0FDQyx3QkFBQyxVQUFEO01BQ0UsU0FBUyxLQUFLO01BQ2QsV0FBVTtnQkFFVCxFQUFFO0tBQ0c7Ozs7ZUFFVix3QkFBQyxVQUFEO01BQ0UsU0FBUyxLQUFLO01BQ2QsV0FBVTtnQkFFVCxFQUFFO0tBQ0c7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7O0dBRU4sUUFBUSxTQUNQLHdCQUFDLE9BQUQ7SUFDRSxhQUFXLEtBQUs7SUFDaEIsV0FBVTtjQUZaLENBSUUsd0JBQUMsU0FBRDtLQUFPLGNBQVksRUFBRTtLQUFTLFdBQVU7ZUFBeEM7TUFDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGlCQUFlO09BQ2YsaUJBQWM7T0FDZCxlQUFlLGdCQUFnQixVQUFVLENBQUMsS0FBSztPQUMvQyxXQUFVO2lCQUxaO1FBT0Usd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7Ozs7UUFDcEIsRUFBRTtRQUNILHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUNHLE1BQU0sVUFBVTtVQUFHO1VBQUUsY0FBYyxNQUFNO1NBQ3RDOzs7Ozs7T0FDQTs7Ozs7O01BQ1Isd0JBQUMsT0FBRDtPQUFLLElBQUc7T0FBa0IsV0FBVTtpQkFDbEMsd0JBQUMsZ0JBQUQ7UUFFRSxRQUFRLEtBQUs7UUFDTjtRQUNQLFFBQVEsS0FBSztRQUNiLE9BQU8sS0FBSztPQUNiLEdBTE0sYUFBYSxNQUFNLFdBQVcsTUFBTSxNQUFNOzs7O2NBS2hEO01BQ0U7Ozs7O01BQ0wsd0JBQUMsUUFBRDtPQUNFLE1BQU07T0FDTixlQUFlLGVBQWUsS0FBSztPQUNuQyxPQUFPLE9BQU87T0FDZDtpQkFKRixDQU1FLHdCQUFDLGdCQUFEO1FBRUUsUUFBUSxLQUFLO1FBQ047UUFDUCxRQUFRLEtBQUs7UUFDYixPQUFPLEtBQUs7T0FDYixHQUxNLFlBQVksTUFBTSxXQUFXLE1BQU0sTUFBTTs7OztjQUsvQyxHQUNELHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsV0FBVTtRQUNWLGVBQWUsZUFBZSxLQUFLO2tCQUVsQyxPQUFPO09BQ0Y7Ozs7ZUFDRjs7Ozs7O0tBQ0g7Ozs7O2NBQ1Asd0JBQUMsV0FBRDtLQUFTLGNBQVksRUFBRTtLQUFPLFdBQVU7ZUFBeEM7TUFDRyxNQUFNLFNBQVMsS0FDZCx3QkFBQyxPQUFEO09BQ0UsY0FBWSxFQUFFO09BQ2QsV0FBVTtpQkFFVCxNQUFNLEtBQUssU0FDVix3QkFBQyxVQUFEO1FBRUUsU0FBUyxLQUFLO1FBQ2QsY0FBWSxHQUFHLEVBQUUsT0FBTyxJQUFJLEtBQUs7UUFDakMsV0FBVTtrQkFKWixDQU1FLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFlLEtBQUs7UUFBWTs7OztrQkFDaEQsd0JBQUMsUUFBRDtTQUFNLGVBQVk7U0FBTyxXQUFVO21CQUFPO1FBRXBDOzs7O2dCQUNBO1VBVEQsS0FBSzs7OztjQVNKLENBQ1Q7TUFDRTs7Ozs7TUFFUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO1FBQVMsV0FBVTtrQkFBM0I7U0FDRyxFQUFFO1NBQVE7U0FBRSxLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUk7U0FBRTtTQUM5RCxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLLEtBQUs7U0FBRTtTQUFFLEVBQUU7U0FBSTtTQUNyRCxLQUFLLE1BQU0sZUFBZTtTQUFHO1NBQzdCLEtBQUssVUFBVSxJQUFJLEVBQUUsVUFBVSxFQUFFO1FBQ2pDOzs7OztpQkFDSCx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDRyxFQUFFLE1BQ0gsd0JBQUMsVUFBRDtTQUNFLGNBQVksRUFBRTtTQUNkLE9BQU8sTUFBTTtTQUNiLFdBQVcsVUFDVCxLQUFLLE9BQU8sRUFBRSxNQUFNLE1BQU0sT0FBTyxNQUFNLENBQUM7U0FFMUMsV0FBVTttQkFFVCxjQUFjLEtBQUssU0FDbEIsd0JBQUMsVUFBRDtVQUFtQixPQUFPO29CQUN2QixFQUFFLE1BQU07U0FDSCxHQUZLOzs7O2dCQUVMLENBQ1Q7UUFDSzs7OztnQkFDSDs7Ozs7ZUFDSjs7Ozs7O01BQ0osQ0FBQyxLQUFLLE1BQU0sU0FDWCx3QkFBQyxZQUFEO09BQ0UsT0FBTyxFQUFFO09BQ1QsYUFBYSxFQUFFO09BQ2YsUUFDRSx3QkFBQyxVQUFEO1FBQ0UsU0FBUyxLQUFLO1FBQ2QsV0FBVTtrQkFFVCxFQUFFO09BQ0c7Ozs7O09BRVYsTUFBSztNQUNOOzs7O2lCQUVELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLEtBQUssTUFBTSxLQUFLLFlBQ2Ysd0JBQUMsb0JBQUQsRUFFVyxRQUNWLEdBRk0sUUFBUTs7OztjQUVkLENBQ0Y7TUFDRTs7Ozs7TUFFUCx3QkFBQyxtQkFBRDtPQUNFLE1BQU0sS0FBSztPQUNYLFlBQVksS0FBSztPQUNqQixXQUFXLFdBQVc7UUFDcEIsS0FBSyxPQUFPLEVBQUUsTUFBTSxPQUFPLE1BQU0sRUFBRSxDQUFDO1FBQ3BDLE9BQU8sU0FBUztTQUFFLEtBQUs7U0FBRyxVQUFVO1FBQVUsQ0FBQztPQUNqRDtNQUNEOzs7OztLQUNNOzs7OztZQUNOOzs7Ozs7RUFFSDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdHNQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRDYXRlZ29yeU5hbWUgfSBmcm9tICcuLi8uLi91dGlscy9jYXRlZ29yeSc7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgUHJvZHVjdEdyaWRTa2VsZXRvbiB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvZmVlZGJhY2svUHJvZHVjdEdyaWRTa2VsZXRvbic7XHJcbmltcG9ydCB7IERpYWxvZyB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWkvRGlhbG9nJztcclxuaW1wb3J0IHsgdWlUZXh0IH0gZnJvbSAnLi4vLi4vdXRpbHMvdWlUZXh0JztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL2NvbW1vbi9JY29uJztcclxuaW1wb3J0IHsgQ0FUQUxPR19TT1JUUyB9IGZyb20gJy4uLy4uL3R5cGVzL2NhdGFsb2cudHlwZXMnO1xyXG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuaW1wb3J0IHsgdXNlUHJvZHVjdHNDYXRhbG9nIH0gZnJvbSAnLi9ob29rcy91c2VQcm9kdWN0c0NhdGFsb2cnO1xyXG5pbXBvcnQgeyBDYXRhbG9nUHJvZHVjdENhcmQgfSBmcm9tICcuL2NvbXBvbmVudHMvQ2F0YWxvZ1Byb2R1Y3RDYXJkJztcclxuaW1wb3J0IHsgQ2F0YWxvZ0ZpbHRlcnMgfSBmcm9tICcuL2NvbXBvbmVudHMvQ2F0YWxvZ0ZpbHRlcnMnO1xyXG5pbXBvcnQgeyBDYXRhbG9nUGFnaW5hdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9DYXRhbG9nUGFnaW5hdGlvbic7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuY2F0YWxvZztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZHVjdHNQYWdlKCkge1xyXG4gIGNvbnN0IFtmaWx0ZXJzT3Blbiwgc2V0RmlsdGVyc09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VQcm9kdWN0c0NhdGFsb2coKTtcclxuICBjb25zdCB7IGRhdGEsIHF1ZXJ5IH0gPSBwYWdlO1xyXG4gIGNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnkgPSBkYXRhPy5mYWNldHMuY2F0ZWdvcmllcy5maW5kKFxyXG4gICAgKGNhdGVnb3J5KSA9PiBjYXRlZ29yeS5jYXRlZ29yeUlEID09PSBxdWVyeT8uY2F0ZWdvcnlJZCxcclxuICApO1xyXG4gIGNvbnN0IGNoaXBzID0gW1xyXG4gICAgLi4uKHF1ZXJ5Py5xXHJcbiAgICAgID8gW3sgbGFiZWw6IGDigJwke3F1ZXJ5LnF94oCdYCwgY2xlYXI6ICgpID0+IHBhZ2UudXBkYXRlKHsgcTogdW5kZWZpbmVkIH0pIH1dXHJcbiAgICAgIDogW10pLFxyXG4gICAgLi4uKHF1ZXJ5Py5jYXRlZ29yeUlkXHJcbiAgICAgID8gW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogc2VsZWN0ZWRDYXRlZ29yeT8ubmFtZSA/PyB0LmNhdGVnb3JpZXMsXHJcbiAgICAgICAgICAgIGNsZWFyOiAoKSA9PiBwYWdlLnVwZGF0ZSh7IGNhdGVnb3J5OiB1bmRlZmluZWQgfSksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF1cclxuICAgICAgOiBbXSksXHJcbiAgICAuLi4ocXVlcnk/LmJyYW5kcz8uc3BsaXQoJywnKS5tYXAoKGJyYW5kKSA9PiAoe1xyXG4gICAgICBsYWJlbDogYnJhbmQsXHJcbiAgICAgIGNsZWFyOiAoKSA9PlxyXG4gICAgICAgIHBhZ2UudXBkYXRlKHtcclxuICAgICAgICAgIGJyYW5kczpcclxuICAgICAgICAgICAgcXVlcnkuYnJhbmRzXHJcbiAgICAgICAgICAgICAgPy5zcGxpdCgnLCcpXHJcbiAgICAgICAgICAgICAgLmZpbHRlcigodmFsdWUpID0+IHZhbHVlICE9PSBicmFuZClcclxuICAgICAgICAgICAgICAuam9pbignLCcpIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICB9KSxcclxuICAgIH0pKSA/PyBbXSksXHJcbiAgICAuLi4ocXVlcnk/Lm1pblByaWNlICE9PSB1bmRlZmluZWRcclxuICAgICAgPyBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBgJHt0Lm1pblByaWNlfTogJHtmb3JtYXRDdXJyZW5jeShxdWVyeS5taW5QcmljZSl9YCxcclxuICAgICAgICAgICAgY2xlYXI6ICgpID0+IHBhZ2UudXBkYXRlKHsgbWluUHJpY2U6IHVuZGVmaW5lZCB9KSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXVxyXG4gICAgICA6IFtdKSxcclxuICAgIC4uLihxdWVyeT8ubWF4UHJpY2UgIT09IHVuZGVmaW5lZFxyXG4gICAgICA/IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IGAke3QubWF4UHJpY2V9OiAke2Zvcm1hdEN1cnJlbmN5KHF1ZXJ5Lm1heFByaWNlKX1gLFxyXG4gICAgICAgICAgICBjbGVhcjogKCkgPT4gcGFnZS51cGRhdGUoeyBtYXhQcmljZTogdW5kZWZpbmVkIH0pLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdXHJcbiAgICAgIDogW10pLFxyXG4gIF07XHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cInNoZWxsLXdpZGUgcHktNiBtZDpweS04XCI+XHJcbiAgICAgIDxuYXZcclxuICAgICAgICBhcmlhLWxhYmVsPXt0LmJyZWFkY3J1bWJ9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibWItNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPExpbmsgdG89e1JPVVRFUy5ob21lfSBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWZnLWxpbmtcIj5cclxuICAgICAgICAgIHt0LmhvbWV9XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKAujwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBhcmlhLWN1cnJlbnQ9XCJwYWdlXCI+e3QudGl0bGV9PC9zcGFuPlxyXG4gICAgICA8L25hdj5cclxuICAgICAgPGgxIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cclxuICAgICAgICB7c2VsZWN0ZWRDYXRlZ29yeSA/IGZvcm1hdENhdGVnb3J5TmFtZShzZWxlY3RlZENhdGVnb3J5Lm5hbWUpIDogdC50aXRsZX1cclxuICAgICAgPC9oMT5cclxuICAgICAge3BhZ2UubG9hZGluZyAmJiAhZGF0YSAmJiA8UHJvZHVjdEdyaWRTa2VsZXRvbiAvPn1cclxuICAgICAge3BhZ2UuZXJyb3IgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZGFuZ2VyLzI1IGJnLWRhbmdlci1iZyBwLTZcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1kYW5nZXJcIj57cGFnZS5lcnJvcn08L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICB7cXVlcnkgJiYgKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3BhZ2UucmV0cnl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcHJpbWFyeS1vblwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3QucmV0cnl9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtwYWdlLmNsZWFyfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tc2Vjb25kYXJ5IHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcHgtNCBweS0yIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3QuY2xlYXJ9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIHtkYXRhICYmIHF1ZXJ5ICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBhcmlhLWJ1c3k9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgaXRlbXMtc3RhcnQgZ2FwLTUgbGc6Z3JpZC1jb2xzLVsxNy41cmVtX21pbm1heCgwLDFmcildIHhsOmdhcC02XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8YXNpZGUgYXJpYS1sYWJlbD17dC5maWx0ZXJzfSBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXtmaWx0ZXJzT3Blbn1cclxuICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPVwiY2F0YWxvZy1maWx0ZXJzXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXJzT3BlbigodmFsdWUpID0+ICF2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1zZWNvbmRhcnkgbWItMyBmbGV4IG1pbi1oLTExIHctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBweC00IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZnLXNlY29uZGFyeSBsZzpoaWRkZW5cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImZpbHRlclwiIC8+XHJcbiAgICAgICAgICAgICAge3QuZmlsdGVyc31cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC1hdXRvIHRleHQteHMgZm9udC1ub3JtYWxcIj5cclxuICAgICAgICAgICAgICAgIHtjaGlwcy5sZW5ndGggfHwgJyd9IHtmaWx0ZXJzT3BlbiA/ICfiiJInIDogJysnfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXYgaWQ9XCJjYXRhbG9nLWZpbHRlcnNcIiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6YmxvY2tcIj5cclxuICAgICAgICAgICAgICA8Q2F0YWxvZ0ZpbHRlcnNcclxuICAgICAgICAgICAgICAgIGtleT17J2Rlc2t0b3AtJyArIHF1ZXJ5Lm1pblByaWNlICsgJzonICsgcXVlcnkubWF4UHJpY2V9XHJcbiAgICAgICAgICAgICAgICBmYWNldHM9e2RhdGEuZmFjZXRzfVxyXG4gICAgICAgICAgICAgICAgcXVlcnk9e3F1ZXJ5fVxyXG4gICAgICAgICAgICAgICAgdXBkYXRlPXtwYWdlLnVwZGF0ZX1cclxuICAgICAgICAgICAgICAgIGNsZWFyPXtwYWdlLmNsZWFyfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8RGlhbG9nXHJcbiAgICAgICAgICAgICAgb3Blbj17ZmlsdGVyc09wZW59XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RmlsdGVyc09wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgICAgIHRpdGxlPXt1aVRleHQuZmlsdGVyc31cclxuICAgICAgICAgICAgICBkcmF3ZXJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxDYXRhbG9nRmlsdGVyc1xyXG4gICAgICAgICAgICAgICAga2V5PXsnbW9iaWxlLScgKyBxdWVyeS5taW5QcmljZSArICc6JyArIHF1ZXJ5Lm1heFByaWNlfVxyXG4gICAgICAgICAgICAgICAgZmFjZXRzPXtkYXRhLmZhY2V0c31cclxuICAgICAgICAgICAgICAgIHF1ZXJ5PXtxdWVyeX1cclxuICAgICAgICAgICAgICAgIHVwZGF0ZT17cGFnZS51cGRhdGV9XHJcbiAgICAgICAgICAgICAgICBjbGVhcj17cGFnZS5jbGVhcn1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktYnV0dG9uIHVpLWJ1dHRvbi1wcmltYXJ5IG10LTUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcnNPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dWlUZXh0LmFwcGx5RmlsdGVyc31cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgPHNlY3Rpb24gYXJpYS1sYWJlbD17dC50aXRsZX0gY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICB7Y2hpcHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dC5hY3RpdmV9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi00IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2NoaXBzLm1hcCgoY2hpcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtjaGlwLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NoaXAuY2xlYXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dC5yZW1vdmV9OiAke2NoaXAubGFiZWx9YH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXgtdy1mdWxsIHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1wcmltYXJ5IGJnLXByaW1hcnktc3VidGxlIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJicmVhay13b3Jkc1wiPntjaGlwLmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDDl1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8cCByb2xlPVwic3RhdHVzXCIgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICB7dC5zaG93aW5nfSB7ZGF0YS50b3RhbCA/IChkYXRhLnBhZ2UgLSAxKSAqIGRhdGEubGltaXQgKyAxIDogMH3igJNcclxuICAgICAgICAgICAgICAgIHtNYXRoLm1pbihkYXRhLnBhZ2UgKiBkYXRhLmxpbWl0LCBkYXRhLnRvdGFsKX0ge3Qub2Z9eycgJ31cclxuICAgICAgICAgICAgICAgIHtkYXRhLnRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9eycgJ31cclxuICAgICAgICAgICAgICAgIHtkYXRhLnRvdGFsID09PSAxID8gdC5wcm9kdWN0IDogdC5wcm9kdWN0c31cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgIHt0LnNvcnR9XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e3Quc29ydH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3F1ZXJ5LnNvcnR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgcGFnZS51cGRhdGUoeyBzb3J0OiBldmVudC50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCBtaW4taC0xMSB3LWF1dG8gcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBweC0zIHRleHQtc20gZm9jdXM6Ym9yZGVyLXByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Q0FUQUxPR19TT1JUUy5tYXAoKHNvcnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17c29ydH0gdmFsdWU9e3NvcnR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Quc29ydHNbc29ydF19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHshZGF0YS5pdGVtcy5sZW5ndGggPyAoXHJcbiAgICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICAgIHRpdGxlPXt0LmVtcHR5fVxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249e3QuZW1wdHlEZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtwYWdlLmNsZWFyfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tcHJpbWFyeSBtdC01IHJvdW5kZWQtc20gYmctcHJpbWFyeSBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktb25cIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3QuY2xlYXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWNvbj1cImJhZ1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbWQ6Z3JpZC1jb2xzLTMgbWQ6Z2FwLTYgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTRcIj5cclxuICAgICAgICAgICAgICAgIHtkYXRhLml0ZW1zLm1hcCgocHJvZHVjdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8Q2F0YWxvZ1Byb2R1Y3RDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtwcm9kdWN0LnByb2R1Y3RJRH1cclxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0PXtwcm9kdWN0fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxDYXRhbG9nUGFnaW5hdGlvblxyXG4gICAgICAgICAgICAgIHBhZ2U9e2RhdGEucGFnZX1cclxuICAgICAgICAgICAgICB0b3RhbFBhZ2VzPXtkYXRhLnRvdGFsUGFnZXN9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgICAgIHBhZ2UudXBkYXRlKHsgcGFnZTogU3RyaW5nKG51bWJlcikgfSk7XHJcbiAgICAgICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oeyB0b3A6IDAsIGJlaGF2aW9yOiAnaW5zdGFudCcgfSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==