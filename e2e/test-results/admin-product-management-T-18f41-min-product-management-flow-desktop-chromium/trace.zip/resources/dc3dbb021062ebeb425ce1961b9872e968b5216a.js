import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/LiveChat/index.tsx");const useState = __vite__cjsImport3_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import { ChatPane } from "/src/components/chat/ChatPane.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
import { Alert } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { useAuth } from "/src/hooks/useAuth.ts";
import { useSupportChat } from "/src/hooks/useSupportChat.ts";
import { ChatConversation } from "/src/components/chat/ChatConversation.tsx";
import { ChatSessionList } from "/src/components/chat/ChatSessionList.tsx";
import { ChatConnection } from "/src/components/chat/ChatConnection.tsx";
import { chatText as t } from "/src/utils/chatText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/LiveChat/index.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export default function LiveChatPage() {
	_s();
	const { user } = useAuth();
	return /* @__PURE__ */ _jsxDEV(CustomerChat, {}, user?.id, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 10
	}, this);
}
_s(LiveChatPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = LiveChatPage;
function CustomerChat() {
	_s2();
	const [showConversation, setShowConversation] = useState(false);
	const chat = useSupportChat("CUSTOMER");
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "mx-auto max-w-[1200px] space-y-6",
			children: [
				/* @__PURE__ */ _jsxDEV("header", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "ui-page-title text-fg",
							children: t.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm text-fg-secondary",
							children: t.customerDescription
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 13
						}, this),
						chat.list && chat.list.total >= 4 && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 max-w-2xl text-xs text-fg-muted",
							children: t.retention
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => {
							setShowConversation(true);
							void chat.create();
						},
						disabled: chat.creating,
						className: "ui-button ui-button-primary min-h-11 rounded-sm bg-primary px-4 text-sm font-medium text-primary-on hover:bg-primary-hover ",
						children: [chat.creating && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 31
						}, this), chat.creating ? t.creating : t.newChat]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(ChatConnection, {
					state: chat.connection,
					reconnect: chat.reconnect
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				chat.actionError && /* @__PURE__ */ _jsxDEV(Alert, {
					severity: "warning",
					children: chat.actionError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this),
				chat.listError ? /* @__PURE__ */ _jsxDEV("div", {
					role: "alert",
					className: "rounded-sm bg-danger-bg p-4 text-sm text-danger",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: chat.listError }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => void chat.refresh(),
						className: "mt-2 rounded underline",
						children: t.retry
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this) : !chat.list ? /* @__PURE__ */ _jsxDEV(LoadingState, {
					label: t.loading,
					compact: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "grid items-start gap-5 lg:grid-cols-[20rem_minmax(0,1fr)]",
					children: [/* @__PURE__ */ _jsxDEV("aside", {
						className: (showConversation && chat.selectedId ? "hidden lg:block " : "") + "min-w-0 rounded-md border border-line bg-surface ",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "border-b border-line p-4 font-semibold text-fg",
							children: [
								t.sessions,
								" · ",
								chat.list.total,
								"/5"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(ChatSessionList, {
							sessions: chat.list.items,
							selectedId: chat.selectedId,
							role: "CUSTOMER",
							select: (id) => {
								chat.select(id);
								setShowConversation(true);
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(ChatPane, {
						chat,
						back: () => {
							chat.deselect();
							setShowConversation(false);
						},
						children: /* @__PURE__ */ _jsxDEV(ChatConversation, { chat }, chat.selectedId, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_s2(CustomerChat, "CN4PBeqGWNbZW0lfxtMPZDN1Km4=", false, function() {
	return [useSupportChat];
});
_c2 = CustomerChat;
var _c, _c2;
$RefreshReg$(_c, "LiveChatPage");
$RefreshReg$(_c2, "CustomerChat");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/LiveChat/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/LiveChat/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/LiveChat/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/LiveChat/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsYUFBYTtBQUN0QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxZQUFZLFNBQVM7Ozs7QUFDOUIsZUFBZSxTQUFTLGVBQWU7O0NBQ3JDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FBTyx3QkFBQyxjQUFELENBQThCLEdBQVgsTUFBTTs7OztRQUFLO0FBQ3ZDOzs7OztBQUNBLFNBQVMsZUFBZTs7Q0FDdEIsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLO0NBQzlELE1BQU0sT0FBTyxlQUFlLFVBQVU7Q0FDdEMsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUNkLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CO0lBQ0Usd0JBQUMsVUFBRDtLQUFRLFdBQVU7ZUFBbEIsQ0FDRSx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXlCLEVBQUU7TUFBVTs7Ozs7TUFDbkQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsRUFBRTtNQUNGOzs7OztNQUNGLEtBQUssUUFBUSxLQUFLLEtBQUssU0FBUyxLQUMvQix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixFQUFFO01BQ0Y7Ozs7O0tBRUY7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWU7T0FDYixvQkFBb0IsSUFBSTtPQUN4QixLQUFLLEtBQUssT0FBTztNQUNuQjtNQUNBLFVBQVUsS0FBSztNQUNmLFdBQVU7Z0JBUFosQ0FTRyxLQUFLLFlBQVksd0JBQUMsU0FBRCxFQUFTLFdBQVUsT0FBUTs7OztnQkFDNUMsS0FBSyxXQUFXLEVBQUUsV0FBVyxFQUFFLE9BQzFCOzs7OzthQUNGOzs7Ozs7SUFDUix3QkFBQyxnQkFBRDtLQUFnQixPQUFPLEtBQUs7S0FBWSxXQUFXLEtBQUs7SUFBWTs7Ozs7SUFDbkUsS0FBSyxlQUNKLHdCQUFDLE9BQUQ7S0FBTyxVQUFTO2VBQVcsS0FBSztJQUFtQjs7Ozs7SUFFcEQsS0FBSyxZQUNKLHdCQUFDLE9BQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtlQUZaLENBSUUsd0JBQUMsS0FBRCxZQUFJLEtBQUssVUFBYTs7OztlQUN0Qix3QkFBQyxVQUFEO01BQ0UsZUFBZSxLQUFLLEtBQUssUUFBUTtNQUNqQyxXQUFVO2dCQUVULEVBQUU7S0FDRzs7OzthQUNMOzs7OztlQUNILENBQUMsS0FBSyxPQUNSLHdCQUFDLGNBQUQ7S0FBYyxPQUFPLEVBQUU7S0FBUyxTQUFTO0lBQU87Ozs7ZUFFaEQsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFDRSxZQUNHLG9CQUFvQixLQUFLLGFBQ3RCLHFCQUNBLE1BQU07Z0JBSmQsQ0FPRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNHLEVBQUU7UUFBUztRQUFJLEtBQUssS0FBSztRQUFNO09BQzlCOzs7OztnQkFDSix3QkFBQyxpQkFBRDtPQUNFLFVBQVUsS0FBSyxLQUFLO09BQ3BCLFlBQVksS0FBSztPQUNqQixNQUFLO09BQ0wsU0FBUyxPQUFPO1FBQ2QsS0FBSyxPQUFPLEVBQUU7UUFDZCxvQkFBb0IsSUFBSTtPQUMxQjtNQUNEOzs7O2NBQ0k7Ozs7O2VBQ1Asd0JBQUMsVUFBRDtNQUNRO01BQ04sWUFBWTtPQUNWLEtBQUssU0FBUztPQUNkLG9CQUFvQixLQUFLO01BQzNCO2dCQUVBLHdCQUFDLGtCQUFELEVBQThDLEtBQU8sR0FBOUIsS0FBSzs7OzthQUF5QjtLQUM3Qzs7OzthQUNQOzs7Ozs7R0FFQTs7Ozs7O0NBQ0w7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoYXRQYW5lIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jaGF0L0NoYXRQYW5lJztcclxuaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBBbGVydCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTG9hZGluZ1N0YXRlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VBdXRoJztcclxuaW1wb3J0IHsgdXNlU3VwcG9ydENoYXQgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VTdXBwb3J0Q2hhdCc7XHJcbmltcG9ydCB7IENoYXRDb252ZXJzYXRpb24gfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NoYXQvQ2hhdENvbnZlcnNhdGlvbic7XHJcbmltcG9ydCB7IENoYXRTZXNzaW9uTGlzdCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY2hhdC9DaGF0U2Vzc2lvbkxpc3QnO1xyXG5pbXBvcnQgeyBDaGF0Q29ubmVjdGlvbiB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY2hhdC9DaGF0Q29ubmVjdGlvbic7XHJcbmltcG9ydCB7IGNoYXRUZXh0IGFzIHQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9jaGF0VGV4dCc7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExpdmVDaGF0UGFnZSgpIHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICByZXR1cm4gPEN1c3RvbWVyQ2hhdCBrZXk9e3VzZXI/LmlkfSAvPjtcclxufVxyXG5mdW5jdGlvbiBDdXN0b21lckNoYXQoKSB7XHJcbiAgY29uc3QgW3Nob3dDb252ZXJzYXRpb24sIHNldFNob3dDb252ZXJzYXRpb25dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGNoYXQgPSB1c2VTdXBwb3J0Q2hhdCgnQ1VTVE9NRVInKTtcclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYmctcGFnZSBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1bMTIwMHB4XSBzcGFjZS15LTZcIj5cclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGUgdGV4dC1mZ1wiPnt0LnRpdGxlfTwvaDE+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIHt0LmN1c3RvbWVyRGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAge2NoYXQubGlzdCAmJiBjaGF0Lmxpc3QudG90YWwgPj0gNCAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiBtYXgtdy0yeGwgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICB7dC5yZXRlbnRpb259XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2hvd0NvbnZlcnNhdGlvbih0cnVlKTtcclxuICAgICAgICAgICAgICB2b2lkIGNoYXQuY3JlYXRlKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtjaGF0LmNyZWF0aW5nfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXByaW1hcnkgbWluLWgtMTEgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlciBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7Y2hhdC5jcmVhdGluZyAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICAgIHtjaGF0LmNyZWF0aW5nID8gdC5jcmVhdGluZyA6IHQubmV3Q2hhdH1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG4gICAgICAgIDxDaGF0Q29ubmVjdGlvbiBzdGF0ZT17Y2hhdC5jb25uZWN0aW9ufSByZWNvbm5lY3Q9e2NoYXQucmVjb25uZWN0fSAvPlxyXG4gICAgICAgIHtjaGF0LmFjdGlvbkVycm9yICYmIChcclxuICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj57Y2hhdC5hY3Rpb25FcnJvcn08L0FsZXJ0PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2NoYXQubGlzdEVycm9yID8gKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIGJnLWRhbmdlci1iZyBwLTQgdGV4dC1zbSB0ZXh0LWRhbmdlclwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxwPntjaGF0Lmxpc3RFcnJvcn08L3A+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGNoYXQucmVmcmVzaCgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgcm91bmRlZCB1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3QucmV0cnl9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6ICFjaGF0Lmxpc3QgPyAoXHJcbiAgICAgICAgICA8TG9hZGluZ1N0YXRlIGxhYmVsPXt0LmxvYWRpbmd9IGNvbXBhY3Q9e3RydWV9IC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNSBsZzpncmlkLWNvbHMtWzIwcmVtX21pbm1heCgwLDFmcildXCI+XHJcbiAgICAgICAgICAgIDxhc2lkZVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAoc2hvd0NvbnZlcnNhdGlvbiAmJiBjaGF0LnNlbGVjdGVkSWRcclxuICAgICAgICAgICAgICAgICAgPyAnaGlkZGVuIGxnOmJsb2NrICdcclxuICAgICAgICAgICAgICAgICAgOiAnJykgKyAnbWluLXctMCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlICdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWxpbmUgcC00IGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAge3Quc2Vzc2lvbnN9IMK3IHtjaGF0Lmxpc3QudG90YWx9LzVcclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDxDaGF0U2Vzc2lvbkxpc3RcclxuICAgICAgICAgICAgICAgIHNlc3Npb25zPXtjaGF0Lmxpc3QuaXRlbXN9XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZElkPXtjaGF0LnNlbGVjdGVkSWR9XHJcbiAgICAgICAgICAgICAgICByb2xlPVwiQ1VTVE9NRVJcIlxyXG4gICAgICAgICAgICAgICAgc2VsZWN0PXsoaWQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY2hhdC5zZWxlY3QoaWQpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93Q29udmVyc2F0aW9uKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICA8Q2hhdFBhbmVcclxuICAgICAgICAgICAgICBjaGF0PXtjaGF0fVxyXG4gICAgICAgICAgICAgIGJhY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIGNoYXQuZGVzZWxlY3QoKTtcclxuICAgICAgICAgICAgICAgIHNldFNob3dDb252ZXJzYXRpb24oZmFsc2UpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Q2hhdENvbnZlcnNhdGlvbiBrZXk9e2NoYXQuc2VsZWN0ZWRJZH0gY2hhdD17Y2hhdH0gLz5cclxuICAgICAgICAgICAgPC9DaGF0UGFuZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==