import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/CustomerLayout.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { NavLink, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { SiteHeader } from "/src/components/layout/SiteHeader.tsx";
import { SiteFooter } from "/src/components/layout/SiteFooter.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { useAuth } from "/src/hooks/useAuth.ts";
import { SeasonalGreeting } from "/src/components/seasonal/SeasonalGreeting.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/CustomerLayout.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function CustomerLayout() {
	_s();
	const { pathname } = useLocation();
	const { user } = useAuth();
	const hideTabs = [
		ROUTES.checkout,
		ROUTES.cart,
		ROUTES.liveChat,
		ROUTES.repairRequest
	].some((path) => pathname.startsWith(path));
	const tabs = [
		{
			path: ROUTES.home,
			label: "Home",
			icon: "home"
		},
		{
			path: ROUTES.products,
			label: "Shop",
			icon: "bag"
		},
		{
			path: user?.role === "REPAIRER" ? ROUTES.repairerRepairs : user?.role === "ADMIN" ? ROUTES.adminRepairs : ROUTES.repairs,
			label: "Repairs",
			icon: "repair"
		},
		{
			path: user?.role === "ADMIN" ? ROUTES.adminOrders : user?.role === "REPAIRER" ? ROUTES.repairer : ROUTES.orders,
			label: user?.role === "REPAIRER" ? "Workspace" : "Orders",
			icon: user?.role === "REPAIRER" ? "grid" : "orders"
		},
		{
			path: user ? ROUTES.account : ROUTES.login,
			label: "Account",
			icon: "user"
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `store-layout flex min-h-screen flex-col bg-page ${hideTabs ? "without-bottom-tabs" : "with-bottom-tabs"}`,
		children: [
			/* @__PURE__ */ _jsxDEV(SiteHeader, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SeasonalGreeting, { compact: pathname !== ROUTES.home }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				id: "main-content",
				tabIndex: -1,
				className: "min-w-0 flex-1 outline-none",
				children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SiteFooter, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this),
			!hideTabs && /* @__PURE__ */ _jsxDEV("nav", {
				className: "mobile-tabs",
				"aria-label": "Mobile navigation",
				children: tabs.map((tab) => /* @__PURE__ */ _jsxDEV(NavLink, {
					to: tab.path,
					end: tab.path === ROUTES.home,
					className: ({ isActive }) => isActive ? "is-active" : "",
					children: [/* @__PURE__ */ _jsxDEV(Icon, {
						name: tab.icon,
						className: "h-6 w-6"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: tab.label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 15
					}, this)]
				}, tab.path, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
}
_s(CustomerLayout, "QDS2mg4YfLuIX5e0/7o/ylxnDe4=", false, function() {
	return [useLocation, useAuth];
});
_c = CustomerLayout;
var _c;
$RefreshReg$(_c, "CustomerLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/CustomerLayout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/CustomerLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/CustomerLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/layout/CustomerLayout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTLFFBQVEsbUJBQW1CO0FBQzdDLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsWUFBMkI7QUFDcEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTtBQUN4QixTQUFTLHdCQUF3Qjs7OztBQUNqQyxPQUFPLFNBQVMsaUJBQWlCOztDQUMvQixNQUFNLEVBQUUsYUFBYSxZQUFZO0NBQ2pDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsTUFBTSxXQUFXO0VBQ2YsT0FBTztFQUNQLE9BQU87RUFDUCxPQUFPO0VBQ1AsT0FBTztDQUNULENBQUMsQ0FBQyxNQUFNLFNBQVMsU0FBUyxXQUFXLElBQUksQ0FBQztDQUMxQyxNQUFNLE9BQTBEO0VBQzlEO0dBQUUsTUFBTSxPQUFPO0dBQU0sT0FBTztHQUFRLE1BQU07RUFBTztFQUNqRDtHQUFFLE1BQU0sT0FBTztHQUFVLE9BQU87R0FBUSxNQUFNO0VBQU07RUFDcEQ7R0FDRSxNQUNFLE1BQU0sU0FBUyxhQUNYLE9BQU8sa0JBQ1AsTUFBTSxTQUFTLFVBQ2IsT0FBTyxlQUNQLE9BQU87R0FDZixPQUFPO0dBQ1AsTUFBTTtFQUNSO0VBQ0E7R0FDRSxNQUNFLE1BQU0sU0FBUyxVQUNYLE9BQU8sY0FDUCxNQUFNLFNBQVMsYUFDYixPQUFPLFdBQ1AsT0FBTztHQUNmLE9BQU8sTUFBTSxTQUFTLGFBQWEsY0FBYztHQUNqRCxNQUFNLE1BQU0sU0FBUyxhQUFhLFNBQVM7RUFDN0M7RUFDQTtHQUNFLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTztHQUNyQyxPQUFPO0dBQ1AsTUFBTTtFQUNSO0NBQ0Y7Q0FDQSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFXLG1EQUFtRCxXQUFXLHdCQUF3QjtZQURuRztHQUdFLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7R0FDYix3QkFBQyxrQkFBRCxFQUFrQixTQUFTLGFBQWEsT0FBTyxLQUFPOzs7OztHQUN0RCx3QkFBQyxPQUFEO0lBQ0UsSUFBRztJQUNILFVBQVUsQ0FBQztJQUNYLFdBQVU7Y0FFVix3QkFBQyxRQUFELENBQVM7Ozs7O0dBQ047Ozs7O0dBQ0wsd0JBQUMsWUFBRCxDQUFhOzs7OztHQUNaLENBQUMsWUFDQSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFjLGNBQVc7Y0FDckMsS0FBSyxLQUFLLFFBQ1Qsd0JBQUMsU0FBRDtLQUVFLElBQUksSUFBSTtLQUNSLEtBQUssSUFBSSxTQUFTLE9BQU87S0FDekIsWUFBWSxFQUFFLGVBQWdCLFdBQVcsY0FBYztlQUp6RCxDQU1FLHdCQUFDLE1BQUQ7TUFBTSxNQUFNLElBQUk7TUFBTSxXQUFVO0tBQVc7Ozs7ZUFDM0Msd0JBQUMsUUFBRCxZQUFPLElBQUksTUFBWTs7OzthQUNoQjtPQVBGLElBQUk7Ozs7V0FPRixDQUNWO0dBQ0U7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyTGF5b3V0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZMaW5rLCBPdXRsZXQsIHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IFNpdGVIZWFkZXIgfSBmcm9tICcuL1NpdGVIZWFkZXInO1xyXG5pbXBvcnQgeyBTaXRlRm9vdGVyIH0gZnJvbSAnLi9TaXRlRm9vdGVyJztcclxuaW1wb3J0IHsgSWNvbiwgdHlwZSBJY29uTmFtZSB9IGZyb20gJy4uL2NvbW1vbi9JY29uJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9ob29rcy91c2VBdXRoJztcclxuaW1wb3J0IHsgU2Vhc29uYWxHcmVldGluZyB9IGZyb20gJy4uL3NlYXNvbmFsL1NlYXNvbmFsR3JlZXRpbmcnO1xyXG5leHBvcnQgZnVuY3Rpb24gQ3VzdG9tZXJMYXlvdXQoKSB7XHJcbiAgY29uc3QgeyBwYXRobmFtZSB9ID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBoaWRlVGFicyA9IFtcclxuICAgIFJPVVRFUy5jaGVja291dCxcclxuICAgIFJPVVRFUy5jYXJ0LFxyXG4gICAgUk9VVEVTLmxpdmVDaGF0LFxyXG4gICAgUk9VVEVTLnJlcGFpclJlcXVlc3QsXHJcbiAgXS5zb21lKChwYXRoKSA9PiBwYXRobmFtZS5zdGFydHNXaXRoKHBhdGgpKTtcclxuICBjb25zdCB0YWJzOiB7IHBhdGg6IHN0cmluZzsgbGFiZWw6IHN0cmluZzsgaWNvbjogSWNvbk5hbWUgfVtdID0gW1xyXG4gICAgeyBwYXRoOiBST1VURVMuaG9tZSwgbGFiZWw6ICdIb21lJywgaWNvbjogJ2hvbWUnIH0sXHJcbiAgICB7IHBhdGg6IFJPVVRFUy5wcm9kdWN0cywgbGFiZWw6ICdTaG9wJywgaWNvbjogJ2JhZycgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDpcclxuICAgICAgICB1c2VyPy5yb2xlID09PSAnUkVQQUlSRVInXHJcbiAgICAgICAgICA/IFJPVVRFUy5yZXBhaXJlclJlcGFpcnNcclxuICAgICAgICAgIDogdXNlcj8ucm9sZSA9PT0gJ0FETUlOJ1xyXG4gICAgICAgICAgICA/IFJPVVRFUy5hZG1pblJlcGFpcnNcclxuICAgICAgICAgICAgOiBST1VURVMucmVwYWlycyxcclxuICAgICAgbGFiZWw6ICdSZXBhaXJzJyxcclxuICAgICAgaWNvbjogJ3JlcGFpcicsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXRoOlxyXG4gICAgICAgIHVzZXI/LnJvbGUgPT09ICdBRE1JTidcclxuICAgICAgICAgID8gUk9VVEVTLmFkbWluT3JkZXJzXHJcbiAgICAgICAgICA6IHVzZXI/LnJvbGUgPT09ICdSRVBBSVJFUidcclxuICAgICAgICAgICAgPyBST1VURVMucmVwYWlyZXJcclxuICAgICAgICAgICAgOiBST1VURVMub3JkZXJzLFxyXG4gICAgICBsYWJlbDogdXNlcj8ucm9sZSA9PT0gJ1JFUEFJUkVSJyA/ICdXb3Jrc3BhY2UnIDogJ09yZGVycycsXHJcbiAgICAgIGljb246IHVzZXI/LnJvbGUgPT09ICdSRVBBSVJFUicgPyAnZ3JpZCcgOiAnb3JkZXJzJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IHVzZXIgPyBST1VURVMuYWNjb3VudCA6IFJPVVRFUy5sb2dpbixcclxuICAgICAgbGFiZWw6ICdBY2NvdW50JyxcclxuICAgICAgaWNvbjogJ3VzZXInLFxyXG4gICAgfSxcclxuICBdO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT17YHN0b3JlLWxheW91dCBmbGV4IG1pbi1oLXNjcmVlbiBmbGV4LWNvbCBiZy1wYWdlICR7aGlkZVRhYnMgPyAnd2l0aG91dC1ib3R0b20tdGFicycgOiAnd2l0aC1ib3R0b20tdGFicyd9YH1cclxuICAgID5cclxuICAgICAgPFNpdGVIZWFkZXIgLz5cclxuICAgICAgPFNlYXNvbmFsR3JlZXRpbmcgY29tcGFjdD17cGF0aG5hbWUgIT09IFJPVVRFUy5ob21lfSAvPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgaWQ9XCJtYWluLWNvbnRlbnRcIlxyXG4gICAgICAgIHRhYkluZGV4PXstMX1cclxuICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMSBvdXRsaW5lLW5vbmVcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPE91dGxldCAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPFNpdGVGb290ZXIgLz5cclxuICAgICAgeyFoaWRlVGFicyAmJiAoXHJcbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJtb2JpbGUtdGFic1wiIGFyaWEtbGFiZWw9XCJNb2JpbGUgbmF2aWdhdGlvblwiPlxyXG4gICAgICAgICAge3RhYnMubWFwKCh0YWIpID0+IChcclxuICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICBrZXk9e3RhYi5wYXRofVxyXG4gICAgICAgICAgICAgIHRvPXt0YWIucGF0aH1cclxuICAgICAgICAgICAgICBlbmQ9e3RhYi5wYXRoID09PSBST1VURVMuaG9tZX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+IChpc0FjdGl2ZSA/ICdpcy1hY3RpdmUnIDogJycpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT17dGFiLmljb259IGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPnt0YWIubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L25hdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19