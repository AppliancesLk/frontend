import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/components/EmailPreview.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { promotionText as t } from "/src/utils/promotionText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/EmailPreview.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function EmailPreview({ html, subject, loading = false, error = "" }) {
	_s();
	const [mobile, setMobile] = useState(false);
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-label": t.preview,
		className: "min-w-0 rounded-lg border border-line bg-surface",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3 border-b border-line p-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-semibold",
							children: t.preview
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex gap-1 rounded-full bg-subtle p-1",
							role: "group",
							"aria-label": "Email preview size",
							children: [false, true].map((value) => /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-pressed": mobile === value,
								onClick: () => setMobile(value),
								className: `min-h-8 rounded-full px-3 text-xs ${mobile === value ? "bg-primary text-primary-on" : "text-fg-secondary"}`,
								children: value ? "Mobile" : "Desktop"
							}, String(value), false, {
								fileName: _jsxFileName,
								lineNumber: 30,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "break-words text-xs text-fg-secondary",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold",
								children: "Subject:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 43,
								columnNumber: 11
							}, this),
							" ",
							subject || "Your promotion subject"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs leading-5 text-fg-muted",
						children: [t.previewHint, loading ? " Updating preview…" : ""]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "m-4 text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this),
			html ? /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-hidden rounded-b-lg bg-subtle p-2 sm:p-3",
				children: /* @__PURE__ */ _jsxDEV("iframe", {
					title: "Promotion email preview",
					sandbox: "",
					srcDoc: html,
					className: "mx-auto block h-[690px] max-w-full rounded-md border border-line bg-white",
					style: { width: mobile ? 360 : "100%" }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(LoadingState, {
				compact: true,
				label: "Preparing email preview"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(EmailPreview, "n/tOkXJqan6ux+2dyl2GZcSzHVQ=");
_c = EmailPreview;
var _c;
$RefreshReg$(_c, "EmailPreview");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/components/EmailPreview.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/EmailPreview.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/EmailPreview.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/components/EmailPreview.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxpQkFBaUIsU0FBUzs7OztBQUNuQyxPQUFPLFNBQVMsYUFBYSxFQUMzQixNQUNBLFNBQ0EsVUFBVSxPQUNWLFFBQVEsTUFNUDs7Q0FDRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxPQUNFLHdCQUFDLFdBQUQ7RUFDRSxjQUFZLEVBQUU7RUFDZCxXQUFVO1lBRlo7R0FJRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBMkIsRUFBRTtNQUFZOzs7O2dCQUN2RCx3QkFBQyxPQUFEO09BQ0UsV0FBVTtPQUNWLE1BQUs7T0FDTCxjQUFXO2lCQUVWLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLFVBQ2xCLHdCQUFDLFVBQUQ7UUFFRSxNQUFLO1FBQ0wsZ0JBQWMsV0FBVztRQUN6QixlQUFlLFVBQVUsS0FBSztRQUM5QixXQUFXLHFDQUFxQyxXQUFXLFFBQVEsK0JBQStCO2tCQUVqRyxRQUFRLFdBQVc7T0FDZCxHQVBELE9BQU8sS0FBSzs7OztjQU9YLENBQ1Q7TUFDRTs7OztjQUNGOzs7Ozs7S0FDTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFnQjtPQUFjOzs7OztPQUFFO09BQy9DLFdBQVc7TUFDWDs7Ozs7O0tBQ0gsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FDRyxFQUFFLGFBQ0YsVUFBVSx1QkFBdUIsRUFDakM7Ozs7OztJQUNBOzs7Ozs7R0FDSixTQUNDLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVEsV0FBVTtjQUN2QjtHQUNBOzs7OztHQUVKLE9BQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxVQUFEO0tBQ0UsT0FBTTtLQUNOLFNBQVE7S0FDUixRQUFRO0tBQ1IsV0FBVTtLQUNWLE9BQU8sRUFBRSxPQUFPLFNBQVMsTUFBTSxPQUFPO0lBQ3ZDOzs7OztHQUNFOzs7O2NBRUwsd0JBQUMsY0FBRDtJQUFjO0lBQVEsT0FBTTtHQUEyQjs7Ozs7RUFFbEQ7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkVtYWlsUHJldmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBwcm9tb3Rpb25UZXh0IGFzIHQgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9wcm9tb3Rpb25UZXh0JztcclxuZXhwb3J0IGZ1bmN0aW9uIEVtYWlsUHJldmlldyh7XHJcbiAgaHRtbCxcclxuICBzdWJqZWN0LFxyXG4gIGxvYWRpbmcgPSBmYWxzZSxcclxuICBlcnJvciA9ICcnLFxyXG59OiB7XHJcbiAgaHRtbD86IHN0cmluZztcclxuICBzdWJqZWN0Pzogc3RyaW5nO1xyXG4gIGxvYWRpbmc/OiBib29sZWFuO1xyXG4gIGVycm9yPzogc3RyaW5nO1xyXG59KSB7XHJcbiAgY29uc3QgW21vYmlsZSwgc2V0TW9iaWxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb25cclxuICAgICAgYXJpYS1sYWJlbD17dC5wcmV2aWV3fVxyXG4gICAgICBjbGFzc05hbWU9XCJtaW4tdy0wIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2VcIlxyXG4gICAgPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBib3JkZXItYiBib3JkZXItbGluZSBwLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZFwiPnt0LnByZXZpZXd9PC9oMj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBnYXAtMSByb3VuZGVkLWZ1bGwgYmctc3VidGxlIHAtMVwiXHJcbiAgICAgICAgICAgIHJvbGU9XCJncm91cFwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJFbWFpbCBwcmV2aWV3IHNpemVcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7W2ZhbHNlLCB0cnVlXS5tYXAoKHZhbHVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAga2V5PXtTdHJpbmcodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e21vYmlsZSA9PT0gdmFsdWV9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGUodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWluLWgtOCByb3VuZGVkLWZ1bGwgcHgtMyB0ZXh0LXhzICR7bW9iaWxlID09PSB2YWx1ZSA/ICdiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1vbicgOiAndGV4dC1mZy1zZWNvbmRhcnknfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3ZhbHVlID8gJ01vYmlsZScgOiAnRGVza3RvcCd9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYnJlYWstd29yZHMgdGV4dC14cyB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlN1YmplY3Q6PC9zcGFuPnsnICd9XHJcbiAgICAgICAgICB7c3ViamVjdCB8fCAnWW91ciBwcm9tb3Rpb24gc3ViamVjdCd9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHt0LnByZXZpZXdIaW50fVxyXG4gICAgICAgICAge2xvYWRpbmcgPyAnIFVwZGF0aW5nIHByZXZpZXfigKYnIDogJyd9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJtLTQgdGV4dC1zbSB0ZXh0LWRhbmdlclwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2h0bWwgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1iLWxnIGJnLXN1YnRsZSBwLTIgc206cC0zXCI+XHJcbiAgICAgICAgICA8aWZyYW1lXHJcbiAgICAgICAgICAgIHRpdGxlPVwiUHJvbW90aW9uIGVtYWlsIHByZXZpZXdcIlxyXG4gICAgICAgICAgICBzYW5kYm94PVwiXCJcclxuICAgICAgICAgICAgc3JjRG9jPXtodG1sfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJteC1hdXRvIGJsb2NrIGgtWzY5MHB4XSBtYXgtdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IG1vYmlsZSA/IDM2MCA6ICcxMDAlJyB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8TG9hZGluZ1N0YXRlIGNvbXBhY3QgbGFiZWw9XCJQcmVwYXJpbmcgZW1haWwgcHJldmlld1wiIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=