import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/feedback/OfflineBanner.tsx");const useSyncExternalStore = __vite__cjsImport0_react["useSyncExternalStore"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/OfflineBanner.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const subscribe = (callback) => {
	window.addEventListener("online", callback);
	window.addEventListener("offline", callback);
	return () => {
		window.removeEventListener("online", callback);
		window.removeEventListener("offline", callback);
	};
};
export function OfflineBanner() {
	_s();
	const online = useSyncExternalStore(subscribe, () => navigator.onLine, () => true);
	if (online) return null;
	return /* @__PURE__ */ _jsxDEV("p", {
		role: "status",
		className: "border-b border-warning/25 bg-warning-bg px-4 py-3 text-center text-sm text-warning",
		children: "You’re offline. Some actions won’t work until you reconnect."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_s(OfflineBanner, "ui15Tv5/q+BmsQ+TAi3H1s3eAAs=");
_c = OfflineBanner;
var _c;
$RefreshReg$(_c, "OfflineBanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/feedback/OfflineBanner.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/OfflineBanner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/OfflineBanner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/feedback/OfflineBanner.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyw0QkFBNEI7Ozs7QUFDckMsTUFBTSxhQUFhLGFBQXlCO0NBQzFDLE9BQU8saUJBQWlCLFVBQVUsUUFBUTtDQUMxQyxPQUFPLGlCQUFpQixXQUFXLFFBQVE7Q0FDM0MsYUFBYTtFQUNYLE9BQU8sb0JBQW9CLFVBQVUsUUFBUTtFQUM3QyxPQUFPLG9CQUFvQixXQUFXLFFBQVE7Q0FDaEQ7QUFDRjtBQUNBLE9BQU8sU0FBUyxnQkFBZ0I7O0NBQzlCLE1BQU0sU0FBUyxxQkFDYixpQkFDTSxVQUFVLGNBQ1YsSUFDUjtDQUNBLElBQUksUUFBUSxPQUFPO0NBQ25CLE9BQ0Usd0JBQUMsS0FBRDtFQUNFLE1BQUs7RUFDTCxXQUFVO1lBQ1g7Q0FFRTs7Ozs7QUFFUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPZmZsaW5lQmFubmVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTeW5jRXh0ZXJuYWxTdG9yZSB9IGZyb20gJ3JlYWN0JztcclxuY29uc3Qgc3Vic2NyaWJlID0gKGNhbGxiYWNrOiAoKSA9PiB2b2lkKSA9PiB7XHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ29ubGluZScsIGNhbGxiYWNrKTtcclxuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignb2ZmbGluZScsIGNhbGxiYWNrKTtcclxuICByZXR1cm4gKCkgPT4ge1xyXG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ29ubGluZScsIGNhbGxiYWNrKTtcclxuICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvZmZsaW5lJywgY2FsbGJhY2spO1xyXG4gIH07XHJcbn07XHJcbmV4cG9ydCBmdW5jdGlvbiBPZmZsaW5lQmFubmVyKCkge1xyXG4gIGNvbnN0IG9ubGluZSA9IHVzZVN5bmNFeHRlcm5hbFN0b3JlKFxyXG4gICAgc3Vic2NyaWJlLFxyXG4gICAgKCkgPT4gbmF2aWdhdG9yLm9uTGluZSxcclxuICAgICgpID0+IHRydWUsXHJcbiAgKTtcclxuICBpZiAob25saW5lKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gKFxyXG4gICAgPHBcclxuICAgICAgcm9sZT1cInN0YXR1c1wiXHJcbiAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci13YXJuaW5nLzI1IGJnLXdhcm5pbmctYmcgcHgtNCBweS0zIHRleHQtY2VudGVyIHRleHQtc20gdGV4dC13YXJuaW5nXCJcclxuICAgID5cclxuICAgICAgWW914oCZcmUgb2ZmbGluZS4gU29tZSBhY3Rpb25zIHdvbuKAmXQgd29yayB1bnRpbCB5b3UgcmVjb25uZWN0LlxyXG4gICAgPC9wPlxyXG4gICk7XHJcbn1cclxuIl19