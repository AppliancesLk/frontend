import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/index.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { Button } from "/src/components/ui/Button.tsx";
import { EmptyState, ErrorState, LoadingState } from "/src/components/ui/Feedback.tsx";
import { formatDate } from "/src/utils/date.ts";
import { promotionText as t } from "/src/utils/promotionText.ts";
import { usePromotionsPage } from "/src/pages/Admin/Promotions/hooks/usePromotionsPage.ts";
import { PromotionBadge } from "/src/pages/Admin/Promotions/components/PromotionBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function PromotionsPage() {
	_s();
	const page = usePromotionsPage();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title",
					children: t.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-secondary",
					children: t.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: `${ROUTES.adminPromotions}/new`,
					className: "ui-button ui-button-primary",
					children: ["+ ", t.newPromotion]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-end gap-3 rounded-md border border-line bg-surface p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "promotion-search",
						className: "auth-label",
						children: t.search
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "promotion-search",
						className: "ui-field",
						type: "search",
						maxLength: 100,
						value: page.search,
						onChange: (e) => {
							page.setSearch(e.target.value);
							page.setPage(1);
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					variant: "secondary",
					onClick: page.refresh,
					children: "Refresh"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV(ErrorState, {
				message: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 22
			}, this),
			page.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: t.loading }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this) : page.result && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [!page.result.items.length ? /* @__PURE__ */ _jsxDEV(EmptyState, {
				title: page.search ? "No matching promotions" : t.empty,
				description: t.emptyHint,
				icon: "chat"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 15
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto rounded-md border border-line bg-surface",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full min-w-[720px] text-left text-sm",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-subtle text-fg-secondary",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							"Promotion",
							"Audience",
							"Last send",
							"Status",
							""
						].map((title) => /* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							className: "px-5 py-4 font-medium",
							children: title
						}, title, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 27
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-line",
						children: page.result.items.map((item) => /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								scope: "row",
								className: "max-w-80 px-5 py-5 text-left font-normal",
								children: [/* @__PURE__ */ _jsxDEV(Link, {
									className: "font-semibold hover:underline",
									to: `${ROUTES.adminPromotions}/${item.id}`,
									children: item.subject || t.noSubject
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 88,
									columnNumber: 27
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-2 text-xs text-fg-muted",
									children: [
										item.productCount,
										" products · Updated",
										" ",
										formatDate(item.updatedAt)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 27
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-5 text-fg-secondary",
								children: [item.audience === "ALL" ? t.all : t.selected, item.latestRun && /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 text-xs",
									children: [item.latestRun.recipientCount, " recipients"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-5 text-xs text-fg-muted",
								children: item.latestRun ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [formatDate(item.latestRun.createdAt), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1",
									children: [
										item.latestRun.counts.SENT,
										" sent ·",
										" ",
										item.latestRun.counts.FAILED + item.latestRun.counts.UNKNOWN,
										" ",
										"failed / unknown"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 111,
									columnNumber: 31
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 29
								}, this) : "Not sent yet"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-5",
								children: [/* @__PURE__ */ _jsxDEV(PromotionBadge, { status: item.latestRun?.status }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 27
								}, this), item.latestRun && item.latestRun.campaignVersion !== item.version && /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-2 text-xs text-fg-muted",
									children: "Edited since last send"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 126,
									columnNumber: 31
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "px-5 py-5",
								children: /* @__PURE__ */ _jsxDEV(Link, {
									className: "ui-button ui-button-secondary whitespace-nowrap",
									to: `${ROUTES.adminPromotions}/${item.id}`,
									children: t.editResend
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 27
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 25
							}, this)
						] }, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 23
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: [
					page.result.total,
					" promotions · Page ",
					page.page
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: page.page <= 1,
						onClick: () => page.setPage(page.page - 1),
						children: "Previous"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						disabled: page.page * page.result.limit >= page.result.total,
						onClick: () => page.setPage(page.page + 1),
						children: "Next"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_s(PromotionsPage, "bIj8uqxZ7KWNJoDw1aQhke/cLh8=", false, function() {
	return [usePromotionsPage];
});
_c = PromotionsPage;
var _c;
$RefreshReg$(_c, "PromotionsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FDRSxZQUNBLFlBQ0Esb0JBQ0s7QUFDUCxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGlCQUFpQixTQUFTO0FBQ25DLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsc0JBQXNCOzs7O0FBQy9CLGVBQWUsU0FBUyxpQkFBaUI7O0NBQ3ZDLE1BQU0sT0FBTyxrQkFBa0I7Q0FDL0IsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWlCLEVBQUU7SUFBVTs7OztjQUMzQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFrQyxFQUFFO0lBQWU7Ozs7WUFDN0Q7Ozs7Y0FDTCx3QkFBQyxNQUFEO0tBQ0UsSUFBSSxHQUFHLE9BQU8sZ0JBQWdCO0tBQzlCLFdBQVU7ZUFGWixDQUdDLE1BQ0ksRUFBRSxZQUNEOzs7OztZQUNBOzs7Ozs7R0FDUix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO01BQW1CLFdBQVU7Z0JBQ3pDLEVBQUU7S0FDRTs7OztlQUNQLHdCQUFDLFNBQUQ7TUFDRSxJQUFHO01BQ0gsV0FBVTtNQUNWLE1BQUs7TUFDTCxXQUFXO01BQ1gsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNO09BQ2YsS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO09BQzdCLEtBQUssUUFBUSxDQUFDO01BQ2hCO0tBQ0Q7Ozs7YUFDRTs7Ozs7Y0FDTCx3QkFBQyxRQUFEO0tBQVEsU0FBUTtLQUFZLFNBQVMsS0FBSztlQUFTO0lBRTNDOzs7O1lBQ0w7Ozs7OztHQUNKLEtBQUssU0FBUyx3QkFBQyxZQUFEO0lBQVksU0FBUyxLQUFLO0lBQU8sT0FBTyxLQUFLO0dBQVU7Ozs7O0dBQ3JFLEtBQUssVUFDSix3QkFBQyxjQUFELEVBQWMsT0FBTyxFQUFFLFFBQVU7Ozs7Y0FFakMsS0FBSyxVQUNMLENBQUMsS0FBSyxTQUNKLGdEQUNHLENBQUMsS0FBSyxPQUFPLE1BQU0sU0FDbEIsd0JBQUMsWUFBRDtJQUNFLE9BQU8sS0FBSyxTQUFTLDJCQUEyQixFQUFFO0lBQ2xELGFBQWEsRUFBRTtJQUNmLE1BQUs7R0FDTjs7OztjQUVELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFDZix3QkFBQyxNQUFELFlBQ0c7T0FBQztPQUFhO09BQVk7T0FBYTtPQUFVO01BQUUsQ0FBQyxDQUFDLEtBQ25ELFVBQ0Msd0JBQUMsTUFBRDtPQUVFLE9BQU07T0FDTixXQUFVO2lCQUVUO01BQ0MsR0FMRzs7OzthQUtILENBRVIsRUFDRTs7Ozs7S0FDQzs7OztlQUNQLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNkLEtBQUssT0FBTyxNQUFNLEtBQUssU0FDdEIsd0JBQUMsTUFBRDtPQUNFLHdCQUFDLE1BQUQ7UUFDRSxPQUFNO1FBQ04sV0FBVTtrQkFGWixDQUlFLHdCQUFDLE1BQUQ7U0FDRSxXQUFVO1NBQ1YsSUFBSSxHQUFHLE9BQU8sZ0JBQWdCLEdBQUcsS0FBSzttQkFFckMsS0FBSyxXQUFXLEVBQUU7UUFDZjs7OztrQkFDTix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUNHLEtBQUs7VUFBYTtVQUFvQjtVQUN0QyxXQUFXLEtBQUssU0FBUztTQUN6Qjs7Ozs7Z0JBQ0Q7Ozs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0csS0FBSyxhQUFhLFFBQVEsRUFBRSxNQUFNLEVBQUUsVUFDcEMsS0FBSyxhQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQ0csS0FBSyxVQUFVLGdCQUFlLGFBQzlCOzs7OztnQkFFSDs7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsS0FBSyxZQUNKLGdEQUNHLFdBQVcsS0FBSyxVQUFVLFNBQVMsR0FDcEMsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFDRyxLQUFLLFVBQVUsT0FBTztVQUFLO1VBQVE7VUFDbkMsS0FBSyxVQUFVLE9BQU8sU0FDckIsS0FBSyxVQUFVLE9BQU87VUFBUztVQUFJO1NBRXBDOzs7OztnQkFDSDs7OzttQkFFRjtPQUVBOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsZ0JBQUQsRUFBZ0IsUUFBUSxLQUFLLFdBQVcsT0FBUzs7OztrQkFDaEQsS0FBSyxhQUNKLEtBQUssVUFBVSxvQkFBb0IsS0FBSyxXQUN0Qyx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkI7UUFFdkM7Ozs7Z0JBRUw7Ozs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLE1BQUQ7U0FDRSxXQUFVO1NBQ1YsSUFBSSxHQUFHLE9BQU8sZ0JBQWdCLEdBQUcsS0FBSzttQkFFckMsRUFBRTtRQUNDOzs7OztPQUNKOzs7OztNQUNGLEtBeERLLEtBQUs7Ozs7YUF3RFYsQ0FDTDtLQUNJOzs7O2FBQ0Y7Ozs7OztHQUNKOzs7O2FBRVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLEtBQUQ7S0FDRyxLQUFLLE9BQU87S0FBTTtLQUFvQixLQUFLO0lBQzNDOzs7O2NBQ0gsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFDRSxTQUFRO01BQ1IsVUFBVSxLQUFLLFFBQVE7TUFDdkIsZUFBZSxLQUFLLFFBQVEsS0FBSyxPQUFPLENBQUM7Z0JBQzFDO0tBRU87Ozs7ZUFDUix3QkFBQyxRQUFEO01BQ0UsU0FBUTtNQUNSLFVBQVUsS0FBSyxPQUFPLEtBQUssT0FBTyxTQUFTLEtBQUssT0FBTztNQUN2RCxlQUFlLEtBQUssUUFBUSxLQUFLLE9BQU8sQ0FBQztnQkFDMUM7S0FFTzs7OzthQUNMOzs7OztZQUNGOzs7OztXQUNMOzs7OztFQUdDOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9CdXR0b24nO1xyXG5pbXBvcnQge1xyXG4gIEVtcHR5U3RhdGUsXHJcbiAgRXJyb3JTdGF0ZSxcclxuICBMb2FkaW5nU3RhdGUsXHJcbn0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IGZvcm1hdERhdGUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9kYXRlJztcclxuaW1wb3J0IHsgcHJvbW90aW9uVGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvcHJvbW90aW9uVGV4dCc7XHJcbmltcG9ydCB7IHVzZVByb21vdGlvbnNQYWdlIH0gZnJvbSAnLi9ob29rcy91c2VQcm9tb3Rpb25zUGFnZSc7XHJcbmltcG9ydCB7IFByb21vdGlvbkJhZGdlIH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb21vdGlvbkJhZGdlJztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvbW90aW9uc1BhZ2UoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZVByb21vdGlvbnNQYWdlKCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGVcIj57dC50aXRsZX08L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+e3QuZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICB0bz17YCR7Uk9VVEVTLmFkbWluUHJvbW90aW9uc30vbmV3YH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tcHJpbWFyeVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgKyB7dC5uZXdQcm9tb3Rpb259XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQgZ2FwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInByb21vdGlvbi1zZWFyY2hcIiBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCI+XHJcbiAgICAgICAgICAgIHt0LnNlYXJjaH1cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9XCJwcm9tb3Rpb24tc2VhcmNoXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGRcIlxyXG4gICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgbWF4TGVuZ3RoPXsxMDB9XHJcbiAgICAgICAgICAgIHZhbHVlPXtwYWdlLnNlYXJjaH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgcGFnZS5zZXRTZWFyY2goZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgIHBhZ2Uuc2V0UGFnZSgxKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17cGFnZS5yZWZyZXNofT5cclxuICAgICAgICAgIFJlZnJlc2hcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtwYWdlLmVycm9yICYmIDxFcnJvclN0YXRlIG1lc3NhZ2U9e3BhZ2UuZXJyb3J9IHJldHJ5PXtwYWdlLnJlZnJlc2h9IC8+fVxyXG4gICAgICB7cGFnZS5sb2FkaW5nID8gKFxyXG4gICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9e3QubG9hZGluZ30gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICBwYWdlLnJlc3VsdCAmJlxyXG4gICAgICAgICFwYWdlLmVycm9yICYmIChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIHshcGFnZS5yZXN1bHQuaXRlbXMubGVuZ3RoID8gKFxyXG4gICAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgICB0aXRsZT17cGFnZS5zZWFyY2ggPyAnTm8gbWF0Y2hpbmcgcHJvbW90aW9ucycgOiB0LmVtcHR5fVxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249e3QuZW1wdHlIaW50fVxyXG4gICAgICAgICAgICAgICAgaWNvbj1cImNoYXRcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZVwiPlxyXG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCBtaW4tdy1bNzIwcHhdIHRleHQtbGVmdCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zdWJ0bGUgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7WydQcm9tb3Rpb24nLCAnQXVkaWVuY2UnLCAnTGFzdCBzZW5kJywgJ1N0YXR1cycsICcnXS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICh0aXRsZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlPVwiY29sXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktNCBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtbGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYWdlLnJlc3VsdC5pdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzY29wZT1cInJvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LXctODAgcHgtNSBweS01IHRleHQtbGVmdCBmb250LW5vcm1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBob3Zlcjp1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2Ake1JPVVRFUy5hZG1pblByb21vdGlvbnN9LyR7aXRlbS5pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN1YmplY3QgfHwgdC5ub1N1YmplY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9kdWN0Q291bnR9IHByb2R1Y3RzIMK3IFVwZGF0ZWR7JyAnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoaXRlbS51cGRhdGVkQXQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmF1ZGllbmNlID09PSAnQUxMJyA/IHQuYWxsIDogdC5zZWxlY3RlZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sYXRlc3RSdW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhdGVzdFJ1bi5yZWNpcGllbnRDb3VudH0gcmVjaXBpZW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTUgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGF0ZXN0UnVuID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoaXRlbS5sYXRlc3RSdW4uY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhdGVzdFJ1bi5jb3VudHMuU0VOVH0gc2VudCDCt3snICd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGF0ZXN0UnVuLmNvdW50cy5GQUlMRUQgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5sYXRlc3RSdW4uY291bnRzLlVOS05PV059eycgJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmYWlsZWQgLyB1bmtub3duXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnTm90IHNlbnQgeWV0J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UHJvbW90aW9uQmFkZ2Ugc3RhdHVzPXtpdGVtLmxhdGVzdFJ1bj8uc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhdGVzdFJ1biAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5sYXRlc3RSdW4uY2FtcGFpZ25WZXJzaW9uICE9PSBpdGVtLnZlcnNpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRlZCBzaW5jZSBsYXN0IHNlbmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1idXR0b24gdWktYnV0dG9uLXNlY29uZGFyeSB3aGl0ZXNwYWNlLW5vd3JhcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YCR7Uk9VVEVTLmFkbWluUHJvbW90aW9uc30vJHtpdGVtLmlkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3QuZWRpdFJlc2VuZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgIHtwYWdlLnJlc3VsdC50b3RhbH0gcHJvbW90aW9ucyDCtyBQYWdlIHtwYWdlLnBhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UucGFnZSA8PSAxfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwYWdlLnNldFBhZ2UocGFnZS5wYWdlIC0gMSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFByZXZpb3VzXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlLnBhZ2UgKiBwYWdlLnJlc3VsdC5saW1pdCA+PSBwYWdlLnJlc3VsdC50b3RhbH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRQYWdlKHBhZ2UucGFnZSArIDEpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBOZXh0XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApXHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=