import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { Link, generatePath } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { translations } from "/src/utils/translations.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { RatingPlate } from "/src/components/common/RatingPlate.tsx";
import { CopyReference } from "/src/components/common/CopyReference.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.repairs;
export function RepairSuccess({ ticket }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "mx-auto max-w-[760px] rounded-lg border border-line bg-surface p-6 sm:p-8",
		"aria-label": "Repair request confirmation",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-success-bg text-success",
				children: /* @__PURE__ */ _jsxDEV(Icon, {
					name: "check",
					className: "h-7 w-7"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "mt-5 text-center text-2xl font-semibold",
				children: "Repair request submitted"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-center text-sm text-fg-secondary",
				children: "We have your request. You can follow every update in Your repairs."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8",
				children: /* @__PURE__ */ _jsxDEV(RatingPlate, {
					title: ticket.reference,
					rows: [
						{
							label: "Reference",
							value: /* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-2",
								children: [ticket.reference, /* @__PURE__ */ _jsxDEV(CopyReference, { value: ticket.reference }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 17
							}, this)
						},
						{
							label: "Device",
							value: `${ticket.device.brand} ${ticket.device.model}`
						},
						{
							label: "Status",
							value: t.statuses[ticket.status]
						}
					]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 flex flex-col justify-center gap-3 sm:flex-row",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: generatePath(ROUTES.repairDetail, { id: ticket.id }),
						className: "auth-primary",
						children: "View repair"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.repairs,
						className: "auth-secondary",
						children: "Back to your repairs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.products,
						className: "ui-button ui-button-ghost",
						children: "Continue shopping"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_c = RepairSuccess;
var _c;
$RefreshReg$(_c, "RepairSuccess");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairSuccess.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQjtBQUVuQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxZQUFZOzs7QUFDckIsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLGNBQWMsRUFBRSxVQUFvQztDQUNsRSxPQUNFLHdCQUFDLFdBQUQ7RUFDRSxXQUFVO0VBQ1YsY0FBVztZQUZiO0dBSUUsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxNQUFEO0tBQU0sTUFBSztLQUFRLFdBQVU7SUFBVzs7Ozs7R0FDcEM7Ozs7O0dBQ04sd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBMEM7R0FFcEQ7Ozs7O0dBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBNkM7R0FFdkQ7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxhQUFEO0tBQ0UsT0FBTyxPQUFPO0tBQ2QsTUFBTTtNQUNKO09BQ0UsT0FBTztPQUNQLE9BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0csT0FBTyxXQUNSLHdCQUFDLGVBQUQsRUFBZSxPQUFPLE9BQU8sVUFBWTs7OztnQkFDckM7Ozs7OztNQUVWO01BQ0E7T0FDRSxPQUFPO09BQ1AsT0FBTyxHQUFHLE9BQU8sT0FBTyxNQUFNLEdBQUcsT0FBTyxPQUFPO01BQ2pEO01BQ0E7T0FBRSxPQUFPO09BQVUsT0FBTyxFQUFFLFNBQVMsT0FBTztNQUFRO0tBQ3REO0lBQ0Q7Ozs7O0dBQ0U7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFDRSxJQUFJLGFBQWEsT0FBTyxjQUFjLEVBQUUsSUFBSSxPQUFPLEdBQUcsQ0FBQztNQUN2RCxXQUFVO2dCQUNYO0tBRUs7Ozs7O0tBQ04sd0JBQUMsTUFBRDtNQUFNLElBQUksT0FBTztNQUFTLFdBQVU7Z0JBQWlCO0tBRS9DOzs7OztLQUNOLHdCQUFDLE1BQUQ7TUFBTSxJQUFJLE9BQU87TUFBVSxXQUFVO2dCQUE0QjtLQUUzRDs7Ozs7SUFDSDs7Ozs7O0VBQ0U7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlcGFpclN1Y2Nlc3MudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIGdlbmVyYXRlUGF0aCB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgdHlwZSB7IFJlcGFpclRpY2tldCB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3R5cGVzL3JlcGFpci50eXBlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyBSYXRpbmdQbGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JhdGluZ1BsYXRlJztcclxuaW1wb3J0IHsgQ29weVJlZmVyZW5jZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0NvcHlSZWZlcmVuY2UnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMucmVwYWlycztcclxuZXhwb3J0IGZ1bmN0aW9uIFJlcGFpclN1Y2Nlc3MoeyB0aWNrZXQgfTogeyB0aWNrZXQ6IFJlcGFpclRpY2tldCB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uXHJcbiAgICAgIGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzc2MHB4XSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBzbTpwLThcIlxyXG4gICAgICBhcmlhLWxhYmVsPVwiUmVwYWlyIHJlcXVlc3QgY29uZmlybWF0aW9uXCJcclxuICAgID5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IGgtMTQgdy0xNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXN1Y2Nlc3MtYmcgdGV4dC1zdWNjZXNzXCI+XHJcbiAgICAgICAgPEljb24gbmFtZT1cImNoZWNrXCIgY2xhc3NOYW1lPVwiaC03IHctN1wiIC8+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cIm10LTUgdGV4dC1jZW50ZXIgdGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgIFJlcGFpciByZXF1ZXN0IHN1Ym1pdHRlZFxyXG4gICAgICA8L2gyPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICBXZSBoYXZlIHlvdXIgcmVxdWVzdC4gWW91IGNhbiBmb2xsb3cgZXZlcnkgdXBkYXRlIGluIFlvdXIgcmVwYWlycy5cclxuICAgICAgPC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LThcIj5cclxuICAgICAgICA8UmF0aW5nUGxhdGVcclxuICAgICAgICAgIHRpdGxlPXt0aWNrZXQucmVmZXJlbmNlfVxyXG4gICAgICAgICAgcm93cz17W1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgbGFiZWw6ICdSZWZlcmVuY2UnLFxyXG4gICAgICAgICAgICAgIHZhbHVlOiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICB7dGlja2V0LnJlZmVyZW5jZX1cclxuICAgICAgICAgICAgICAgICAgPENvcHlSZWZlcmVuY2UgdmFsdWU9e3RpY2tldC5yZWZlcmVuY2V9IC8+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGxhYmVsOiAnRGV2aWNlJyxcclxuICAgICAgICAgICAgICB2YWx1ZTogYCR7dGlja2V0LmRldmljZS5icmFuZH0gJHt0aWNrZXQuZGV2aWNlLm1vZGVsfWAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHsgbGFiZWw6ICdTdGF0dXMnLCB2YWx1ZTogdC5zdGF0dXNlc1t0aWNrZXQuc3RhdHVzXSB9LFxyXG4gICAgICAgICAgXX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgZ2FwLTMgc206ZmxleC1yb3dcIj5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e2dlbmVyYXRlUGF0aChST1VURVMucmVwYWlyRGV0YWlsLCB7IGlkOiB0aWNrZXQuaWQgfSl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXByaW1hcnlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIFZpZXcgcmVwYWlyXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxMaW5rIHRvPXtST1VURVMucmVwYWlyc30gY2xhc3NOYW1lPVwiYXV0aC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgIEJhY2sgdG8geW91ciByZXBhaXJzXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxMaW5rIHRvPXtST1VURVMucHJvZHVjdHN9IGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tZ2hvc3RcIj5cclxuICAgICAgICAgIENvbnRpbnVlIHNob3BwaW5nXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==