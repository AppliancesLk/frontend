import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Checkout/components/PaymentAction.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { formatCurrency } from "/src/utils/currency.ts";
import { translations } from "/src/utils/translations.ts";
import { commerceText as c } from "/src/utils/commerceText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PaymentAction.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.checkout;
export function PaymentAction({ page }) {
	const retryable = page.paymentStatus === "FAILED" || page.paymentStatus === "CANCELLED";
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "payment-heading",
		className: "rounded-md border border-line bg-surface p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				id: "payment-heading",
				className: "flex items-center gap-3 text-xl font-semibold text-fg",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "form-step-number",
					children: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this), c.method]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				className: "mt-5 space-y-3",
				disabled: page.locked,
				children: [/* @__PURE__ */ _jsxDEV("legend", {
					className: "sr-only",
					children: c.method
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this), ["CASH_ON_DELIVERY", "PAYHERE"].map((method) => /* @__PURE__ */ _jsxDEV("label", {
					className: `flex cursor-pointer items-start gap-3 rounded-md border p-4 ${page.paymentMethod === method ? "border-primary bg-primary-subtle" : "border-line"}`,
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "radio",
						name: "paymentMethod",
						value: method,
						checked: page.paymentMethod === method,
						onChange: () => page.changePaymentMethod(method),
						className: "mt-1 h-5 w-5 accent-primary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "block text-sm font-semibold",
						children: method === "CASH_ON_DELIVERY" ? c.cod : c.payHere
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "mt-1 block text-sm text-fg-secondary",
						children: method === "CASH_ON_DELIVERY" ? c.codDescription : c.payHereDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 13
					}, this)]
				}, method, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 11
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 border-t border-line pt-5",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-semibold",
						children: c.loyalty
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-xs leading-5 text-fg-muted",
						children: c.loyaltyDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 9
					}, this),
					page.loyaltyError ? /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						className: "mt-3 text-sm text-warning",
						children: page.loyaltyError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-3 text-sm",
							children: [
								c.loyaltyBalance,
								":",
								" ",
								/* @__PURE__ */ _jsxDEV("strong", { children: formatCurrency(page.loyalty?.balance ?? "0.00") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "mt-4 flex min-h-11 items-center gap-3 text-sm",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: page.useCredit,
								onChange: (e) => page.toggleCredit(e.target.checked),
								disabled: page.locked || !page.loyalty || page.loyalty.balance === "0.00",
								className: "h-5 w-5 accent-primary"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 15
							}, this), c.useCredit]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this),
						page.useCredit && /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "loyalty-amount",
								className: "auth-label",
								children: c.creditAmount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "loyalty-amount",
								className: "ui-field",
								inputMode: "decimal",
								value: page.creditAmount,
								onChange: (e) => page.changeCredit(e.target.value),
								disabled: page.locked,
								maxLength: 31
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 7
			}, this),
			page.paymentMessage && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: `ui-alert mt-5 ${retryable ? "ui-tone-warning" : "ui-tone-info"}`,
				children: page.paymentMessage
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-5 flex flex-wrap justify-between gap-2 border-t border-line pt-4 text-lg font-semibold",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: c.amountDue }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: formatCurrency(page.amountDue) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-5 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void page.pay(),
					disabled: page.paying,
					className: "auth-primary min-h-12 flex-1",
					children: page.paying ? c.placingOrder : page.amountDue === "0.00" ? c.fullyCovered : page.paymentMethod === "CASH_ON_DELIVERY" ? c.placeOrder : retryable ? t.retryPayment : `Pay ${formatCurrency(page.amountDue)}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this), page.paymentStatus === "PENDING" && !page.paying && page.paymentMethod === "PAYHERE" && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void page.retryVerification(),
					className: "auth-secondary min-h-12",
					children: t.checkPaymentStatus
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 7
			}, this),
			page.paymentMethod === "PAYHERE" && /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-xs leading-5 text-fg-muted",
				children: t.backendVerificationNotice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = PaymentAction;
var _c;
$RefreshReg$(_c, "PaymentAction");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Checkout/components/PaymentAction.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PaymentAction.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PaymentAction.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Checkout/components/PaymentAction.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxnQkFBZ0IsU0FBUzs7O0FBRWxDLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxjQUFjLEVBQzVCLFFBR0M7Q0FDRCxNQUFNLFlBQ0osS0FBSyxrQkFBa0IsWUFBWSxLQUFLLGtCQUFrQjtDQUM1RCxPQUNFLHdCQUFDLFdBQUQ7RUFDRSxtQkFBZ0I7RUFDaEIsV0FBVTtZQUZaO0dBSUUsd0JBQUMsTUFBRDtJQUNFLElBQUc7SUFDSCxXQUFVO2NBRlosQ0FJRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFtQjtJQUFPOzs7O2NBQ3pDLEVBQUUsTUFDRDs7Ozs7O0dBQ0osd0JBQUMsWUFBRDtJQUFVLFdBQVU7SUFBaUIsVUFBVSxLQUFLO2NBQXBELENBQ0Usd0JBQUMsVUFBRDtLQUFRLFdBQVU7ZUFBVyxFQUFFO0lBQWU7Ozs7Y0FDNUMsQ0FBQyxvQkFBb0IsU0FBUyxDQUFDLENBQVcsS0FBSyxXQUMvQyx3QkFBQyxTQUFEO0tBRUUsV0FBVywrREFBK0QsS0FBSyxrQkFBa0IsU0FBUyxxQ0FBcUM7ZUFGakosQ0FJRSx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLE1BQUs7TUFDTCxPQUFPO01BQ1AsU0FBUyxLQUFLLGtCQUFrQjtNQUNoQyxnQkFBZ0IsS0FBSyxvQkFBb0IsTUFBTTtNQUMvQyxXQUFVO0tBQ1g7Ozs7ZUFDRCx3QkFBQyxRQUFELGFBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQ2IsV0FBVyxxQkFBcUIsRUFBRSxNQUFNLEVBQUU7S0FDdkM7Ozs7ZUFDTix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFDYixXQUFXLHFCQUNSLEVBQUUsaUJBQ0YsRUFBRTtLQUNGOzs7O2FBQ0Y7Ozs7YUFDRDtPQXJCQTs7OztXQXFCQSxDQUNSLENBQ087Ozs7OztHQUNWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBaUIsRUFBRTtLQUFZOzs7OztLQUM3Qyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixFQUFFO0tBQ0Y7Ozs7O0tBQ0YsS0FBSyxlQUNKLHdCQUFDLEtBQUQ7TUFBRyxNQUFLO01BQVMsV0FBVTtnQkFDeEIsS0FBSztLQUNMOzs7O2dCQUVIO01BQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFDRyxFQUFFO1FBQWU7UUFBRTtRQUNwQix3QkFBQyxVQUFELFlBQVMsZUFBZSxLQUFLLFNBQVMsV0FBVyxNQUFNLEVBQVU7Ozs7O09BQ2hFOzs7Ozs7TUFDSCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVMsS0FBSztRQUNkLFdBQVcsTUFBTSxLQUFLLGFBQWEsRUFBRSxPQUFPLE9BQU87UUFDbkQsVUFDRSxLQUFLLFVBQ0wsQ0FBQyxLQUFLLFdBQ04sS0FBSyxRQUFRLFlBQVk7UUFFM0IsV0FBVTtPQUNYOzs7O2lCQUNBLEVBQUUsU0FDRTs7Ozs7O01BQ04sS0FBSyxhQUNKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFNBQVE7UUFBaUIsV0FBVTtrQkFDdkMsRUFBRTtPQUNFOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxJQUFHO1FBQ0gsV0FBVTtRQUNWLFdBQVU7UUFDVixPQUFPLEtBQUs7UUFDWixXQUFXLE1BQU0sS0FBSyxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQ2pELFVBQVUsS0FBSztRQUNmLFdBQVc7T0FDWjs7OztlQUNFOzs7Ozs7S0FFUDs7Ozs7SUFFRDs7Ozs7O0dBQ0osS0FBSyxrQkFDSix3QkFBQyxLQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVcsaUJBQWlCLFlBQVksb0JBQW9CO2NBRTNELEtBQUs7R0FDTDs7Ozs7R0FFTCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiLENBQ0Usd0JBQUMsUUFBRCxZQUFPLEVBQUUsVUFBZ0I7Ozs7Y0FDekIsd0JBQUMsUUFBRCxZQUFPLGVBQWUsS0FBSyxTQUFTLEVBQVE7Ozs7WUFDM0M7Ozs7OztHQUNILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsS0FBSyxLQUFLLElBQUk7S0FDN0IsVUFBVSxLQUFLO0tBQ2YsV0FBVTtlQUVULEtBQUssU0FDRixFQUFFLGVBQ0YsS0FBSyxjQUFjLFNBQ2pCLEVBQUUsZUFDRixLQUFLLGtCQUFrQixxQkFDckIsRUFBRSxhQUNGLFlBQ0UsRUFBRSxlQUNGLE9BQU8sZUFBZSxLQUFLLFNBQVM7SUFDeEM7Ozs7Y0FDUCxLQUFLLGtCQUFrQixhQUN0QixDQUFDLEtBQUssVUFDTixLQUFLLGtCQUFrQixhQUNyQix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsS0FBSyxLQUFLLGtCQUFrQjtLQUMzQyxXQUFVO2VBRVQsRUFBRTtJQUNHOzs7O1lBRVQ7Ozs7OztHQUNKLEtBQUssa0JBQWtCLGFBQ3RCLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsRUFBRTtHQUNGOzs7OztFQUVFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQYXltZW50QWN0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgY29tbWVyY2VUZXh0IGFzIGMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9jb21tZXJjZVRleHQnO1xyXG5pbXBvcnQgdHlwZSB7IHVzZUNoZWNrb3V0UGFnZSB9IGZyb20gJy4uL2hvb2tzL3VzZUNoZWNrb3V0UGFnZSc7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuY2hlY2tvdXQ7XHJcbmV4cG9ydCBmdW5jdGlvbiBQYXltZW50QWN0aW9uKHtcclxuICBwYWdlLFxyXG59OiB7XHJcbiAgcGFnZTogUmV0dXJuVHlwZTx0eXBlb2YgdXNlQ2hlY2tvdXRQYWdlPjtcclxufSkge1xyXG4gIGNvbnN0IHJldHJ5YWJsZSA9XHJcbiAgICBwYWdlLnBheW1lbnRTdGF0dXMgPT09ICdGQUlMRUQnIHx8IHBhZ2UucGF5bWVudFN0YXR1cyA9PT0gJ0NBTkNFTExFRCc7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uXHJcbiAgICAgIGFyaWEtbGFiZWxsZWRieT1cInBheW1lbnQtaGVhZGluZ1wiXHJcbiAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IHNtOnAtNlwiXHJcbiAgICA+XHJcbiAgICAgIDxoMlxyXG4gICAgICAgIGlkPVwicGF5bWVudC1oZWFkaW5nXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiXHJcbiAgICAgID5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb3JtLXN0ZXAtbnVtYmVyXCI+Mjwvc3Bhbj5cclxuICAgICAgICB7Yy5tZXRob2R9XHJcbiAgICAgIDwvaDI+XHJcbiAgICAgIDxmaWVsZHNldCBjbGFzc05hbWU9XCJtdC01IHNwYWNlLXktM1wiIGRpc2FibGVkPXtwYWdlLmxvY2tlZH0+XHJcbiAgICAgICAgPGxlZ2VuZCBjbGFzc05hbWU9XCJzci1vbmx5XCI+e2MubWV0aG9kfTwvbGVnZW5kPlxyXG4gICAgICAgIHsoWydDQVNIX09OX0RFTElWRVJZJywgJ1BBWUhFUkUnXSBhcyBjb25zdCkubWFwKChtZXRob2QpID0+IChcclxuICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICBrZXk9e21ldGhvZH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBjdXJzb3ItcG9pbnRlciBpdGVtcy1zdGFydCBnYXAtMyByb3VuZGVkLW1kIGJvcmRlciBwLTQgJHtwYWdlLnBheW1lbnRNZXRob2QgPT09IG1ldGhvZCA/ICdib3JkZXItcHJpbWFyeSBiZy1wcmltYXJ5LXN1YnRsZScgOiAnYm9yZGVyLWxpbmUnfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgbmFtZT1cInBheW1lbnRNZXRob2RcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXttZXRob2R9XHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17cGFnZS5wYXltZW50TWV0aG9kID09PSBtZXRob2R9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHBhZ2UuY2hhbmdlUGF5bWVudE1ldGhvZChtZXRob2QpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgaC01IHctNSBhY2NlbnQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAge21ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknID8gYy5jb2QgOiBjLnBheUhlcmV9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdGV4dC1zbSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAge21ldGhvZCA9PT0gJ0NBU0hfT05fREVMSVZFUlknXHJcbiAgICAgICAgICAgICAgICAgID8gYy5jb2REZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgICAgICA6IGMucGF5SGVyZURlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICApKX1cclxuICAgICAgPC9maWVsZHNldD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJvcmRlci10IGJvcmRlci1saW5lIHB0LTVcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntjLmxveWFsdHl9PC9oMz5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgbGVhZGluZy01IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHtjLmxveWFsdHlEZXNjcmlwdGlvbn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAge3BhZ2UubG95YWx0eUVycm9yID8gKFxyXG4gICAgICAgICAgPHAgcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSB0ZXh0LXdhcm5pbmdcIj5cclxuICAgICAgICAgICAge3BhZ2UubG95YWx0eUVycm9yfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICB7Yy5sb3lhbHR5QmFsYW5jZX06eycgJ31cclxuICAgICAgICAgICAgICA8c3Ryb25nPntmb3JtYXRDdXJyZW5jeShwYWdlLmxveWFsdHk/LmJhbGFuY2UgPz8gJzAuMDAnKX08L3N0cm9uZz5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibXQtNCBmbGV4IG1pbi1oLTExIGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17cGFnZS51c2VDcmVkaXR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHBhZ2UudG9nZ2xlQ3JlZGl0KGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgICBwYWdlLmxvY2tlZCB8fFxyXG4gICAgICAgICAgICAgICAgICAhcGFnZS5sb3lhbHR5IHx8XHJcbiAgICAgICAgICAgICAgICAgIHBhZ2UubG95YWx0eS5iYWxhbmNlID09PSAnMC4wMCdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNSB3LTUgYWNjZW50LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2MudXNlQ3JlZGl0fVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICB7cGFnZS51c2VDcmVkaXQgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJsb3lhbHR5LWFtb3VudFwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgICAge2MuY3JlZGl0QW1vdW50fVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cImxveWFsdHktYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhZ2UuY3JlZGl0QW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHBhZ2UuY2hhbmdlQ3JlZGl0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UubG9ja2VkfVxyXG4gICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezMxfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7cGFnZS5wYXltZW50TWVzc2FnZSAmJiAoXHJcbiAgICAgICAgPHBcclxuICAgICAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgdWktYWxlcnQgbXQtNSAke3JldHJ5YWJsZSA/ICd1aS10b25lLXdhcm5pbmcnIDogJ3VpLXRvbmUtaW5mbyd9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7cGFnZS5wYXltZW50TWVzc2FnZX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTUgZmxleCBmbGV4LXdyYXAganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci10IGJvcmRlci1saW5lIHB0LTQgdGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgPHNwYW4+e2MuYW1vdW50RHVlfTwvc3Bhbj5cclxuICAgICAgICA8c3Bhbj57Zm9ybWF0Q3VycmVuY3kocGFnZS5hbW91bnREdWUpfTwvc3Bhbj5cclxuICAgICAgPC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgZmxleCBmbGV4LWNvbCBnYXAtMyBzbTpmbGV4LXJvd1wiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwYWdlLnBheSgpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UucGF5aW5nfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5IG1pbi1oLTEyIGZsZXgtMVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3BhZ2UucGF5aW5nXHJcbiAgICAgICAgICAgID8gYy5wbGFjaW5nT3JkZXJcclxuICAgICAgICAgICAgOiBwYWdlLmFtb3VudER1ZSA9PT0gJzAuMDAnXHJcbiAgICAgICAgICAgICAgPyBjLmZ1bGx5Q292ZXJlZFxyXG4gICAgICAgICAgICAgIDogcGFnZS5wYXltZW50TWV0aG9kID09PSAnQ0FTSF9PTl9ERUxJVkVSWSdcclxuICAgICAgICAgICAgICAgID8gYy5wbGFjZU9yZGVyXHJcbiAgICAgICAgICAgICAgICA6IHJldHJ5YWJsZVxyXG4gICAgICAgICAgICAgICAgICA/IHQucmV0cnlQYXltZW50XHJcbiAgICAgICAgICAgICAgICAgIDogYFBheSAke2Zvcm1hdEN1cnJlbmN5KHBhZ2UuYW1vdW50RHVlKX1gfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIHtwYWdlLnBheW1lbnRTdGF0dXMgPT09ICdQRU5ESU5HJyAmJlxyXG4gICAgICAgICAgIXBhZ2UucGF5aW5nICYmXHJcbiAgICAgICAgICBwYWdlLnBheW1lbnRNZXRob2QgPT09ICdQQVlIRVJFJyAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmV0cnlWZXJpZmljYXRpb24oKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeSBtaW4taC0xMlwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dC5jaGVja1BheW1lbnRTdGF0dXN9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtwYWdlLnBheW1lbnRNZXRob2QgPT09ICdQQVlIRVJFJyAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICB7dC5iYWNrZW5kVmVyaWZpY2F0aW9uTm90aWNlfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==