import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Cart/components/CartRecommendations.tsx");const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { useCartRecommendations } from "/src/pages/Customer/Cart/hooks/useCartRecommendations.ts";
import { generatePath, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { Icon } from "/src/components/common/Icon.tsx";
import { Rating } from "/src/components/common/Rating.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { formatCurrency } from "/src/utils/currency.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartRecommendations.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.cart;
export function CartRecommendations({ cart, busy, onAdd }) {
	_s();
	const { products, error, retry } = useCartRecommendations();
	const suggestions = products?.filter((product) => product.isActive && product.stockQty > 0 && !cart.items.some((item) => item.productId === product.productID)).slice(0, 4);
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "cart-suggestions",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-4 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				id: "cart-suggestions",
				className: "text-xl font-semibold text-fg",
				children: t.recommendations
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-1 text-sm text-fg-muted",
				children: t.recommendationsDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Link, {
				to: ROUTES.products,
				className: "flex items-center gap-2 text-sm font-medium text-fg-link",
				children: [t.viewAll, /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this), error ? /* @__PURE__ */ _jsxDEV("div", {
			role: "alert",
			className: "rounded-md border border-line bg-surface p-4 text-sm text-fg-secondary",
			children: [
				t.recommendationsError,
				" ",
				/* @__PURE__ */ _jsxDEV("button", {
					className: "font-medium text-fg-link underline",
					onClick: retry,
					children: translations.common.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 9
		}, this) : !products ? /* @__PURE__ */ _jsxDEV(LoadingState, {
			label: t.recommendationsLoading,
			compact: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 9
		}, this) : !suggestions?.length ? /* @__PURE__ */ _jsxDEV("p", {
			className: "text-sm text-fg-muted",
			children: t.recommendationsEmpty
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
			children: suggestions.map((product) => /* @__PURE__ */ _jsxDEV("article", {
				className: "flex min-w-0 items-center gap-3 sm:flex-col sm:items-stretch rounded-md border border-line bg-surface p-3",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: generatePath(ROUTES.productDetail, { id: product.productID }),
					className: "w-20 shrink-0 rounded-md bg-well p-2 sm:w-full",
					children: /* @__PURE__ */ _jsxDEV(ProductImage, {
						src: product.images[0],
						alt: product.name,
						className: "aspect-square w-full"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "line-clamp-2 text-sm font-medium text-fg",
							children: /* @__PURE__ */ _jsxDEV(Link, {
								to: generatePath(ROUTES.productDetail, { id: product.productID }),
								className: "hover:text-fg-link",
								children: product.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm font-semibold text-fg",
							children: formatCurrency(product.price)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex flex-wrap items-center justify-between gap-2",
							children: [(product.ratingCount ?? 0) > 0 && /* @__PURE__ */ _jsxDEV(Rating, {
								average: product.ratingAverage ?? 0,
								count: product.ratingCount ?? 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: busy,
								onClick: () => onAdd(product.productID),
								"aria-label": `${t.add}: ${product.name}`,
								className: "ml-auto flex min-h-11 w-11 items-center justify-center rounded-sm border border-line text-fg-link hover:bg-subtle ",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "cart" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 15
				}, this)]
			}, product.productID, true, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_s(CartRecommendations, "syKke9M2I+D5xxhJnXuWFRMIs9A=", false, function() {
	return [useCartRecommendations];
});
_c = CartRecommendations;
var _c;
$RefreshReg$(_c, "CartRecommendations");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Cart/components/CartRecommendations.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartRecommendations.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartRecommendations.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Cart/components/CartRecommendations.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyw4QkFBOEI7QUFDdkMsU0FBUyxjQUFjLFlBQVk7QUFFbkMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7Ozs7QUFDL0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLG9CQUFvQixFQUNsQyxNQUNBLE1BQ0EsU0FLQzs7Q0FDRCxNQUFNLEVBQUUsVUFBVSxPQUFPLFVBQVUsdUJBQXVCO0NBQzFELE1BQU0sY0FBYyxVQUNoQixRQUNDLFlBQ0MsUUFBUSxZQUNSLFFBQVEsV0FBVyxLQUNuQixDQUFDLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxjQUFjLFFBQVEsU0FBUyxDQUNuRSxDQUFDLENBQ0EsTUFBTSxHQUFHLENBQUM7Q0FDYixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxtQkFBZ0I7WUFBekIsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7SUFBSSxJQUFHO0lBQW1CLFdBQVU7Y0FDakMsRUFBRTtHQUNEOzs7O2FBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixFQUFFO0dBQ0Y7Ozs7V0FDQTs7OzthQUNMLHdCQUFDLE1BQUQ7SUFDRSxJQUFJLE9BQU87SUFDWCxXQUFVO2NBRlosQ0FJRyxFQUFFLFNBQ0gsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztZQUNoQjs7Ozs7V0FDSDs7Ozs7WUFDSixRQUNDLHdCQUFDLE9BQUQ7R0FDRSxNQUFLO0dBQ0wsV0FBVTthQUZaO0lBSUcsRUFBRTtJQUFzQjtJQUN6Qix3QkFBQyxVQUFEO0tBQ0UsV0FBVTtLQUNWLFNBQVM7ZUFFUixhQUFhLE9BQU87SUFDZjs7Ozs7R0FDTDs7Ozs7YUFDSCxDQUFDLFdBQ0gsd0JBQUMsY0FBRDtHQUFjLE9BQU8sRUFBRTtHQUF3QixTQUFTO0VBQU87Ozs7YUFDN0QsQ0FBQyxhQUFhLFNBQ2hCLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQXlCLEVBQUU7RUFBd0I7Ozs7YUFFaEUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixZQUFZLEtBQUssWUFDaEIsd0JBQUMsV0FBRDtJQUVFLFdBQVU7Y0FGWixDQUlFLHdCQUFDLE1BQUQ7S0FDRSxJQUFJLGFBQWEsT0FBTyxlQUFlLEVBQ3JDLElBQUksUUFBUSxVQUNkLENBQUM7S0FDRCxXQUFVO2VBRVYsd0JBQUMsY0FBRDtNQUNFLEtBQUssUUFBUSxPQUFPO01BQ3BCLEtBQUssUUFBUTtNQUNiLFdBQVU7S0FDWDs7Ozs7SUFDRzs7OztjQUNOLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWix3QkFBQyxNQUFEO1FBQ0UsSUFBSSxhQUFhLE9BQU8sZUFBZSxFQUNyQyxJQUFJLFFBQVEsVUFDZCxDQUFDO1FBQ0QsV0FBVTtrQkFFVCxRQUFRO09BQ0w7Ozs7O01BQ0o7Ozs7O01BQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsZUFBZSxRQUFRLEtBQUs7TUFDNUI7Ozs7O01BQ0gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsRUFDSSxRQUFRLGVBQWUsS0FBSyxLQUM1Qix3QkFBQyxRQUFEO1FBQ0UsU0FBUyxRQUFRLGlCQUFpQjtRQUNsQyxPQUFPLFFBQVEsZUFBZTtPQUMvQjs7OztpQkFFSCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixlQUFlLE1BQU0sUUFBUSxTQUFTO1FBQ3RDLGNBQVksR0FBRyxFQUFFLElBQUksSUFBSSxRQUFRO1FBQ2pDLFdBQVU7a0JBRVYsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7T0FDYjs7OztlQUNMOzs7Ozs7S0FDRjs7Ozs7WUFDRTtNQS9DRixRQUFROzs7O1VBK0NOLENBQ1Y7RUFDRTs7OztVQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDYXJ0UmVjb21tZW5kYXRpb25zLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMb2FkaW5nU3RhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlQ2FydFJlY29tbWVuZGF0aW9ucyB9IGZyb20gJy4uL2hvb2tzL3VzZUNhcnRSZWNvbW1lbmRhdGlvbnMnO1xyXG5pbXBvcnQgeyBnZW5lcmF0ZVBhdGgsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHR5cGUgeyBDYXJ0IH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvY2FydC50eXBlcyc7XHJcbmltcG9ydCB7IFByb2R1Y3RJbWFnZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1Byb2R1Y3RJbWFnZSc7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9JY29uJztcclxuaW1wb3J0IHsgUmF0aW5nIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmF0aW5nJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvY3VycmVuY3knO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmNhcnQ7XHJcbmV4cG9ydCBmdW5jdGlvbiBDYXJ0UmVjb21tZW5kYXRpb25zKHtcclxuICBjYXJ0LFxyXG4gIGJ1c3ksXHJcbiAgb25BZGQsXHJcbn06IHtcclxuICBjYXJ0OiBDYXJ0O1xyXG4gIGJ1c3k6IGJvb2xlYW47XHJcbiAgb25BZGQ6IChwcm9kdWN0SWQ6IHN0cmluZykgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHsgcHJvZHVjdHMsIGVycm9yLCByZXRyeSB9ID0gdXNlQ2FydFJlY29tbWVuZGF0aW9ucygpO1xyXG4gIGNvbnN0IHN1Z2dlc3Rpb25zID0gcHJvZHVjdHNcclxuICAgID8uZmlsdGVyKFxyXG4gICAgICAocHJvZHVjdCkgPT5cclxuICAgICAgICBwcm9kdWN0LmlzQWN0aXZlICYmXHJcbiAgICAgICAgcHJvZHVjdC5zdG9ja1F0eSA+IDAgJiZcclxuICAgICAgICAhY2FydC5pdGVtcy5zb21lKChpdGVtKSA9PiBpdGVtLnByb2R1Y3RJZCA9PT0gcHJvZHVjdC5wcm9kdWN0SUQpLFxyXG4gICAgKVxyXG4gICAgLnNsaWNlKDAsIDQpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJjYXJ0LXN1Z2dlc3Rpb25zXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMiBpZD1cImNhcnQtc3VnZ2VzdGlvbnNcIiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICB7dC5yZWNvbW1lbmRhdGlvbnN9XHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAge3QucmVjb21tZW5kYXRpb25zRGVzY3JpcHRpb259XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMucHJvZHVjdHN9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3Qudmlld0FsbH1cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIC8+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge2Vycm9yID8gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNCB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7dC5yZWNvbW1lbmRhdGlvbnNFcnJvcn17JyAnfVxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZnLWxpbmsgdW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgb25DbGljaz17cmV0cnl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLnJldHJ5fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAhcHJvZHVjdHMgPyAoXHJcbiAgICAgICAgPExvYWRpbmdTdGF0ZSBsYWJlbD17dC5yZWNvbW1lbmRhdGlvbnNMb2FkaW5nfSBjb21wYWN0PXt0cnVlfSAvPlxyXG4gICAgICApIDogIXN1Z2dlc3Rpb25zPy5sZW5ndGggPyAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+e3QucmVjb21tZW5kYXRpb25zRW1wdHl9PC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBzbTpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtM1wiPlxyXG4gICAgICAgICAge3N1Z2dlc3Rpb25zLm1hcCgocHJvZHVjdCkgPT4gKFxyXG4gICAgICAgICAgICA8YXJ0aWNsZVxyXG4gICAgICAgICAgICAgIGtleT17cHJvZHVjdC5wcm9kdWN0SUR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGl0ZW1zLWNlbnRlciBnYXAtMyBzbTpmbGV4LWNvbCBzbTppdGVtcy1zdHJldGNoIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC0zXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICB0bz17Z2VuZXJhdGVQYXRoKFJPVVRFUy5wcm9kdWN0RGV0YWlsLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBwcm9kdWN0LnByb2R1Y3RJRCxcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0yMCBzaHJpbmstMCByb3VuZGVkLW1kIGJnLXdlbGwgcC0yIHNtOnctZnVsbFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFByb2R1Y3RJbWFnZVxyXG4gICAgICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3QuaW1hZ2VzWzBdfVxyXG4gICAgICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QubmFtZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImxpbmUtY2xhbXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz17Z2VuZXJhdGVQYXRoKFJPVVRFUy5wcm9kdWN0RGV0YWlsLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZDogcHJvZHVjdC5wcm9kdWN0SUQsXHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1mZy1saW5rXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlKX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsocHJvZHVjdC5yYXRpbmdDb3VudCA/PyAwKSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxSYXRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2U9e3Byb2R1Y3QucmF0aW5nQXZlcmFnZSA/PyAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY291bnQ9e3Byb2R1Y3QucmF0aW5nQ291bnQgPz8gMH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25BZGQocHJvZHVjdC5wcm9kdWN0SUQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2Ake3QuYWRkfTogJHtwcm9kdWN0Lm5hbWV9YH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC1hdXRvIGZsZXggbWluLWgtMTEgdy0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLWxpbmUgdGV4dC1mZy1saW5rIGhvdmVyOmJnLXN1YnRsZSBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImNhcnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==