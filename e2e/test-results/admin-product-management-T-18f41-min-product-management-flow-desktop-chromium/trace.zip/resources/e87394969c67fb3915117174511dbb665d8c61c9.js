import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Auth/Forbidden/index.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/Forbidden/index.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export default function ForbiddenPage() {
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title text-fg",
				children: translations.auth.accessRestricted
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "my-4 text-fg-muted",
				children: translations.auth.accessDenied
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				className: "auth-primary",
				to: ROUTES.account,
				children: translations.auth.backToAccount
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = ForbiddenPage;
var _c;
$RefreshReg$(_c, "ForbiddenPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Auth/Forbidden/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/Forbidden/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/Forbidden/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Auth/Forbidden/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjs7O0FBQzdCLGVBQWUsU0FBUyxnQkFBZ0I7Q0FDdEMsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsYUFBYSxLQUFLO0dBQ2pCOzs7OztHQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXNCLGFBQWEsS0FBSztHQUFnQjs7Ozs7R0FDckUsd0JBQUMsTUFBRDtJQUFNLFdBQVU7SUFBZSxJQUFJLE9BQU87Y0FDdkMsYUFBYSxLQUFLO0dBQ2Y7Ozs7O0VBQ0Y7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGb3JiaWRkZW5QYWdlKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJweC00IHB5LTIwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIHRleHQtZmdcIj5cclxuICAgICAgICB7dHJhbnNsYXRpb25zLmF1dGguYWNjZXNzUmVzdHJpY3RlZH1cclxuICAgICAgPC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXktNCB0ZXh0LWZnLW11dGVkXCI+e3RyYW5zbGF0aW9ucy5hdXRoLmFjY2Vzc0RlbmllZH08L3A+XHJcbiAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImF1dGgtcHJpbWFyeVwiIHRvPXtST1VURVMuYWNjb3VudH0+XHJcbiAgICAgICAge3RyYW5zbGF0aW9ucy5hdXRoLmJhY2tUb0FjY291bnR9XHJcbiAgICAgIDwvTGluaz5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==