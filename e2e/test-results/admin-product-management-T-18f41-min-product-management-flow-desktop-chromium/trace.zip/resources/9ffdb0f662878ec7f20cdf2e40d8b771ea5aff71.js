import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { formatDate } from "/src/utils/date.ts";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { RepairStatusBadge } from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function RepairerRepairsTable({ repairs }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "overflow-hidden rounded-md border border-line bg-surface ",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "ui-table ui-card-table w-full",
				children: [/* @__PURE__ */ _jsxDEV("thead", {
					className: "border-b border-line bg-page",
					children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", {
							className: "px-6 py-3 text-left text-xs font-medium tracking-wider text-fg-secondary",
							children: "Reference"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "px-6 py-3 text-left text-xs font-medium tracking-wider text-fg-secondary",
							children: "Customer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "px-6 py-3 text-left text-xs font-medium tracking-wider text-fg-secondary",
							children: "Device"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "px-6 py-3 text-left text-xs font-medium tracking-wider text-fg-secondary",
							children: "Status"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "px-6 py-3 text-left text-xs font-medium tracking-wider text-fg-secondary",
							children: "Created"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "px-6 py-3 text-right text-xs font-medium tracking-wider text-fg-secondary",
							children: "Actions"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("tbody", {
					className: "divide-y divide-line",
					children: repairs.map((repair) => /* @__PURE__ */ _jsxDEV("tr", {
						className: "transition-colors hover:bg-page",
						children: [
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": "Reference",
								className: "xl:whitespace-nowrap px-6 py-4 text-sm font-medium text-fg",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: repair.reference
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 44,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": "Customer",
								className: "xl:whitespace-nowrap px-6 py-4 text-sm text-fg-secondary",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-medium",
										children: repair.customer.username
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 52,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-fg-muted",
										children: repair.customer.email
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 55,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 51,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": "Device",
								className: "xl:whitespace-nowrap px-6 py-4 text-sm text-fg-secondary",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-medium",
										children: repair.device.brand
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-fg-muted",
										children: [
											repair.device.model,
											" (",
											repair.device.deviceType,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 66,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 65,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": "Status",
								className: "xl:whitespace-nowrap px-6 py-4 text-sm",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status: repair.status }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": "Created",
								className: "xl:whitespace-nowrap px-6 py-4 text-sm text-fg-muted",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: formatDate(repair.createdAt)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								"data-label": "Actions",
								className: "xl:whitespace-nowrap px-6 py-4 text-right text-sm",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "ui-cell-value",
									children: /* @__PURE__ */ _jsxDEV(Link, {
										to: `/repairer/repairs/${repair.id}`,
										className: "font-medium text-fg-link hover:text-fg-link",
										children: "View Details"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 95,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 17
							}, this)
						]
					}, repair.id, true, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = RepairerRepairsTable;
var _c;
$RefreshReg$(_c, "RepairerRepairsTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZO0FBRXJCLFNBQVMseUJBQXlCOzs7QUFNbEMsT0FBTyxTQUFTLHFCQUFxQixFQUFFLFdBQXNDO0NBQzNFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWpCLENBQ0Usd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFDZix3QkFBQyxNQUFEO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTJFO01BRXJGOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUEyRTtNQUVyRjs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBMkU7TUFFckY7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTJFO01BRXJGOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUEyRTtNQUVyRjs7Ozs7TUFDSix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBNEU7TUFFdEY7Ozs7O0tBQ0Y7Ozs7O0lBQ0M7Ozs7Y0FDUCx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUNkLFFBQVEsS0FBSyxXQUNaLHdCQUFDLE1BQUQ7TUFBb0IsV0FBVTtnQkFBOUI7T0FDRSx3QkFBQyxNQUFEO1FBQ0UsY0FBWTtRQUNaLFdBQVU7a0JBRVYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWlCLE9BQU87UUFBZTs7Ozs7T0FDcEQ7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUNFLGNBQVk7UUFDWixXQUFVO2tCQUVWLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixPQUFPLFNBQVM7U0FDZDs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixPQUFPLFNBQVM7U0FDZDs7OztpQkFDRjs7Ozs7UUFDRjs7Ozs7T0FDSDs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQ0UsY0FBWTtRQUNaLFdBQVU7a0JBRVYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFlLE9BQU8sT0FBTztTQUFXOzs7O21CQUN2RCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNHLE9BQU8sT0FBTztXQUFNO1dBQUcsT0FBTyxPQUFPO1dBQVc7VUFDOUM7Ozs7O2lCQUNGOzs7OztRQUNGOzs7OztPQUNIOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFDRSxjQUFZO1FBQ1osV0FBVTtrQkFFVix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxtQkFBRCxFQUFtQixRQUFRLE9BQU8sT0FBUzs7Ozs7UUFDeEM7Ozs7O09BQ0g7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUNFLGNBQVk7UUFDWixXQUFVO2tCQUVWLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFdBQVcsT0FBTyxTQUFTO1FBQ3pCOzs7OztPQUNIOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFDRSxjQUFZO1FBQ1osV0FBVTtrQkFFVix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxNQUFEO1VBQ0UsSUFBSSxxQkFBcUIsT0FBTztVQUNoQyxXQUFVO29CQUNYO1NBRUs7Ozs7O1FBQ0g7Ozs7O09BQ0g7Ozs7O01BQ0Y7UUFoRUssT0FBTzs7OztZQWdFWixDQUNMO0lBQ0k7Ozs7WUFDRjs7Ozs7O0VBQ0o7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVwYWlyZXJSZXBhaXJzVGFibGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGZvcm1hdERhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9kYXRlJztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgdHlwZSB7IFJlcGFpcmVyUmVwYWlyVGlja2V0IH0gZnJvbSAnLi4vLi4vLi4vLi4vdHlwZXMvcmVwYWlyLnR5cGVzJztcclxuaW1wb3J0IHsgUmVwYWlyU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi8uLi8uLi9BZG1pbi9SZXBhaXJzL2NvbXBvbmVudHMvUmVwYWlyU3RhdHVzQmFkZ2UnO1xyXG5cclxuaW50ZXJmYWNlIFJlcGFpcmVyUmVwYWlyc1RhYmxlUHJvcHMge1xyXG4gIHJlcGFpcnM6IFJlcGFpcmVyUmVwYWlyVGlja2V0W107XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZXBhaXJlclJlcGFpcnNUYWJsZSh7IHJlcGFpcnMgfTogUmVwYWlyZXJSZXBhaXJzVGFibGVQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ1aS10YWJsZSB1aS1jYXJkLXRhYmxlIHctZnVsbFwiPlxyXG4gICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIGJnLXBhZ2VcIj5cclxuICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdHJhY2tpbmctd2lkZXIgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgIFJlZmVyZW5jZVxyXG4gICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0cmFja2luZy13aWRlciB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdHJhY2tpbmctd2lkZXIgdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgIERldmljZVxyXG4gICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0cmFja2luZy13aWRlciB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYWNraW5nLXdpZGVyIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICBDcmVhdGVkXHJcbiAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0cmFja2luZy13aWRlciB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgQWN0aW9uc1xyXG4gICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1saW5lXCI+XHJcbiAgICAgICAgICAgIHtyZXBhaXJzLm1hcCgocmVwYWlyKSA9PiAoXHJcbiAgICAgICAgICAgICAgPHRyIGtleT17cmVwYWlyLmlkfSBjbGFzc05hbWU9XCJ0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1wYWdlXCI+XHJcbiAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17J1JlZmVyZW5jZSd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInhsOndoaXRlc3BhY2Utbm93cmFwIHB4LTYgcHktNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmdcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj57cmVwYWlyLnJlZmVyZW5jZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17J0N1c3RvbWVyJ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwieGw6d2hpdGVzcGFjZS1ub3dyYXAgcHgtNiBweS00IHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVwYWlyLmN1c3RvbWVyLnVzZXJuYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JlcGFpci5jdXN0b21lci5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17J0RldmljZSd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInhsOndoaXRlc3BhY2Utbm93cmFwIHB4LTYgcHktNCB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57cmVwYWlyLmRldmljZS5icmFuZH08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVwYWlyLmRldmljZS5tb2RlbH0gKHtyZXBhaXIuZGV2aWNlLmRldmljZVR5cGV9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICBkYXRhLWxhYmVsPXsnU3RhdHVzJ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwieGw6d2hpdGVzcGFjZS1ub3dyYXAgcHgtNiBweS00IHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8UmVwYWlyU3RhdHVzQmFkZ2Ugc3RhdHVzPXtyZXBhaXIuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17J0NyZWF0ZWQnfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ4bDp3aGl0ZXNwYWNlLW5vd3JhcCBweC02IHB5LTQgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocmVwYWlyLmNyZWF0ZWRBdCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICBkYXRhLWxhYmVsPXsnQWN0aW9ucyd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInhsOndoaXRlc3BhY2Utbm93cmFwIHB4LTYgcHktNCB0ZXh0LXJpZ2h0IHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgdG89e2AvcmVwYWlyZXIvcmVwYWlycy8ke3JlcGFpci5pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mZy1saW5rIGhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVmlldyBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgIDwvdGFibGU+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=