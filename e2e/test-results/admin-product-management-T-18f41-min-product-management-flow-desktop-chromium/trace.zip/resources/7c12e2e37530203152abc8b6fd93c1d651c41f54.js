import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Repairs/Details/index.tsx");const useEffect = __vite__cjsImport4_react["useEffect"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import { RatingPlate } from "/src/components/common/RatingPlate.tsx";
import { CopyReference } from "/src/components/common/CopyReference.tsx";
import { formatDate } from "/src/utils/date.ts";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { useCustomerRepairDetails } from "/src/pages/Customer/Repairs/Details/hooks/useCustomerRepairDetails.ts";
import { RepairStatusBadge } from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
import { getStatusLabel } from "/src/utils/statusTransitions.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Details/index.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function CustomerRepairDetailsPage() {
	_s();
	const page = useCustomerRepairDetails();
	useEffect(() => {
		const previous = document.title;
		document.title = "Repair details | Appliances LK";
		return () => {
			document.title = previous;
		};
	}, []);
	if (page.loading) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto max-w-[1200px]",
				children: /* @__PURE__ */ _jsxDEV(LoadingState, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this);
	}
	if (page.error) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto max-w-[1200px]",
				children: /* @__PURE__ */ _jsxDEV("div", {
					role: "alert",
					className: "rounded-md border border-danger/25 bg-danger-bg p-8 text-center ",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "font-medium text-danger",
							children: "Repair not found"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm text-danger",
							children: page.error
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => void page.refresh(),
							className: "mt-4 auth-secondary",
							children: "Try again"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this);
	}
	if (!page.repair) {
		return null;
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "bg-page px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-[1200px] space-y-6",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: page.goBack,
							className: "mb-2 text-sm font-medium text-fg-link hover:text-fg-link",
							children: "← Back to your repairs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "ui-page-title text-fg",
							children: "Repair details"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 tabular-nums text-sm text-fg-muted",
							children: page.repair.reference
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => void page.refresh(),
						className: "auth-secondary",
						children: "Refresh"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(RatingPlate, {
					title: page.repair.reference,
					rows: [
						{
							label: "Reference",
							value: /* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-2",
								children: [page.repair.reference, /* @__PURE__ */ _jsxDEV(CopyReference, { value: page.repair.reference }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 17
							}, this)
						},
						{
							label: "Device",
							value: `${page.repair.device.brand} ${page.repair.device.model}`
						},
						{
							label: "Serial number",
							value: page.repair.device.serialNumber || "Not provided"
						},
						{
							label: "Submitted",
							value: formatDate(page.repair.createdAt)
						}
					]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-6 lg:grid-cols-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-md border border-line bg-surface p-6 ",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-semibold text-fg",
							children: "Current status"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ _jsxDEV(RepairStatusBadge, { status: page.repair.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-3 text-sm text-fg-secondary",
								children: getStatusDescription(page.repair.status)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-md border border-line bg-surface p-6 ",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-semibold text-fg",
							children: "Device information"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dl", {
							className: "mt-4 space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-sm font-medium text-fg-muted",
									children: "Type"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 text-sm text-fg",
									children: page.repair.device.deviceType
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-sm font-medium text-fg-muted",
									children: "Brand"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 text-sm text-fg",
									children: page.repair.device.brand
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-sm font-medium text-fg-muted",
									children: "Model"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 text-sm text-fg",
									children: page.repair.device.model
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 15
								}, this),
								page.repair.device.serialNumber && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-sm font-medium text-fg-muted",
									children: "Serial Number"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 tabular-nums text-sm text-fg",
									children: page.repair.device.serialNumber
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 17
								}, this),
								page.repair.device.purchaseDate && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
									className: "text-sm font-medium text-fg-muted",
									children: "Purchase Date"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("dd", {
									className: "mt-1 text-sm text-fg",
									children: new Date(page.repair.device.purchaseDate).toLocaleDateString()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: "Problem Description"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-4 whitespace-pre-wrap text-sm text-fg-secondary",
						children: page.repair.problemDescription
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 167,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: "Repair Timeline"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 175,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary-subtle",
									children: /* @__PURE__ */ _jsxDEV("svg", {
										className: "h-4 w-4 text-fg-link",
										fill: "currentColor",
										viewBox: "0 0 20 20",
										children: /* @__PURE__ */ _jsxDEV("path", {
											fillRule: "evenodd",
											d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
											clipRule: "evenodd"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 184,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-fg",
										children: "Repair Submitted"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-fg-muted",
										children: formatDate(page.repair.createdAt)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 13
							}, this),
							page.repair.reviewedAt && /* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary-subtle",
									children: /* @__PURE__ */ _jsxDEV("svg", {
										className: "h-4 w-4 text-fg-link",
										fill: "currentColor",
										viewBox: "0 0 20 20",
										children: /* @__PURE__ */ _jsxDEV("path", {
											fillRule: "evenodd",
											d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
											clipRule: "evenodd"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 207,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-fg",
										children: "Reviewed by Admin"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-fg-muted",
										children: formatDate(page.repair.reviewedAt)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${[
										"IN_PROGRESS",
										"AWAITING_PARTS",
										"READY_FOR_COLLECTION",
										"COMPLETED"
									].includes(page.repair.status) ? "bg-primary-subtle" : "bg-subtle"}`,
									children: [
										"IN_PROGRESS",
										"AWAITING_PARTS",
										"READY_FOR_COLLECTION",
										"COMPLETED"
									].includes(page.repair.status) ? /* @__PURE__ */ _jsxDEV("svg", {
										className: "h-4 w-4 text-fg-link",
										fill: "currentColor",
										viewBox: "0 0 20 20",
										children: /* @__PURE__ */ _jsxDEV("path", {
											fillRule: "evenodd",
											d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
											clipRule: "evenodd"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 249,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 244,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "h-2 w-2 rounded-full bg-sunken" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: `text-sm font-medium ${[
											"IN_PROGRESS",
											"AWAITING_PARTS",
											"READY_FOR_COLLECTION",
											"COMPLETED"
										].includes(page.repair.status) ? "text-fg" : "text-fg-muted"}`,
										children: "In repair"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 260,
										columnNumber: 17
									}, this), [
										"IN_PROGRESS",
										"AWAITING_PARTS",
										"READY_FOR_COLLECTION",
										"COMPLETED"
									].includes(page.repair.status) && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-fg-muted",
										children: ["Currently: ", getStatusLabel(page.repair.status)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 280,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${page.repair.status === "COMPLETED" ? "bg-success-bg" : "bg-subtle"}`,
									children: page.repair.status === "COMPLETED" ? /* @__PURE__ */ _jsxDEV("svg", {
										className: "h-4 w-4 text-success",
										fill: "currentColor",
										viewBox: "0 0 20 20",
										children: /* @__PURE__ */ _jsxDEV("path", {
											fillRule: "evenodd",
											d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
											clipRule: "evenodd"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 301,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "h-2 w-2 rounded-full bg-sunken" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 288,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: `text-sm font-medium ${page.repair.status === "COMPLETED" ? "text-fg" : "text-fg-muted"}`,
										children: "Repair completed"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 312,
										columnNumber: 17
									}, this), page.repair.status === "COMPLETED" && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-fg-muted",
										children: formatDate(page.repair.updatedAt)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 174,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md border border-line bg-surface p-6 ",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-fg",
						children: "Important information"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 space-y-3 text-sm text-fg-secondary",
						children: [
							/* @__PURE__ */ _jsxDEV("p", { children: [
								"• Your repair ticket reference is:",
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "tabular-nums font-medium",
									children: page.repair.reference
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "• Please keep this reference for any inquiries about your repair." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 13
							}, this),
							page.repair.status === "READY_FOR_COLLECTION" && /* @__PURE__ */ _jsxDEV("p", {
								className: "font-medium text-success",
								children: "• Your device is ready for collection! Please visit our service center."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 15
							}, this),
							page.repair.status === "PENDING" && /* @__PURE__ */ _jsxDEV("p", { children: "• Your repair request is pending admin review. We'll update the status soon." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 352,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 331,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
}
_s(CustomerRepairDetailsPage, "qLYmCC4Cj3FzbWACoif+SL6+O2U=", false, function() {
	return [useCustomerRepairDetails];
});
_c = CustomerRepairDetailsPage;
function getStatusDescription(status) {
	const descriptions = {
		PENDING: "Your repair request is under review. Our team will approve it shortly.",
		APPROVED: "Your repair has been approved and will be assigned to a technician soon.",
		REJECTED: "Unfortunately, your repair request has been rejected. Please contact support for more information.",
		ASSIGNED: "Your repair has been assigned to a technician and will begin shortly.",
		IN_PROGRESS: "Our technician is currently working on your device.",
		AWAITING_PARTS: "We are waiting for spare parts to arrive to complete your repair.",
		READY_FOR_COLLECTION: "Great news! Your repair is complete and ready for collection.",
		COMPLETED: "Your repair has been completed and your device has been collected.",
		CANCELLED: "This repair request has been cancelled."
	};
	return descriptions[status] || "Status information not available.";
}
var _c;
$RefreshReg$(_c, "CustomerRepairDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Repairs/Details/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Details/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Details/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Details/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxnQ0FBZ0M7QUFDekMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxzQkFBc0I7Ozs7QUFFL0IsZUFBZSxTQUFTLDRCQUE0Qjs7Q0FDbEQsTUFBTSxPQUFPLHlCQUF5QjtDQUV0QyxnQkFBZ0I7RUFDZCxNQUFNLFdBQVcsU0FBUztFQUMxQixTQUFTLFFBQVE7RUFDakIsYUFBYTtHQUNYLFNBQVMsUUFBUTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsSUFBSSxLQUFLLFNBQVM7RUFDaEIsT0FDRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUNkLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsY0FBRCxDQUFlOzs7OztHQUNaOzs7OztFQUNEOzs7OztDQUVWO0NBRUEsSUFBSSxLQUFLLE9BQU87RUFDZCxPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQ2Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7ZUFGWjtNQUlFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUEwQjtNQUFtQjs7Ozs7TUFDMUQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTRCLEtBQUs7TUFBUzs7Ozs7TUFDdkQsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxlQUFlLEtBQUssS0FBSyxRQUFRO09BQ2pDLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7Ozs7O0dBQ0Y7Ozs7O0VBQ0Q7Ozs7O0NBRVY7Q0FFQSxJQUFJLENBQUMsS0FBSyxRQUFRO0VBQ2hCLE9BQU87Q0FDVDtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFNBQVMsS0FBSztPQUNkLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7TUFDUix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBd0I7TUFBa0I7Ozs7O01BQ3hELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLEtBQUssT0FBTztNQUNaOzs7OztLQUNBOzs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxlQUFlLEtBQUssS0FBSyxRQUFRO01BQ2pDLFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7SUFFTCx3QkFBQyxhQUFEO0tBQ0UsT0FBTyxLQUFLLE9BQU87S0FDbkIsTUFBTTtNQUNKO09BQ0UsT0FBTztPQUNQLE9BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0csS0FBSyxPQUFPLFdBQ2Isd0JBQUMsZUFBRCxFQUFlLE9BQU8sS0FBSyxPQUFPLFVBQVk7Ozs7Z0JBQzFDOzs7Ozs7TUFFVjtNQUNBO09BQ0UsT0FBTztPQUNQLE9BQU8sR0FBRyxLQUFLLE9BQU8sT0FBTyxNQUFNLEdBQUcsS0FBSyxPQUFPLE9BQU87TUFDM0Q7TUFDQTtPQUNFLE9BQU87T0FDUCxPQUFPLEtBQUssT0FBTyxPQUFPLGdCQUFnQjtNQUM1QztNQUNBO09BQUUsT0FBTztPQUFhLE9BQU8sV0FBVyxLQUFLLE9BQU8sU0FBUztNQUFFO0tBQ2pFO0lBQ0Q7Ozs7O0lBQ0Qsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWdDO01BQWtCOzs7O2dCQUNoRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLG1CQUFELEVBQW1CLFFBQVEsS0FBSyxPQUFPLE9BQVM7Ozs7aUJBQ2hELHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLHFCQUFxQixLQUFLLE9BQU8sTUFBTTtPQUN2Qzs7OztlQUNBOzs7OztjQUNGOzs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWdDO01BRTFDOzs7O2dCQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFvQztRQUFROzs7O2tCQUMxRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxLQUFLLE9BQU8sT0FBTztRQUNsQjs7OztnQkFDRDs7Ozs7UUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9DO1FBQVM7Ozs7a0JBQzNELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLEtBQUssT0FBTyxPQUFPO1FBQ2xCOzs7O2dCQUNEOzs7OztRQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBb0M7UUFBUzs7OztrQkFDM0Qsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsS0FBSyxPQUFPLE9BQU87UUFDbEI7Ozs7Z0JBQ0Q7Ozs7O1FBQ0osS0FBSyxPQUFPLE9BQU8sZ0JBQ2xCLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBb0M7UUFFOUM7Ozs7a0JBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsS0FBSyxPQUFPLE9BQU87UUFDbEI7Ozs7Z0JBQ0Q7Ozs7O1FBRU4sS0FBSyxPQUFPLE9BQU8sZ0JBQ2xCLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBb0M7UUFFOUM7Ozs7a0JBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsSUFBSSxLQUNILEtBQUssT0FBTyxPQUFPLFlBQ3JCLENBQUMsQ0FBQyxtQkFBbUI7UUFDbkI7Ozs7Z0JBQ0Q7Ozs7O09BRUw7Ozs7O2NBQ0Q7Ozs7O2FBQ0Y7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZ0M7S0FBdUI7Ozs7ZUFDckUsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsS0FBSyxPQUFPO0tBQ1o7Ozs7YUFDQTs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFnQztLQUFtQjs7OztlQUNqRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRDtVQUNFLFdBQVU7VUFDVixNQUFLO1VBQ0wsU0FBUTtvQkFFUix3QkFBQyxRQUFEO1dBQ0UsVUFBUztXQUNULEdBQUU7V0FDRixVQUFTO1VBQ1Y7Ozs7O1NBQ0U7Ozs7O1FBQ0Y7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBOEI7U0FBbUI7Ozs7bUJBQzlELHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLFdBQVcsS0FBSyxPQUFPLFNBQVM7U0FDaEM7Ozs7aUJBQ0E7Ozs7O2dCQUNGOzs7Ozs7T0FFSixLQUFLLE9BQU8sY0FDWCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQ7VUFDRSxXQUFVO1VBQ1YsTUFBSztVQUNMLFNBQVE7b0JBRVIsd0JBQUMsUUFBRDtXQUNFLFVBQVM7V0FDVCxHQUFFO1dBQ0YsVUFBUztVQUNWOzs7OztTQUNFOzs7OztRQUNGOzs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThCO1NBRXhDOzs7O21CQUNILHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLFdBQVcsS0FBSyxPQUFPLFVBQVU7U0FDakM7Ozs7aUJBQ0E7Ozs7O2dCQUNGOzs7Ozs7T0FHUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FDRSxXQUFXLHVFQUNUO1VBQ0U7VUFDQTtVQUNBO1VBQ0E7U0FDRixDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU8sTUFBTSxJQUN6QixzQkFDQTttQkFHTDtVQUNDO1VBQ0E7VUFDQTtVQUNBO1NBQ0YsQ0FBQyxDQUFDLFNBQVMsS0FBSyxPQUFPLE1BQU0sSUFDM0Isd0JBQUMsT0FBRDtVQUNFLFdBQVU7VUFDVixNQUFLO1VBQ0wsU0FBUTtvQkFFUix3QkFBQyxRQUFEO1dBQ0UsVUFBUztXQUNULEdBQUU7V0FDRixVQUFTO1VBQ1Y7Ozs7O1NBQ0U7Ozs7b0JBRUwsd0JBQUMsT0FBRCxFQUFLLFdBQVUsaUNBQWtDOzs7OztRQUVoRDs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLEtBQUQ7VUFDRSxXQUFXLHVCQUNUO1dBQ0U7V0FDQTtXQUNBO1dBQ0E7VUFDRixDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU8sTUFBTSxJQUN6QixZQUNBO29CQUVQO1NBRUU7Ozs7bUJBQ0Y7VUFDQztVQUNBO1VBQ0E7VUFDQTtTQUNGLENBQUMsQ0FBQyxTQUFTLEtBQUssT0FBTyxNQUFNLEtBQzNCLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQXFDLGVBQ3ZCLGVBQWUsS0FBSyxPQUFPLE1BQU0sQ0FDNUM7Ozs7O2lCQUVGOzs7OztnQkFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQ0UsV0FBVyx1RUFDVCxLQUFLLE9BQU8sV0FBVyxjQUNuQixrQkFDQTttQkFHTCxLQUFLLE9BQU8sV0FBVyxjQUN0Qix3QkFBQyxPQUFEO1VBQ0UsV0FBVTtVQUNWLE1BQUs7VUFDTCxTQUFRO29CQUVSLHdCQUFDLFFBQUQ7V0FDRSxVQUFTO1dBQ1QsR0FBRTtXQUNGLFVBQVM7VUFDVjs7Ozs7U0FDRTs7OztvQkFFTCx3QkFBQyxPQUFELEVBQUssV0FBVSxpQ0FBa0M7Ozs7O1FBRWhEOzs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsS0FBRDtVQUNFLFdBQVcsdUJBQ1QsS0FBSyxPQUFPLFdBQVcsY0FDbkIsWUFDQTtvQkFFUDtTQUVFOzs7O21CQUNGLEtBQUssT0FBTyxXQUFXLGVBQ3RCLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLFdBQVcsS0FBSyxPQUFPLFNBQVM7U0FDaEM7Ozs7aUJBRUY7Ozs7O2dCQUNGOzs7Ozs7TUFDRjs7Ozs7YUFDRjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFnQztLQUUxQzs7OztlQUNKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsS0FBRDtRQUFHO1FBQ2tDO1FBQ25DLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEtBQUssT0FBTztRQUNUOzs7OztPQUNMOzs7OztPQUNILHdCQUFDLEtBQUQsWUFBRyxvRUFFQTs7Ozs7T0FDRixLQUFLLE9BQU8sV0FBVywwQkFDdEIsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTJCO09BR3JDOzs7OztPQUVKLEtBQUssT0FBTyxXQUFXLGFBQ3RCLHdCQUFDLEtBQUQsWUFBRywrRUFHQTs7Ozs7TUFFRjs7Ozs7YUFDRjs7Ozs7O0dBQ0Y7Ozs7OztDQUNEOzs7OztBQUVWOzs7OztBQUVBLFNBQVMscUJBQXFCLFFBQXdCO0NBQ3BELE1BQU0sZUFBdUM7RUFDM0MsU0FDRTtFQUNGLFVBQ0U7RUFDRixVQUNFO0VBQ0YsVUFDRTtFQUNGLGFBQWE7RUFDYixnQkFDRTtFQUNGLHNCQUNFO0VBQ0YsV0FDRTtFQUNGLFdBQVc7Q0FDYjtDQUVBLE9BQU8sYUFBYSxXQUFXO0FBQ2pDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSYXRpbmdQbGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JhdGluZ1BsYXRlJztcclxuaW1wb3J0IHsgQ29weVJlZmVyZW5jZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0NvcHlSZWZlcmVuY2UnO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUN1c3RvbWVyUmVwYWlyRGV0YWlscyB9IGZyb20gJy4vaG9va3MvdXNlQ3VzdG9tZXJSZXBhaXJEZXRhaWxzJztcclxuaW1wb3J0IHsgUmVwYWlyU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi8uLi8uLi9BZG1pbi9SZXBhaXJzL2NvbXBvbmVudHMvUmVwYWlyU3RhdHVzQmFkZ2UnO1xyXG5pbXBvcnQgeyBnZXRTdGF0dXNMYWJlbCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3N0YXR1c1RyYW5zaXRpb25zJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEN1c3RvbWVyUmVwYWlyRGV0YWlsc1BhZ2UoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZUN1c3RvbWVyUmVwYWlyRGV0YWlscygpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgcHJldmlvdXMgPSBkb2N1bWVudC50aXRsZTtcclxuICAgIGRvY3VtZW50LnRpdGxlID0gJ1JlcGFpciBkZXRhaWxzIHwgQXBwbGlhbmNlcyBMSyc7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC50aXRsZSA9IHByZXZpb3VzO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGlmIChwYWdlLmxvYWRpbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImJnLXBhZ2UgcHgtNCBweS02IHNtOnB4LTYgbWQ6cHktOCBsZzpweC04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LVsxMjAwcHhdXCI+XHJcbiAgICAgICAgICA8TG9hZGluZ1N0YXRlIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAocGFnZS5lcnJvcikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiYmctcGFnZSBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzEyMDBweF1cIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWRhbmdlci8yNSBiZy1kYW5nZXItYmcgcC04IHRleHQtY2VudGVyIFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZGFuZ2VyXCI+UmVwYWlyIG5vdCBmb3VuZDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZGFuZ2VyXCI+e3BhZ2UuZXJyb3J9PC9wPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwYWdlLnJlZnJlc2goKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IGF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFRyeSBhZ2FpblxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L21haW4+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKCFwYWdlLnJlcGFpcikge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYmctcGFnZSBweC00IHB5LTYgc206cHgtNiBtZDpweS04IGxnOnB4LThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LVsxMjAwcHhdIHNwYWNlLXktNlwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17cGFnZS5nb0JhY2t9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAg4oaQIEJhY2sgdG8geW91ciByZXBhaXJzXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+UmVwYWlyIGRldGFpbHM8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRhYnVsYXItbnVtcyB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIucmVmZXJlbmNlfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgcGFnZS5yZWZyZXNoKCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVmcmVzaFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxSYXRpbmdQbGF0ZVxyXG4gICAgICAgICAgdGl0bGU9e3BhZ2UucmVwYWlyLnJlZmVyZW5jZX1cclxuICAgICAgICAgIHJvd3M9e1tcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGxhYmVsOiAnUmVmZXJlbmNlJyxcclxuICAgICAgICAgICAgICB2YWx1ZTogKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLnJlZmVyZW5jZX1cclxuICAgICAgICAgICAgICAgICAgPENvcHlSZWZlcmVuY2UgdmFsdWU9e3BhZ2UucmVwYWlyLnJlZmVyZW5jZX0gLz5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgbGFiZWw6ICdEZXZpY2UnLFxyXG4gICAgICAgICAgICAgIHZhbHVlOiBgJHtwYWdlLnJlcGFpci5kZXZpY2UuYnJhbmR9ICR7cGFnZS5yZXBhaXIuZGV2aWNlLm1vZGVsfWAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBsYWJlbDogJ1NlcmlhbCBudW1iZXInLFxyXG4gICAgICAgICAgICAgIHZhbHVlOiBwYWdlLnJlcGFpci5kZXZpY2Uuc2VyaWFsTnVtYmVyIHx8ICdOb3QgcHJvdmlkZWQnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7IGxhYmVsOiAnU3VibWl0dGVkJywgdmFsdWU6IGZvcm1hdERhdGUocGFnZS5yZXBhaXIuY3JlYXRlZEF0KSB9LFxyXG4gICAgICAgICAgXX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBsZzpncmlkLWNvbHMtMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+Q3VycmVudCBzdGF0dXM8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICA8UmVwYWlyU3RhdHVzQmFkZ2Ugc3RhdHVzPXtwYWdlLnJlcGFpci5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzRGVzY3JpcHRpb24ocGFnZS5yZXBhaXIuc3RhdHVzKX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgRGV2aWNlIGluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+VHlwZTwvZHQ+XHJcbiAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5kZXZpY2VUeXBlfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPkJyYW5kPC9kdD5cclxuICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuZGV2aWNlLmJyYW5kfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZy1tdXRlZFwiPk1vZGVsPC9kdD5cclxuICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuZGV2aWNlLm1vZGVsfVxyXG4gICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7cGFnZS5yZXBhaXIuZGV2aWNlLnNlcmlhbE51bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VyaWFsIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICA8L2R0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0YWJ1bGFyLW51bXMgdGV4dC1zbSB0ZXh0LWZnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLmRldmljZS5zZXJpYWxOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5kZXZpY2UucHVyY2hhc2VEYXRlICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBQdXJjaGFzZSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZ2UucmVwYWlyLmRldmljZS5wdXJjaGFzZURhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlByb2JsZW0gRGVzY3JpcHRpb248L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB3aGl0ZXNwYWNlLXByZS13cmFwIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAge3BhZ2UucmVwYWlyLnByb2JsZW1EZXNjcmlwdGlvbn1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlJlcGFpciBUaW1lbGluZTwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTggdy04IGZsZXgtc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1wcmltYXJ5LXN1YnRsZVwiPlxyXG4gICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZmctbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDIwIDIwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMTYuNzA3IDUuMjkzYTEgMSAwIDAxMCAxLjQxNGwtOCA4YTEgMSAwIDAxLTEuNDE0IDBsLTQtNGExIDEgMCAwMTEuNDE0LTEuNDE0TDggMTIuNTg2bDcuMjkzLTcuMjkzYTEgMSAwIDAxMS40MTQgMHpcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZnXCI+UmVwYWlyIFN1Ym1pdHRlZDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShwYWdlLnJlcGFpci5jcmVhdGVkQXQpfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtwYWdlLnJlcGFpci5yZXZpZXdlZEF0ICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTggdy04IGZsZXgtc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1wcmltYXJ5LXN1YnRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjAgMjBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTE2LjcwNyA1LjI5M2ExIDEgMCAwMTAgMS40MTRsLTggOGExIDEgMCAwMS0xLjQxNCAwbC00LTRhMSAxIDAgMDExLjQxNC0xLjQxNEw4IDEyLjU4Nmw3LjI5My03LjI5M2ExIDEgMCAwMTEuNDE0IDB6XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJldmlld2VkIGJ5IEFkbWluXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocGFnZS5yZXBhaXIucmV2aWV3ZWRBdCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBoLTggdy04IGZsZXgtc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCAke1xyXG4gICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgJ0lOX1BST0dSRVNTJyxcclxuICAgICAgICAgICAgICAgICAgICAnQVdBSVRJTkdfUEFSVFMnLFxyXG4gICAgICAgICAgICAgICAgICAgICdSRUFEWV9GT1JfQ09MTEVDVElPTicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0NPTVBMRVRFRCcsXHJcbiAgICAgICAgICAgICAgICAgIF0uaW5jbHVkZXMocGFnZS5yZXBhaXIuc3RhdHVzKVxyXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLXByaW1hcnktc3VidGxlJ1xyXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXN1YnRsZSdcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICdJTl9QUk9HUkVTUycsXHJcbiAgICAgICAgICAgICAgICAgICdBV0FJVElOR19QQVJUUycsXHJcbiAgICAgICAgICAgICAgICAgICdSRUFEWV9GT1JfQ09MTEVDVElPTicsXHJcbiAgICAgICAgICAgICAgICAgICdDT01QTEVURUQnLFxyXG4gICAgICAgICAgICAgICAgXS5pbmNsdWRlcyhwYWdlLnJlcGFpci5zdGF0dXMpID8gKFxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjAgMjBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTE2LjcwNyA1LjI5M2ExIDEgMCAwMTAgMS40MTRsLTggOGExIDEgMCAwMS0xLjQxNCAwbC00LTRhMSAxIDAgMDExLjQxNC0xLjQxNEw4IDEyLjU4Nmw3LjI5My03LjI5M2ExIDEgMCAwMTEuNDE0IDB6XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLXN1bmtlblwiIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbWVkaXVtICR7XHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgJ0lOX1BST0dSRVNTJyxcclxuICAgICAgICAgICAgICAgICAgICAgICdBV0FJVElOR19QQVJUUycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnUkVBRFlfRk9SX0NPTExFQ1RJT04nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ0NPTVBMRVRFRCcsXHJcbiAgICAgICAgICAgICAgICAgICAgXS5pbmNsdWRlcyhwYWdlLnJlcGFpci5zdGF0dXMpXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWZnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1mZy1tdXRlZCdcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEluIHJlcGFpclxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgJ0lOX1BST0dSRVNTJyxcclxuICAgICAgICAgICAgICAgICAgJ0FXQUlUSU5HX1BBUlRTJyxcclxuICAgICAgICAgICAgICAgICAgJ1JFQURZX0ZPUl9DT0xMRUNUSU9OJyxcclxuICAgICAgICAgICAgICAgICAgJ0NPTVBMRVRFRCcsXHJcbiAgICAgICAgICAgICAgICBdLmluY2x1ZGVzKHBhZ2UucmVwYWlyLnN0YXR1cykgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXJyZW50bHk6IHtnZXRTdGF0dXNMYWJlbChwYWdlLnJlcGFpci5zdGF0dXMpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaC04IHctOCBmbGV4LXNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgJHtcclxuICAgICAgICAgICAgICAgICAgcGFnZS5yZXBhaXIuc3RhdHVzID09PSAnQ09NUExFVEVEJ1xyXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLXN1Y2Nlc3MtYmcnXHJcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctc3VidGxlJ1xyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UucmVwYWlyLnN0YXR1cyA9PT0gJ0NPTVBMRVRFRCcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtc3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyMCAyMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTYuNzA3IDUuMjkzYTEgMSAwIDAxMCAxLjQxNGwtOCA4YTEgMSAwIDAxLTEuNDE0IDBsLTQtNGExIDEgMCAwMTEuNDE0LTEuNDE0TDggMTIuNTg2bDcuMjkzLTcuMjkzYTEgMSAwIDAxMS40MTQgMHpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctc3Vua2VuXCIgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tZWRpdW0gJHtcclxuICAgICAgICAgICAgICAgICAgICBwYWdlLnJlcGFpci5zdGF0dXMgPT09ICdDT01QTEVURUQnXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWZnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1mZy1tdXRlZCdcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFJlcGFpciBjb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5zdGF0dXMgPT09ICdDT01QTEVURUQnICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocGFnZS5yZXBhaXIudXBkYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNiBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgICBJbXBvcnRhbnQgaW5mb3JtYXRpb25cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0zIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAg4oCiIFlvdXIgcmVwYWlyIHRpY2tldCByZWZlcmVuY2UgaXM6eycgJ31cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YWJ1bGFyLW51bXMgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgIHtwYWdlLnJlcGFpci5yZWZlcmVuY2V9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIOKAoiBQbGVhc2Uga2VlcCB0aGlzIHJlZmVyZW5jZSBmb3IgYW55IGlucXVpcmllcyBhYm91dCB5b3VyIHJlcGFpci5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICB7cGFnZS5yZXBhaXIuc3RhdHVzID09PSAnUkVBRFlfRk9SX0NPTExFQ1RJT04nICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXN1Y2Nlc3NcIj5cclxuICAgICAgICAgICAgICAgIOKAoiBZb3VyIGRldmljZSBpcyByZWFkeSBmb3IgY29sbGVjdGlvbiEgUGxlYXNlIHZpc2l0IG91ciBzZXJ2aWNlXHJcbiAgICAgICAgICAgICAgICBjZW50ZXIuXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7cGFnZS5yZXBhaXIuc3RhdHVzID09PSAnUEVORElORycgJiYgKFxyXG4gICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAg4oCiIFlvdXIgcmVwYWlyIHJlcXVlc3QgaXMgcGVuZGluZyBhZG1pbiByZXZpZXcuIFdlJ2xsIHVwZGF0ZSB0aGVcclxuICAgICAgICAgICAgICAgIHN0YXR1cyBzb29uLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRTdGF0dXNEZXNjcmlwdGlvbihzdGF0dXM6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgY29uc3QgZGVzY3JpcHRpb25zOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gICAgUEVORElORzpcclxuICAgICAgJ1lvdXIgcmVwYWlyIHJlcXVlc3QgaXMgdW5kZXIgcmV2aWV3LiBPdXIgdGVhbSB3aWxsIGFwcHJvdmUgaXQgc2hvcnRseS4nLFxyXG4gICAgQVBQUk9WRUQ6XHJcbiAgICAgICdZb3VyIHJlcGFpciBoYXMgYmVlbiBhcHByb3ZlZCBhbmQgd2lsbCBiZSBhc3NpZ25lZCB0byBhIHRlY2huaWNpYW4gc29vbi4nLFxyXG4gICAgUkVKRUNURUQ6XHJcbiAgICAgICdVbmZvcnR1bmF0ZWx5LCB5b3VyIHJlcGFpciByZXF1ZXN0IGhhcyBiZWVuIHJlamVjdGVkLiBQbGVhc2UgY29udGFjdCBzdXBwb3J0IGZvciBtb3JlIGluZm9ybWF0aW9uLicsXHJcbiAgICBBU1NJR05FRDpcclxuICAgICAgJ1lvdXIgcmVwYWlyIGhhcyBiZWVuIGFzc2lnbmVkIHRvIGEgdGVjaG5pY2lhbiBhbmQgd2lsbCBiZWdpbiBzaG9ydGx5LicsXHJcbiAgICBJTl9QUk9HUkVTUzogJ091ciB0ZWNobmljaWFuIGlzIGN1cnJlbnRseSB3b3JraW5nIG9uIHlvdXIgZGV2aWNlLicsXHJcbiAgICBBV0FJVElOR19QQVJUUzpcclxuICAgICAgJ1dlIGFyZSB3YWl0aW5nIGZvciBzcGFyZSBwYXJ0cyB0byBhcnJpdmUgdG8gY29tcGxldGUgeW91ciByZXBhaXIuJyxcclxuICAgIFJFQURZX0ZPUl9DT0xMRUNUSU9OOlxyXG4gICAgICAnR3JlYXQgbmV3cyEgWW91ciByZXBhaXIgaXMgY29tcGxldGUgYW5kIHJlYWR5IGZvciBjb2xsZWN0aW9uLicsXHJcbiAgICBDT01QTEVURUQ6XHJcbiAgICAgICdZb3VyIHJlcGFpciBoYXMgYmVlbiBjb21wbGV0ZWQgYW5kIHlvdXIgZGV2aWNlIGhhcyBiZWVuIGNvbGxlY3RlZC4nLFxyXG4gICAgQ0FOQ0VMTEVEOiAnVGhpcyByZXBhaXIgcmVxdWVzdCBoYXMgYmVlbiBjYW5jZWxsZWQuJyxcclxuICB9O1xyXG5cclxuICByZXR1cm4gZGVzY3JpcHRpb25zW3N0YXR1c10gfHwgJ1N0YXR1cyBpbmZvcm1hdGlvbiBub3QgYXZhaWxhYmxlLic7XHJcbn1cclxuIl19