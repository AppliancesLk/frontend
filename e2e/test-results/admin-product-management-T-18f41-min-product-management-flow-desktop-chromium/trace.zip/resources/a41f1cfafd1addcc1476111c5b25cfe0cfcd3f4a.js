import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Home/index.tsx");const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport10_react_jsxDevRuntime["Fragment"];import { Link, generatePath } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { ProductGridSkeleton } from "/src/components/feedback/ProductGridSkeleton.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { useHomePage } from "/src/pages/Customer/Home/hooks/useHomePage.ts";
import { PromotionalBanner } from "/src/pages/Customer/Home/components/PromotionalBanner.tsx";
import { HomeProductSection } from "/src/pages/Customer/Home/components/HomeProductSection.tsx";
import { HomeCategorySection } from "/src/pages/Customer/Home/components/HomeCategorySection.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/index.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function HomePage() {
	_s();
	const { data, retry } = useHomePage();
	const heroProduct = data?.products.find((product) => product.images[0] && product.isActive) ?? data?.products[0];
	const banner = (position) => data?.banners.find((section) => section.position === position);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "home-page shell-wide",
		children: [
			/* @__PURE__ */ _jsxDEV(PromotionalBanner, { section: banner("top") }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			banner("top")?.visible ? /* @__PURE__ */ _jsxDEV("h1", {
				className: "sr-only",
				children: "Appliances and everyday technology"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("section", {
				className: "home-hero",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "hero-copy",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", { children: [
							"Made for your",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 28,
								columnNumber: 15
							}, this),
							"everyday."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Good technology makes life a little easier. Discover appliances and electronics for the way you live." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.products,
								className: "ui-button ui-button-primary",
								children: "Shop all products"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.repairRequest,
								className: "ui-button ui-button-secondary",
								children: "Repair a device"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 42,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hero-assurance",
							children: [
								/* @__PURE__ */ _jsxDEV(Icon, {
									name: "truck",
									className: "h-4 w-4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Islandwide delivery" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { className: "hero-assurance-dot" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Icon, {
									name: "chat",
									className: "h-4 w-4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Real people. Ready to help." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 54,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "hero-product-stage",
					children: heroProduct ? /* @__PURE__ */ _jsxDEV(Link, {
						className: "hero-product",
						to: generatePath(ROUTES.productDetail, { id: heroProduct.productID }),
						children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
							src: heroProduct.images[0],
							alt: heroProduct.name,
							eager: true,
							className: "hero-product-image"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "hero-product-label",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-fg-muted",
									children: heroProduct.brand || heroProduct.category.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 line-clamp-2 text-sm font-semibold",
									children: heroProduct.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "price shrink-0 text-sm font-semibold",
								children: formatCurrency(heroProduct.price)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "hero-placeholder",
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							name: "appliance",
							className: "h-32 w-32"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Something good for every home." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this),
			!data ? /* @__PURE__ */ _jsxDEV(ProductGridSkeleton, { count: 4 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				data.errors.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
					role: "alert",
					className: "ui-alert ui-tone-warning flex-wrap justify-between",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: Array.from(new Set(data.errors)).join(" ") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: retry,
						className: "font-semibold underline underline-offset-4",
						children: "Try again"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(HomeCategorySection, { categories: data.categories }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(HomeProductSection, {
					title: "Popular right now",
					products: data.products.slice(0, 8)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(PromotionalBanner, { section: banner("middle") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 11
				}, this),
				data.products.length > 8 && /* @__PURE__ */ _jsxDEV(HomeProductSection, {
					title: "More to make life easier",
					products: data.products.slice(8, 16)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "home-repair",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "repair-art",
							"aria-hidden": "true",
							children: /* @__PURE__ */ _jsxDEV(Icon, {
								name: "repair",
								className: "h-20 w-20"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: "A little care. A longer life." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Keep the devices you love working for longer. Tell us what’s wrong and follow your repair, from request to ready." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.repairRequest,
								className: "ui-button ui-button-primary mt-6",
								children: "Request a repair"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("ol", {
							className: "repair-steps",
							children: [
								/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "1" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 17
								}, this), "Tell us about your device"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 17
								}, this), "Get help from our team"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 17
								}, this), "Track your repair online"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(PromotionalBanner, { section: banner("bottom-one") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(PromotionalBanner, { section: banner("bottom-two") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 97,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_s(HomePage, "CdY1gA4oyC5uK8In4m9wwUzeC3g=", false, function() {
	return [useHomePage];
});
_c = HomePage;
var _c;
$RefreshReg$(_c, "HomePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Home/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Home/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQjtBQUNuQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsMkJBQTJCOzs7O0FBQ3BDLGVBQWUsU0FBUyxXQUFXOztDQUNqQyxNQUFNLEVBQUUsTUFBTSxVQUFVLFlBQVk7Q0FDcEMsTUFBTSxjQUNKLE1BQU0sU0FBUyxNQUFNLFlBQVksUUFBUSxPQUFPLE1BQU0sUUFBUSxRQUFRLEtBQ3RFLE1BQU0sU0FBUztDQUNqQixNQUFNLFVBQVUsYUFDZCxNQUFNLFFBQVEsTUFBTSxZQUFZLFFBQVEsYUFBYSxRQUFRO0NBQy9ELE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDRSx3QkFBQyxtQkFBRCxFQUFtQixTQUFTLE9BQU8sS0FBSyxFQUFJOzs7OztHQUMzQyxPQUFPLEtBQUssQ0FBQyxFQUFFLFVBQ2Qsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBVTtHQUFzQzs7OztjQUU5RCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxNQUFEO09BQUk7T0FFRix3QkFBQyxNQUFELENBQUs7Ozs7O09BQUM7TUFFSjs7Ozs7TUFDSix3QkFBQyxLQUFELFlBQUcsd0dBR0E7Ozs7O01BQ0gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPO1FBQ1gsV0FBVTtrQkFDWDtPQUVLOzs7O2lCQUNOLHdCQUFDLE1BQUQ7UUFDRSxJQUFJLE9BQU87UUFDWCxXQUFVO2tCQUNYO09BRUs7Ozs7ZUFDSDs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFEO1NBQU0sTUFBSztTQUFRLFdBQVU7UUFBVzs7Ozs7UUFDeEMsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7Ozs7UUFDL0Isd0JBQUMsUUFBRCxFQUFNLFdBQVUscUJBQXNCOzs7OztRQUN0Qyx3QkFBQyxNQUFEO1NBQU0sTUFBSztTQUFPLFdBQVU7UUFBVzs7Ozs7UUFDdkMsd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7Ozs7T0FDcEM7Ozs7OztLQUNGOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osY0FDQyx3QkFBQyxNQUFEO01BQ0UsV0FBVTtNQUNWLElBQUksYUFBYSxPQUFPLGVBQWUsRUFDckMsSUFBSSxZQUFZLFVBQ2xCLENBQUM7Z0JBSkgsQ0FNRSx3QkFBQyxjQUFEO09BQ0UsS0FBSyxZQUFZLE9BQU87T0FDeEIsS0FBSyxZQUFZO09BQ2pCO09BQ0EsV0FBVTtNQUNYOzs7O2dCQUNELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixZQUFZLFNBQVMsWUFBWSxTQUFTO1FBQzFDOzs7O2tCQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLFlBQVk7UUFDWjs7OztnQkFDQTs7Ozs7aUJBQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsZUFBZSxZQUFZLEtBQUs7T0FDaEM7Ozs7ZUFDQTs7Ozs7Y0FDRDs7Ozs7Z0JBRU4sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQU0sTUFBSztPQUFZLFdBQVU7TUFBYTs7OztnQkFDOUMsd0JBQUMsS0FBRCxZQUFHLGlDQUFpQzs7OztjQUNqQzs7Ozs7O0lBRUo7Ozs7WUFDRTs7Ozs7O0dBRVYsQ0FBQyxPQUNBLHdCQUFDLHFCQUFELEVBQXFCLE9BQU8sRUFBSTs7OztjQUVoQztJQUNHLEtBQUssT0FBTyxTQUFTLEtBQ3BCLHdCQUFDLE9BQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtlQUZaLENBSUUsd0JBQUMsS0FBRCxZQUFJLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFLOzs7O2VBQ2xELHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztJQUVQLHdCQUFDLHFCQUFELEVBQXFCLFlBQVksS0FBSyxXQUFhOzs7OztJQUNuRCx3QkFBQyxvQkFBRDtLQUNFLE9BQU07S0FDTixVQUFVLEtBQUssU0FBUyxNQUFNLEdBQUcsQ0FBQztJQUNuQzs7Ozs7SUFDRCx3QkFBQyxtQkFBRCxFQUFtQixTQUFTLE9BQU8sUUFBUSxFQUFJOzs7OztJQUM5QyxLQUFLLFNBQVMsU0FBUyxLQUN0Qix3QkFBQyxvQkFBRDtLQUNFLE9BQU07S0FDTixVQUFVLEtBQUssU0FBUyxNQUFNLEdBQUcsRUFBRTtJQUNwQzs7Ozs7SUFFSCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQWEsZUFBWTtpQkFDdEMsd0JBQUMsTUFBRDtRQUFNLE1BQUs7UUFBUyxXQUFVO09BQWE7Ozs7O01BQ3hDOzs7OztNQUNMLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxNQUFELFlBQUksZ0NBQWlDOzs7OztPQUNyQyx3QkFBQyxLQUFELFlBQUcsb0hBR0E7Ozs7O09BQ0gsd0JBQUMsTUFBRDtRQUNFLElBQUksT0FBTztRQUNYLFdBQVU7a0JBQ1g7T0FFSzs7Ozs7TUFDSDs7Ozs7TUFDTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztrQkFBQywyQkFDWjs7Ozs7UUFDSix3QkFBQyxNQUFELGFBQ0Usd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7a0JBQUMsd0JBQ1o7Ozs7O1FBQ0osd0JBQUMsTUFBRCxhQUNFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O2tCQUFDLDBCQUNaOzs7OztPQUNGOzs7Ozs7S0FDRzs7Ozs7O0lBQ1Qsd0JBQUMsbUJBQUQsRUFBbUIsU0FBUyxPQUFPLFlBQVksRUFBSTs7Ozs7SUFDbkQsd0JBQUMsbUJBQUQsRUFBbUIsU0FBUyxPQUFPLFlBQVksRUFBSTs7Ozs7R0FDbkQ7Ozs7O0VBRUE7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCBnZW5lcmF0ZVBhdGggfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUHJvZHVjdEltYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJvZHVjdEltYWdlJztcclxuaW1wb3J0IHsgUHJvZHVjdEdyaWRTa2VsZXRvbiB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvZmVlZGJhY2svUHJvZHVjdEdyaWRTa2VsZXRvbic7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50cy9yb3V0ZXMnO1xyXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSWNvbic7XHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY3VycmVuY3knO1xyXG5pbXBvcnQgeyB1c2VIb21lUGFnZSB9IGZyb20gJy4vaG9va3MvdXNlSG9tZVBhZ2UnO1xyXG5pbXBvcnQgeyBQcm9tb3Rpb25hbEJhbm5lciB9IGZyb20gJy4vY29tcG9uZW50cy9Qcm9tb3Rpb25hbEJhbm5lcic7XHJcbmltcG9ydCB7IEhvbWVQcm9kdWN0U2VjdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9Ib21lUHJvZHVjdFNlY3Rpb24nO1xyXG5pbXBvcnQgeyBIb21lQ2F0ZWdvcnlTZWN0aW9uIH0gZnJvbSAnLi9jb21wb25lbnRzL0hvbWVDYXRlZ29yeVNlY3Rpb24nO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lUGFnZSgpIHtcclxuICBjb25zdCB7IGRhdGEsIHJldHJ5IH0gPSB1c2VIb21lUGFnZSgpO1xyXG4gIGNvbnN0IGhlcm9Qcm9kdWN0ID1cclxuICAgIGRhdGE/LnByb2R1Y3RzLmZpbmQoKHByb2R1Y3QpID0+IHByb2R1Y3QuaW1hZ2VzWzBdICYmIHByb2R1Y3QuaXNBY3RpdmUpID8/XHJcbiAgICBkYXRhPy5wcm9kdWN0c1swXTtcclxuICBjb25zdCBiYW5uZXIgPSAocG9zaXRpb246IHN0cmluZykgPT5cclxuICAgIGRhdGE/LmJhbm5lcnMuZmluZCgoc2VjdGlvbikgPT4gc2VjdGlvbi5wb3NpdGlvbiA9PT0gcG9zaXRpb24pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJob21lLXBhZ2Ugc2hlbGwtd2lkZVwiPlxyXG4gICAgICA8UHJvbW90aW9uYWxCYW5uZXIgc2VjdGlvbj17YmFubmVyKCd0b3AnKX0gLz5cclxuICAgICAge2Jhbm5lcigndG9wJyk/LnZpc2libGUgPyAoXHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5BcHBsaWFuY2VzIGFuZCBldmVyeWRheSB0ZWNobm9sb2d5PC9oMT5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJob21lLWhlcm9cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1jb3B5XCI+XHJcbiAgICAgICAgICAgIDxoMT5cclxuICAgICAgICAgICAgICBNYWRlIGZvciB5b3VyXHJcbiAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgZXZlcnlkYXkuXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIEdvb2QgdGVjaG5vbG9neSBtYWtlcyBsaWZlIGEgbGl0dGxlIGVhc2llci4gRGlzY292ZXIgYXBwbGlhbmNlc1xyXG4gICAgICAgICAgICAgIGFuZCBlbGVjdHJvbmljcyBmb3IgdGhlIHdheSB5b3UgbGl2ZS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89e1JPVVRFUy5wcm9kdWN0c31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgU2hvcCBhbGwgcHJvZHVjdHNcclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPXtST1VURVMucmVwYWlyUmVxdWVzdH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBSZXBhaXIgYSBkZXZpY2VcclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tYXNzdXJhbmNlXCI+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cInRydWNrXCIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+SXNsYW5kd2lkZSBkZWxpdmVyeTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZXJvLWFzc3VyYW5jZS1kb3RcIiAvPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjaGF0XCIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+UmVhbCBwZW9wbGUuIFJlYWR5IHRvIGhlbHAuPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLXByb2R1Y3Qtc3RhZ2VcIj5cclxuICAgICAgICAgICAge2hlcm9Qcm9kdWN0ID8gKFxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvLXByb2R1Y3RcIlxyXG4gICAgICAgICAgICAgICAgdG89e2dlbmVyYXRlUGF0aChST1VURVMucHJvZHVjdERldGFpbCwge1xyXG4gICAgICAgICAgICAgICAgICBpZDogaGVyb1Byb2R1Y3QucHJvZHVjdElELFxyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFByb2R1Y3RJbWFnZVxyXG4gICAgICAgICAgICAgICAgICBzcmM9e2hlcm9Qcm9kdWN0LmltYWdlc1swXX1cclxuICAgICAgICAgICAgICAgICAgYWx0PXtoZXJvUHJvZHVjdC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBlYWdlclxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvLXByb2R1Y3QtaW1hZ2VcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1wcm9kdWN0LWxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2hlcm9Qcm9kdWN0LmJyYW5kIHx8IGhlcm9Qcm9kdWN0LmNhdGVnb3J5Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgbGluZS1jbGFtcC0yIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2hlcm9Qcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHJpY2Ugc2hyaW5rLTAgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGhlcm9Qcm9kdWN0LnByaWNlKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1wbGFjZWhvbGRlclwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImFwcGxpYW5jZVwiIGNsYXNzTmFtZT1cImgtMzIgdy0zMlwiIC8+XHJcbiAgICAgICAgICAgICAgICA8cD5Tb21ldGhpbmcgZ29vZCBmb3IgZXZlcnkgaG9tZS48L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICl9XHJcbiAgICAgIHshZGF0YSA/IChcclxuICAgICAgICA8UHJvZHVjdEdyaWRTa2VsZXRvbiBjb3VudD17NH0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAge2RhdGEuZXJyb3JzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1hbGVydCB1aS10b25lLXdhcm5pbmcgZmxleC13cmFwIGp1c3RpZnktYmV0d2VlblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8cD57QXJyYXkuZnJvbShuZXcgU2V0KGRhdGEuZXJyb3JzKSkuam9pbignICcpfTwvcD5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZXRyeX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVHJ5IGFnYWluXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxIb21lQ2F0ZWdvcnlTZWN0aW9uIGNhdGVnb3JpZXM9e2RhdGEuY2F0ZWdvcmllc30gLz5cclxuICAgICAgICAgIDxIb21lUHJvZHVjdFNlY3Rpb25cclxuICAgICAgICAgICAgdGl0bGU9XCJQb3B1bGFyIHJpZ2h0IG5vd1wiXHJcbiAgICAgICAgICAgIHByb2R1Y3RzPXtkYXRhLnByb2R1Y3RzLnNsaWNlKDAsIDgpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxQcm9tb3Rpb25hbEJhbm5lciBzZWN0aW9uPXtiYW5uZXIoJ21pZGRsZScpfSAvPlxyXG4gICAgICAgICAge2RhdGEucHJvZHVjdHMubGVuZ3RoID4gOCAmJiAoXHJcbiAgICAgICAgICAgIDxIb21lUHJvZHVjdFNlY3Rpb25cclxuICAgICAgICAgICAgICB0aXRsZT1cIk1vcmUgdG8gbWFrZSBsaWZlIGVhc2llclwiXHJcbiAgICAgICAgICAgICAgcHJvZHVjdHM9e2RhdGEucHJvZHVjdHMuc2xpY2UoOCwgMTYpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhvbWUtcmVwYWlyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwYWlyLWFydFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJyZXBhaXJcIiBjbGFzc05hbWU9XCJoLTIwIHctMjBcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDI+QSBsaXR0bGUgY2FyZS4gQSBsb25nZXIgbGlmZS48L2gyPlxyXG4gICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgS2VlcCB0aGUgZGV2aWNlcyB5b3UgbG92ZSB3b3JraW5nIGZvciBsb25nZXIuIFRlbGwgdXMgd2hhdOKAmXNcclxuICAgICAgICAgICAgICAgIHdyb25nIGFuZCBmb2xsb3cgeW91ciByZXBhaXIsIGZyb20gcmVxdWVzdCB0byByZWFkeS5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPXtST1VURVMucmVwYWlyUmVxdWVzdH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tcHJpbWFyeSBtdC02XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBSZXF1ZXN0IGEgcmVwYWlyXHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPG9sIGNsYXNzTmFtZT1cInJlcGFpci1zdGVwc1wiPlxyXG4gICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgIDxzcGFuPjE8L3NwYW4+VGVsbCB1cyBhYm91dCB5b3VyIGRldmljZVxyXG4gICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+Mjwvc3Bhbj5HZXQgaGVscCBmcm9tIG91ciB0ZWFtXHJcbiAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj4zPC9zcGFuPlRyYWNrIHlvdXIgcmVwYWlyIG9ubGluZVxyXG4gICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICA8UHJvbW90aW9uYWxCYW5uZXIgc2VjdGlvbj17YmFubmVyKCdib3R0b20tb25lJyl9IC8+XHJcbiAgICAgICAgICA8UHJvbW90aW9uYWxCYW5uZXIgc2VjdGlvbj17YmFubmVyKCdib3R0b20tdHdvJyl9IC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXX0=