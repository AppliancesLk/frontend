import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.productEdit;
export function UnsavedChangesDialog({ page }) {
	_s();
	const dialog = useRef(null);
	const blocked = page.blocker.state === "blocked";
	useEffect(() => {
		const element = dialog.current;
		if (blocked && !element?.open) element?.showModal();
		else if (!blocked && element?.open) element.close();
	}, [blocked]);
	function stay() {
		if (page.blocker.state === "blocked") page.blocker.reset();
	}
	return /* @__PURE__ */ _jsxDEV("dialog", {
		ref: dialog,
		"aria-labelledby": "unsaved-title",
		"aria-describedby": "unsaved-description",
		onCancel: (event) => {
			event.preventDefault();
			stay();
		},
		className: "ui-dialog",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				id: "unsaved-title",
				className: "text-xl font-semibold text-fg",
				children: page.busy ? t.savingTitle : t.unsavedTitle
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				id: "unsaved-description",
				className: "mt-3 text-sm leading-6 text-fg-muted",
				children: page.busy ? t.savingDescription : t.unsavedDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					autoFocus: true,
					className: "auth-primary",
					onClick: stay,
					children: t.keepEditing
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "auth-secondary ",
					disabled: page.busy,
					onClick: page.discard,
					children: t.discard
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 5
	}, this);
}
_s(UnsavedChangesDialog, "vRUw/VE3c/Q7nxFeTfUOgCM7JKY=");
_c = UnsavedChangesDialog;
var _c;
$RefreshReg$(_c, "UnsavedChangesDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Products/Edit/components/UnsavedChangesDialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGNBQWM7QUFFbEMsU0FBUyxvQkFBb0I7Ozs7QUFDN0IsTUFBTSxJQUFJLGFBQWE7QUFDdkIsT0FBTyxTQUFTLHFCQUFxQixFQUNuQyxRQUdDOztDQUNELE1BQU0sU0FBUyxPQUEwQixJQUFJO0NBQzdDLE1BQU0sVUFBVSxLQUFLLFFBQVEsVUFBVTtDQUN2QyxnQkFBZ0I7RUFDZCxNQUFNLFVBQVUsT0FBTztFQUN2QixJQUFJLFdBQVcsQ0FBQyxTQUFTLE1BQU0sU0FBUyxVQUFVO09BQzdDLElBQUksQ0FBQyxXQUFXLFNBQVMsTUFBTSxRQUFRLE1BQU07Q0FDcEQsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQUNaLFNBQVMsT0FBTztFQUNkLElBQUksS0FBSyxRQUFRLFVBQVUsV0FBVyxLQUFLLFFBQVEsTUFBTTtDQUMzRDtDQUNBLE9BQ0Usd0JBQUMsVUFBRDtFQUNFLEtBQUs7RUFDTCxtQkFBZ0I7RUFDaEIsb0JBQWlCO0VBQ2pCLFdBQVcsVUFBVTtHQUNuQixNQUFNLGVBQWU7R0FDckIsS0FBSztFQUNQO0VBQ0EsV0FBVTtZQVJaO0dBVUUsd0JBQUMsTUFBRDtJQUFJLElBQUc7SUFBZ0IsV0FBVTtjQUM5QixLQUFLLE9BQU8sRUFBRSxjQUFjLEVBQUU7R0FDN0I7Ozs7O0dBQ0osd0JBQUMsS0FBRDtJQUNFLElBQUc7SUFDSCxXQUFVO2NBRVQsS0FBSyxPQUFPLEVBQUUsb0JBQW9CLEVBQUU7R0FDcEM7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVM7S0FBVSxXQUFVO0tBQWUsU0FBUztlQUMvRCxFQUFFO0lBQ0c7Ozs7Y0FDUix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixVQUFVLEtBQUs7S0FDZixTQUFTLEtBQUs7ZUFFYixFQUFFO0lBQ0c7Ozs7WUFDTDs7Ozs7O0VBQ0M7Ozs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlVuc2F2ZWRDaGFuZ2VzRGlhbG9nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHR5cGUgeyB1c2VQcm9kdWN0RWRpdCB9IGZyb20gJy4uL2hvb2tzL3VzZVByb2R1Y3RFZGl0JztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5wcm9kdWN0RWRpdDtcclxuZXhwb3J0IGZ1bmN0aW9uIFVuc2F2ZWRDaGFuZ2VzRGlhbG9nKHtcclxuICBwYWdlLFxyXG59OiB7XHJcbiAgcGFnZTogUmV0dXJuVHlwZTx0eXBlb2YgdXNlUHJvZHVjdEVkaXQ+O1xyXG59KSB7XHJcbiAgY29uc3QgZGlhbG9nID0gdXNlUmVmPEhUTUxEaWFsb2dFbGVtZW50PihudWxsKTtcclxuICBjb25zdCBibG9ja2VkID0gcGFnZS5ibG9ja2VyLnN0YXRlID09PSAnYmxvY2tlZCc7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGVsZW1lbnQgPSBkaWFsb2cuY3VycmVudDtcclxuICAgIGlmIChibG9ja2VkICYmICFlbGVtZW50Py5vcGVuKSBlbGVtZW50Py5zaG93TW9kYWwoKTtcclxuICAgIGVsc2UgaWYgKCFibG9ja2VkICYmIGVsZW1lbnQ/Lm9wZW4pIGVsZW1lbnQuY2xvc2UoKTtcclxuICB9LCBbYmxvY2tlZF0pO1xyXG4gIGZ1bmN0aW9uIHN0YXkoKSB7XHJcbiAgICBpZiAocGFnZS5ibG9ja2VyLnN0YXRlID09PSAnYmxvY2tlZCcpIHBhZ2UuYmxvY2tlci5yZXNldCgpO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPGRpYWxvZ1xyXG4gICAgICByZWY9e2RpYWxvZ31cclxuICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwidW5zYXZlZC10aXRsZVwiXHJcbiAgICAgIGFyaWEtZGVzY3JpYmVkYnk9XCJ1bnNhdmVkLWRlc2NyaXB0aW9uXCJcclxuICAgICAgb25DYW5jZWw9eyhldmVudCkgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgc3RheSgpO1xyXG4gICAgICB9fVxyXG4gICAgICBjbGFzc05hbWU9XCJ1aS1kaWFsb2dcIlxyXG4gICAgPlxyXG4gICAgICA8aDIgaWQ9XCJ1bnNhdmVkLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZmdcIj5cclxuICAgICAgICB7cGFnZS5idXN5ID8gdC5zYXZpbmdUaXRsZSA6IHQudW5zYXZlZFRpdGxlfVxyXG4gICAgICA8L2gyPlxyXG4gICAgICA8cFxyXG4gICAgICAgIGlkPVwidW5zYXZlZC1kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgPlxyXG4gICAgICAgIHtwYWdlLmJ1c3kgPyB0LnNhdmluZ0Rlc2NyaXB0aW9uIDogdC51bnNhdmVkRGVzY3JpcHRpb259XHJcbiAgICAgIDwvcD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggZmxleC13cmFwIGdhcC0zXCI+XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgYXV0b0ZvY3VzIGNsYXNzTmFtZT1cImF1dGgtcHJpbWFyeVwiIG9uQ2xpY2s9e3N0YXl9PlxyXG4gICAgICAgICAge3Qua2VlcEVkaXRpbmd9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeSBcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UuYnVzeX1cclxuICAgICAgICAgIG9uQ2xpY2s9e3BhZ2UuZGlzY2FyZH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7dC5kaXNjYXJkfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGlhbG9nPlxyXG4gICk7XHJcbn1cclxuIl19