import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/seasonal/SeasonalScene.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { SeasonalArtwork } from "/src/components/seasonal/SeasonalArtwork.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalScene.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
function SantaSleigh() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "season-sleigh season-animated",
		viewBox: "0 0 240 110",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M89 64c24-9 57-11 91-14",
				stroke: "#e6c776",
				strokeWidth: "1.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("g", {
				className: "season-reindeer season-animated",
				children: [
					/* @__PURE__ */ _jsxDEV("ellipse", {
						cx: "183",
						cy: "50",
						rx: "19",
						ry: "9",
						fill: "#a9784d"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("path", {
						d: "m193 47 8-18 9 3-4 21-13-6Z",
						fill: "#a9784d"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("ellipse", {
						cx: "210",
						cy: "31",
						rx: "10",
						ry: "6",
						fill: "#ba8b5b"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("circle", {
						cx: "218",
						cy: "30",
						r: "3",
						fill: "#d34b4b"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("circle", {
						cx: "211",
						cy: "28",
						r: "1.3",
						fill: "#25211e"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("path", {
						d: "m203 27-4-13m3 8-9-3m10 0 5-8m-35 43-10 15m15-13 1 16m14-17 9 13m-4-15 12 3m-42-8-9-7",
						stroke: "#c79966",
						strokeWidth: "3",
						strokeLinecap: "round"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("rect", {
				x: "36",
				y: "42",
				width: "18",
				height: "20",
				rx: "2",
				fill: "#527959"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M45 42v20m-9-13h18",
				stroke: "#edcf86",
				strokeWidth: "2"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M53 55c0-16 7-25 17-25s18 13 18 25H53Z",
				fill: "#b73947"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "70",
				cy: "25",
				r: "9",
				fill: "#f0c7a5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M60 27c1 19 18 18 20-1-6 5-14 5-20 1Z",
				fill: "#fff4df"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M60 19c0-15 20-20 25-8l-8 4-17 4Z",
				fill: "#bd3444"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "m59 19 19-4",
				stroke: "#fff4df",
				strokeWidth: "5",
				strokeLinecap: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "86",
				cy: "11",
				r: "4",
				fill: "#fff4df"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				className: "season-santa-wave season-animated",
				d: "m79 39 11-13 6 1",
				stroke: "#b73947",
				strokeWidth: "6",
				strokeLinecap: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M26 58h68c10 0 16-5 21-14-1 30-22 36-72 29L26 58Z",
				fill: "#aa3041",
				stroke: "#f0c878",
				strokeWidth: "2"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "m45 74-3 9m46-10 4 10M25 84h84c9 0 15-4 18-10",
				stroke: "#e6c776",
				strokeWidth: "3",
				strokeLinecap: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "m13 38 2 4 5 1-4 3 1 5-4-2-4 2 1-5-4-3 5-1 2-4Z",
				fill: "#f0dba3"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = SantaSleigh;
function NewYearLamp() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "season-lamp",
		viewBox: "0 0 80 130",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M40 46v54m-22 12h44M27 99h26l12 13H15l12-13Zm-7-65h40L49 49H31L20 34Z",
				stroke: "#e9c978",
				strokeWidth: "3",
				strokeLinejoin: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				className: "season-flame season-animated",
				d: "M40 9c12 14 12 22 0 26-10-5-10-12 0-26Z",
				fill: "#f6d179"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "M40 24c4 6 4 9 0 11-4-2-4-5 0-11Z",
				fill: "#fff1c5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "m35 5 5-4 5 4M28 119h24",
				stroke: "#e9c978",
				strokeWidth: "2",
				strokeLinecap: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 5
	}, this);
}
_c2 = NewYearLamp;
function EasterBunny() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "season-bunny season-animated",
		viewBox: "0 0 110 150",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ _jsxDEV("g", {
				className: "season-bunny-ears season-animated",
				children: [
					/* @__PURE__ */ _jsxDEV("ellipse", {
						cx: "39",
						cy: "35",
						rx: "11",
						ry: "30",
						transform: "rotate(-13 39 35)",
						fill: "#f2e8e3",
						stroke: "#d9c3c8",
						strokeWidth: "2"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("ellipse", {
						cx: "66",
						cy: "35",
						rx: "11",
						ry: "30",
						transform: "rotate(12 66 35)",
						fill: "#f2e8e3",
						stroke: "#d9c3c8",
						strokeWidth: "2"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("path", {
						d: "m36 16 6 33m27-32-6 32",
						stroke: "#dcaabd",
						strokeWidth: "6",
						strokeLinecap: "round"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ellipse", {
				cx: "54",
				cy: "111",
				rx: "30",
				ry: "31",
				fill: "#e8dedc"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "82",
				cy: "119",
				r: "12",
				fill: "#fff5ec"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ellipse", {
				cx: "53",
				cy: "77",
				rx: "31",
				ry: "27",
				fill: "#f8eee6"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "42",
				cy: "74",
				r: "2.8",
				fill: "#514555"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "64",
				cy: "74",
				r: "2.8",
				fill: "#514555"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "m49 83 4 4 4-4h-8Zm4 4v6m-6 0c4 4 8 4 12 0",
				stroke: "#ad718a",
				strokeWidth: "2",
				strokeLinecap: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("path", {
				d: "m35 86-16-3m16 9-16 3m52-9 16-3m-16 9 16 3",
				stroke: "#c8aab3",
				strokeWidth: "1.5",
				strokeLinecap: "round"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ellipse", {
				cx: "36",
				cy: "137",
				rx: "16",
				ry: "7",
				fill: "#f8eee6"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ellipse", {
				cx: "66",
				cy: "137",
				rx: "16",
				ry: "7",
				fill: "#f8eee6"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 153,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 100,
		columnNumber: 5
	}, this);
}
_c3 = EasterBunny;
export function SeasonalScene({ theme }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "season-scene",
		"data-scene": theme,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "season-scene-orbit" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SeasonalArtwork, {
				theme,
				className: "season-greeting-art"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 162,
				columnNumber: 7
			}, this),
			theme === "CHRISTMAS" && /* @__PURE__ */ _jsxDEV("div", {
				className: "season-sleigh-track",
				children: /* @__PURE__ */ _jsxDEV(SantaSleigh, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 164,
				columnNumber: 9
			}, this),
			theme === "AVURUDU" && /* @__PURE__ */ _jsxDEV(NewYearLamp, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 31
			}, this),
			theme === "HALLOWEEN" && /* @__PURE__ */ _jsxDEV("svg", {
				className: "season-mist season-animated",
				viewBox: "0 0 300 70",
				fill: "none",
				focusable: "false",
				children: /* @__PURE__ */ _jsxDEV("path", {
					d: "M0 30c35-25 60 25 100 0s65 20 105 0 70 20 100 0M-30 52c35-25 60 25 100 0s65 20 105 0 70 20 100 0",
					stroke: "#d4c5d9",
					strokeOpacity: ".2",
					strokeWidth: "6",
					strokeLinecap: "round"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 176,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 9
			}, this),
			theme === "EASTER" && /* @__PURE__ */ _jsxDEV(EasterBunny, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 30
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 160,
		columnNumber: 5
	}, this);
}
_c4 = SeasonalScene;
export function SeasonalParticles({ theme }) {
	if (theme !== "CHRISTMAS" && theme !== "AVURUDU") return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `season-particles ${theme === "CHRISTMAS" ? "season-snow" : "season-petals"}`,
		"aria-hidden": "true",
		children: Array.from({ length: theme === "CHRISTMAS" ? 16 : 8 }, (_, i) => /* @__PURE__ */ _jsxDEV("span", {
			className: "season-particle season-animated",
			style: {
				left: `${(i * 37 + 7) % 100}%`,
				width: `${3 + i % 4}px`,
				height: `${3 + i % 4}px`,
				animationDuration: `${8 + i % 5}s`,
				animationDelay: `${-i * 1.7}s`
			}
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 198,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 193,
		columnNumber: 5
	}, this);
}
_c5 = SeasonalParticles;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "SantaSleigh");
$RefreshReg$(_c2, "NewYearLamp");
$RefreshReg$(_c3, "EasterBunny");
$RefreshReg$(_c4, "SeasonalScene");
$RefreshReg$(_c5, "SeasonalParticles");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/seasonal/SeasonalScene.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalScene.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalScene.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalScene.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyx1QkFBdUI7OztBQUVoQyxTQUFTLGNBQWM7Q0FDckIsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsV0FBVTtFQUNWLFNBQVE7RUFDUixNQUFLO0VBQ0wsZUFBWTtFQUNaLFdBQVU7WUFMWjtHQU9FLHdCQUFDLFFBQUQ7SUFBTSxHQUFFO0lBQTBCLFFBQU87SUFBVSxhQUFZO0dBQU87Ozs7O0dBQ3RFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWI7S0FDRSx3QkFBQyxXQUFEO01BQVMsSUFBRztNQUFNLElBQUc7TUFBSyxJQUFHO01BQUssSUFBRztNQUFJLE1BQUs7S0FBVzs7Ozs7S0FDekQsd0JBQUMsUUFBRDtNQUFNLEdBQUU7TUFBOEIsTUFBSztLQUFXOzs7OztLQUN0RCx3QkFBQyxXQUFEO01BQVMsSUFBRztNQUFNLElBQUc7TUFBSyxJQUFHO01BQUssSUFBRztNQUFJLE1BQUs7S0FBVzs7Ozs7S0FDekQsd0JBQUMsVUFBRDtNQUFRLElBQUc7TUFBTSxJQUFHO01BQUssR0FBRTtNQUFJLE1BQUs7S0FBVzs7Ozs7S0FDL0Msd0JBQUMsVUFBRDtNQUFRLElBQUc7TUFBTSxJQUFHO01BQUssR0FBRTtNQUFNLE1BQUs7S0FBVzs7Ozs7S0FDakQsd0JBQUMsUUFBRDtNQUNFLEdBQUU7TUFDRixRQUFPO01BQ1AsYUFBWTtNQUNaLGVBQWM7S0FDZjs7Ozs7SUFDQTs7Ozs7O0dBQ0gsd0JBQUMsUUFBRDtJQUFNLEdBQUU7SUFBSyxHQUFFO0lBQUssT0FBTTtJQUFLLFFBQU87SUFBSyxJQUFHO0lBQUksTUFBSztHQUFXOzs7OztHQUNsRSx3QkFBQyxRQUFEO0lBQU0sR0FBRTtJQUFxQixRQUFPO0lBQVUsYUFBWTtHQUFLOzs7OztHQUMvRCx3QkFBQyxRQUFEO0lBQU0sR0FBRTtJQUF5QyxNQUFLO0dBQVc7Ozs7O0dBQ2pFLHdCQUFDLFVBQUQ7SUFBUSxJQUFHO0lBQUssSUFBRztJQUFLLEdBQUU7SUFBSSxNQUFLO0dBQVc7Ozs7O0dBQzlDLHdCQUFDLFFBQUQ7SUFBTSxHQUFFO0lBQXdDLE1BQUs7R0FBVzs7Ozs7R0FDaEUsd0JBQUMsUUFBRDtJQUFNLEdBQUU7SUFBb0MsTUFBSztHQUFXOzs7OztHQUM1RCx3QkFBQyxRQUFEO0lBQ0UsR0FBRTtJQUNGLFFBQU87SUFDUCxhQUFZO0lBQ1osZUFBYztHQUNmOzs7OztHQUNELHdCQUFDLFVBQUQ7SUFBUSxJQUFHO0lBQUssSUFBRztJQUFLLEdBQUU7SUFBSSxNQUFLO0dBQVc7Ozs7O0dBQzlDLHdCQUFDLFFBQUQ7SUFDRSxXQUFVO0lBQ1YsR0FBRTtJQUNGLFFBQU87SUFDUCxhQUFZO0lBQ1osZUFBYztHQUNmOzs7OztHQUNELHdCQUFDLFFBQUQ7SUFDRSxHQUFFO0lBQ0YsTUFBSztJQUNMLFFBQU87SUFDUCxhQUFZO0dBQ2I7Ozs7O0dBQ0Qsd0JBQUMsUUFBRDtJQUNFLEdBQUU7SUFDRixRQUFPO0lBQ1AsYUFBWTtJQUNaLGVBQWM7R0FDZjs7Ozs7R0FDRCx3QkFBQyxRQUFEO0lBQ0UsR0FBRTtJQUNGLE1BQUs7R0FDTjs7Ozs7RUFDRTs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxjQUFjO0NBQ3JCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVU7RUFDVixTQUFRO0VBQ1IsTUFBSztFQUNMLGVBQVk7RUFDWixXQUFVO1lBTFo7R0FPRSx3QkFBQyxRQUFEO0lBQ0UsR0FBRTtJQUNGLFFBQU87SUFDUCxhQUFZO0lBQ1osZ0JBQWU7R0FDaEI7Ozs7O0dBQ0Qsd0JBQUMsUUFBRDtJQUNFLFdBQVU7SUFDVixHQUFFO0lBQ0YsTUFBSztHQUNOOzs7OztHQUNELHdCQUFDLFFBQUQ7SUFBTSxHQUFFO0lBQW9DLE1BQUs7R0FBVzs7Ozs7R0FDNUQsd0JBQUMsUUFBRDtJQUNFLEdBQUU7SUFDRixRQUFPO0lBQ1AsYUFBWTtJQUNaLGVBQWM7R0FDZjs7Ozs7RUFDRTs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxjQUFjO0NBQ3JCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVU7RUFDVixTQUFRO0VBQ1IsTUFBSztFQUNMLGVBQVk7RUFDWixXQUFVO1lBTFo7R0FPRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQ0Usd0JBQUMsV0FBRDtNQUNFLElBQUc7TUFDSCxJQUFHO01BQ0gsSUFBRztNQUNILElBQUc7TUFDSCxXQUFVO01BQ1YsTUFBSztNQUNMLFFBQU87TUFDUCxhQUFZO0tBQ2I7Ozs7O0tBQ0Qsd0JBQUMsV0FBRDtNQUNFLElBQUc7TUFDSCxJQUFHO01BQ0gsSUFBRztNQUNILElBQUc7TUFDSCxXQUFVO01BQ1YsTUFBSztNQUNMLFFBQU87TUFDUCxhQUFZO0tBQ2I7Ozs7O0tBQ0Qsd0JBQUMsUUFBRDtNQUNFLEdBQUU7TUFDRixRQUFPO01BQ1AsYUFBWTtNQUNaLGVBQWM7S0FDZjs7Ozs7SUFDQTs7Ozs7O0dBQ0gsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBSyxJQUFHO0lBQU0sSUFBRztJQUFLLElBQUc7SUFBSyxNQUFLO0dBQVc7Ozs7O0dBQzFELHdCQUFDLFVBQUQ7SUFBUSxJQUFHO0lBQUssSUFBRztJQUFNLEdBQUU7SUFBSyxNQUFLO0dBQVc7Ozs7O0dBQ2hELHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQUssSUFBRztJQUFLLElBQUc7SUFBSyxJQUFHO0lBQUssTUFBSztHQUFXOzs7OztHQUN6RCx3QkFBQyxVQUFEO0lBQVEsSUFBRztJQUFLLElBQUc7SUFBSyxHQUFFO0lBQU0sTUFBSztHQUFXOzs7OztHQUNoRCx3QkFBQyxVQUFEO0lBQVEsSUFBRztJQUFLLElBQUc7SUFBSyxHQUFFO0lBQU0sTUFBSztHQUFXOzs7OztHQUNoRCx3QkFBQyxRQUFEO0lBQ0UsR0FBRTtJQUNGLFFBQU87SUFDUCxhQUFZO0lBQ1osZUFBYztHQUNmOzs7OztHQUNELHdCQUFDLFFBQUQ7SUFDRSxHQUFFO0lBQ0YsUUFBTztJQUNQLGFBQVk7SUFDWixlQUFjO0dBQ2Y7Ozs7O0dBQ0Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBSyxJQUFHO0lBQU0sSUFBRztJQUFLLElBQUc7SUFBSSxNQUFLO0dBQVc7Ozs7O0dBQ3pELHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQUssSUFBRztJQUFNLElBQUc7SUFBSyxJQUFHO0lBQUksTUFBSztHQUFXOzs7OztFQUN0RDs7Ozs7O0FBRVQ7O0FBRUEsT0FBTyxTQUFTLGNBQWMsRUFBRSxTQUFtQztDQUNqRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQWUsY0FBWTtFQUFPLGVBQVk7WUFBN0Q7R0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSxxQkFBc0I7Ozs7O0dBQ3JDLHdCQUFDLGlCQUFEO0lBQXdCO0lBQU8sV0FBVTtHQUF1Qjs7Ozs7R0FDL0QsVUFBVSxlQUNULHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsYUFBRCxDQUFjOzs7OztHQUNYOzs7OztHQUVOLFVBQVUsYUFBYSx3QkFBQyxhQUFELENBQWM7Ozs7O0dBQ3JDLFVBQVUsZUFDVCx3QkFBQyxPQUFEO0lBQ0UsV0FBVTtJQUNWLFNBQVE7SUFDUixNQUFLO0lBQ0wsV0FBVTtjQUVWLHdCQUFDLFFBQUQ7S0FDRSxHQUFFO0tBQ0YsUUFBTztLQUNQLGVBQWM7S0FDZCxhQUFZO0tBQ1osZUFBYztJQUNmOzs7OztHQUNFOzs7OztHQUVOLFVBQVUsWUFBWSx3QkFBQyxhQUFELENBQWM7Ozs7O0VBQ2xDOzs7Ozs7QUFFVDs7QUFFQSxPQUFPLFNBQVMsa0JBQWtCLEVBQUUsU0FBbUM7Q0FDckUsSUFBSSxVQUFVLGVBQWUsVUFBVSxXQUFXLE9BQU87Q0FDekQsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsV0FBVyxvQkFBb0IsVUFBVSxjQUFjLGdCQUFnQjtFQUN2RSxlQUFZO1lBRVgsTUFBTSxLQUFLLEVBQUUsUUFBUSxVQUFVLGNBQWMsS0FBSyxFQUFFLElBQUksR0FBRyxNQUMxRCx3QkFBQyxRQUFEO0dBRUUsV0FBVTtHQUNWLE9BQU87SUFDTCxNQUFNLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSTtJQUM1QixPQUFPLEdBQUcsSUFBSyxJQUFJLEVBQUc7SUFDdEIsUUFBUSxHQUFHLElBQUssSUFBSSxFQUFHO0lBQ3ZCLG1CQUFtQixHQUFHLElBQUssSUFBSSxFQUFHO0lBQ2xDLGdCQUFnQixHQUFHLENBQUMsSUFBSSxJQUFJO0dBQzlCO0VBQ0QsR0FUTTs7OztTQVNOLENBQ0Y7Q0FDRTs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZWFzb25hbFNjZW5lLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFNlYXNvbmFsVGhlbWUgfSBmcm9tICcuLi8uLi90eXBlcy9zZWFzb25hbC10aGVtZS50eXBlcyc7XHJcbmltcG9ydCB7IFNlYXNvbmFsQXJ0d29yayB9IGZyb20gJy4vU2Vhc29uYWxBcnR3b3JrJztcclxuXHJcbmZ1bmN0aW9uIFNhbnRhU2xlaWdoKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIGNsYXNzTmFtZT1cInNlYXNvbi1zbGVpZ2ggc2Vhc29uLWFuaW1hdGVkXCJcclxuICAgICAgdmlld0JveD1cIjAgMCAyNDAgMTEwXCJcclxuICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICBmb2N1c2FibGU9XCJmYWxzZVwiXHJcbiAgICA+XHJcbiAgICAgIDxwYXRoIGQ9XCJNODkgNjRjMjQtOSA1Ny0xMSA5MS0xNFwiIHN0cm9rZT1cIiNlNmM3NzZcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XHJcbiAgICAgIDxnIGNsYXNzTmFtZT1cInNlYXNvbi1yZWluZGVlciBzZWFzb24tYW5pbWF0ZWRcIj5cclxuICAgICAgICA8ZWxsaXBzZSBjeD1cIjE4M1wiIGN5PVwiNTBcIiByeD1cIjE5XCIgcnk9XCI5XCIgZmlsbD1cIiNhOTc4NGRcIiAvPlxyXG4gICAgICAgIDxwYXRoIGQ9XCJtMTkzIDQ3IDgtMTggOSAzLTQgMjEtMTMtNlpcIiBmaWxsPVwiI2E5Nzg0ZFwiIC8+XHJcbiAgICAgICAgPGVsbGlwc2UgY3g9XCIyMTBcIiBjeT1cIjMxXCIgcng9XCIxMFwiIHJ5PVwiNlwiIGZpbGw9XCIjYmE4YjViXCIgLz5cclxuICAgICAgICA8Y2lyY2xlIGN4PVwiMjE4XCIgY3k9XCIzMFwiIHI9XCIzXCIgZmlsbD1cIiNkMzRiNGJcIiAvPlxyXG4gICAgICAgIDxjaXJjbGUgY3g9XCIyMTFcIiBjeT1cIjI4XCIgcj1cIjEuM1wiIGZpbGw9XCIjMjUyMTFlXCIgLz5cclxuICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgZD1cIm0yMDMgMjctNC0xM20zIDgtOS0zbTEwIDAgNS04bS0zNSA0My0xMCAxNW0xNS0xMyAxIDE2bTE0LTE3IDkgMTNtLTQtMTUgMTIgM20tNDItOC05LTdcIlxyXG4gICAgICAgICAgc3Ryb2tlPVwiI2M3OTk2NlwiXHJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjNcIlxyXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2c+XHJcbiAgICAgIDxyZWN0IHg9XCIzNlwiIHk9XCI0MlwiIHdpZHRoPVwiMThcIiBoZWlnaHQ9XCIyMFwiIHJ4PVwiMlwiIGZpbGw9XCIjNTI3OTU5XCIgLz5cclxuICAgICAgPHBhdGggZD1cIk00NSA0MnYyMG0tOS0xM2gxOFwiIHN0cm9rZT1cIiNlZGNmODZcIiBzdHJva2VXaWR0aD1cIjJcIiAvPlxyXG4gICAgICA8cGF0aCBkPVwiTTUzIDU1YzAtMTYgNy0yNSAxNy0yNXMxOCAxMyAxOCAyNUg1M1pcIiBmaWxsPVwiI2I3Mzk0N1wiIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9XCI3MFwiIGN5PVwiMjVcIiByPVwiOVwiIGZpbGw9XCIjZjBjN2E1XCIgLz5cclxuICAgICAgPHBhdGggZD1cIk02MCAyN2MxIDE5IDE4IDE4IDIwLTEtNiA1LTE0IDUtMjAgMVpcIiBmaWxsPVwiI2ZmZjRkZlwiIC8+XHJcbiAgICAgIDxwYXRoIGQ9XCJNNjAgMTljMC0xNSAyMC0yMCAyNS04bC04IDQtMTcgNFpcIiBmaWxsPVwiI2JkMzQ0NFwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIm01OSAxOSAxOS00XCJcclxuICAgICAgICBzdHJva2U9XCIjZmZmNGRmXCJcclxuICAgICAgICBzdHJva2VXaWR0aD1cIjVcIlxyXG4gICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9XCI4NlwiIGN5PVwiMTFcIiByPVwiNFwiIGZpbGw9XCIjZmZmNGRmXCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBjbGFzc05hbWU9XCJzZWFzb24tc2FudGEtd2F2ZSBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgIGQ9XCJtNzkgMzkgMTEtMTMgNiAxXCJcclxuICAgICAgICBzdHJva2U9XCIjYjczOTQ3XCJcclxuICAgICAgICBzdHJva2VXaWR0aD1cIjZcIlxyXG4gICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0yNiA1OGg2OGMxMCAwIDE2LTUgMjEtMTQtMSAzMC0yMiAzNi03MiAyOUwyNiA1OFpcIlxyXG4gICAgICAgIGZpbGw9XCIjYWEzMDQxXCJcclxuICAgICAgICBzdHJva2U9XCIjZjBjODc4XCJcclxuICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJtNDUgNzQtMyA5bTQ2LTEwIDQgMTBNMjUgODRoODRjOSAwIDE1LTQgMTgtMTBcIlxyXG4gICAgICAgIHN0cm9rZT1cIiNlNmM3NzZcIlxyXG4gICAgICAgIHN0cm9rZVdpZHRoPVwiM1wiXHJcbiAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwibTEzIDM4IDIgNCA1IDEtNCAzIDEgNS00LTItNCAyIDEtNS00LTMgNS0xIDItNFpcIlxyXG4gICAgICAgIGZpbGw9XCIjZjBkYmEzXCJcclxuICAgICAgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE5ld1llYXJMYW1wKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIGNsYXNzTmFtZT1cInNlYXNvbi1sYW1wXCJcclxuICAgICAgdmlld0JveD1cIjAgMCA4MCAxMzBcIlxyXG4gICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgIGZvY3VzYWJsZT1cImZhbHNlXCJcclxuICAgID5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTQwIDQ2djU0bS0yMiAxMmg0NE0yNyA5OWgyNmwxMiAxM0gxNWwxMi0xM1ptLTctNjVoNDBMNDkgNDlIMzFMMjAgMzRaXCJcclxuICAgICAgICBzdHJva2U9XCIjZTljOTc4XCJcclxuICAgICAgICBzdHJva2VXaWR0aD1cIjNcIlxyXG4gICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGNsYXNzTmFtZT1cInNlYXNvbi1mbGFtZSBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgIGQ9XCJNNDAgOWMxMiAxNCAxMiAyMiAwIDI2LTEwLTUtMTAtMTIgMC0yNlpcIlxyXG4gICAgICAgIGZpbGw9XCIjZjZkMTc5XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGggZD1cIk00MCAyNGM0IDYgNCA5IDAgMTEtNC0yLTQtNSAwLTExWlwiIGZpbGw9XCIjZmZmMWM1XCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwibTM1IDUgNS00IDUgNE0yOCAxMTloMjRcIlxyXG4gICAgICAgIHN0cm9rZT1cIiNlOWM5NzhcIlxyXG4gICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIEVhc3RlckJ1bm55KCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIGNsYXNzTmFtZT1cInNlYXNvbi1idW5ueSBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICB2aWV3Qm94PVwiMCAwIDExMCAxNTBcIlxyXG4gICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgIGZvY3VzYWJsZT1cImZhbHNlXCJcclxuICAgID5cclxuICAgICAgPGcgY2xhc3NOYW1lPVwic2Vhc29uLWJ1bm55LWVhcnMgc2Vhc29uLWFuaW1hdGVkXCI+XHJcbiAgICAgICAgPGVsbGlwc2VcclxuICAgICAgICAgIGN4PVwiMzlcIlxyXG4gICAgICAgICAgY3k9XCIzNVwiXHJcbiAgICAgICAgICByeD1cIjExXCJcclxuICAgICAgICAgIHJ5PVwiMzBcIlxyXG4gICAgICAgICAgdHJhbnNmb3JtPVwicm90YXRlKC0xMyAzOSAzNSlcIlxyXG4gICAgICAgICAgZmlsbD1cIiNmMmU4ZTNcIlxyXG4gICAgICAgICAgc3Ryb2tlPVwiI2Q5YzNjOFwiXHJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGVsbGlwc2VcclxuICAgICAgICAgIGN4PVwiNjZcIlxyXG4gICAgICAgICAgY3k9XCIzNVwiXHJcbiAgICAgICAgICByeD1cIjExXCJcclxuICAgICAgICAgIHJ5PVwiMzBcIlxyXG4gICAgICAgICAgdHJhbnNmb3JtPVwicm90YXRlKDEyIDY2IDM1KVwiXHJcbiAgICAgICAgICBmaWxsPVwiI2YyZThlM1wiXHJcbiAgICAgICAgICBzdHJva2U9XCIjZDljM2M4XCJcclxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgZD1cIm0zNiAxNiA2IDMzbTI3LTMyLTYgMzJcIlxyXG4gICAgICAgICAgc3Ryb2tlPVwiI2RjYWFiZFwiXHJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjZcIlxyXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2c+XHJcbiAgICAgIDxlbGxpcHNlIGN4PVwiNTRcIiBjeT1cIjExMVwiIHJ4PVwiMzBcIiByeT1cIjMxXCIgZmlsbD1cIiNlOGRlZGNcIiAvPlxyXG4gICAgICA8Y2lyY2xlIGN4PVwiODJcIiBjeT1cIjExOVwiIHI9XCIxMlwiIGZpbGw9XCIjZmZmNWVjXCIgLz5cclxuICAgICAgPGVsbGlwc2UgY3g9XCI1M1wiIGN5PVwiNzdcIiByeD1cIjMxXCIgcnk9XCIyN1wiIGZpbGw9XCIjZjhlZWU2XCIgLz5cclxuICAgICAgPGNpcmNsZSBjeD1cIjQyXCIgY3k9XCI3NFwiIHI9XCIyLjhcIiBmaWxsPVwiIzUxNDU1NVwiIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9XCI2NFwiIGN5PVwiNzRcIiByPVwiMi44XCIgZmlsbD1cIiM1MTQ1NTVcIiAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJtNDkgODMgNCA0IDQtNGgtOFptNCA0djZtLTYgMGM0IDQgOCA0IDEyIDBcIlxyXG4gICAgICAgIHN0cm9rZT1cIiNhZDcxOGFcIlxyXG4gICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwibTM1IDg2LTE2LTNtMTYgOS0xNiAzbTUyLTkgMTYtM20tMTYgOSAxNiAzXCJcclxuICAgICAgICBzdHJva2U9XCIjYzhhYWIzXCJcclxuICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgLz5cclxuICAgICAgPGVsbGlwc2UgY3g9XCIzNlwiIGN5PVwiMTM3XCIgcng9XCIxNlwiIHJ5PVwiN1wiIGZpbGw9XCIjZjhlZWU2XCIgLz5cclxuICAgICAgPGVsbGlwc2UgY3g9XCI2NlwiIGN5PVwiMTM3XCIgcng9XCIxNlwiIHJ5PVwiN1wiIGZpbGw9XCIjZjhlZWU2XCIgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTZWFzb25hbFNjZW5lKHsgdGhlbWUgfTogeyB0aGVtZTogU2Vhc29uYWxUaGVtZSB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic2Vhc29uLXNjZW5lXCIgZGF0YS1zY2VuZT17dGhlbWV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlYXNvbi1zY2VuZS1vcmJpdFwiIC8+XHJcbiAgICAgIDxTZWFzb25hbEFydHdvcmsgdGhlbWU9e3RoZW1lfSBjbGFzc05hbWU9XCJzZWFzb24tZ3JlZXRpbmctYXJ0XCIgLz5cclxuICAgICAge3RoZW1lID09PSAnQ0hSSVNUTUFTJyAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFzb24tc2xlaWdoLXRyYWNrXCI+XHJcbiAgICAgICAgICA8U2FudGFTbGVpZ2ggLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAge3RoZW1lID09PSAnQVZVUlVEVScgJiYgPE5ld1llYXJMYW1wIC8+fVxyXG4gICAgICB7dGhlbWUgPT09ICdIQUxMT1dFRU4nICYmIChcclxuICAgICAgICA8c3ZnXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJzZWFzb24tbWlzdCBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgICAgdmlld0JveD1cIjAgMCAzMDAgNzBcIlxyXG4gICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgZm9jdXNhYmxlPVwiZmFsc2VcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgIGQ9XCJNMCAzMGMzNS0yNSA2MCAyNSAxMDAgMHM2NSAyMCAxMDUgMCA3MCAyMCAxMDAgME0tMzAgNTJjMzUtMjUgNjAgMjUgMTAwIDBzNjUgMjAgMTA1IDAgNzAgMjAgMTAwIDBcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCIjZDRjNWQ5XCJcclxuICAgICAgICAgICAgc3Ryb2tlT3BhY2l0eT1cIi4yXCJcclxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCI2XCJcclxuICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9zdmc+XHJcbiAgICAgICl9XHJcbiAgICAgIHt0aGVtZSA9PT0gJ0VBU1RFUicgJiYgPEVhc3RlckJ1bm55IC8+fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNlYXNvbmFsUGFydGljbGVzKHsgdGhlbWUgfTogeyB0aGVtZTogU2Vhc29uYWxUaGVtZSB9KSB7XHJcbiAgaWYgKHRoZW1lICE9PSAnQ0hSSVNUTUFTJyAmJiB0aGVtZSAhPT0gJ0FWVVJVRFUnKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e2BzZWFzb24tcGFydGljbGVzICR7dGhlbWUgPT09ICdDSFJJU1RNQVMnID8gJ3NlYXNvbi1zbm93JyA6ICdzZWFzb24tcGV0YWxzJ31gfVxyXG4gICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgPlxyXG4gICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogdGhlbWUgPT09ICdDSFJJU1RNQVMnID8gMTYgOiA4IH0sIChfLCBpKSA9PiAoXHJcbiAgICAgICAgPHNwYW5cclxuICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInNlYXNvbi1wYXJ0aWNsZSBzZWFzb24tYW5pbWF0ZWRcIlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgbGVmdDogYCR7KGkgKiAzNyArIDcpICUgMTAwfSVgLFxyXG4gICAgICAgICAgICB3aWR0aDogYCR7MyArIChpICUgNCl9cHhgLFxyXG4gICAgICAgICAgICBoZWlnaHQ6IGAkezMgKyAoaSAlIDQpfXB4YCxcclxuICAgICAgICAgICAgYW5pbWF0aW9uRHVyYXRpb246IGAkezggKyAoaSAlIDUpfXNgLFxyXG4gICAgICAgICAgICBhbmltYXRpb25EZWxheTogYCR7LWkgKiAxLjd9c2AsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=