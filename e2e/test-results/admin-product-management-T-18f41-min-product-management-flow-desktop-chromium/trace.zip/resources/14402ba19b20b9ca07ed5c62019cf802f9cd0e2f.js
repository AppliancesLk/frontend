import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Products/components/CatalogProductCard.tsx");const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import { formatCategoryName } from "/src/utils/category.ts";
import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
import { Link, generatePath } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ProductImage } from "/src/components/common/ProductImage.tsx";
import { AddToCart } from "/src/components/common/AddToCart.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { Price } from "/src/components/common/Price.tsx";
import { formatCurrency } from "/src/utils/currency.ts";
import { translations } from "/src/utils/translations.ts";
import { Rating } from "/src/components/common/Rating.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogProductCard.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.catalog;
export function CatalogProductCard({ product }) {
	const available = product.isActive && product.stockQty > 0;
	return /* @__PURE__ */ _jsxDEV("article", {
		className: "product-card group flex min-w-0 flex-col rounded-md border border-line-subtle bg-surface p-3 transition-colors hover:border-line",
		children: [
			/* @__PURE__ */ _jsxDEV(Link, {
				to: generatePath(ROUTES.productDetail, { id: product.productID }),
				className: "product-card-well relative mb-3 block overflow-hidden rounded-md bg-well p-3",
				children: [/* @__PURE__ */ _jsxDEV(ProductImage, {
					src: product.images[0],
					alt: product.name,
					className: `aspect-square w-full transition-transform duration-200 group-hover:scale-[1.03] ${available ? "" : "grayscale-[.4]"}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this), product.badge && /* @__PURE__ */ _jsxDEV("span", {
					className: "absolute left-0 top-0 rounded px-2 py-1 text-xs font-medium bg-accent text-accent-on",
					children: t.badges[product.badge]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			product.brand && /* @__PURE__ */ _jsxDEV("p", {
				className: "mb-1 truncate text-xs text-fg-muted",
				children: product.brand
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "line-clamp-2 min-h-12 break-words text-base font-medium leading-6 text-fg",
				children: /* @__PURE__ */ _jsxDEV(Link, {
					to: generatePath(ROUTES.productDetail, { id: product.productID }),
					className: "hover:text-fg-link",
					children: product.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-1 truncate text-xs text-fg-muted",
				children: product.subtitle || formatCategoryName(product.category.name)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-auto pt-3",
				children: [
					(product.ratingCount ?? 0) > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "mb-2",
						children: /* @__PURE__ */ _jsxDEV(Rating, {
							average: product.ratingAverage ?? 0,
							count: product.ratingCount ?? 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-base font-semibold tabular-nums text-fg sm:text-lg",
						children: /* @__PURE__ */ _jsxDEV(Price, { value: product.price }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 9
					}, this),
					product.compareAtPrice != null && Number(product.compareAtPrice) > Number(product.price) && /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-xs text-fg-muted",
						children: /* @__PURE__ */ _jsxDEV("s", { children: formatCurrency(product.compareAtPrice) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-3 flex flex-col items-start gap-1",
						children: [/* @__PURE__ */ _jsxDEV(StatusBadge, {
							status: available ? product.stockQty <= 5 ? "LOW_STOCK" : "IN_STOCK" : "OUT_OF_STOCK",
							children: available ? product.stockQty <= 5 ? `Only ${product.stockQty} left` : translations.productDetails.inStock : translations.productDetails.outOfStock
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 11
						}, this), available && /* @__PURE__ */ _jsxDEV(AddToCart, {
							compact: true,
							card: true,
							productId: product.productID,
							productName: product.name,
							available
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_c = CatalogProductCard;
var _c;
$RefreshReg$(_c, "CatalogProductCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Products/components/CatalogProductCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogProductCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogProductCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Products/components/CatalogProductCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxNQUFNLG9CQUFvQjtBQUVuQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsY0FBYzs7O0FBQ3ZCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxtQkFBbUIsRUFBRSxXQUFpQztDQUNwRSxNQUFNLFlBQVksUUFBUSxZQUFZLFFBQVEsV0FBVztDQUN6RCxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsTUFBRDtJQUNFLElBQUksYUFBYSxPQUFPLGVBQWUsRUFBRSxJQUFJLFFBQVEsVUFBVSxDQUFDO0lBQ2hFLFdBQVU7Y0FGWixDQUlFLHdCQUFDLGNBQUQ7S0FDRSxLQUFLLFFBQVEsT0FBTztLQUNwQixLQUFLLFFBQVE7S0FDYixXQUFXLG1GQUFtRixZQUFZLEtBQUs7SUFDaEg7Ozs7Y0FDQSxRQUFRLFNBQ1Asd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDYixFQUFFLE9BQU8sUUFBUTtJQUNkOzs7O1lBRUo7Ozs7OztHQUNMLFFBQVEsU0FDUCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF1QyxRQUFRO0dBQVM7Ozs7O0dBRXZFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1osd0JBQUMsTUFBRDtLQUNFLElBQUksYUFBYSxPQUFPLGVBQWUsRUFBRSxJQUFJLFFBQVEsVUFBVSxDQUFDO0tBQ2hFLFdBQVU7ZUFFVCxRQUFRO0lBQ0w7Ozs7O0dBQ0o7Ozs7O0dBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixRQUFRLFlBQVksbUJBQW1CLFFBQVEsU0FBUyxJQUFJO0dBQzVEOzs7OztHQUNILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7TUFDSSxRQUFRLGVBQWUsS0FBSyxLQUM1Qix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxRQUFEO09BQ0UsU0FBUyxRQUFRLGlCQUFpQjtPQUNsQyxPQUFPLFFBQVEsZUFBZTtNQUMvQjs7Ozs7S0FDRTs7Ozs7S0FFUCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDWCx3QkFBQyxPQUFELEVBQU8sT0FBTyxRQUFRLE1BQVE7Ozs7O0tBQzdCOzs7OztLQUNGLFFBQVEsa0JBQWtCLFFBQ3pCLE9BQU8sUUFBUSxjQUFjLElBQUksT0FBTyxRQUFRLEtBQUssS0FDbkQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1gsd0JBQUMsS0FBRCxZQUFJLGVBQWUsUUFBUSxjQUFjLEVBQUs7Ozs7O0tBQzdDOzs7OztLQUVQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsYUFBRDtPQUNFLFFBQ0UsWUFDSSxRQUFRLFlBQVksSUFDbEIsY0FDQSxhQUNGO2lCQUdMLFlBQ0csUUFBUSxZQUFZLElBQ2xCLFFBQVEsUUFBUSxTQUFTLFNBQ3pCLGFBQWEsZUFBZSxVQUM5QixhQUFhLGVBQWU7TUFDckI7Ozs7Z0JBQ1osYUFDQyx3QkFBQyxXQUFEO09BQ0U7T0FDQTtPQUNBLFdBQVcsUUFBUTtPQUNuQixhQUFhLFFBQVE7T0FDVjtNQUNaOzs7O2NBRUE7Ozs7OztJQUNGOzs7Ozs7RUFDRTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2F0YWxvZ1Byb2R1Y3RDYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRDYXRlZ29yeU5hbWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9jYXRlZ29yeSc7XHJcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9TdGF0dXNCYWRnZSc7XHJcbmltcG9ydCB7IExpbmssIGdlbmVyYXRlUGF0aCB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi8uLi90eXBlcy9wcm9kdWN0LnR5cGVzJztcclxuaW1wb3J0IHsgUHJvZHVjdEltYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJvZHVjdEltYWdlJztcclxuaW1wb3J0IHsgQWRkVG9DYXJ0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vQWRkVG9DYXJ0JztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IFByaWNlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUHJpY2UnO1xyXG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2N1cnJlbmN5JztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgUmF0aW5nIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmF0aW5nJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5jYXRhbG9nO1xyXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1Byb2R1Y3RDYXJkKHsgcHJvZHVjdCB9OiB7IHByb2R1Y3Q6IFByb2R1Y3QgfSkge1xyXG4gIGNvbnN0IGF2YWlsYWJsZSA9IHByb2R1Y3QuaXNBY3RpdmUgJiYgcHJvZHVjdC5zdG9ja1F0eSA+IDA7XHJcbiAgcmV0dXJuIChcclxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInByb2R1Y3QtY2FyZCBncm91cCBmbGV4IG1pbi13LTAgZmxleC1jb2wgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUtc3VidGxlIGJnLXN1cmZhY2UgcC0zIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJvcmRlci1saW5lXCI+XHJcbiAgICAgIDxMaW5rXHJcbiAgICAgICAgdG89e2dlbmVyYXRlUGF0aChST1VURVMucHJvZHVjdERldGFpbCwgeyBpZDogcHJvZHVjdC5wcm9kdWN0SUQgfSl9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwicHJvZHVjdC1jYXJkLXdlbGwgcmVsYXRpdmUgbWItMyBibG9jayBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1tZCBiZy13ZWxsIHAtM1wiXHJcbiAgICAgID5cclxuICAgICAgICA8UHJvZHVjdEltYWdlXHJcbiAgICAgICAgICBzcmM9e3Byb2R1Y3QuaW1hZ2VzWzBdfVxyXG4gICAgICAgICAgYWx0PXtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2Bhc3BlY3Qtc3F1YXJlIHctZnVsbCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDAgZ3JvdXAtaG92ZXI6c2NhbGUtWzEuMDNdICR7YXZhaWxhYmxlID8gJycgOiAnZ3JheXNjYWxlLVsuNF0nfWB9XHJcbiAgICAgICAgLz5cclxuICAgICAgICB7cHJvZHVjdC5iYWRnZSAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTAgdG9wLTAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSBiZy1hY2NlbnQgdGV4dC1hY2NlbnQtb25cIj5cclxuICAgICAgICAgICAge3QuYmFkZ2VzW3Byb2R1Y3QuYmFkZ2VdfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvTGluaz5cclxuICAgICAge3Byb2R1Y3QuYnJhbmQgJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTEgdHJ1bmNhdGUgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+e3Byb2R1Y3QuYnJhbmR9PC9wPlxyXG4gICAgICApfVxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwibGluZS1jbGFtcC0yIG1pbi1oLTEyIGJyZWFrLXdvcmRzIHRleHQtYmFzZSBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1mZ1wiPlxyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICB0bz17Z2VuZXJhdGVQYXRoKFJPVVRFUy5wcm9kdWN0RGV0YWlsLCB7IGlkOiBwcm9kdWN0LnByb2R1Y3RJRCB9KX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtZmctbGlua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3Byb2R1Y3QubmFtZX1cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvaDI+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdHJ1bmNhdGUgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAge3Byb2R1Y3Quc3VidGl0bGUgfHwgZm9ybWF0Q2F0ZWdvcnlOYW1lKHByb2R1Y3QuY2F0ZWdvcnkubmFtZSl9XHJcbiAgICAgIDwvcD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIHB0LTNcIj5cclxuICAgICAgICB7KHByb2R1Y3QucmF0aW5nQ291bnQgPz8gMCkgPiAwICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICA8UmF0aW5nXHJcbiAgICAgICAgICAgICAgYXZlcmFnZT17cHJvZHVjdC5yYXRpbmdBdmVyYWdlID8/IDB9XHJcbiAgICAgICAgICAgICAgY291bnQ9e3Byb2R1Y3QucmF0aW5nQ291bnQgPz8gMH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRleHQtZmcgc206dGV4dC1sZ1wiPlxyXG4gICAgICAgICAgPFByaWNlIHZhbHVlPXtwcm9kdWN0LnByaWNlfSAvPlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICB7cHJvZHVjdC5jb21wYXJlQXRQcmljZSAhPSBudWxsICYmXHJcbiAgICAgICAgICBOdW1iZXIocHJvZHVjdC5jb21wYXJlQXRQcmljZSkgPiBOdW1iZXIocHJvZHVjdC5wcmljZSkgJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgIDxzPntmb3JtYXRDdXJyZW5jeShwcm9kdWN0LmNvbXBhcmVBdFByaWNlKX08L3M+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggZmxleC1jb2wgaXRlbXMtc3RhcnQgZ2FwLTFcIj5cclxuICAgICAgICAgIDxTdGF0dXNCYWRnZVxyXG4gICAgICAgICAgICBzdGF0dXM9e1xyXG4gICAgICAgICAgICAgIGF2YWlsYWJsZVxyXG4gICAgICAgICAgICAgICAgPyBwcm9kdWN0LnN0b2NrUXR5IDw9IDVcclxuICAgICAgICAgICAgICAgICAgPyAnTE9XX1NUT0NLJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdJTl9TVE9DSydcclxuICAgICAgICAgICAgICAgIDogJ09VVF9PRl9TVE9DSydcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7YXZhaWxhYmxlXHJcbiAgICAgICAgICAgICAgPyBwcm9kdWN0LnN0b2NrUXR5IDw9IDVcclxuICAgICAgICAgICAgICAgID8gYE9ubHkgJHtwcm9kdWN0LnN0b2NrUXR5fSBsZWZ0YFxyXG4gICAgICAgICAgICAgICAgOiB0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMuaW5TdG9ja1xyXG4gICAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLnByb2R1Y3REZXRhaWxzLm91dE9mU3RvY2t9XHJcbiAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxyXG4gICAgICAgICAge2F2YWlsYWJsZSAmJiAoXHJcbiAgICAgICAgICAgIDxBZGRUb0NhcnRcclxuICAgICAgICAgICAgICBjb21wYWN0XHJcbiAgICAgICAgICAgICAgY2FyZFxyXG4gICAgICAgICAgICAgIHByb2R1Y3RJZD17cHJvZHVjdC5wcm9kdWN0SUR9XHJcbiAgICAgICAgICAgICAgcHJvZHVjdE5hbWU9e3Byb2R1Y3QubmFtZX1cclxuICAgICAgICAgICAgICBhdmFpbGFibGU9e2F2YWlsYWJsZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9hcnRpY2xlPlxyXG4gICk7XHJcbn1cclxuIl19