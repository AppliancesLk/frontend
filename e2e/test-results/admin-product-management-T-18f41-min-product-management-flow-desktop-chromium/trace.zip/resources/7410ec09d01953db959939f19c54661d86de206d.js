import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/AddToCart.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport11_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { notifyToast } from "/src/utils/toast.ts";
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { useAuth } from "/src/hooks/useAuth.ts";
import { USER_ROLES } from "/src/constants/roles.ts";
import { ROUTES } from "/src/constants/routes.ts";
import { addCartItem } from "/src/services/cartService.ts";
import { getApiError } from "/src/utils/apiErrors.ts";
import { translations } from "/src/utils/translations.ts";
import { Icon } from "/src/components/common/Icon.tsx";
import { Spinner } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AddToCart.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.cart;
export function AddToCart({ productId, available, compact = false, card = false, productName = "" }) {
	_s();
	const { user, loading } = useAuth();
	const location = useLocation();
	const [saving, setSaving] = useState(false);
	const [added, setAdded] = useState(false);
	const [error, setError] = useState("");
	const busy = useRef(false);
	useEffect(() => {
		if (!added) return;
		const timer = window.setTimeout(() => setAdded(false), 1600);
		return () => window.clearTimeout(timer);
	}, [added]);
	async function add() {
		if (busy.current || !available) return;
		busy.current = true;
		setSaving(true);
		setError("");
		setAdded(false);
		try {
			await addCartItem({
				productId,
				quantity: 1
			});
			setAdded(true);
			notifyToast({
				message: translations.storefront.added,
				action: {
					label: t.view,
					to: ROUTES.cart
				}
			});
		} catch (err) {
			setError(getApiError(err, t.addError));
		} finally {
			busy.current = false;
			setSaving(false);
		}
	}
	if (loading || user && user.role !== USER_ROLES.CUSTOMER) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: card ? "mt-3 w-full space-y-2" : compact ? "space-y-2" : "mb-5 space-y-3",
		children: [
			compact && !available ? /* @__PURE__ */ _jsxDEV("button", {
				disabled: true,
				"aria-label": translations.productDetails.outOfStock,
				className: "flex min-h-11 w-11 items-center justify-center rounded-sm bg-subtle text-fg-muted",
				children: /* @__PURE__ */ _jsxDEV(Icon, { name: "cart" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this) : !user ? /* @__PURE__ */ _jsxDEV(Link, {
				to: ROUTES.login,
				state: { from: location.pathname + location.search },
				"aria-label": compact ? `${t.signInToAdd}: ${productName}` : undefined,
				className: card ? "ui-button ui-button-secondary w-full" : compact ? "flex h-10 w-10 items-center justify-center rounded-sm bg-primary text-primary-on hover:bg-primary-hover" : "auth-primary w-full",
				children: card ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Icon, {
					name: "cart",
					className: "h-4 w-4"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 15
				}, this), t.add] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 13
				}, this) : compact ? /* @__PURE__ */ _jsxDEV(Icon, { name: "cart" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 13
				}, this) : t.signInToAdd
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				disabled: !available || saving,
				"aria-busy": saving,
				onClick: () => void add(),
				"aria-label": compact ? `${saving ? t.adding : t.add}: ${productName}` : undefined,
				className: card ? "ui-button ui-button-secondary w-full" : compact ? "flex h-11 w-11 items-center justify-center rounded-sm bg-primary text-primary-on hover:bg-primary-hover " : "auth-primary w-full",
				children: card ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [saving ? /* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 17
				}, this) : /* @__PURE__ */ _jsxDEV(Icon, {
					name: added ? "check" : "cart",
					className: "h-4 w-4"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 17
				}, this), saving ? t.adding : added ? "Added" : t.add] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 118,
					columnNumber: 13
				}, this) : compact ? saving ? /* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV(Icon, { name: added ? "check" : "cart" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 15
				}, this) : saving ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 15
				}, this), t.adding] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 13
				}, this) : available ? t.add : translations.productDetails.outOfStock
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 9
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: compact ? "max-w-40 rounded-sm bg-danger-bg p-2 text-xs text-danger" : "rounded-sm bg-danger-bg p-3 text-sm text-danger",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 9
			}, this),
			added && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: compact ? "sr-only" : "rounded-sm bg-success-bg p-3 text-sm text-success",
				children: [
					t.added,
					" ",
					!compact && /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.cart,
						className: "font-semibold underline underline-offset-4",
						children: t.view
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 157,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
}
_s(AddToCart, "KyIE98+/og5EdJUUrrzVN9uFFCc=", false, function() {
	return [useAuth, useLocation];
});
_c = AddToCart;
var _c;
$RefreshReg$(_c, "AddToCart");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/AddToCart.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AddToCart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AddToCart.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/AddToCart.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsTUFBTSxtQkFBbUI7QUFDbEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFlBQVk7QUFDckIsU0FBUyxlQUFlOzs7O0FBQ3hCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxVQUFVLEVBQ3hCLFdBQ0EsV0FDQSxVQUFVLE9BQ1YsT0FBTyxPQUNQLGNBQWMsTUFPYjs7Q0FDRCxNQUFNLEVBQUUsTUFBTSxZQUFZLFFBQVE7Q0FDbEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEtBQUs7Q0FDeEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxPQUFPLE9BQU8sS0FBSztDQUN6QixnQkFBZ0I7RUFDZCxJQUFJLENBQUMsT0FBTztFQUNaLE1BQU0sUUFBUSxPQUFPLGlCQUFpQixTQUFTLEtBQUssR0FBRyxJQUFJO0VBQzNELGFBQWEsT0FBTyxhQUFhLEtBQUs7Q0FDeEMsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUNWLGVBQWUsTUFBTTtFQUNuQixJQUFJLEtBQUssV0FBVyxDQUFDLFdBQVc7RUFDaEMsS0FBSyxVQUFVO0VBQ2YsVUFBVSxJQUFJO0VBQ2QsU0FBUyxFQUFFO0VBQ1gsU0FBUyxLQUFLO0VBQ2QsSUFBSTtHQUNGLE1BQU0sWUFBWTtJQUFFO0lBQVcsVUFBVTtHQUFFLENBQUM7R0FDNUMsU0FBUyxJQUFJO0dBQ2IsWUFBWTtJQUNWLFNBQVMsYUFBYSxXQUFXO0lBQ2pDLFFBQVE7S0FBRSxPQUFPLEVBQUU7S0FBTSxJQUFJLE9BQU87SUFBSztHQUMzQyxDQUFDO0VBQ0gsU0FBUyxLQUFjO0dBQ3JCLFNBQVMsWUFBWSxLQUFLLEVBQUUsUUFBUSxDQUFDO0VBQ3ZDLFVBQVU7R0FDUixLQUFLLFVBQVU7R0FDZixVQUFVLEtBQUs7RUFDakI7Q0FDRjtDQUNBLElBQUksV0FBWSxRQUFRLEtBQUssU0FBUyxXQUFXLFVBQVcsT0FBTztDQUNuRSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUNFLE9BQ0ksMEJBQ0EsVUFDRSxjQUNBO1lBTlY7R0FTRyxXQUFXLENBQUMsWUFDWCx3QkFBQyxVQUFEO0lBQ0U7SUFDQSxjQUFZLGFBQWEsZUFBZTtJQUN4QyxXQUFVO2NBRVYsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7R0FDYjs7OztjQUNOLENBQUMsT0FDSCx3QkFBQyxNQUFEO0lBQ0UsSUFBSSxPQUFPO0lBQ1gsT0FBTyxFQUFFLE1BQU0sU0FBUyxXQUFXLFNBQVMsT0FBTztJQUNuRCxjQUFZLFVBQVUsR0FBRyxFQUFFLFlBQVksSUFBSSxnQkFBZ0I7SUFDM0QsV0FDRSxPQUNJLHlDQUNBLFVBQ0UsNEdBQ0E7Y0FHUCxPQUNDLGdEQUNFLHdCQUFDLE1BQUQ7S0FBTSxNQUFLO0tBQU8sV0FBVTtJQUFXOzs7O2NBQ3RDLEVBQUUsR0FDSDs7OztlQUNBLFVBQ0Ysd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztlQUVuQixFQUFFO0dBRUE7Ozs7Y0FFTix3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFVBQVUsQ0FBQyxhQUFhO0lBQ3hCLGFBQVc7SUFDWCxlQUFlLEtBQUssSUFBSTtJQUN4QixjQUNFLFVBQVUsR0FBRyxTQUFTLEVBQUUsU0FBUyxFQUFFLElBQUksSUFBSSxnQkFBZ0I7SUFFN0QsV0FDRSxPQUNJLHlDQUNBLFVBQ0UsNkdBQ0E7Y0FHUCxPQUNDLGdEQUNHLFNBQ0Msd0JBQUMsU0FBRCxDQUFVOzs7O2VBRVYsd0JBQUMsTUFBRDtLQUFNLE1BQU0sUUFBUSxVQUFVO0tBQVEsV0FBVTtJQUFXOzs7O2NBRTVELFNBQVMsRUFBRSxTQUFTLFFBQVEsVUFBVSxFQUFFLEdBQ3pDOzs7O2VBQ0EsVUFDRixTQUNFLHdCQUFDLFNBQUQsQ0FBVTs7OztlQUVWLHdCQUFDLE1BQUQsRUFBTSxNQUFNLFFBQVEsVUFBVSxPQUFTOzs7O2VBRXZDLFNBQ0YsZ0RBQ0Usd0JBQUMsU0FBRCxDQUFVOzs7O2NBQ1QsRUFBRSxNQUNIOzs7O2VBQ0EsWUFDRixFQUFFLE1BRUYsYUFBYSxlQUFlO0dBRXhCOzs7OztHQUVULFNBQ0Msd0JBQUMsS0FBRDtJQUNFLE1BQUs7SUFDTCxXQUNFLFVBQ0ksNkRBQ0E7Y0FHTDtHQUNBOzs7OztHQUVKLFNBQ0Msd0JBQUMsS0FBRDtJQUNFLE1BQUs7SUFDTCxXQUNFLFVBQ0ksWUFDQTtjQUxSO0tBUUcsRUFBRTtLQUFPO0tBQ1QsQ0FBQyxXQUNBLHdCQUFDLE1BQUQ7TUFDRSxJQUFJLE9BQU87TUFDWCxXQUFVO2dCQUVULEVBQUU7S0FDQzs7Ozs7SUFFUDs7Ozs7O0VBRUY7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFkZFRvQ2FydC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBub3RpZnlUb2FzdCB9IGZyb20gJy4uLy4uL3V0aWxzL3RvYXN0JztcclxuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xyXG5pbXBvcnQgeyBVU0VSX1JPTEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvbGVzJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IGFkZENhcnRJdGVtIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvY2FydFNlcnZpY2UnO1xyXG5pbXBvcnQgeyBnZXRBcGlFcnJvciB9IGZyb20gJy4uLy4uL3V0aWxzL2FwaUVycm9ycyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tICcuL0ljb24nO1xyXG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnLi4vdWkvRmVlZGJhY2snO1xyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmNhcnQ7XHJcbmV4cG9ydCBmdW5jdGlvbiBBZGRUb0NhcnQoe1xyXG4gIHByb2R1Y3RJZCxcclxuICBhdmFpbGFibGUsXHJcbiAgY29tcGFjdCA9IGZhbHNlLFxyXG4gIGNhcmQgPSBmYWxzZSxcclxuICBwcm9kdWN0TmFtZSA9ICcnLFxyXG59OiB7XHJcbiAgcHJvZHVjdElkOiBzdHJpbmc7XHJcbiAgYXZhaWxhYmxlOiBib29sZWFuO1xyXG4gIGNvbXBhY3Q/OiBib29sZWFuO1xyXG4gIGNhcmQ/OiBib29sZWFuO1xyXG4gIHByb2R1Y3ROYW1lPzogc3RyaW5nO1xyXG59KSB7XHJcbiAgY29uc3QgeyB1c2VyLCBsb2FkaW5nIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkZGVkLCBzZXRBZGRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgYnVzeSA9IHVzZVJlZihmYWxzZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghYWRkZWQpIHJldHVybjtcclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0QWRkZWQoZmFsc2UpLCAxNjAwKTtcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICB9LCBbYWRkZWRdKTtcclxuICBhc3luYyBmdW5jdGlvbiBhZGQoKSB7XHJcbiAgICBpZiAoYnVzeS5jdXJyZW50IHx8ICFhdmFpbGFibGUpIHJldHVybjtcclxuICAgIGJ1c3kuY3VycmVudCA9IHRydWU7XHJcbiAgICBzZXRTYXZpbmcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcignJyk7XHJcbiAgICBzZXRBZGRlZChmYWxzZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhZGRDYXJ0SXRlbSh7IHByb2R1Y3RJZCwgcXVhbnRpdHk6IDEgfSk7XHJcbiAgICAgIHNldEFkZGVkKHRydWUpO1xyXG4gICAgICBub3RpZnlUb2FzdCh7XHJcbiAgICAgICAgbWVzc2FnZTogdHJhbnNsYXRpb25zLnN0b3JlZnJvbnQuYWRkZWQsXHJcbiAgICAgICAgYWN0aW9uOiB7IGxhYmVsOiB0LnZpZXcsIHRvOiBST1VURVMuY2FydCB9LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xyXG4gICAgICBzZXRFcnJvcihnZXRBcGlFcnJvcihlcnIsIHQuYWRkRXJyb3IpKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIGJ1c3kuY3VycmVudCA9IGZhbHNlO1xyXG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAobG9hZGluZyB8fCAodXNlciAmJiB1c2VyLnJvbGUgIT09IFVTRVJfUk9MRVMuQ1VTVE9NRVIpKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgIGNhcmRcclxuICAgICAgICAgID8gJ210LTMgdy1mdWxsIHNwYWNlLXktMidcclxuICAgICAgICAgIDogY29tcGFjdFxyXG4gICAgICAgICAgICA/ICdzcGFjZS15LTInXHJcbiAgICAgICAgICAgIDogJ21iLTUgc3BhY2UteS0zJ1xyXG4gICAgICB9XHJcbiAgICA+XHJcbiAgICAgIHtjb21wYWN0ICYmICFhdmFpbGFibGUgPyAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgIGFyaWEtbGFiZWw9e3RyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscy5vdXRPZlN0b2NrfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0xMSB3LTExIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXNtIGJnLXN1YnRsZSB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiY2FydFwiIC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICkgOiAhdXNlciA/IChcclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5sb2dpbn1cclxuICAgICAgICAgIHN0YXRlPXt7IGZyb206IGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoIH19XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtjb21wYWN0ID8gYCR7dC5zaWduSW5Ub0FkZH06ICR7cHJvZHVjdE5hbWV9YCA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgIGNhcmRcclxuICAgICAgICAgICAgICA/ICd1aS1idXR0b24gdWktYnV0dG9uLXNlY29uZGFyeSB3LWZ1bGwnXHJcbiAgICAgICAgICAgICAgOiBjb21wYWN0XHJcbiAgICAgICAgICAgICAgICA/ICdmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1vbiBob3ZlcjpiZy1wcmltYXJ5LWhvdmVyJ1xyXG4gICAgICAgICAgICAgICAgOiAnYXV0aC1wcmltYXJ5IHctZnVsbCdcclxuICAgICAgICAgIH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7Y2FyZCA/IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiY2FydFwiIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgIHt0LmFkZH1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogY29tcGFjdCA/IChcclxuICAgICAgICAgICAgPEljb24gbmFtZT1cImNhcnRcIiAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgdC5zaWduSW5Ub0FkZFxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBkaXNhYmxlZD17IWF2YWlsYWJsZSB8fCBzYXZpbmd9XHJcbiAgICAgICAgICBhcmlhLWJ1c3k9e3NhdmluZ31cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgYWRkKCl9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtcclxuICAgICAgICAgICAgY29tcGFjdCA/IGAke3NhdmluZyA/IHQuYWRkaW5nIDogdC5hZGR9OiAke3Byb2R1Y3ROYW1lfWAgOiB1bmRlZmluZWRcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgIGNhcmRcclxuICAgICAgICAgICAgICA/ICd1aS1idXR0b24gdWktYnV0dG9uLXNlY29uZGFyeSB3LWZ1bGwnXHJcbiAgICAgICAgICAgICAgOiBjb21wYWN0XHJcbiAgICAgICAgICAgICAgICA/ICdmbGV4IGgtMTEgdy0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1zbSBiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1vbiBob3ZlcjpiZy1wcmltYXJ5LWhvdmVyICdcclxuICAgICAgICAgICAgICAgIDogJ2F1dGgtcHJpbWFyeSB3LWZ1bGwnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2NhcmQgPyAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAge3NhdmluZyA/IChcclxuICAgICAgICAgICAgICAgIDxTcGlubmVyIC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2FkZGVkID8gJ2NoZWNrJyA6ICdjYXJ0J30gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7c2F2aW5nID8gdC5hZGRpbmcgOiBhZGRlZCA/ICdBZGRlZCcgOiB0LmFkZH1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogY29tcGFjdCA/IChcclxuICAgICAgICAgICAgc2F2aW5nID8gKFxyXG4gICAgICAgICAgICAgIDxTcGlubmVyIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT17YWRkZWQgPyAnY2hlY2snIDogJ2NhcnQnfSAvPlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICApIDogc2F2aW5nID8gKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxTcGlubmVyIC8+XHJcbiAgICAgICAgICAgICAge3QuYWRkaW5nfVxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICkgOiBhdmFpbGFibGUgPyAoXHJcbiAgICAgICAgICAgIHQuYWRkXHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICB0cmFuc2xhdGlvbnMucHJvZHVjdERldGFpbHMub3V0T2ZTdG9ja1xyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgKX1cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8cFxyXG4gICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgIGNvbXBhY3RcclxuICAgICAgICAgICAgICA/ICdtYXgtdy00MCByb3VuZGVkLXNtIGJnLWRhbmdlci1iZyBwLTIgdGV4dC14cyB0ZXh0LWRhbmdlcidcclxuICAgICAgICAgICAgICA6ICdyb3VuZGVkLXNtIGJnLWRhbmdlci1iZyBwLTMgdGV4dC1zbSB0ZXh0LWRhbmdlcidcclxuICAgICAgICAgIH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICB7YWRkZWQgJiYgKFxyXG4gICAgICAgIDxwXHJcbiAgICAgICAgICByb2xlPVwic3RhdHVzXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgIGNvbXBhY3RcclxuICAgICAgICAgICAgICA/ICdzci1vbmx5J1xyXG4gICAgICAgICAgICAgIDogJ3JvdW5kZWQtc20gYmctc3VjY2Vzcy1iZyBwLTMgdGV4dC1zbSB0ZXh0LXN1Y2Nlc3MnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3QuYWRkZWR9eycgJ31cclxuICAgICAgICAgIHshY29tcGFjdCAmJiAoXHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89e1JPVVRFUy5jYXJ0fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dC52aWV3fVxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19