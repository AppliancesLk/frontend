import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/seasonal/SeasonalGreeting.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { useSeasonalTheme } from "/src/hooks/useSeasonalTheme.ts";
import { seasonalPresets, seasonalText } from "/src/utils/seasonalText.ts";
import { SeasonalParticles, SeasonalScene } from "/src/components/seasonal/SeasonalScene.tsx";
import { useSeasonalMotion } from "/src/components/seasonal/useSeasonalMotion.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalGreeting.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function SeasonalGreeting({ appearance, compact = false }) {
	_s();
	const { active } = useSeasonalTheme();
	const current = appearance ?? active;
	const { ref: bannerRef, running, controllable, paused, toggle } = useSeasonalMotion(current.theme !== "DEFAULT" && current.showGreeting && current.decorations && current.animations);
	if (current.theme === "DEFAULT" || !current.showGreeting) return null;
	return /* @__PURE__ */ _jsxDEV("aside", {
		ref: bannerRef,
		className: `season-greeting${compact ? " season-greeting-compact" : ""}`,
		"data-motion": running ? "running" : controllable ? "paused" : "disabled",
		"data-greeting-theme": current.theme,
		"aria-label": seasonalText.greetingLabel,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "season-greeting-inner",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "season-greeting-copy",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "season-occasion",
							children: seasonalPresets[current.theme].occasion
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "season-greeting-title",
							children: current.headline
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "season-greeting-message",
							children: current.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this), current.decorations && /* @__PURE__ */ _jsxDEV(SeasonalScene, { theme: current.theme }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 33
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 7
			}, this),
			current.decorations && current.animations && /* @__PURE__ */ _jsxDEV(SeasonalParticles, { theme: current.theme }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this),
			controllable && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "season-motion-toggle",
				onClick: toggle,
				"aria-pressed": paused,
				children: [/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": "true",
					children: paused ? "▶" : "Ⅱ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this), paused ? seasonalText.playEffects : seasonalText.pauseEffects]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_s(SeasonalGreeting, "mgbdeVBi0izCKxcaMV12RAMetUU=", false, function() {
	return [useSeasonalTheme, useSeasonalMotion];
});
_c = SeasonalGreeting;
var _c;
$RefreshReg$(_c, "SeasonalGreeting");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/seasonal/SeasonalGreeting.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalGreeting.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalGreeting.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/seasonal/SeasonalGreeting.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyx3QkFBd0I7QUFFakMsU0FBUyxpQkFBaUIsb0JBQW9CO0FBQzlDLFNBQVMsbUJBQW1CLHFCQUFxQjtBQUNqRCxTQUFTLHlCQUF5Qjs7OztBQUVsQyxPQUFPLFNBQVMsaUJBQWlCLEVBQy9CLFlBQ0EsVUFBVSxTQUlUOztDQUNELE1BQU0sRUFBRSxXQUFXLGlCQUFpQjtDQUNwQyxNQUFNLFVBQVUsY0FBYztDQUM5QixNQUFNLEVBQ0osS0FBSyxXQUNMLFNBQ0EsY0FDQSxRQUNBLFdBQ0Usa0JBQ0YsUUFBUSxVQUFVLGFBQ2hCLFFBQVEsZ0JBQ1IsUUFBUSxlQUNSLFFBQVEsVUFDWjtDQUNBLElBQUksUUFBUSxVQUFVLGFBQWEsQ0FBQyxRQUFRLGNBQWMsT0FBTztDQUNqRSxPQUNFLHdCQUFDLFNBQUQ7RUFDRSxLQUFLO0VBQ0wsV0FBVyxrQkFBa0IsVUFBVSw2QkFBNkI7RUFDcEUsZUFBYSxVQUFVLFlBQVksZUFBZSxXQUFXO0VBQzdELHVCQUFxQixRQUFRO0VBQzdCLGNBQVksYUFBYTtZQUwzQjtHQU9FLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsZ0JBQWdCLFFBQVEsTUFBTSxDQUFDO01BQzVCOzs7OztNQUNOLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QixRQUFRO01BQVk7Ozs7O01BQzFELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUEyQixRQUFRO01BQVc7Ozs7O0tBQ3hEOzs7OztjQUNKLFFBQVEsZUFBZSx3QkFBQyxlQUFELEVBQWUsT0FBTyxRQUFRLE1BQVE7Ozs7WUFDM0Q7Ozs7OztHQUNKLFFBQVEsZUFBZSxRQUFRLGNBQzlCLHdCQUFDLG1CQUFELEVBQW1CLE9BQU8sUUFBUSxNQUFROzs7OztHQUUzQyxnQkFDQyx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7SUFDVixTQUFTO0lBQ1QsZ0JBQWM7Y0FKaEIsQ0FNRSx3QkFBQyxRQUFEO0tBQU0sZUFBWTtlQUFRLFNBQVMsTUFBTTtJQUFVOzs7O2NBQ2xELFNBQVMsYUFBYSxjQUFjLGFBQWEsWUFDNUM7Ozs7OztFQUVMOzs7Ozs7QUFFWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZWFzb25hbEdyZWV0aW5nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTZWFzb25hbFRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlU2Vhc29uYWxUaGVtZSc7XHJcbmltcG9ydCB0eXBlIHsgQWN0aXZlU2Vhc29uYWxUaGVtZSB9IGZyb20gJy4uLy4uL3R5cGVzL3NlYXNvbmFsLXRoZW1lLnR5cGVzJztcclxuaW1wb3J0IHsgc2Vhc29uYWxQcmVzZXRzLCBzZWFzb25hbFRleHQgfSBmcm9tICcuLi8uLi91dGlscy9zZWFzb25hbFRleHQnO1xyXG5pbXBvcnQgeyBTZWFzb25hbFBhcnRpY2xlcywgU2Vhc29uYWxTY2VuZSB9IGZyb20gJy4vU2Vhc29uYWxTY2VuZSc7XHJcbmltcG9ydCB7IHVzZVNlYXNvbmFsTW90aW9uIH0gZnJvbSAnLi91c2VTZWFzb25hbE1vdGlvbic7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2Vhc29uYWxHcmVldGluZyh7XHJcbiAgYXBwZWFyYW5jZSxcclxuICBjb21wYWN0ID0gZmFsc2UsXHJcbn06IHtcclxuICBhcHBlYXJhbmNlPzogQWN0aXZlU2Vhc29uYWxUaGVtZTtcclxuICBjb21wYWN0PzogYm9vbGVhbjtcclxufSkge1xyXG4gIGNvbnN0IHsgYWN0aXZlIH0gPSB1c2VTZWFzb25hbFRoZW1lKCk7XHJcbiAgY29uc3QgY3VycmVudCA9IGFwcGVhcmFuY2UgPz8gYWN0aXZlO1xyXG4gIGNvbnN0IHtcclxuICAgIHJlZjogYmFubmVyUmVmLFxyXG4gICAgcnVubmluZyxcclxuICAgIGNvbnRyb2xsYWJsZSxcclxuICAgIHBhdXNlZCxcclxuICAgIHRvZ2dsZSxcclxuICB9ID0gdXNlU2Vhc29uYWxNb3Rpb24oXHJcbiAgICBjdXJyZW50LnRoZW1lICE9PSAnREVGQVVMVCcgJiZcclxuICAgICAgY3VycmVudC5zaG93R3JlZXRpbmcgJiZcclxuICAgICAgY3VycmVudC5kZWNvcmF0aW9ucyAmJlxyXG4gICAgICBjdXJyZW50LmFuaW1hdGlvbnMsXHJcbiAgKTtcclxuICBpZiAoY3VycmVudC50aGVtZSA9PT0gJ0RFRkFVTFQnIHx8ICFjdXJyZW50LnNob3dHcmVldGluZykgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIChcclxuICAgIDxhc2lkZVxyXG4gICAgICByZWY9e2Jhbm5lclJlZn1cclxuICAgICAgY2xhc3NOYW1lPXtgc2Vhc29uLWdyZWV0aW5nJHtjb21wYWN0ID8gJyBzZWFzb24tZ3JlZXRpbmctY29tcGFjdCcgOiAnJ31gfVxyXG4gICAgICBkYXRhLW1vdGlvbj17cnVubmluZyA/ICdydW5uaW5nJyA6IGNvbnRyb2xsYWJsZSA/ICdwYXVzZWQnIDogJ2Rpc2FibGVkJ31cclxuICAgICAgZGF0YS1ncmVldGluZy10aGVtZT17Y3VycmVudC50aGVtZX1cclxuICAgICAgYXJpYS1sYWJlbD17c2Vhc29uYWxUZXh0LmdyZWV0aW5nTGFiZWx9XHJcbiAgICA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2Vhc29uLWdyZWV0aW5nLWlubmVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFzb24tZ3JlZXRpbmctY29weVwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2Vhc29uLW9jY2FzaW9uXCI+XHJcbiAgICAgICAgICAgIHtzZWFzb25hbFByZXNldHNbY3VycmVudC50aGVtZV0ub2NjYXNpb259XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzZWFzb24tZ3JlZXRpbmctdGl0bGVcIj57Y3VycmVudC5oZWFkbGluZX08L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzZWFzb24tZ3JlZXRpbmctbWVzc2FnZVwiPntjdXJyZW50Lm1lc3NhZ2V9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtjdXJyZW50LmRlY29yYXRpb25zICYmIDxTZWFzb25hbFNjZW5lIHRoZW1lPXtjdXJyZW50LnRoZW1lfSAvPn1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtjdXJyZW50LmRlY29yYXRpb25zICYmIGN1cnJlbnQuYW5pbWF0aW9ucyAmJiAoXHJcbiAgICAgICAgPFNlYXNvbmFsUGFydGljbGVzIHRoZW1lPXtjdXJyZW50LnRoZW1lfSAvPlxyXG4gICAgICApfVxyXG4gICAgICB7Y29udHJvbGxhYmxlICYmIChcclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInNlYXNvbi1tb3Rpb24tdG9nZ2xlXCJcclxuICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZX1cclxuICAgICAgICAgIGFyaWEtcHJlc3NlZD17cGF1c2VkfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPntwYXVzZWQgPyAn4pa2JyA6ICfihaEnfTwvc3Bhbj5cclxuICAgICAgICAgIHtwYXVzZWQgPyBzZWFzb25hbFRleHQucGxheUVmZmVjdHMgOiBzZWFzb25hbFRleHQucGF1c2VFZmZlY3RzfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApfVxyXG4gICAgPC9hc2lkZT5cclxuICApO1xyXG59XHJcbiJdfQ==