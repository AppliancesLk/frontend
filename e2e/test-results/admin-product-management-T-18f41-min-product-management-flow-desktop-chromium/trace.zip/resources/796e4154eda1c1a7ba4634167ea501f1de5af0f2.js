import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
import { StatusBadge } from "/src/components/ui/StatusBadge.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function RepairStatusBadge({ status }) {
	return /* @__PURE__ */ _jsxDEV(StatusBadge, {
		status,
		children: translations.repairs.statuses[status] ?? status
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = RepairStatusBadge;
var _c;
$RefreshReg$(_c, "RepairStatusBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/components/RepairStatusBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7OztBQUM1QixPQUFPLFNBQVMsa0JBQWtCLEVBQUUsVUFBb0M7Q0FDdEUsT0FDRSx3QkFBQyxhQUFEO0VBQXFCO1lBQ2xCLGFBQWEsUUFBUSxTQUFTLFdBQVc7Q0FDL0I7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlcGFpclN0YXR1c0JhZGdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlcGFpclN0YXR1cyB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL3JlcGFpci50eXBlcyc7XG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL1N0YXR1c0JhZGdlJztcbmV4cG9ydCBmdW5jdGlvbiBSZXBhaXJTdGF0dXNCYWRnZSh7IHN0YXR1cyB9OiB7IHN0YXR1czogUmVwYWlyU3RhdHVzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8U3RhdHVzQmFkZ2Ugc3RhdHVzPXtzdGF0dXN9PlxuICAgICAge3RyYW5zbGF0aW9ucy5yZXBhaXJzLnN0YXR1c2VzW3N0YXR1c10gPz8gc3RhdHVzfVxuICAgIDwvU3RhdHVzQmFkZ2U+XG4gICk7XG59XG4iXX0=