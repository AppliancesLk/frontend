import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/Rating.tsx");const useId = __vite__cjsImport0_react["useId"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Rating.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export function Rating({ average, count }) {
	_s();
	const id = useId();
	const rating = Math.min(5, Math.max(0, Number(average)));
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "inline-flex flex-wrap items-center gap-1.5 text-xs",
		"aria-label": count ? `${rating.toFixed(1)} out of 5, ${count} reviews` : translations.experience.noRatings,
		children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "inline-flex gap-0.5",
			"aria-hidden": "true",
			children: Array.from({ length: 5 }, (_, index) => /* @__PURE__ */ _jsxDEV("svg", {
				viewBox: "0 0 20 20",
				className: "h-3.5 w-3.5",
				children: [/* @__PURE__ */ _jsxDEV("defs", { children: /* @__PURE__ */ _jsxDEV("linearGradient", {
					id: `${id}-${index}`,
					children: [/* @__PURE__ */ _jsxDEV("stop", {
						offset: `${Math.min(1, Math.max(0, rating - index)) * 100}%`,
						stopColor: "var(--star)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("stop", {
						offset: `${Math.min(1, Math.max(0, rating - index)) * 100}%`,
						stopColor: "var(--border-default)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("path", {
					d: "m10 1 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L1.2 7.4l6.1-.9Z",
					fill: `url(#${id}-${index})`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 13
				}, this)]
			}, index, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this), count > 0 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "font-semibold text-fg",
			children: rating.toFixed(1)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "text-fg-muted",
			children: [
				"(",
				count.toLocaleString(),
				")"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("span", {
			className: "text-fg-muted",
			children: translations.experience.noRatings
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s(Rating, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=");
_c = Rating;
var _c;
$RefreshReg$(_c, "Rating");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/Rating.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Rating.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Rating.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Rating.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsb0JBQW9COzs7O0FBQzdCLE9BQU8sU0FBUyxPQUFPLEVBQ3JCLFNBQ0EsU0FJQzs7Q0FDRCxNQUFNLEtBQUssTUFBTTtDQUNqQixNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQztDQUN2RCxPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFVO0VBQ1YsY0FDRSxRQUNJLEdBQUcsT0FBTyxRQUFRLENBQUMsRUFBRSxhQUFhLE1BQU0sWUFDeEMsYUFBYSxXQUFXO1lBTGhDLENBUUUsd0JBQUMsUUFBRDtHQUFNLFdBQVU7R0FBc0IsZUFBWTthQUMvQyxNQUFNLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxHQUFHLFVBQzdCLHdCQUFDLE9BQUQ7SUFBaUIsU0FBUTtJQUFZLFdBQVU7Y0FBL0MsQ0FDRSx3QkFBQyxRQUFELFlBQ0Usd0JBQUMsa0JBQUQ7S0FBZ0IsSUFBSSxHQUFHLEdBQUcsR0FBRztlQUE3QixDQUNFLHdCQUFDLFFBQUQ7TUFDRSxRQUFRLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsU0FBUyxLQUFLLENBQUMsSUFBSSxJQUFJO01BQzFELFdBQVU7S0FDWDs7OztlQUNELHdCQUFDLFFBQUQ7TUFDRSxRQUFRLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsU0FBUyxLQUFLLENBQUMsSUFBSSxJQUFJO01BQzFELFdBQVU7S0FDWDs7OzthQUNhOzs7OzthQUNaOzs7O2NBQ04sd0JBQUMsUUFBRDtLQUNFLEdBQUU7S0FDRixNQUFNLFFBQVEsR0FBRyxHQUFHLE1BQU07SUFDM0I7Ozs7WUFDRTtNQWpCSzs7OztVQWlCTCxDQUNOO0VBQ0c7Ozs7WUFDTCxRQUFRLElBQ1AsZ0RBQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBeUIsT0FBTyxRQUFRLENBQUM7RUFBUTs7OztZQUNqRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFoQjtJQUFnQztJQUFFLE1BQU0sZUFBZTtJQUFFO0dBQU87Ozs7O1VBQ2hFOzs7O2FBRUYsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDYixhQUFhLFdBQVc7RUFDckI7Ozs7VUFFSjs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmF0aW5nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VJZCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuZXhwb3J0IGZ1bmN0aW9uIFJhdGluZyh7XHJcbiAgYXZlcmFnZSxcclxuICBjb3VudCxcclxufToge1xyXG4gIGF2ZXJhZ2U6IHN0cmluZyB8IG51bWJlcjtcclxuICBjb3VudDogbnVtYmVyO1xyXG59KSB7XHJcbiAgY29uc3QgaWQgPSB1c2VJZCgpO1xyXG4gIGNvbnN0IHJhdGluZyA9IE1hdGgubWluKDUsIE1hdGgubWF4KDAsIE51bWJlcihhdmVyYWdlKSkpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14c1wiXHJcbiAgICAgIGFyaWEtbGFiZWw9e1xyXG4gICAgICAgIGNvdW50XHJcbiAgICAgICAgICA/IGAke3JhdGluZy50b0ZpeGVkKDEpfSBvdXQgb2YgNSwgJHtjb3VudH0gcmV2aWV3c2BcclxuICAgICAgICAgIDogdHJhbnNsYXRpb25zLmV4cGVyaWVuY2Uubm9SYXRpbmdzXHJcbiAgICAgIH1cclxuICAgID5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggZ2FwLTAuNVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiA1IH0sIChfLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgPHN2ZyBrZXk9e2luZGV4fSB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIj5cclxuICAgICAgICAgICAgPGRlZnM+XHJcbiAgICAgICAgICAgICAgPGxpbmVhckdyYWRpZW50IGlkPXtgJHtpZH0tJHtpbmRleH1gfT5cclxuICAgICAgICAgICAgICAgIDxzdG9wXHJcbiAgICAgICAgICAgICAgICAgIG9mZnNldD17YCR7TWF0aC5taW4oMSwgTWF0aC5tYXgoMCwgcmF0aW5nIC0gaW5kZXgpKSAqIDEwMH0lYH1cclxuICAgICAgICAgICAgICAgICAgc3RvcENvbG9yPVwidmFyKC0tc3RhcilcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzdG9wXHJcbiAgICAgICAgICAgICAgICAgIG9mZnNldD17YCR7TWF0aC5taW4oMSwgTWF0aC5tYXgoMCwgcmF0aW5nIC0gaW5kZXgpKSAqIDEwMH0lYH1cclxuICAgICAgICAgICAgICAgICAgc3RvcENvbG9yPVwidmFyKC0tYm9yZGVyLWRlZmF1bHQpXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cclxuICAgICAgICAgICAgPC9kZWZzPlxyXG4gICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgIGQ9XCJtMTAgMSAyLjcgNS41IDYuMS45LTQuNCA0LjMgMSA2LjEtNS40LTIuOS01LjQgMi45IDEtNi4xTDEuMiA3LjRsNi4xLS45WlwiXHJcbiAgICAgICAgICAgICAgZmlsbD17YHVybCgjJHtpZH0tJHtpbmRleH0pYH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICAgIHtjb3VudCA+IDAgPyAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPntyYXRpbmcudG9GaXhlZCgxKX08L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZnLW11dGVkXCI+KHtjb3VudC50b0xvY2FsZVN0cmluZygpfSk8L3NwYW4+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAge3RyYW5zbGF0aW9ucy5leHBlcmllbmNlLm5vUmF0aW5nc31cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICl9XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufVxyXG4iXX0=