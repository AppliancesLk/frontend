import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Promotions/Editor/index.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport14_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { Button } from "/src/components/ui/Button.tsx";
import { Dialog } from "/src/components/ui/Dialog.tsx";
import { LoadingState } from "/src/components/ui/Feedback.tsx";
import { ROUTES } from "/src/constants/routes.ts";
import { promotionText as t } from "/src/utils/promotionText.ts";
import { usePromotionEditor } from "/src/pages/Admin/Promotions/hooks/usePromotionEditor.ts";
import { canReviewPromotion } from "/src/pages/Admin/Promotions/helpers/promotion.helpers.ts";
import { RecipientPicker } from "/src/pages/Admin/Promotions/components/RecipientPicker.tsx";
import { ProductPicker } from "/src/pages/Admin/Promotions/components/ProductPicker.tsx";
import { MessageFields } from "/src/pages/Admin/Promotions/components/MessageFields.tsx";
import { EmailPreview } from "/src/pages/Admin/Promotions/components/EmailPreview.tsx";
import { SendHistory } from "/src/pages/Admin/Promotions/components/SendHistory.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/Editor/index.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function PromotionEditorPage() {
	_s();
	const page = usePromotionEditor(), errorRef = useRef(null);
	useEffect(() => {
		if (page.error && !page.review) errorRef.current?.focus();
	}, [page.error, page.review]);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "mx-auto max-w-[1440px] space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV(Link, {
				to: ROUTES.adminPromotions,
				className: "inline-flex min-h-9 items-center text-sm text-fg-secondary hover:underline",
				children: ["← ", t.back]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title",
					children: page.detail ? t.edit : t.editor
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: page.dirty ? t.unsaved : t.current
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "rounded-full border border-line bg-surface px-4 py-2 text-xs",
					children: [page.preview?.recipientCount ?? 0, " eligible recipients"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			page.loading ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Loading promotion" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				page.error && !page.review && /* @__PURE__ */ _jsxDEV("div", {
					ref: errorRef,
					tabIndex: -1,
					role: "alert",
					className: "ui-alert ui-tone-danger",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: page.error }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "secondary",
						className: "mt-3",
						onClick: page.reload,
						disabled: page.busy,
						children: "Reload promotion"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 13
				}, this),
				page.success && /* @__PURE__ */ _jsxDEV("p", {
					role: "status",
					className: "ui-alert ui-tone-success",
					children: page.success
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this),
				page.ready && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: (event) => {
						event.preventDefault();
						void page.save();
					},
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(360px,0.95fr)]",
						children: [/* @__PURE__ */ _jsxDEV("fieldset", {
							disabled: page.busy,
							className: "min-w-0 space-y-6",
							children: [
								/* @__PURE__ */ _jsxDEV("legend", {
									className: "sr-only",
									children: "Promotion editor"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV(RecipientPicker, {
									draft: page.draft,
									onChange: page.setDraft,
									selectedUsers: page.selectedUsers,
									onUsers: page.setSelectedUsers
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV(ProductPicker, {
									draft: page.draft,
									onChange: page.setDraft,
									selectedProducts: page.selectedProducts,
									onProducts: page.setSelectedProducts
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV(MessageFields, {
									draft: page.draft,
									onChange: page.setDraft
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("aside", {
							className: "min-w-0 xl:sticky xl:top-24",
							children: [/* @__PURE__ */ _jsxDEV(EmailPreview, {
								html: page.preview?.html,
								subject: page.preview?.subject,
								loading: page.previewing,
								error: page.previewError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 21
							}, this), Boolean(page.preview?.excludedCount) && /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-3 text-xs text-warning",
								children: [
									page.preview?.excludedCount,
									" ",
									t.excluded
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 23
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "sticky bottom-0 z-10 mt-6 flex flex-wrap items-center justify-between gap-3 rounded-md border border-line bg-surface p-4 shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-fg-muted",
							children: [
								page.draft.productIds.length,
								" products ·",
								" ",
								page.draft.audience === "ALL" ? t.all : `${page.draft.userIds.length} selected users`
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap gap-3",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								type: "submit",
								variant: "secondary",
								busy: page.busy,
								children: t.save
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								disabled: page.busy || !canReviewPromotion(page.draft) || page.hasActive,
								onClick: () => void page.save(true),
								children: page.hasActive ? "Send in progress" : t.review
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 15
				}, this), page.detail && /* @__PURE__ */ _jsxDEV(SendHistory, {
					id: page.detail.id,
					runs: page.detail.runs
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: Boolean(page.review),
				onClose: () => page.setReview(null),
				title: t.reviewTitle,
				description: t.reviewHint,
				busy: page.busy,
				children: page.review && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-md border border-line bg-subtle p-4",
							children: [
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-fg-muted",
									children: "Subject"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 break-words font-semibold",
									children: page.review.promotion.subject
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "mt-3 text-sm",
									children: [
										page.review.preview.recipientCount,
										" recipients ·",
										" ",
										page.review.promotion.productIds.length,
										" products"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "mt-2 text-xs text-fg-muted",
									children: page.review.promotion.audience === "ALL" ? t.all : t.selected
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 13
						}, this),
						page.review.preview.excludedCount > 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-warning",
							children: [
								page.review.preview.excludedCount,
								" ",
								t.excluded
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 15
						}, this),
						page.error && /* @__PURE__ */ _jsxDEV("p", {
							role: "alert",
							className: "ui-alert ui-tone-danger",
							children: page.error
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap justify-end gap-3",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "secondary",
								disabled: page.busy,
								onClick: () => page.setReview(null),
								children: "Keep editing"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								busy: page.busy,
								disabled: !page.review.preview.recipientCount,
								onClick: () => void page.send(),
								children: t.confirmSend
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_s(PromotionEditorPage, "+YW80XCl3iCVlM2LKS0/JOdYcy4=", false, function() {
	return [usePromotionEditor];
});
_c = PromotionEditorPage;
var _c;
$RefreshReg$(_c, "PromotionEditorPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Promotions/Editor/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/Editor/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/Editor/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Promotions/Editor/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGNBQWM7QUFDbEMsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsaUJBQWlCLFNBQVM7QUFDbkMsU0FBUywwQkFBMEI7QUFDbkMsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7Ozs7QUFDNUIsZUFBZSxTQUFTLHNCQUFzQjs7Q0FDNUMsTUFBTSxPQUFPLG1CQUFtQixHQUM5QixXQUFXLE9BQXVCLElBQUk7Q0FDeEMsZ0JBQWdCO0VBQ2QsSUFBSSxLQUFLLFNBQVMsQ0FBQyxLQUFLLFFBQVEsU0FBUyxTQUFTLE1BQU07Q0FDMUQsR0FBRyxDQUFDLEtBQUssT0FBTyxLQUFLLE1BQU0sQ0FBQztDQUM1QixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsTUFBRDtJQUNFLElBQUksT0FBTztJQUNYLFdBQVU7Y0FGWixDQUdDLE1BQ0ksRUFBRSxJQUNEOzs7Ozs7R0FDTix3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFpQixLQUFLLFNBQVMsRUFBRSxPQUFPLEVBQUU7SUFBVzs7OztjQUNuRSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUNWLEtBQUssUUFBUSxFQUFFLFVBQVUsRUFBRTtJQUMzQjs7OztZQUNBOzs7O2NBQ0wsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FDRyxLQUFLLFNBQVMsa0JBQWtCLEdBQUUsc0JBQy9COzs7OztZQUNBOzs7Ozs7R0FDUCxLQUFLLFVBQ0osd0JBQUMsY0FBRCxFQUFjLE9BQU0sb0JBQXFCOzs7O2NBRXpDO0lBQ0csS0FBSyxTQUFTLENBQUMsS0FBSyxVQUNuQix3QkFBQyxPQUFEO0tBQ0UsS0FBSztLQUNMLFVBQVUsQ0FBQztLQUNYLE1BQUs7S0FDTCxXQUFVO2VBSlosQ0FNRSx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7O2VBQ2xCLHdCQUFDLFFBQUQ7TUFDRSxTQUFRO01BQ1IsV0FBVTtNQUNWLFNBQVMsS0FBSztNQUNkLFVBQVUsS0FBSztnQkFDaEI7S0FFTzs7OzthQUNMOzs7Ozs7SUFFTixLQUFLLFdBQ0osd0JBQUMsS0FBRDtLQUFHLE1BQUs7S0FBUyxXQUFVO2VBQ3hCLEtBQUs7SUFDTDs7Ozs7SUFFSixLQUFLLFNBQ0osZ0RBQ0Usd0JBQUMsUUFBRDtLQUNFLFdBQVcsVUFBVTtNQUNuQixNQUFNLGVBQWU7TUFDckIsS0FBSyxLQUFLLEtBQUs7S0FDakI7ZUFKRixDQU1FLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsWUFBRDtPQUFVLFVBQVUsS0FBSztPQUFNLFdBQVU7aUJBQXpDO1FBQ0Usd0JBQUMsVUFBRDtTQUFRLFdBQVU7bUJBQVU7UUFBd0I7Ozs7O1FBQ3BELHdCQUFDLGlCQUFEO1NBQ0UsT0FBTyxLQUFLO1NBQ1osVUFBVSxLQUFLO1NBQ2YsZUFBZSxLQUFLO1NBQ3BCLFNBQVMsS0FBSztRQUNmOzs7OztRQUNELHdCQUFDLGVBQUQ7U0FDRSxPQUFPLEtBQUs7U0FDWixVQUFVLEtBQUs7U0FDZixrQkFBa0IsS0FBSztTQUN2QixZQUFZLEtBQUs7UUFDbEI7Ozs7O1FBQ0Qsd0JBQUMsZUFBRDtTQUNFLE9BQU8sS0FBSztTQUNaLFVBQVUsS0FBSztRQUNoQjs7Ozs7T0FDTzs7Ozs7Z0JBQ1Ysd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsY0FBRDtRQUNFLE1BQU0sS0FBSyxTQUFTO1FBQ3BCLFNBQVMsS0FBSyxTQUFTO1FBQ3ZCLFNBQVMsS0FBSztRQUNkLE9BQU8sS0FBSztPQUNiOzs7O2lCQUNBLFFBQVEsS0FBSyxTQUFTLGFBQWEsS0FDbEMsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FDRyxLQUFLLFNBQVM7U0FBYztTQUFFLEVBQUU7UUFDaEM7Ozs7O2VBRUE7Ozs7O2NBQ0o7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUNHLEtBQUssTUFBTSxXQUFXO1FBQU87UUFBWTtRQUN6QyxLQUFLLE1BQU0sYUFBYSxRQUNyQixFQUFFLE1BQ0YsR0FBRyxLQUFLLE1BQU0sUUFBUSxPQUFPO09BQ2hDOzs7OztnQkFDSCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBUSxNQUFLO1FBQVMsU0FBUTtRQUFZLE1BQU0sS0FBSztrQkFDbEQsRUFBRTtPQUNHOzs7O2lCQUNSLHdCQUFDLFFBQUQ7UUFDRSxVQUNFLEtBQUssUUFDTCxDQUFDLG1CQUFtQixLQUFLLEtBQUssS0FDOUIsS0FBSztRQUVQLGVBQWUsS0FBSyxLQUFLLEtBQUssSUFBSTtrQkFFakMsS0FBSyxZQUFZLHFCQUFxQixFQUFFO09BQ25DOzs7O2VBQ0w7Ozs7O2NBQ0Y7Ozs7O2FBQ0Q7Ozs7O2NBQ0wsS0FBSyxVQUNKLHdCQUFDLGFBQUQ7S0FBYSxJQUFJLEtBQUssT0FBTztLQUFJLE1BQU0sS0FBSyxPQUFPO0lBQU87Ozs7WUFFNUQ7Ozs7O0dBRUo7Ozs7O0dBRUosd0JBQUMsUUFBRDtJQUNFLE1BQU0sUUFBUSxLQUFLLE1BQU07SUFDekIsZUFBZSxLQUFLLFVBQVUsSUFBSTtJQUNsQyxPQUFPLEVBQUU7SUFDVCxhQUFhLEVBQUU7SUFDZixNQUFNLEtBQUs7Y0FFVixLQUFLLFVBQ0osd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXdCO1FBQVU7Ozs7O1FBQy9DLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLEtBQUssT0FBTyxVQUFVO1FBQ3RCOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQ0csS0FBSyxPQUFPLFFBQVE7VUFBZTtVQUFjO1VBQ2pELEtBQUssT0FBTyxVQUFVLFdBQVc7VUFBTztTQUN4Qzs7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsS0FBSyxPQUFPLFVBQVUsYUFBYSxRQUFRLEVBQUUsTUFBTSxFQUFFO1FBQ3JEOzs7OztPQUNBOzs7Ozs7TUFDSixLQUFLLE9BQU8sUUFBUSxnQkFBZ0IsS0FDbkMsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFDRyxLQUFLLE9BQU8sUUFBUTtRQUFjO1FBQUUsRUFBRTtPQUN0Qzs7Ozs7O01BRUosS0FBSyxTQUNKLHdCQUFDLEtBQUQ7T0FBRyxNQUFLO09BQVEsV0FBVTtpQkFDdkIsS0FBSztNQUNMOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUNFLFNBQVE7UUFDUixVQUFVLEtBQUs7UUFDZixlQUFlLEtBQUssVUFBVSxJQUFJO2tCQUNuQztPQUVPOzs7O2lCQUNSLHdCQUFDLFFBQUQ7UUFDRSxNQUFNLEtBQUs7UUFDWCxVQUFVLENBQUMsS0FBSyxPQUFPLFFBQVE7UUFDL0IsZUFBZSxLQUFLLEtBQUssS0FBSztrQkFFN0IsRUFBRTtPQUNHOzs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7R0FFRDs7Ozs7RUFDRDs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uJztcclxuaW1wb3J0IHsgRGlhbG9nIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tcG9uZW50cy91aS9EaWFsb2cnO1xyXG5pbXBvcnQgeyBMb2FkaW5nU3RhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHByb21vdGlvblRleHQgYXMgdCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3Byb21vdGlvblRleHQnO1xyXG5pbXBvcnQgeyB1c2VQcm9tb3Rpb25FZGl0b3IgfSBmcm9tICcuLi9ob29rcy91c2VQcm9tb3Rpb25FZGl0b3InO1xyXG5pbXBvcnQgeyBjYW5SZXZpZXdQcm9tb3Rpb24gfSBmcm9tICcuLi9oZWxwZXJzL3Byb21vdGlvbi5oZWxwZXJzJztcclxuaW1wb3J0IHsgUmVjaXBpZW50UGlja2VyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9SZWNpcGllbnRQaWNrZXInO1xyXG5pbXBvcnQgeyBQcm9kdWN0UGlja2VyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9Qcm9kdWN0UGlja2VyJztcclxuaW1wb3J0IHsgTWVzc2FnZUZpZWxkcyB9IGZyb20gJy4uL2NvbXBvbmVudHMvTWVzc2FnZUZpZWxkcyc7XHJcbmltcG9ydCB7IEVtYWlsUHJldmlldyB9IGZyb20gJy4uL2NvbXBvbmVudHMvRW1haWxQcmV2aWV3JztcclxuaW1wb3J0IHsgU2VuZEhpc3RvcnkgfSBmcm9tICcuLi9jb21wb25lbnRzL1NlbmRIaXN0b3J5JztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvbW90aW9uRWRpdG9yUGFnZSgpIHtcclxuICBjb25zdCBwYWdlID0gdXNlUHJvbW90aW9uRWRpdG9yKCksXHJcbiAgICBlcnJvclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChwYWdlLmVycm9yICYmICFwYWdlLnJldmlldykgZXJyb3JSZWYuY3VycmVudD8uZm9jdXMoKTtcclxuICB9LCBbcGFnZS5lcnJvciwgcGFnZS5yZXZpZXddKTtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1bMTQ0MHB4XSBzcGFjZS15LTZcIj5cclxuICAgICAgPExpbmtcclxuICAgICAgICB0bz17Uk9VVEVTLmFkbWluUHJvbW90aW9uc31cclxuICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBtaW4taC05IGl0ZW1zLWNlbnRlciB0ZXh0LXNtIHRleHQtZmctc2Vjb25kYXJ5IGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgID5cclxuICAgICAgICDihpAge3QuYmFja31cclxuICAgICAgPC9MaW5rPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZVwiPntwYWdlLmRldGFpbCA/IHQuZWRpdCA6IHQuZWRpdG9yfTwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICB7cGFnZS5kaXJ0eSA/IHQudW5zYXZlZCA6IHQuY3VycmVudH1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcHgtNCBweS0yIHRleHQteHNcIj5cclxuICAgICAgICAgIHtwYWdlLnByZXZpZXc/LnJlY2lwaWVudENvdW50ID8/IDB9IGVsaWdpYmxlIHJlY2lwaWVudHNcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgICB7cGFnZS5sb2FkaW5nID8gKFxyXG4gICAgICAgIDxMb2FkaW5nU3RhdGUgbGFiZWw9XCJMb2FkaW5nIHByb21vdGlvblwiIC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIHtwYWdlLmVycm9yICYmICFwYWdlLnJldmlldyAmJiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICByZWY9e2Vycm9yUmVmfVxyXG4gICAgICAgICAgICAgIHRhYkluZGV4PXstMX1cclxuICAgICAgICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWFsZXJ0IHVpLXRvbmUtZGFuZ2VyXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxwPntwYWdlLmVycm9yfTwvcD5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTNcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17cGFnZS5yZWxvYWR9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5idXN5fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFJlbG9hZCBwcm9tb3Rpb25cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge3BhZ2Uuc3VjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJ1aS1hbGVydCB1aS10b25lLXN1Y2Nlc3NcIj5cclxuICAgICAgICAgICAgICB7cGFnZS5zdWNjZXNzfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge3BhZ2UucmVhZHkgJiYgKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgIHZvaWQgcGFnZS5zYXZlKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNiB4bDpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfbWlubWF4KDM2MHB4LDAuOTVmcildXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxmaWVsZHNldCBkaXNhYmxlZD17cGFnZS5idXN5fSBjbGFzc05hbWU9XCJtaW4tdy0wIHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsZWdlbmQgY2xhc3NOYW1lPVwic3Itb25seVwiPlByb21vdGlvbiBlZGl0b3I8L2xlZ2VuZD5cclxuICAgICAgICAgICAgICAgICAgICA8UmVjaXBpZW50UGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBkcmFmdD17cGFnZS5kcmFmdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtwYWdlLnNldERyYWZ0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRVc2Vycz17cGFnZS5zZWxlY3RlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25Vc2Vycz17cGFnZS5zZXRTZWxlY3RlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFByb2R1Y3RQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgIGRyYWZ0PXtwYWdlLmRyYWZ0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3BhZ2Uuc2V0RHJhZnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFByb2R1Y3RzPXtwYWdlLnNlbGVjdGVkUHJvZHVjdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvblByb2R1Y3RzPXtwYWdlLnNldFNlbGVjdGVkUHJvZHVjdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZUZpZWxkc1xyXG4gICAgICAgICAgICAgICAgICAgICAgZHJhZnQ9e3BhZ2UuZHJhZnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17cGFnZS5zZXREcmFmdH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwibWluLXctMCB4bDpzdGlja3kgeGw6dG9wLTI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEVtYWlsUHJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbD17cGFnZS5wcmV2aWV3Py5odG1sfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3ViamVjdD17cGFnZS5wcmV2aWV3Py5zdWJqZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17cGFnZS5wcmV2aWV3aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3I9e3BhZ2UucHJldmlld0Vycm9yfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge0Jvb2xlYW4ocGFnZS5wcmV2aWV3Py5leGNsdWRlZENvdW50KSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgdGV4dC13YXJuaW5nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYWdlLnByZXZpZXc/LmV4Y2x1ZGVkQ291bnR9IHt0LmV4Y2x1ZGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IGJvdHRvbS0wIHotMTAgbXQtNiBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC00IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cGFnZS5kcmFmdC5wcm9kdWN0SWRzLmxlbmd0aH0gcHJvZHVjdHMgwrd7JyAnfVxyXG4gICAgICAgICAgICAgICAgICAgIHtwYWdlLmRyYWZ0LmF1ZGllbmNlID09PSAnQUxMJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyB0LmFsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBgJHtwYWdlLmRyYWZ0LnVzZXJJZHMubGVuZ3RofSBzZWxlY3RlZCB1c2Vyc2B9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBidXN5PXtwYWdlLmJ1c3l9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Quc2F2ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2UuYnVzeSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAhY2FuUmV2aWV3UHJvbW90aW9uKHBhZ2UuZHJhZnQpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2UuaGFzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2Uuc2F2ZSh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGFnZS5oYXNBY3RpdmUgPyAnU2VuZCBpbiBwcm9ncmVzcycgOiB0LnJldmlld31cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAge3BhZ2UuZGV0YWlsICYmIChcclxuICAgICAgICAgICAgICAgIDxTZW5kSGlzdG9yeSBpZD17cGFnZS5kZXRhaWwuaWR9IHJ1bnM9e3BhZ2UuZGV0YWlsLnJ1bnN9IC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgICA8RGlhbG9nXHJcbiAgICAgICAgb3Blbj17Qm9vbGVhbihwYWdlLnJldmlldyl9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gcGFnZS5zZXRSZXZpZXcobnVsbCl9XHJcbiAgICAgICAgdGl0bGU9e3QucmV2aWV3VGl0bGV9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3QucmV2aWV3SGludH1cclxuICAgICAgICBidXN5PXtwYWdlLmJ1c3l9XHJcbiAgICAgID5cclxuICAgICAgICB7cGFnZS5yZXZpZXcgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdWJ0bGUgcC00XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+U3ViamVjdDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIGJyZWFrLXdvcmRzIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHtwYWdlLnJldmlldy5wcm9tb3Rpb24uc3ViamVjdH1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5yZXZpZXcucHJldmlldy5yZWNpcGllbnRDb3VudH0gcmVjaXBpZW50cyDCt3snICd9XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5yZXZpZXcucHJvbW90aW9uLnByb2R1Y3RJZHMubGVuZ3RofSBwcm9kdWN0c1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UucmV2aWV3LnByb21vdGlvbi5hdWRpZW5jZSA9PT0gJ0FMTCcgPyB0LmFsbCA6IHQuc2VsZWN0ZWR9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3BhZ2UucmV2aWV3LnByZXZpZXcuZXhjbHVkZWRDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC13YXJuaW5nXCI+XHJcbiAgICAgICAgICAgICAgICB7cGFnZS5yZXZpZXcucHJldmlldy5leGNsdWRlZENvdW50fSB7dC5leGNsdWRlZH1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtwYWdlLmVycm9yICYmIChcclxuICAgICAgICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ1aS1hbGVydCB1aS10b25lLWRhbmdlclwiPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZS5idXN5fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGFnZS5zZXRSZXZpZXcobnVsbCl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgS2VlcCBlZGl0aW5nXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgYnVzeT17cGFnZS5idXN5fVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFwYWdlLnJldmlldy5wcmV2aWV3LnJlY2lwaWVudENvdW50fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBwYWdlLnNlbmQoKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dC5jb25maXJtU2VuZH1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L0RpYWxvZz5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==