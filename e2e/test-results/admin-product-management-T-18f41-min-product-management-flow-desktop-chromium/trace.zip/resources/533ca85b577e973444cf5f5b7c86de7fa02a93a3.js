import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Repairs/index.tsx");const useEffect = __vite__cjsImport1_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import { EmptyState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { translations } from "/src/utils/translations.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { useAdminRepairsPage } from "/src/pages/Admin/Repairs/hooks/useAdminRepairsPage.ts";
import { RepairsTable } from "/src/pages/Admin/Repairs/components/RepairsTable.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/index.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.adminRepairs;
export default function AdminRepairsPage() {
	_s();
	const page = useAdminRepairsPage();
	useEffect(() => {
		const previous = document.title;
		document.title = `${t.title} | ${translations.common.storeName}`;
		return () => {
			document.title = previous;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: t.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: t.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void page.refresh(),
					disabled: page.loading,
					className: "auth-secondary",
					children: t.refresh
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 7
			}, this),
			!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: page.repairs.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyState, {
				title: t.empty,
				description: t.emptyDescription,
				icon: "repair"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV(RepairsTable, { repairs: page.repairs }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_s(AdminRepairsPage, "BYah0KOYL23aMHOCDabxza62BZk=", false, function() {
	return [useAdminRepairsPage];
});
_c = AdminRepairsPage;
var _c;
$RefreshReg$(_c, "AdminRepairsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Repairs/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Repairs/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsTUFBTSxJQUFJLGFBQWE7QUFFdkIsZUFBZSxTQUFTLG1CQUFtQjs7Q0FDekMsTUFBTSxPQUFPLG9CQUFvQjtDQUVqQyxnQkFBZ0I7RUFDZCxNQUFNLFdBQVcsU0FBUztFQUMxQixTQUFTLFFBQVEsR0FBRyxFQUFFLE1BQU0sS0FBSyxhQUFhLE9BQU87RUFDckQsYUFBYTtHQUNYLFNBQVMsUUFBUTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUIsRUFBRTtJQUFVOzs7O2NBQ25ELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCLEVBQUU7SUFBZTs7OztZQUN6RDs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxLQUFLLEtBQUssUUFBUTtLQUNqQyxVQUFVLEtBQUs7S0FDZixXQUFVO2VBRVQsRUFBRTtJQUNHOzs7O1lBQ0w7Ozs7OztHQUVMLHdCQUFDLGlCQUFEO0lBQ0UsU0FBUyxLQUFLO0lBQ2QsT0FBTyxLQUFLO0lBQ1osT0FBTyxLQUFLO0dBQ2I7Ozs7O0dBRUEsQ0FBQyxLQUFLLFdBQVcsQ0FBQyxLQUFLLFNBQ3RCLCtDQUNHLEtBQUssUUFBUSxXQUFXLElBQ3ZCLHdCQUFDLFlBQUQ7SUFDRSxPQUFPLEVBQUU7SUFDVCxhQUFhLEVBQUU7SUFDZixNQUFLO0dBQ047Ozs7Y0FFRCx3QkFBQyxjQUFELEVBQWMsU0FBUyxLQUFLLFFBQVU7Ozs7WUFFeEM7Ozs7O0VBRUc7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9GZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgQ2F0YWxvZ0ZlZWRiYWNrIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9mZWVkYmFjay9DYXRhbG9nRmVlZGJhY2snO1xyXG5pbXBvcnQgeyB1c2VBZG1pblJlcGFpcnNQYWdlIH0gZnJvbSAnLi9ob29rcy91c2VBZG1pblJlcGFpcnNQYWdlJztcclxuaW1wb3J0IHsgUmVwYWlyc1RhYmxlIH0gZnJvbSAnLi9jb21wb25lbnRzL1JlcGFpcnNUYWJsZSc7XHJcblxyXG5jb25zdCB0ID0gdHJhbnNsYXRpb25zLmFkbWluUmVwYWlycztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFkbWluUmVwYWlyc1BhZ2UoKSB7XHJcbiAgY29uc3QgcGFnZSA9IHVzZUFkbWluUmVwYWlyc1BhZ2UoKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHByZXZpb3VzID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICBkb2N1bWVudC50aXRsZSA9IGAke3QudGl0bGV9IHwgJHt0cmFuc2xhdGlvbnMuY29tbW9uLnN0b3JlTmFtZX1gO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ1aS1wYWdlLXRpdGxlIHRleHQtZmdcIj57dC50aXRsZX08L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVmcmVzaCgpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7dC5yZWZyZXNofVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxDYXRhbG9nRmVlZGJhY2tcclxuICAgICAgICBsb2FkaW5nPXtwYWdlLmxvYWRpbmd9XHJcbiAgICAgICAgZXJyb3I9e3BhZ2UuZXJyb3J9XHJcbiAgICAgICAgcmV0cnk9e3BhZ2UucmVmcmVzaH1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIHshcGFnZS5sb2FkaW5nICYmICFwYWdlLmVycm9yICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAge3BhZ2UucmVwYWlycy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgdGl0bGU9e3QuZW1wdHl9XHJcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb249e3QuZW1wdHlEZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICBpY29uPVwicmVwYWlyXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxSZXBhaXJzVGFibGUgcmVwYWlycz17cGFnZS5yZXBhaXJzfSAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==