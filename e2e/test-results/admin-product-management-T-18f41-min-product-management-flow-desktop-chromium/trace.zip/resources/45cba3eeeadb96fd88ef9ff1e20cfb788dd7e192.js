import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Repairer/Repairs/index.tsx");const useEffect = __vite__cjsImport1_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import { EmptyState } from "/src/components/ui/Feedback.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { useRepairerRepairsPage } from "/src/pages/Repairer/Repairs/hooks/useRepairerRepairsPage.ts";
import { RepairerRepairsTable } from "/src/pages/Repairer/Repairs/components/RepairerRepairsTable.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
export default function RepairerRepairsPage() {
	_s();
	const page = useRepairerRepairsPage();
	useEffect(() => {
		const previous = document.title;
		document.title = "My Assigned Repairs | Appliances LK";
		return () => {
			document.title = previous;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 md:py-8 lg:px-8",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "ui-page-title text-fg",
					children: "My Assigned Repairs"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: "View and manage repair tickets assigned to you"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void page.refresh(),
					disabled: page.loading,
					className: "auth-secondary",
					children: "Refresh"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: page.loading,
				error: page.error,
				retry: page.refresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 7
			}, this),
			!page.loading && !page.error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: page.repairs.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyState, {
				title: "No repairs assigned",
				description: "You don't have any repair tickets assigned to you yet.",
				icon: "repair"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV(RepairerRepairsTable, { repairs: page.repairs }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_s(RepairerRepairsPage, "opE69/tXGgh4u5vC8An4sxqJJT8=", false, function() {
	return [useRepairerRepairsPage];
});
_c = RepairerRepairsPage;
var _c;
$RefreshReg$(_c, "RepairerRepairsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Repairer/Repairs/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Repairer/Repairs/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyw4QkFBOEI7QUFDdkMsU0FBUyw0QkFBNEI7Ozs7QUFFckMsZUFBZSxTQUFTLHNCQUFzQjs7Q0FDNUMsTUFBTSxPQUFPLHVCQUF1QjtDQUVwQyxnQkFBZ0I7RUFDZCxNQUFNLFdBQVcsU0FBUztFQUMxQixTQUFTLFFBQVE7RUFDakIsYUFBYTtHQUNYLFNBQVMsUUFBUTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBd0I7SUFBdUI7Ozs7Y0FDN0Qsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkI7SUFFdkM7Ozs7WUFDQTs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxLQUFLLEtBQUssUUFBUTtLQUNqQyxVQUFVLEtBQUs7S0FDZixXQUFVO2VBQ1g7SUFFTzs7OztZQUNMOzs7Ozs7R0FFTCx3QkFBQyxpQkFBRDtJQUNFLFNBQVMsS0FBSztJQUNkLE9BQU8sS0FBSztJQUNaLE9BQU8sS0FBSztHQUNiOzs7OztHQUVBLENBQUMsS0FBSyxXQUFXLENBQUMsS0FBSyxTQUN0QiwrQ0FDRyxLQUFLLFFBQVEsV0FBVyxJQUN2Qix3QkFBQyxZQUFEO0lBQ0UsT0FBTztJQUNQLGFBQ0U7SUFFRixNQUFLO0dBQ047Ozs7Y0FFRCx3QkFBQyxzQkFBRCxFQUFzQixTQUFTLEtBQUssUUFBVTs7OztZQUVoRDs7Ozs7RUFFQTs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IHVzZVJlcGFpcmVyUmVwYWlyc1BhZ2UgfSBmcm9tICcuL2hvb2tzL3VzZVJlcGFpcmVyUmVwYWlyc1BhZ2UnO1xyXG5pbXBvcnQgeyBSZXBhaXJlclJlcGFpcnNUYWJsZSB9IGZyb20gJy4vY29tcG9uZW50cy9SZXBhaXJlclJlcGFpcnNUYWJsZSc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBhaXJlclJlcGFpcnNQYWdlKCkge1xyXG4gIGNvbnN0IHBhZ2UgPSB1c2VSZXBhaXJlclJlcGFpcnNQYWdlKCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBwcmV2aW91cyA9IGRvY3VtZW50LnRpdGxlO1xyXG4gICAgZG9jdW1lbnQudGl0bGUgPSAnTXkgQXNzaWduZWQgUmVwYWlycyB8IEFwcGxpYW5jZXMgTEsnO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91cztcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy03eGwgc3BhY2UteS02IHB4LTQgcHktNiBzbTpweC02IG1kOnB5LTggbGc6cHgtOFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+TXkgQXNzaWduZWQgUmVwYWlyczwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgICBWaWV3IGFuZCBtYW5hZ2UgcmVwYWlyIHRpY2tldHMgYXNzaWduZWQgdG8geW91XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHBhZ2UucmVmcmVzaCgpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICBSZWZyZXNoXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPENhdGFsb2dGZWVkYmFja1xyXG4gICAgICAgIGxvYWRpbmc9e3BhZ2UubG9hZGluZ31cclxuICAgICAgICBlcnJvcj17cGFnZS5lcnJvcn1cclxuICAgICAgICByZXRyeT17cGFnZS5yZWZyZXNofVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgeyFwYWdlLmxvYWRpbmcgJiYgIXBhZ2UuZXJyb3IgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7cGFnZS5yZXBhaXJzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICB0aXRsZT17J05vIHJlcGFpcnMgYXNzaWduZWQnfVxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uPXtcclxuICAgICAgICAgICAgICAgIFwiWW91IGRvbid0IGhhdmUgYW55IHJlcGFpciB0aWNrZXRzIGFzc2lnbmVkIHRvIHlvdSB5ZXQuXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgaWNvbj1cInJlcGFpclwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8UmVwYWlyZXJSZXBhaXJzVGFibGUgcmVwYWlycz17cGFnZS5yZXBhaXJzfSAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==