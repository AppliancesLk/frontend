import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Orders/components/AdminOrdersTable.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { EmptyState } from "/src/components/ui/Feedback.tsx";
import { generatePath, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { formatCurrency } from "/src/utils/currency.ts";
import { formatDate } from "/src/utils/date.ts";
import { translations } from "/src/utils/translations.ts";
import { AdminOrderStatusBadge, PaymentBadge } from "/src/pages/Admin/Orders/components/AdminOrderBadges.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrdersTable.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.adminOrders;
export function AdminOrdersTable({ orders }) {
	if (!orders.length) return /* @__PURE__ */ _jsxDEV(EmptyState, {
		title: t.empty,
		description: t.emptyDescription,
		icon: "orders"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 7
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "overflow-x-auto rounded-md border border-line bg-surface ",
		children: /* @__PURE__ */ _jsxDEV("table", {
			className: "ui-table ui-card-table min-w-full text-left text-sm",
			children: [/* @__PURE__ */ _jsxDEV("thead", {
				className: "bg-page text-fg-secondary",
				children: /* @__PURE__ */ _jsxDEV("tr", { children: [
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4 font-medium",
						children: translations.orders.id
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4 font-medium",
						children: t.customer
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4 font-medium",
						children: translations.orders.date
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4 font-medium",
						children: translations.orders.total
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4 font-medium",
						children: t.payment
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4 font-medium",
						children: translations.orders.status
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "px-5 py-4",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "sr-only",
							children: translations.orders.view
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("tbody", {
				className: "divide-y divide-line",
				children: orders.map((order) => /* @__PURE__ */ _jsxDEV("tr", { children: [
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": translations.orders.id,
						className: "xl:max-w-48 xl:truncate px-5 py-4 tabular-nums text-xs text-fg-secondary",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: order.id
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": t.customer,
						className: "px-5 py-4",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "font-medium text-fg",
								children: order.customer.username
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-fg-muted",
								children: order.customer.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": translations.orders.date,
						className: "xl:whitespace-nowrap px-5 py-4 text-fg-secondary",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: formatDate(order.createdAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": translations.orders.total,
						className: "xl:whitespace-nowrap px-5 py-4 font-semibold text-fg",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: formatCurrency(order.total)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": t.payment,
						className: "px-5 py-4",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: order.payment ? /* @__PURE__ */ _jsxDEV(PaymentBadge, { status: order.payment.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 21
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "text-fg-muted",
								children: t.noPayment
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": translations.orders.status,
						className: "px-5 py-4",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: /* @__PURE__ */ _jsxDEV(AdminOrderStatusBadge, { status: order.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						"data-label": translations.admin.actions,
						className: "px-5 py-4 text-right",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "ui-cell-value",
							children: /* @__PURE__ */ _jsxDEV(Link, {
								className: "font-medium text-fg-link hover:text-fg-link",
								to: generatePath(ROUTES.adminOrderDetail, { id: order.id }),
								children: translations.orders.view
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 15
					}, this)
				] }, order.id, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_c = AdminOrdersTable;
var _c;
$RefreshReg$(_c, "AdminOrdersTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Orders/components/AdminOrdersTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrdersTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrdersTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Orders/components/AdminOrdersTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjLFlBQVk7QUFDbkMsU0FBUyxjQUFjO0FBRXZCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsdUJBQXVCLG9CQUFvQjs7O0FBRXBELE1BQU0sSUFBSSxhQUFhO0FBRXZCLE9BQU8sU0FBUyxpQkFBaUIsRUFBRSxVQUFvQztDQUNyRSxJQUFJLENBQUMsT0FBTyxRQUNWLE9BQ0Usd0JBQUMsWUFBRDtFQUNFLE9BQU8sRUFBRTtFQUNULGFBQWEsRUFBRTtFQUNmLE1BQUs7Q0FDTjs7Ozs7Q0FFTCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsU0FBRDtHQUFPLFdBQVU7YUFBakIsQ0FDRSx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUNmLHdCQUFDLE1BQUQ7S0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBeUIsYUFBYSxPQUFPO0tBQU87Ozs7O0tBQ2xFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUF5QixFQUFFO0tBQWE7Ozs7O0tBQ3RELHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYLGFBQWEsT0FBTztLQUNuQjs7Ozs7S0FDSix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxhQUFhLE9BQU87S0FDbkI7Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCLEVBQUU7S0FBWTs7Ozs7S0FDckQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsYUFBYSxPQUFPO0tBQ25COzs7OztLQUNKLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNaLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXLGFBQWEsT0FBTztNQUFXOzs7OztLQUN4RDs7Ozs7SUFDRjs7Ozs7R0FDQzs7OzthQUNQLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQ2QsT0FBTyxLQUFLLFVBQ1gsd0JBQUMsTUFBRDtLQUNFLHdCQUFDLE1BQUQ7TUFDRSxjQUFZLGFBQWEsT0FBTztNQUNoQyxXQUFVO2dCQUVWLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFpQixNQUFNO01BQVE7Ozs7O0tBQzVDOzs7OztLQUNKLHdCQUFDLE1BQUQ7TUFBSSxjQUFZLEVBQUU7TUFBVSxXQUFVO2dCQUNwQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLE1BQU0sU0FBUztPQUNmOzs7O2lCQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLE1BQU0sU0FBUztPQUNmOzs7O2VBQ0E7Ozs7OztLQUNIOzs7OztLQUNKLHdCQUFDLE1BQUQ7TUFDRSxjQUFZLGFBQWEsT0FBTztNQUNoQyxXQUFVO2dCQUVWLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFdBQVcsTUFBTSxTQUFTO01BQ3hCOzs7OztLQUNIOzs7OztLQUNKLHdCQUFDLE1BQUQ7TUFDRSxjQUFZLGFBQWEsT0FBTztNQUNoQyxXQUFVO2dCQUVWLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGVBQWUsTUFBTSxLQUFLO01BQ3hCOzs7OztLQUNIOzs7OztLQUNKLHdCQUFDLE1BQUQ7TUFBSSxjQUFZLEVBQUU7TUFBUyxXQUFVO2dCQUNuQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixNQUFNLFVBQ0wsd0JBQUMsY0FBRCxFQUFjLFFBQVEsTUFBTSxRQUFRLE9BQVM7Ozs7a0JBRTdDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpQixFQUFFO09BQWdCOzs7OztNQUVsRDs7Ozs7S0FDSDs7Ozs7S0FDSix3QkFBQyxNQUFEO01BQUksY0FBWSxhQUFhLE9BQU87TUFBUSxXQUFVO2dCQUNwRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyx1QkFBRCxFQUF1QixRQUFRLE1BQU0sT0FBUzs7Ozs7TUFDM0M7Ozs7O0tBQ0g7Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUNFLGNBQVksYUFBYSxNQUFNO01BQy9CLFdBQVU7Z0JBRVYsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsTUFBRDtRQUNFLFdBQVU7UUFDVixJQUFJLGFBQWEsT0FBTyxrQkFBa0IsRUFBRSxJQUFJLE1BQU0sR0FBRyxDQUFDO2tCQUV6RCxhQUFhLE9BQU87T0FDakI7Ozs7O01BQ0g7Ozs7O0tBQ0g7Ozs7O0lBQ0YsS0E1REssTUFBTTs7OztXQTREWCxDQUNMO0dBQ0k7Ozs7V0FDRjs7Ozs7O0NBQ0o7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWRtaW5PcmRlcnNUYWJsZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgeyBnZW5lcmF0ZVBhdGgsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB0eXBlIHsgQWRtaW5PcmRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3R5cGVzL29yZGVyLnR5cGVzJztcclxuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9jdXJyZW5jeSc7XHJcbmltcG9ydCB7IGZvcm1hdERhdGUgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9kYXRlJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuaW1wb3J0IHsgQWRtaW5PcmRlclN0YXR1c0JhZGdlLCBQYXltZW50QmFkZ2UgfSBmcm9tICcuL0FkbWluT3JkZXJCYWRnZXMnO1xyXG5cclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5hZG1pbk9yZGVycztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBZG1pbk9yZGVyc1RhYmxlKHsgb3JkZXJzIH06IHsgb3JkZXJzOiBBZG1pbk9yZGVyW10gfSkge1xyXG4gIGlmICghb3JkZXJzLmxlbmd0aClcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgdGl0bGU9e3QuZW1wdHl9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3QuZW1wdHlEZXNjcmlwdGlvbn1cclxuICAgICAgICBpY29uPVwib3JkZXJzXCJcclxuICAgICAgLz5cclxuICAgICk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgXCI+XHJcbiAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ1aS10YWJsZSB1aS1jYXJkLXRhYmxlIG1pbi13LWZ1bGwgdGV4dC1sZWZ0IHRleHQtc21cIj5cclxuICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctcGFnZSB0ZXh0LWZnLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS00IGZvbnQtbWVkaXVtXCI+e3RyYW5zbGF0aW9ucy5vcmRlcnMuaWR9PC90aD5cclxuICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktNCBmb250LW1lZGl1bVwiPnt0LmN1c3RvbWVyfTwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTQgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLm9yZGVycy5kYXRlfVxyXG4gICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS00IGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5vcmRlcnMudG90YWx9XHJcbiAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTQgZm9udC1tZWRpdW1cIj57dC5wYXltZW50fTwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTQgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLm9yZGVycy5zdGF0dXN9XHJcbiAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+e3RyYW5zbGF0aW9ucy5vcmRlcnMudmlld308L3NwYW4+XHJcbiAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICA8L3RyPlxyXG4gICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1saW5lXCI+XHJcbiAgICAgICAgICB7b3JkZXJzLm1hcCgob3JkZXIpID0+IChcclxuICAgICAgICAgICAgPHRyIGtleT17b3JkZXIuaWR9PlxyXG4gICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17dHJhbnNsYXRpb25zLm9yZGVycy5pZH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInhsOm1heC13LTQ4IHhsOnRydW5jYXRlIHB4LTUgcHktNCB0YWJ1bGFyLW51bXMgdGV4dC14cyB0ZXh0LWZnLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+e29yZGVyLmlkfTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9e3QuY3VzdG9tZXJ9IGNsYXNzTmFtZT1cInB4LTUgcHktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZmdcIj5cclxuICAgICAgICAgICAgICAgICAgICB7b3JkZXIuY3VzdG9tZXIudXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge29yZGVyLmN1c3RvbWVyLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgZGF0YS1sYWJlbD17dHJhbnNsYXRpb25zLm9yZGVycy5kYXRlfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwieGw6d2hpdGVzcGFjZS1ub3dyYXAgcHgtNSBweS00IHRleHQtZmctc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLWNlbGwtdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUob3JkZXIuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICBkYXRhLWxhYmVsPXt0cmFuc2xhdGlvbnMub3JkZXJzLnRvdGFsfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwieGw6d2hpdGVzcGFjZS1ub3dyYXAgcHgtNSBweS00IGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShvcmRlci50b3RhbCl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZCBkYXRhLWxhYmVsPXt0LnBheW1lbnR9IGNsYXNzTmFtZT1cInB4LTUgcHktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1jZWxsLXZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtvcmRlci5wYXltZW50ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxQYXltZW50QmFkZ2Ugc3RhdHVzPXtvcmRlci5wYXltZW50LnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZnLW11dGVkXCI+e3Qubm9QYXltZW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkIGRhdGEtbGFiZWw9e3RyYW5zbGF0aW9ucy5vcmRlcnMuc3RhdHVzfSBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktY2VsbC12YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8QWRtaW5PcmRlclN0YXR1c0JhZGdlIHN0YXR1cz17b3JkZXIuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgIGRhdGEtbGFiZWw9e3RyYW5zbGF0aW9ucy5hZG1pbi5hY3Rpb25zfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS00IHRleHQtcmlnaHRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktY2VsbC12YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZmctbGluayBob3Zlcjp0ZXh0LWZnLWxpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRvPXtnZW5lcmF0ZVBhdGgoUk9VVEVTLmFkbWluT3JkZXJEZXRhaWwsIHsgaWQ6IG9yZGVyLmlkIH0pfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5vcmRlcnMudmlld31cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvdGJvZHk+XHJcbiAgICAgIDwvdGFibGU+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==