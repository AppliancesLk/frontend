import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/Icon.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Icon.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const paths = {
	mail: "M3 5h18v14H3ZM3 6l9 7 9-7",
	copy: "M9 9h12v12H9ZM5 15H3V3h12v2",
	menu: "M4 6h16M4 12h16M4 18h16",
	close: "m6 6 12 12M6 18 18 6",
	chat: "M21 11a8 8 0 0 1-8 8H7l-5 3V11a8 8 0 0 1 8-8h3a8 8 0 0 1 8 8ZM7 10h10M7 14h6",
	info: "M12 8h.01M12 11v6M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z",
	trash: "M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7",
	bag: "M4 7h16l1 14H3ZM8 8V6a4 4 0 0 1 8 0v2",
	shield: "M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6ZM8 12l3 3 5-6",
	truck: "M2 5h12v12H2ZM14 9h4l4 5v3h-8M8 18a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm12 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z",
	lock: "M5 10h14v11H5ZM8 10V6a4 4 0 0 1 8 0v4",
	phone: "M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Zm2 3h4m-3 14h2",
	laptop: "M5 3h14v13H5ZM2 20h20l-3-4H5Z",
	headphones: "M3 14v-3a9 9 0 0 1 18 0v3M3 12h4v9H3ZM17 12h4v9h-4Z",
	watch: "m8 7 1-5h6l1 5m-8 10 1 5h6l1-5M7 7h10v10H7Z",
	appliance: "M5 2h14v20H5ZM5 7h14M8 4h1m2 0h1m5 9a5 5 0 1 1-10 0 5 5 0 0 1 10 0",
	filter: "M4 6h16M7 12h10M10 18h4",
	home: "m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z",
	cart: "M3 3h2l3 12h11l3-9H6M9 21h.01M19 21h.01",
	orders: "M6 3h12v18l-3-2-3 2-3-2-3 2ZM9 7h6M9 11h6",
	repair: "m14 7 3 3 4-4a7 7 0 0 1-9 9l-6 6-3-3 6-6a7 7 0 0 1 9-9Z",
	user: "M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 5a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
	search: "m21 21-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0",
	arrow: "M4 12h16m-6-6 6 6-6 6",
	grid: "M3 3h7v7H3ZM14 3h7v7h-7ZM3 14h7v7H3ZM14 14h7v7h-7Z",
	check: "m5 12 4 4L19 6"
};
export function Icon({ name, className = "h-5 w-5" }) {
	return /* @__PURE__ */ _jsxDEV("svg", {
		"aria-hidden": "true",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.75",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		className,
		children: /* @__PURE__ */ _jsxDEV("path", { d: paths[name] }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_c = Icon;
var _c;
$RefreshReg$(_c, "Icon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/Icon.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Icon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Icon.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/Icon.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxNQUFNLFFBQVE7Q0FDWixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixPQUFPO0NBQ1AsTUFBTTtDQUNOLE1BQU07Q0FDTixPQUFPO0NBQ1AsS0FBSztDQUNMLFFBQVE7Q0FDUixPQUNFO0NBQ0YsTUFBTTtDQUNOLE9BQ0U7Q0FDRixRQUFRO0NBQ1IsWUFBWTtDQUNaLE9BQU87Q0FDUCxXQUNFO0NBQ0YsUUFBUTtDQUNSLE1BQU07Q0FDTixNQUFNO0NBQ04sUUFBUTtDQUNSLFFBQVE7Q0FDUixNQUFNO0NBQ04sUUFBUTtDQUNSLE9BQU87Q0FDUCxNQUFNO0NBQ04sT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLEtBQUssRUFDbkIsTUFDQSxZQUFZLGFBSVg7Q0FDRCxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxlQUFZO0VBQ1osU0FBUTtFQUNSLE1BQUs7RUFDTCxRQUFPO0VBQ1AsYUFBWTtFQUNaLGVBQWM7RUFDZCxnQkFBZTtFQUNKO1lBRVgsd0JBQUMsUUFBRCxFQUFNLEdBQUcsTUFBTSxNQUFROzs7OztDQUNwQjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJJY29uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBwYXRocyA9IHtcclxuICBtYWlsOiAnTTMgNWgxOHYxNEgzWk0zIDZsOSA3IDktNycsXHJcbiAgY29weTogJ005IDloMTJ2MTJIOVpNNSAxNUgzVjNoMTJ2MicsXHJcbiAgbWVudTogJ000IDZoMTZNNCAxMmgxNk00IDE4aDE2JyxcclxuICBjbG9zZTogJ202IDYgMTIgMTJNNiAxOCAxOCA2JyxcclxuICBjaGF0OiAnTTIxIDExYTggOCAwIDAgMS04IDhIN2wtNSAzVjExYTggOCAwIDAgMSA4LThoM2E4IDggMCAwIDEgOCA4Wk03IDEwaDEwTTcgMTRoNicsXHJcbiAgaW5mbzogJ00xMiA4aC4wMU0xMiAxMXY2TTIyIDEyYTEwIDEwIDAgMSAxLTIwIDAgMTAgMTAgMCAwIDEgMjAgMFonLFxyXG4gIHRyYXNoOiAnTTMgNmgxOE05IDZWM2g2djNNNSA2bDEgMTVoMTJsMS0xNU0xMCAxMHY3bTQtN3Y3JyxcclxuICBiYWc6ICdNNCA3aDE2bDEgMTRIM1pNOCA4VjZhNCA0IDAgMCAxIDggMHYyJyxcclxuICBzaGllbGQ6ICdNMTIgMiAzIDZ2NmMwIDUgOSAxMCA5IDEwczktNSA5LTEwVjZaTTggMTJsMyAzIDUtNicsXHJcbiAgdHJ1Y2s6XHJcbiAgICAnTTIgNWgxMnYxMkgyWk0xNCA5aDRsNCA1djNoLThNOCAxOGEyIDIgMCAxIDEtNCAwIDIgMiAwIDAgMSA0IDBabTEyIDBhMiAyIDAgMSAxLTQgMCAyIDIgMCAwIDEgNCAwWicsXHJcbiAgbG9jazogJ001IDEwaDE0djExSDVaTTggMTBWNmE0IDQgMCAwIDEgOCAwdjQnLFxyXG4gIHBob25lOlxyXG4gICAgJ004IDJoOGEyIDIgMCAwIDEgMiAydjE2YTIgMiAwIDAgMS0yIDJIOGEyIDIgMCAwIDEtMi0yVjRhMiAyIDAgMCAxIDItMlptMiAzaDRtLTMgMTRoMicsXHJcbiAgbGFwdG9wOiAnTTUgM2gxNHYxM0g1Wk0yIDIwaDIwbC0zLTRINVonLFxyXG4gIGhlYWRwaG9uZXM6ICdNMyAxNHYtM2E5IDkgMCAwIDEgMTggMHYzTTMgMTJoNHY5SDNaTTE3IDEyaDR2OWgtNFonLFxyXG4gIHdhdGNoOiAnbTggNyAxLTVoNmwxIDVtLTggMTAgMSA1aDZsMS01TTcgN2gxMHYxMEg3WicsXHJcbiAgYXBwbGlhbmNlOlxyXG4gICAgJ001IDJoMTR2MjBINVpNNSA3aDE0TTggNGgxbTIgMGgxbTUgOWE1IDUgMCAxIDEtMTAgMCA1IDUgMCAwIDEgMTAgMCcsXHJcbiAgZmlsdGVyOiAnTTQgNmgxNk03IDEyaDEwTTEwIDE4aDQnLFxyXG4gIGhvbWU6ICdtMyAxMCA5LTcgOSA3djEwYTEgMSAwIDAgMS0xIDFoLTV2LTdIOXY3SDRhMSAxIDAgMCAxLTEtMVonLFxyXG4gIGNhcnQ6ICdNMyAzaDJsMyAxMmgxMWwzLTlINk05IDIxaC4wMU0xOSAyMWguMDEnLFxyXG4gIG9yZGVyczogJ002IDNoMTJ2MThsLTMtMi0zIDItMy0yLTMgMlpNOSA3aDZNOSAxMWg2JyxcclxuICByZXBhaXI6ICdtMTQgNyAzIDMgNC00YTcgNyAwIDAgMS05IDlsLTYgNi0zLTMgNi02YTcgNyAwIDAgMSA5LTlaJyxcclxuICB1c2VyOiAnTTIwIDIxdi0yYTYgNiAwIDAgMC02LTZoLTRhNiA2IDAgMCAwLTYgNnYyTTE2IDVhNCA0IDAgMSAxLTggMCA0IDQgMCAwIDEgOCAwJyxcclxuICBzZWFyY2g6ICdtMjEgMjEtNS01TTE4IDEwYTggOCAwIDEgMS0xNiAwIDggOCAwIDAgMSAxNiAwJyxcclxuICBhcnJvdzogJ000IDEyaDE2bS02LTYgNiA2LTYgNicsXHJcbiAgZ3JpZDogJ00zIDNoN3Y3SDNaTTE0IDNoN3Y3aC03Wk0zIDE0aDd2N0gzWk0xNCAxNGg3djdoLTdaJyxcclxuICBjaGVjazogJ201IDEyIDQgNEwxOSA2JyxcclxufSBhcyBjb25zdDtcclxuZXhwb3J0IHR5cGUgSWNvbk5hbWUgPSBrZXlvZiB0eXBlb2YgcGF0aHM7XHJcbmV4cG9ydCBmdW5jdGlvbiBJY29uKHtcclxuICBuYW1lLFxyXG4gIGNsYXNzTmFtZSA9ICdoLTUgdy01JyxcclxufToge1xyXG4gIG5hbWU6IGtleW9mIHR5cGVvZiBwYXRocztcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHN2Z1xyXG4gICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICBzdHJva2VXaWR0aD1cIjEuNzVcIlxyXG4gICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XHJcbiAgICA+XHJcbiAgICAgIDxwYXRoIGQ9e3BhdGhzW25hbWVdfSAvPlxyXG4gICAgPC9zdmc+XHJcbiAgKTtcclxufVxyXG4iXX0=