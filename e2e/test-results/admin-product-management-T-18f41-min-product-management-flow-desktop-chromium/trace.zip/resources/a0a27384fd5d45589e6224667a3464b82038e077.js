import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Themes/components/ThemeConfiguration.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];import { seasonalPresets, seasonalText as t } from "/src/utils/seasonalText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeConfiguration.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function ThemeConfiguration({ draft, saving, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("fieldset", {
		disabled: saving || draft.theme === "DEFAULT",
		className: "rounded-lg border border-line bg-surface p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("legend", {
				className: "sr-only",
				children: t.customize
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-semibold",
				children: t.customize
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this),
			draft.theme === "DEFAULT" ? /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-sm leading-6 text-fg-muted",
				children: t.defaultHint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs leading-5 text-fg-muted",
					children: t.defaults
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "season-headline",
						className: "auth-label",
						children: t.headline
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "season-headline",
						className: "ui-field",
						maxLength: 80,
						value: draft.headline,
						placeholder: seasonalPresets[draft.theme].headline,
						onChange: (e) => onChange({
							...draft,
							headline: e.target.value
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "season-message",
						className: "auth-label",
						children: t.message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						id: "season-message",
						className: "ui-field min-h-28 py-3",
						maxLength: 180,
						value: draft.message,
						placeholder: seasonalPresets[draft.theme].message,
						onChange: (e) => onChange({
							...draft,
							message: e.target.value
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "mt-4 flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: draft.showGreeting,
						onChange: (e) => onChange({
							...draft,
							showGreeting: e.target.checked
						}),
						className: "h-5 w-5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 15
					}, this), t.greeting]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "mt-1 flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: draft.decorations,
						onChange: (e) => onChange({
							...draft,
							decorations: e.target.checked
						}),
						className: "h-5 w-5 shrink-0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 15
					}, this), t.decorations]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "mt-1 flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: draft.animations,
						disabled: !draft.decorations || !draft.showGreeting,
						onChange: (e) => onChange({
							...draft,
							animations: e.target.checked
						}),
						className: "h-5 w-5 shrink-0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 15
					}, this), t.animations]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs leading-5 text-fg-muted",
					children: t.motionHint
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 7
	}, this), draft.theme !== "DEFAULT" && /* @__PURE__ */ _jsxDEV("fieldset", {
		disabled: saving,
		className: "rounded-lg border border-line bg-surface p-5 sm:p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("legend", {
				className: "sr-only",
				children: t.timing
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-semibold",
				children: t.timing
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 space-y-3",
				children: ["NOW", "SCHEDULED"].map((timing) => /* @__PURE__ */ _jsxDEV("label", {
					className: "flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "radio",
						name: "seasonTiming",
						checked: draft.timing === timing,
						onChange: () => onChange({
							...draft,
							timing
						}),
						className: "h-5 w-5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 17
					}, this), timing === "NOW" ? t.now : t.schedule]
				}, timing, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 11
			}, this),
			draft.timing === "SCHEDULED" && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "season-start",
					className: "auth-label",
					children: t.startsAt
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "season-start",
					type: "datetime-local",
					required: true,
					className: "ui-field",
					value: draft.startsAt,
					onChange: (e) => onChange({
						...draft,
						startsAt: e.target.value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "season-end",
					className: "auth-label",
					children: t.endsAt
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "season-end",
					type: "datetime-local",
					className: "ui-field",
					value: draft.endsAt,
					onChange: (e) => onChange({
						...draft,
						endsAt: e.target.value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-xs leading-5 text-fg-muted",
				children: t.timezone
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_c = ThemeConfiguration;
var _c;
$RefreshReg$(_c, "ThemeConfiguration");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Themes/components/ThemeConfiguration.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeConfiguration.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeConfiguration.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Themes/components/ThemeConfiguration.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxpQkFDQSxnQkFBZ0IsU0FDWDs7O0FBR1AsT0FBTyxTQUFTLG1CQUFtQixFQUNqQyxPQUNBLFFBQ0EsWUFLQztDQUNELE9BQ0UsZ0RBQ0Usd0JBQUMsWUFBRDtFQUNFLFVBQVUsVUFBVSxNQUFNLFVBQVU7RUFDcEMsV0FBVTtZQUZaO0dBSUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBVyxFQUFFO0dBQWtCOzs7OztHQUNqRCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF5QixFQUFFO0dBQWM7Ozs7O0dBQ3RELE1BQU0sVUFBVSxZQUNmLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsRUFBRTtHQUNGOzs7O2NBRUg7SUFDRSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF3QyxFQUFFO0lBQVk7Ozs7O0lBQ25FLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxTQUFEO01BQU8sU0FBUTtNQUFrQixXQUFVO2dCQUN4QyxFQUFFO0tBQ0U7Ozs7ZUFDUCx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILFdBQVU7TUFDVixXQUFXO01BQ1gsT0FBTyxNQUFNO01BQ2IsYUFBYSxnQkFBZ0IsTUFBTSxNQUFNLENBQUM7TUFDMUMsV0FBVyxNQUNULFNBQVM7T0FBRSxHQUFHO09BQU8sVUFBVSxFQUFFLE9BQU87TUFBTSxDQUFDO0tBRWxEOzs7O2FBQ0U7Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxTQUFEO01BQU8sU0FBUTtNQUFpQixXQUFVO2dCQUN2QyxFQUFFO0tBQ0U7Ozs7ZUFDUCx3QkFBQyxZQUFEO01BQ0UsSUFBRztNQUNILFdBQVU7TUFDVixXQUFXO01BQ1gsT0FBTyxNQUFNO01BQ2IsYUFBYSxnQkFBZ0IsTUFBTSxNQUFNLENBQUM7TUFDMUMsV0FBVyxNQUNULFNBQVM7T0FBRSxHQUFHO09BQU8sU0FBUyxFQUFFLE9BQU87TUFBTSxDQUFDO0tBRWpEOzs7O2FBQ0U7Ozs7OztJQUNMLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxTQUFTLE1BQU07TUFDZixXQUFXLE1BQ1QsU0FBUztPQUNQLEdBQUc7T0FDSCxjQUFjLEVBQUUsT0FBTztNQUN6QixDQUFDO01BRUgsV0FBVTtLQUNYOzs7O2VBQ0EsRUFBRSxRQUNFOzs7Ozs7SUFDUCx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUyxNQUFNO01BQ2YsV0FBVyxNQUNULFNBQVM7T0FDUCxHQUFHO09BQ0gsYUFBYSxFQUFFLE9BQU87TUFDeEIsQ0FBQztNQUVILFdBQVU7S0FDWDs7OztlQUNBLEVBQUUsV0FDRTs7Ozs7O0lBQ1Asd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLFNBQVMsTUFBTTtNQUNmLFVBQVUsQ0FBQyxNQUFNLGVBQWUsQ0FBQyxNQUFNO01BQ3ZDLFdBQVcsTUFDVCxTQUFTO09BQUUsR0FBRztPQUFPLFlBQVksRUFBRSxPQUFPO01BQVEsQ0FBQztNQUVyRCxXQUFVO0tBQ1g7Ozs7ZUFDQSxFQUFFLFVBQ0U7Ozs7OztJQUNQLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsRUFBRTtJQUNGOzs7OztHQUNIOzs7OztFQUVJOzs7OztXQUNULE1BQU0sVUFBVSxhQUNmLHdCQUFDLFlBQUQ7RUFDRSxVQUFVO0VBQ1YsV0FBVTtZQUZaO0dBSUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBVyxFQUFFO0dBQWU7Ozs7O0dBQzlDLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXlCLEVBQUU7R0FBVzs7Ozs7R0FDcEQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWCxDQUFDLE9BQU8sV0FBVyxDQUFDLENBQVcsS0FBSyxXQUNwQyx3QkFBQyxTQUFEO0tBRUUsV0FBVTtlQUZaLENBSUUsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxNQUFLO01BQ0wsU0FBUyxNQUFNLFdBQVc7TUFDMUIsZ0JBQWdCLFNBQVM7T0FBRSxHQUFHO09BQU87TUFBTyxDQUFDO01BQzdDLFdBQVU7S0FDWDs7OztlQUNBLFdBQVcsUUFBUSxFQUFFLE1BQU0sRUFBRSxRQUN6QjtPQVhBOzs7O1dBV0EsQ0FDUjtHQUNFOzs7OztHQUNKLE1BQU0sV0FBVyxlQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsU0FBRDtLQUFPLFNBQVE7S0FBZSxXQUFVO2VBQ3JDLEVBQUU7SUFDRTs7OztjQUNQLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMO0tBQ0EsV0FBVTtLQUNWLE9BQU8sTUFBTTtLQUNiLFdBQVcsTUFDVCxTQUFTO01BQUUsR0FBRztNQUFPLFVBQVUsRUFBRSxPQUFPO0tBQU0sQ0FBQztJQUVsRDs7OztZQUNFOzs7Ozs7R0FFUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsU0FBRDtLQUFPLFNBQVE7S0FBYSxXQUFVO2VBQ25DLEVBQUU7SUFDRTs7OztjQUNQLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLFdBQVU7S0FDVixPQUFPLE1BQU07S0FDYixXQUFXLE1BQU0sU0FBUztNQUFFLEdBQUc7TUFBTyxRQUFRLEVBQUUsT0FBTztLQUFNLENBQUM7SUFDL0Q7Ozs7WUFDRTs7Ozs7O0dBQ0wsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBd0MsRUFBRTtHQUFZOzs7OztFQUMzRDs7Ozs7U0FFWjs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUaGVtZUNvbmZpZ3VyYXRpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgc2Vhc29uYWxQcmVzZXRzLFxyXG4gIHNlYXNvbmFsVGV4dCBhcyB0LFxyXG59IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3NlYXNvbmFsVGV4dCc7XHJcbmltcG9ydCB0eXBlIHsgVGhlbWVEcmFmdCB9IGZyb20gJy4uL2hlbHBlcnMvdGhlbWUuaGVscGVycyc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGhlbWVDb25maWd1cmF0aW9uKHtcclxuICBkcmFmdCxcclxuICBzYXZpbmcsXHJcbiAgb25DaGFuZ2UsXHJcbn06IHtcclxuICBkcmFmdDogVGhlbWVEcmFmdDtcclxuICBzYXZpbmc6IGJvb2xlYW47XHJcbiAgb25DaGFuZ2U6IChkcmFmdDogVGhlbWVEcmFmdCkgPT4gdm9pZDtcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZmllbGRzZXRcclxuICAgICAgICBkaXNhYmxlZD17c2F2aW5nIHx8IGRyYWZ0LnRoZW1lID09PSAnREVGQVVMVCd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTUgc206cC02XCJcclxuICAgICAgPlxyXG4gICAgICAgIDxsZWdlbmQgY2xhc3NOYW1lPVwic3Itb25seVwiPnt0LmN1c3RvbWl6ZX08L2xlZ2VuZD5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+e3QuY3VzdG9taXplfTwvaDI+XHJcbiAgICAgICAge2RyYWZ0LnRoZW1lID09PSAnREVGQVVMVCcgPyAoXHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgICAge3QuZGVmYXVsdEhpbnR9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBsZWFkaW5nLTUgdGV4dC1mZy1tdXRlZFwiPnt0LmRlZmF1bHRzfTwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJzZWFzb24taGVhZGxpbmVcIiBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICB7dC5oZWFkbGluZX1cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgaWQ9XCJzZWFzb24taGVhZGxpbmVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs4MH1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdC5oZWFkbGluZX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtzZWFzb25hbFByZXNldHNbZHJhZnQudGhlbWVdLmhlYWRsaW5lfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZSh7IC4uLmRyYWZ0LCBoZWFkbGluZTogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJzZWFzb24tbWVzc2FnZVwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgIHt0Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgIGlkPVwic2Vhc29uLW1lc3NhZ2VcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidWktZmllbGQgbWluLWgtMjggcHktM1wiXHJcbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezE4MH1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdC5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3NlYXNvbmFsUHJlc2V0c1tkcmFmdC50aGVtZV0ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2UoeyAuLi5kcmFmdCwgbWVzc2FnZTogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm10LTQgZmxleCBtaW4taC0xMSBpdGVtcy1jZW50ZXIgZ2FwLTMgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2RyYWZ0LnNob3dHcmVldGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLmRyYWZ0LFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dHcmVldGluZzogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNSB3LTVcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge3QuZ3JlZXRpbmd9XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtdC0xIGZsZXggbWluLWgtMTEgaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXtkcmFmdC5kZWNvcmF0aW9uc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLmRyYWZ0LFxyXG4gICAgICAgICAgICAgICAgICAgIGRlY29yYXRpb25zOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC01IHctNSBzaHJpbmstMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7dC5kZWNvcmF0aW9uc31cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm10LTEgZmxleCBtaW4taC0xMSBpdGVtcy1jZW50ZXIgZ2FwLTMgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2RyYWZ0LmFuaW1hdGlvbnN9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWRyYWZ0LmRlY29yYXRpb25zIHx8ICFkcmFmdC5zaG93R3JlZXRpbmd9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKHsgLi4uZHJhZnQsIGFuaW1hdGlvbnM6IGUudGFyZ2V0LmNoZWNrZWQgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNSB3LTUgc2hyaW5rLTBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge3QuYW5pbWF0aW9uc31cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAge3QubW90aW9uSGludH1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9maWVsZHNldD5cclxuICAgICAge2RyYWZ0LnRoZW1lICE9PSAnREVGQVVMVCcgJiYgKFxyXG4gICAgICAgIDxmaWVsZHNldFxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IHNtOnAtNlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGxlZ2VuZCBjbGFzc05hbWU9XCJzci1vbmx5XCI+e3QudGltaW5nfTwvbGVnZW5kPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPnt0LnRpbWluZ308L2gyPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICB7KFsnTk9XJywgJ1NDSEVEVUxFRCddIGFzIGNvbnN0KS5tYXAoKHRpbWluZykgPT4gKFxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAga2V5PXt0aW1pbmd9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTExIGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInNlYXNvblRpbWluZ1wiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2RyYWZ0LnRpbWluZyA9PT0gdGltaW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gb25DaGFuZ2UoeyAuLi5kcmFmdCwgdGltaW5nIH0pfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTUgdy01XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7dGltaW5nID09PSAnTk9XJyA/IHQubm93IDogdC5zY2hlZHVsZX1cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2RyYWZ0LnRpbWluZyA9PT0gJ1NDSEVEVUxFRCcgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInNlYXNvbi1zdGFydFwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgIHt0LnN0YXJ0c0F0fVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD1cInNlYXNvbi1zdGFydFwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWZpZWxkXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdC5zdGFydHNBdH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2UoeyAuLi5kcmFmdCwgc3RhcnRzQXQ6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic2Vhc29uLWVuZFwiIGNsYXNzTmFtZT1cImF1dGgtbGFiZWxcIj5cclxuICAgICAgICAgICAgICB7dC5lbmRzQXR9XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIGlkPVwic2Vhc29uLWVuZFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0LmVuZHNBdH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKHsgLi4uZHJhZnQsIGVuZHNBdDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyBsZWFkaW5nLTUgdGV4dC1mZy1tdXRlZFwiPnt0LnRpbWV6b25lfTwvcD5cclxuICAgICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXX0=