import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/OrderTimeline.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { formatDate } from "/src/utils/date.ts";
import { translations } from "/src/utils/translations.ts";
import { commerceText as t } from "/src/utils/commerceText.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/OrderTimeline.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function OrderTimeline({ history }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "rounded-md border border-line bg-surface p-5 sm:p-6",
		"aria-labelledby": "order-history",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			id: "order-history",
			className: "text-xl font-semibold",
			children: t.history
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this), !history?.length ? /* @__PURE__ */ _jsxDEV("p", {
			className: "mt-4 text-sm text-fg-muted",
			children: t.historyEmpty
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("ol", {
			className: "mt-5 space-y-5 border-l border-line pl-5",
			children: history.map((event) => /* @__PURE__ */ _jsxDEV("li", {
				className: "relative",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": "true",
						className: "absolute -left-[25px] top-1.5 h-2 w-2 rounded-full bg-primary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm font-medium",
						children: translations.orders.statuses[event.status]
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("time", {
						dateTime: event.createdAt,
						className: "mt-1 block text-xs text-fg-muted",
						children: formatDate(event.createdAt)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 15
					}, this)
				]
			}, event.id, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = OrderTimeline;
var _c;
$RefreshReg$(_c, "OrderTimeline");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/OrderTimeline.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/OrderTimeline.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/OrderTimeline.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/OrderTimeline.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxnQkFBZ0IsU0FBUzs7O0FBQ2xDLE9BQU8sU0FBUyxjQUFjLEVBQUUsV0FBMEM7Q0FDeEUsT0FDRSx3QkFBQyxXQUFEO0VBQ0UsV0FBVTtFQUNWLG1CQUFnQjtZQUZsQixDQUlFLHdCQUFDLE1BQUQ7R0FBSSxJQUFHO0dBQWdCLFdBQVU7YUFDOUIsRUFBRTtFQUNEOzs7O1lBQ0gsQ0FBQyxTQUFTLFNBQ1Qsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBOEIsRUFBRTtFQUFnQjs7OzthQUU3RCx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUNYLFFBQVEsS0FBSyxVQUNaLHdCQUFDLE1BQUQ7SUFBbUIsV0FBVTtjQUE3QjtLQUNFLHdCQUFDLFFBQUQ7TUFDRSxlQUFZO01BQ1osV0FBVTtLQUNYOzs7OztLQUNELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLGFBQWEsT0FBTyxTQUFTLE1BQU07S0FDbkM7Ozs7O0tBQ0gsd0JBQUMsUUFBRDtNQUNFLFVBQVUsTUFBTTtNQUNoQixXQUFVO2dCQUVULFdBQVcsTUFBTSxTQUFTO0tBQ3ZCOzs7OztJQUNKO01BZEssTUFBTTs7OztVQWNYLENBQ0w7RUFDQzs7OztVQUVDOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPcmRlclRpbWVsaW5lLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE9yZGVyIH0gZnJvbSAnLi4vLi4vdHlwZXMvb3JkZXIudHlwZXMnO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vdXRpbHMvZGF0ZSc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IGNvbW1lcmNlVGV4dCBhcyB0IH0gZnJvbSAnLi4vLi4vdXRpbHMvY29tbWVyY2VUZXh0JztcclxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyVGltZWxpbmUoeyBoaXN0b3J5IH06IHsgaGlzdG9yeTogT3JkZXJbJ2hpc3RvcnknXSB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uXHJcbiAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IHNtOnAtNlwiXHJcbiAgICAgIGFyaWEtbGFiZWxsZWRieT1cIm9yZGVyLWhpc3RvcnlcIlxyXG4gICAgPlxyXG4gICAgICA8aDIgaWQ9XCJvcmRlci1oaXN0b3J5XCIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAge3QuaGlzdG9yeX1cclxuICAgICAgPC9oMj5cclxuICAgICAgeyFoaXN0b3J5Py5sZW5ndGggPyAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZmctbXV0ZWRcIj57dC5oaXN0b3J5RW1wdHl9PC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxvbCBjbGFzc05hbWU9XCJtdC01IHNwYWNlLXktNSBib3JkZXItbCBib3JkZXItbGluZSBwbC01XCI+XHJcbiAgICAgICAgICB7aGlzdG9yeS5tYXAoKGV2ZW50KSA9PiAoXHJcbiAgICAgICAgICAgIDxsaSBrZXk9e2V2ZW50LmlkfSBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWxlZnQtWzI1cHhdIHRvcC0xLjUgaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLm9yZGVycy5zdGF0dXNlc1tldmVudC5zdGF0dXNdfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8dGltZVxyXG4gICAgICAgICAgICAgICAgZGF0ZVRpbWU9e2V2ZW50LmNyZWF0ZWRBdH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShldmVudC5jcmVhdGVkQXQpfVxyXG4gICAgICAgICAgICAgIDwvdGltZT5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvb2w+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=