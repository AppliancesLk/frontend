import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/RatingPlate.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/RatingPlate.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function RatingPlate({ title, reference, rows, footer }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "rating-plate",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "plate-heading",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this), reference && /* @__PURE__ */ _jsxDEV("span", {
					className: "plate-reference",
					children: reference
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 23
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("dl", { children: rows.map((row) => /* @__PURE__ */ _jsxDEV("div", {
				className: "plate-row",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: row.label }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: row.value }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 13
				}, this)]
			}, row.label, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 11
			}, this)) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 7
			}, this),
			footer && /* @__PURE__ */ _jsxDEV("div", {
				className: "plate-footer",
				children: footer
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 18
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = RatingPlate;
var _c;
$RefreshReg$(_c, "RatingPlate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/RatingPlate.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/RatingPlate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/RatingPlate.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/components/common/RatingPlate.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFDQSxPQUFPLFNBQVMsWUFBWSxFQUMxQixPQUNBLFdBQ0EsTUFDQSxVQU1DO0NBQ0QsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O2NBQ2xCLGFBQWEsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBbUI7SUFBZ0I7Ozs7WUFDOUQ7Ozs7OztHQUNMLHdCQUFDLE1BQUQsWUFDRyxLQUFLLEtBQUssUUFDVCx3QkFBQyxPQUFEO0lBQXFCLFdBQVU7Y0FBL0IsQ0FDRSx3QkFBQyxNQUFELFlBQUssSUFBSSxNQUFVOzs7O2NBQ25CLHdCQUFDLE1BQUQsWUFBSyxJQUFJLE1BQVU7Ozs7WUFDaEI7TUFISyxJQUFJOzs7O1VBR1QsQ0FDTixFQUNDOzs7OztHQUNILFVBQVUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZ0I7R0FBWTs7Ozs7RUFDbkQ7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJhdGluZ1BsYXRlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcclxuZXhwb3J0IGZ1bmN0aW9uIFJhdGluZ1BsYXRlKHtcclxuICB0aXRsZSxcclxuICByZWZlcmVuY2UsXHJcbiAgcm93cyxcclxuICBmb290ZXIsXHJcbn06IHtcclxuICB0aXRsZTogc3RyaW5nO1xyXG4gIHJlZmVyZW5jZT86IHN0cmluZztcclxuICByb3dzOiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBSZWFjdE5vZGUgfVtdO1xyXG4gIGZvb3Rlcj86IFJlYWN0Tm9kZTtcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJhdGluZy1wbGF0ZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYXRlLWhlYWRpbmdcIj5cclxuICAgICAgICA8c3Bhbj57dGl0bGV9PC9zcGFuPlxyXG4gICAgICAgIHtyZWZlcmVuY2UgJiYgPHNwYW4gY2xhc3NOYW1lPVwicGxhdGUtcmVmZXJlbmNlXCI+e3JlZmVyZW5jZX08L3NwYW4+fVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRsPlxyXG4gICAgICAgIHtyb3dzLm1hcCgocm93KSA9PiAoXHJcbiAgICAgICAgICA8ZGl2IGtleT17cm93LmxhYmVsfSBjbGFzc05hbWU9XCJwbGF0ZS1yb3dcIj5cclxuICAgICAgICAgICAgPGR0Pntyb3cubGFiZWx9PC9kdD5cclxuICAgICAgICAgICAgPGRkPntyb3cudmFsdWV9PC9kZD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2RsPlxyXG4gICAgICB7Zm9vdGVyICYmIDxkaXYgY2xhc3NOYW1lPVwicGxhdGUtZm9vdGVyXCI+e2Zvb3Rlcn08L2Rpdj59XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==