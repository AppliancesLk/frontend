import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Inventory/components/InventoryList.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/src/components/ui/Feedback.tsx";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/components/InventoryList.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export function InventoryList({ page }) {
	const { products, drafts, saving, messages, handleDraftChange, handleSave } = page;
	return /* @__PURE__ */ _jsxDEV("ul", {
		className: "space-y-3",
		children: products.map((product) => {
			const { productID } = product;
			const isSaving = saving[productID] === true;
			const message = messages[productID];
			const draft = drafts[productID] ?? String(product.stockQty);
			const isUnchanged = draft.trim() === String(product.stockQty);
			return /* @__PURE__ */ _jsxDEV("li", {
				className: "rounded-md border border-line bg-surface p-5 ",
				children: /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: (event) => void handleSave(event, product),
					className: "flex flex-col gap-4 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "font-semibold text-fg",
									children: product.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 31,
									columnNumber: 19
								}, this), !product.isActive && /* @__PURE__ */ _jsxDEV("span", {
									className: "rounded-full bg-subtle px-2 py-1 text-xs font-medium text-fg-secondary",
									children: translations.admin.inactive
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 34,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 30,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 text-sm text-fg-muted",
								children: [
									translations.admin.sku,
									": ",
									product.SKU,
									" |",
									" ",
									product.category.name
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 text-sm text-fg-secondary",
								children: [
									translations.admin.currentStock,
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold",
										children: product.stockQty
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 47,
										columnNumber: 19
									}, this),
									product.stockQty === 0 && /* @__PURE__ */ _jsxDEV("span", {
										className: "ml-2 rounded-full bg-danger-bg px-2 py-1 text-xs font-medium text-danger",
										children: translations.admin.outOfStock
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 49,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								inputMode: "numeric",
								value: draft,
								onChange: (event) => handleDraftChange(productID, event.target.value),
								disabled: isSaving,
								"aria-label": `${translations.admin.newStockLabel} ${product.name}`,
								"aria-invalid": message?.type === "error",
								className: "ui-field w-28 rounded-sm border border-line px-3 py-2 text-sm text-fg focus:border-primary focus:outline-none disabled:bg-subtle"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: isSaving || isUnchanged,
								className: "ui-button ui-button-primary rounded-sm bg-primary px-4 py-2 text-sm font-medium text-primary-on transition hover:bg-primary-hover disabled:cursor-not-allowed ",
								children: [isSaving && /* @__PURE__ */ _jsxDEV(Spinner, { className: "mr-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 34
								}, this), isSaving ? translations.admin.saving : translations.admin.save]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 17
						}, this), message && /* @__PURE__ */ _jsxDEV("p", {
							role: message.type === "error" ? "alert" : "status",
							className: `mt-2 text-sm ${message.type === "error" ? "text-danger" : "text-success"}`,
							children: message.text
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 13
				}, this)
			}, productID, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 11
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = InventoryList;
var _c;
$RefreshReg$(_c, "InventoryList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Inventory/components/InventoryList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/components/InventoryList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/components/InventoryList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Inventory/components/InventoryList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBRXhCLFNBQVMsb0JBQW9COzs7QUFDN0IsT0FBTyxTQUFTLGNBQWMsRUFDNUIsUUFHQztDQUNELE1BQU0sRUFBRSxVQUFVLFFBQVEsUUFBUSxVQUFVLG1CQUFtQixlQUM3RDtDQUNGLE9BQ0Usd0JBQUMsTUFBRDtFQUFJLFdBQVU7WUFDWCxTQUFTLEtBQUssWUFBWTtHQUN6QixNQUFNLEVBQUUsY0FBYztHQUN0QixNQUFNLFdBQVcsT0FBTyxlQUFlO0dBQ3ZDLE1BQU0sVUFBVSxTQUFTO0dBQ3pCLE1BQU0sUUFBUSxPQUFPLGNBQWMsT0FBTyxRQUFRLFFBQVE7R0FDMUQsTUFBTSxjQUFjLE1BQU0sS0FBSyxNQUFNLE9BQU8sUUFBUSxRQUFRO0dBRTVELE9BQ0Usd0JBQUMsTUFBRDtJQUVFLFdBQVU7Y0FFVix3QkFBQyxRQUFEO0tBQ0UsV0FBVyxVQUFVLEtBQUssV0FBVyxPQUFPLE9BQU87S0FDbkQsV0FBVTtlQUZaLENBSUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QixRQUFRO1FBQVM7Ozs7a0JBRXZELENBQUMsUUFBUSxZQUNSLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLGFBQWEsTUFBTTtRQUNoQjs7OztnQkFFTDs7Ozs7O09BRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FDRyxhQUFhLE1BQU07U0FBSTtTQUFHLFFBQVE7U0FBSTtTQUFHO1NBQ3pDLFFBQVEsU0FBUztRQUNqQjs7Ozs7O09BRUgsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FDRyxhQUFhLE1BQU07U0FBYztTQUNsQyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUIsUUFBUTtTQUFlOzs7OztTQUN2RCxRQUFRLGFBQWEsS0FDcEIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsYUFBYSxNQUFNO1NBQ2hCOzs7OztRQUVQOzs7Ozs7TUFDQTs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO1FBQ1YsT0FBTztRQUNQLFdBQVcsVUFDVCxrQkFBa0IsV0FBVyxNQUFNLE9BQU8sS0FBSztRQUVqRCxVQUFVO1FBQ1YsY0FBWSxHQUFHLGFBQWEsTUFBTSxjQUFjLEdBQUcsUUFBUTtRQUMzRCxnQkFBYyxTQUFTLFNBQVM7UUFDaEMsV0FBVTtPQUNYOzs7O2lCQUVELHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVSxZQUFZO1FBQ3RCLFdBQVU7a0JBSFosQ0FLRyxZQUFZLHdCQUFDLFNBQUQsRUFBUyxXQUFVLE9BQVE7Ozs7a0JBQ3ZDLFdBQ0csYUFBYSxNQUFNLFNBQ25CLGFBQWEsTUFBTSxJQUNqQjs7Ozs7ZUFDTDs7Ozs7Z0JBRUosV0FDQyx3QkFBQyxLQUFEO09BQ0UsTUFBTSxRQUFRLFNBQVMsVUFBVSxVQUFVO09BQzNDLFdBQVcsZ0JBQ1QsUUFBUSxTQUFTLFVBQVUsZ0JBQWdCO2lCQUc1QyxRQUFRO01BQ1I7Ozs7Y0FFRjs7Ozs7YUFDRDs7Ozs7O0dBQ0osR0F6RUc7Ozs7VUF5RUg7RUFFUixDQUFDO0NBQ0M7Ozs7O0FBRVIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW52ZW50b3J5TGlzdC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvRmVlZGJhY2snO1xyXG5pbXBvcnQgdHlwZSB7IHVzZUludmVudG9yeVBhZ2UgfSBmcm9tICcuLi9ob29rcy91c2VJbnZlbnRvcnlQYWdlJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuZXhwb3J0IGZ1bmN0aW9uIEludmVudG9yeUxpc3Qoe1xyXG4gIHBhZ2UsXHJcbn06IHtcclxuICBwYWdlOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VJbnZlbnRvcnlQYWdlPjtcclxufSkge1xyXG4gIGNvbnN0IHsgcHJvZHVjdHMsIGRyYWZ0cywgc2F2aW5nLCBtZXNzYWdlcywgaGFuZGxlRHJhZnRDaGFuZ2UsIGhhbmRsZVNhdmUgfSA9XHJcbiAgICBwYWdlO1xyXG4gIHJldHVybiAoXHJcbiAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgIHtwcm9kdWN0cy5tYXAoKHByb2R1Y3QpID0+IHtcclxuICAgICAgICBjb25zdCB7IHByb2R1Y3RJRCB9ID0gcHJvZHVjdDtcclxuICAgICAgICBjb25zdCBpc1NhdmluZyA9IHNhdmluZ1twcm9kdWN0SURdID09PSB0cnVlO1xyXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBtZXNzYWdlc1twcm9kdWN0SURdO1xyXG4gICAgICAgIGNvbnN0IGRyYWZ0ID0gZHJhZnRzW3Byb2R1Y3RJRF0gPz8gU3RyaW5nKHByb2R1Y3Quc3RvY2tRdHkpO1xyXG4gICAgICAgIGNvbnN0IGlzVW5jaGFuZ2VkID0gZHJhZnQudHJpbSgpID09PSBTdHJpbmcocHJvZHVjdC5zdG9ja1F0eSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8bGlcclxuICAgICAgICAgICAga2V5PXtwcm9kdWN0SUR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcC01IFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgb25TdWJtaXQ9eyhldmVudCkgPT4gdm9pZCBoYW5kbGVTYXZlKGV2ZW50LCBwcm9kdWN0KX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBtZDpqdXN0aWZ5LWJldHdlZW5cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZnXCI+e3Byb2R1Y3QubmFtZX08L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgeyFwcm9kdWN0LmlzQWN0aXZlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctc3VidGxlIHB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNsYXRpb25zLmFkbWluLmluYWN0aXZlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuYWRtaW4uc2t1fToge3Byb2R1Y3QuU0tVfSB8eycgJ31cclxuICAgICAgICAgICAgICAgICAge3Byb2R1Y3QuY2F0ZWdvcnkubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1mZy1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5hZG1pbi5jdXJyZW50U3RvY2t9eycgJ31cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntwcm9kdWN0LnN0b2NrUXR5fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge3Byb2R1Y3Quc3RvY2tRdHkgPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgcm91bmRlZC1mdWxsIGJnLWRhbmdlci1iZyBweC0yIHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWRhbmdlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zbGF0aW9ucy5hZG1pbi5vdXRPZlN0b2NrfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEcmFmdENoYW5nZShwcm9kdWN0SUQsIGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2Ake3RyYW5zbGF0aW9ucy5hZG1pbi5uZXdTdG9ja0xhYmVsfSAke3Byb2R1Y3QubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17bWVzc2FnZT8udHlwZSA9PT0gJ2Vycm9yJ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1maWVsZCB3LTI4IHJvdW5kZWQtc20gYm9yZGVyIGJvcmRlci1saW5lIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZmcgZm9jdXM6Ym9yZGVyLXByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lIGRpc2FibGVkOmJnLXN1YnRsZVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nIHx8IGlzVW5jaGFuZ2VkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLWJ1dHRvbiB1aS1idXR0b24tcHJpbWFyeSByb3VuZGVkLXNtIGJnLXByaW1hcnkgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LW9uIHRyYW5zaXRpb24gaG92ZXI6YmctcHJpbWFyeS1ob3ZlciBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpc1NhdmluZyAmJiA8U3Bpbm5lciBjbGFzc05hbWU9XCJtci0yXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAge2lzU2F2aW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IHRyYW5zbGF0aW9ucy5hZG1pbi5zYXZpbmdcclxuICAgICAgICAgICAgICAgICAgICAgIDogdHJhbnNsYXRpb25zLmFkbWluLnNhdmV9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge21lc3NhZ2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgICAgICAgIHJvbGU9e21lc3NhZ2UudHlwZSA9PT0gJ2Vycm9yJyA/ICdhbGVydCcgOiAnc3RhdHVzJ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtdC0yIHRleHQtc20gJHtcclxuICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudHlwZSA9PT0gJ2Vycm9yJyA/ICd0ZXh0LWRhbmdlcicgOiAndGV4dC1zdWNjZXNzJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge21lc3NhZ2UudGV4dH1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICApO1xyXG4gICAgICB9KX1cclxuICAgIDwvdWw+XHJcbiAgKTtcclxufVxyXG4iXX0=