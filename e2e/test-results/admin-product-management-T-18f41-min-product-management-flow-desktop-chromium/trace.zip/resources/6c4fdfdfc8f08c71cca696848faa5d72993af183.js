import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Banners/index.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=89206e9e";
import { getBanners } from "/src/services/bannerService.ts";
import { BANNER_POSITIONS } from "/src/types/banner.types.ts";
import { translations } from "/src/utils/translations.ts";
import { CatalogFeedback } from "/src/components/feedback/CatalogFeedback.tsx";
import { BannerSectionEditor } from "/src/pages/Admin/Banners/components/BannerSectionEditor.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/index.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
var _s = $RefreshSig$();
const t = translations.storefront;
export default function BannersPage() {
	_s();
	const [sections, setSections] = useState(null);
	const [error, setError] = useState("");
	const [revision, setRevision] = useState(0);
	useEffect(() => {
		let active = true;
		void getBanners(true).then((data) => {
			if (active) setSections(data);
		}).catch(() => {
			if (active) setError(t.loadError);
		});
		return () => {
			active = false;
		};
	}, [revision]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "mx-auto max-w-5xl",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title text-fg",
				children: t.banners
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mb-8 mt-3 text-sm leading-6 text-fg-secondary",
				children: t.bannerDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogFeedback, {
				loading: !sections && !error,
				error,
				retry: () => {
					setError("");
					setRevision((value) => value + 1);
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			sections && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: BANNER_POSITIONS.map((position) => /* @__PURE__ */ _jsxDEV(BannerSectionEditor, { section: sections.find((section) => section.position === position) ?? {
					position,
					visible: false,
					slides: []
				} }, position, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
}
_s(BannersPage, "Yga8YRzMTRjbNJFZW5t7pFxb0JI=");
_c = BannersPage;
var _c;
$RefreshReg$(_c, "BannersPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Admin/Banners/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Admin/Banners/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGtCQUFrQjtBQUMzQixTQUNFLHdCQUVLO0FBQ1AsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUywyQkFBMkI7Ozs7QUFDcEMsTUFBTSxJQUFJLGFBQWE7QUFDdkIsZUFBZSxTQUFTLGNBQWM7O0NBQ3BDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUMsSUFBSTtDQUNyRSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUMxQyxnQkFBZ0I7RUFDZCxJQUFJLFNBQVM7RUFDYixLQUFLLFdBQVcsSUFBSSxDQUFDLENBQ2xCLE1BQU0sU0FBUztHQUNkLElBQUksUUFBUSxZQUFZLElBQUk7RUFDOUIsQ0FBQyxDQUFDLENBQ0QsWUFBWTtHQUNYLElBQUksUUFBUSxTQUFTLEVBQUUsU0FBUztFQUNsQyxDQUFDO0VBQ0gsYUFBYTtHQUNYLFNBQVM7RUFDWDtDQUNGLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDYixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF5QixFQUFFO0dBQVk7Ozs7O0dBQ3JELHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsRUFBRTtHQUNGOzs7OztHQUNILHdCQUFDLGlCQUFEO0lBQ0UsU0FBUyxDQUFDLFlBQVksQ0FBQztJQUNoQjtJQUNQLGFBQWE7S0FDWCxTQUFTLEVBQUU7S0FDWCxhQUFhLFVBQVUsUUFBUSxDQUFDO0lBQ2xDO0dBQ0Q7Ozs7O0dBQ0EsWUFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLGlCQUFpQixLQUFLLGFBQ3JCLHdCQUFDLHFCQUFELEVBRUUsU0FDRSxTQUFTLE1BQU0sWUFBWSxRQUFRLGFBQWEsUUFBUSxLQUFLO0tBQzNEO0tBQ0EsU0FBUztLQUNULFFBQVEsQ0FBQztJQUNYLEVBRUgsR0FSTTs7OztXQVFOLENBQ0Y7R0FDRTs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IGdldEJhbm5lcnMgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9iYW5uZXJTZXJ2aWNlJztcclxuaW1wb3J0IHtcclxuICBCQU5ORVJfUE9TSVRJT05TLFxyXG4gIHR5cGUgQmFubmVyU2VjdGlvbixcclxufSBmcm9tICcuLi8uLi8uLi90eXBlcy9iYW5uZXIudHlwZXMnO1xyXG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgeyBDYXRhbG9nRmVlZGJhY2sgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2ZlZWRiYWNrL0NhdGFsb2dGZWVkYmFjayc7XHJcbmltcG9ydCB7IEJhbm5lclNlY3Rpb25FZGl0b3IgfSBmcm9tICcuL2NvbXBvbmVudHMvQmFubmVyU2VjdGlvbkVkaXRvcic7XHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMuc3RvcmVmcm9udDtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFubmVyc1BhZ2UoKSB7XHJcbiAgY29uc3QgW3NlY3Rpb25zLCBzZXRTZWN0aW9uc10gPSB1c2VTdGF0ZTxCYW5uZXJTZWN0aW9uW10gfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbcmV2aXNpb24sIHNldFJldmlzaW9uXSA9IHVzZVN0YXRlKDApO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZTtcclxuICAgIHZvaWQgZ2V0QmFubmVycyh0cnVlKVxyXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICAgIGlmIChhY3RpdmUpIHNldFNlY3Rpb25zKGRhdGEpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgIGlmIChhY3RpdmUpIHNldEVycm9yKHQubG9hZEVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBhY3RpdmUgPSBmYWxzZTtcclxuICAgIH07XHJcbiAgfSwgW3JldmlzaW9uXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy01eGxcIj5cclxuICAgICAgPGgxIGNsYXNzTmFtZT1cInVpLXBhZ2UtdGl0bGUgdGV4dC1mZ1wiPnt0LmJhbm5lcnN9PC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibWItOCBtdC0zIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAge3QuYmFubmVyRGVzY3JpcHRpb259XHJcbiAgICAgIDwvcD5cclxuICAgICAgPENhdGFsb2dGZWVkYmFja1xyXG4gICAgICAgIGxvYWRpbmc9eyFzZWN0aW9ucyAmJiAhZXJyb3J9XHJcbiAgICAgICAgZXJyb3I9e2Vycm9yfVxyXG4gICAgICAgIHJldHJ5PXsoKSA9PiB7XHJcbiAgICAgICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgICAgICBzZXRSZXZpc2lvbigodmFsdWUpID0+IHZhbHVlICsgMSk7XHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuICAgICAge3NlY3Rpb25zICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAge0JBTk5FUl9QT1NJVElPTlMubWFwKChwb3NpdGlvbikgPT4gKFxyXG4gICAgICAgICAgICA8QmFubmVyU2VjdGlvbkVkaXRvclxyXG4gICAgICAgICAgICAgIGtleT17cG9zaXRpb259XHJcbiAgICAgICAgICAgICAgc2VjdGlvbj17XHJcbiAgICAgICAgICAgICAgICBzZWN0aW9ucy5maW5kKChzZWN0aW9uKSA9PiBzZWN0aW9uLnBvc2l0aW9uID09PSBwb3NpdGlvbikgPz8ge1xyXG4gICAgICAgICAgICAgICAgICBwb3NpdGlvbixcclxuICAgICAgICAgICAgICAgICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgIHNsaWRlczogW10sXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==