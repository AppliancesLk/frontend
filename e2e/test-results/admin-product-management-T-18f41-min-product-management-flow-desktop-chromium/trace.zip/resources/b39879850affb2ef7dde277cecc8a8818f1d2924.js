import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NotFound/index.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
import { uiText } from "/src/utils/uiText.ts";
import { EmptyState } from "/src/components/ui/Feedback.tsx";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/NotFound/index.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
export default function NotFoundPage() {
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto max-w-3xl px-4 py-12 sm:py-20",
		children: [/* @__PURE__ */ _jsxDEV("p", {
			className: "mb-6 text-center text-xs font-semibold tracking-normal text-fg-link",
			children: "404"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(EmptyState, {
			headingAs: "h1",
			icon: "search",
			title: translations.common.notFound,
			description: uiText.notFoundDescription,
			action: /* @__PURE__ */ _jsxDEV(Link, {
				className: "auth-primary",
				to: ROUTES.products,
				children: translations.common.backToShop
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = NotFoundPage;
var _c;
$RefreshReg$(_c, "NotFoundPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/NotFound/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/NotFound/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/NotFound/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/NotFound/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxrQkFBa0I7OztBQUMzQixlQUFlLFNBQVMsZUFBZTtDQUNyQyxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQ0Usd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBc0U7RUFFaEY7Ozs7WUFDSCx3QkFBQyxZQUFEO0dBQ0UsV0FBVTtHQUNWLE1BQUs7R0FDTCxPQUFPLGFBQWEsT0FBTztHQUMzQixhQUFhLE9BQU87R0FDcEIsUUFDRSx3QkFBQyxNQUFEO0lBQU0sV0FBVTtJQUFlLElBQUksT0FBTztjQUN2QyxhQUFhLE9BQU87R0FDakI7Ozs7O0VBRVQ7Ozs7VUFDRzs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnLi4vLi4vY29uc3RhbnRzL3JvdXRlcyc7XHJcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XHJcbmltcG9ydCB7IHVpVGV4dCB9IGZyb20gJy4uLy4uL3V0aWxzL3VpVGV4dCc7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTm90Rm91bmRQYWdlKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTN4bCBweC00IHB5LTEyIHNtOnB5LTIwXCI+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTYgdGV4dC1jZW50ZXIgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYWNraW5nLW5vcm1hbCB0ZXh0LWZnLWxpbmtcIj5cclxuICAgICAgICA0MDRcclxuICAgICAgPC9wPlxyXG4gICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgIGhlYWRpbmdBcz1cImgxXCJcclxuICAgICAgICBpY29uPVwic2VhcmNoXCJcclxuICAgICAgICB0aXRsZT17dHJhbnNsYXRpb25zLmNvbW1vbi5ub3RGb3VuZH1cclxuICAgICAgICBkZXNjcmlwdGlvbj17dWlUZXh0Lm5vdEZvdW5kRGVzY3JpcHRpb259XHJcbiAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImF1dGgtcHJpbWFyeVwiIHRvPXtST1VURVMucHJvZHVjdHN9PlxyXG4gICAgICAgICAgICB7dHJhbnNsYXRpb25zLmNvbW1vbi5iYWNrVG9TaG9wfVxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdfQ==