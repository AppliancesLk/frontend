import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Skeleton } from "/src/components/ui/Feedback.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=76776d4b";
import { ROUTES } from "/src/constants/routes.ts";
import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.productDetails;
export function ProductDetailsState({ status, retry }) {
	if (status === "loading") return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		"aria-label": "Loading product",
		className: "grid gap-6 md:grid-cols-2 xl:grid-cols-[1.3fr_1fr_.9fr]",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Loading product…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "aspect-square w-full" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-1/3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-4 h-8 w-full" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-3 h-8 w-3/4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-8 h-64 w-full" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-4 rounded-lg border border-line bg-surface p-6",
				children: [
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-10 w-4/5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-1/2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-8 h-12 w-full" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-12 w-full" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 7
	}, this);
	const missing = status === "not-found";
	return /* @__PURE__ */ _jsxDEV("section", {
		role: missing ? undefined : "alert",
		className: "mx-auto max-w-xl rounded-md border border-line bg-surface px-6 py-12 text-center ",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "ui-page-title text-fg",
				children: missing ? t.notFound : t.loadError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-sm leading-6 text-fg-muted",
				children: missing ? t.notFoundDescription : t.loadErrorDescription
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 flex flex-wrap justify-center gap-3",
				children: [!missing && /* @__PURE__ */ _jsxDEV("button", {
					onClick: retry,
					className: "auth-primary",
					children: translations.common.retry
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.products,
					className: "auth-secondary",
					children: t.backToProducts
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_c = ProductDetailsState;
var _c;
$RefreshReg$(_c, "ProductDetailsState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/ProductDetails/components/ProductDetailsState.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjs7O0FBQzdCLE1BQU0sSUFBSSxhQUFhO0FBQ3ZCLE9BQU8sU0FBUyxvQkFBb0IsRUFDbEMsUUFDQSxTQUlDO0NBQ0QsSUFBSSxXQUFXLFdBQ2IsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsTUFBSztFQUNMLGNBQVc7RUFDWCxXQUFVO1lBSFo7R0FLRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFVO0dBQXNCOzs7OztHQUNoRCx3QkFBQyxVQUFELEVBQVUsV0FBVSx1QkFBd0I7Ozs7O0dBQzVDLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxZQUFhOzs7OztJQUNqQyx3QkFBQyxVQUFELEVBQVUsV0FBVSxrQkFBbUI7Ozs7O0lBQ3ZDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGlCQUFrQjs7Ozs7SUFDdEMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsbUJBQW9COzs7OztHQUNyQzs7Ozs7R0FDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsYUFBYzs7Ozs7S0FDbEMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsWUFBYTs7Ozs7S0FDakMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsbUJBQW9COzs7OztLQUN4Qyx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7OztJQUNoQzs7Ozs7O0VBQ0Y7Ozs7OztDQUVULE1BQU0sVUFBVSxXQUFXO0NBQzNCLE9BQ0Usd0JBQUMsV0FBRDtFQUNFLE1BQU0sVUFBVSxZQUFZO0VBQzVCLFdBQVU7WUFGWjtHQUlFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsVUFBVSxFQUFFLFdBQVcsRUFBRTtHQUN4Qjs7Ozs7R0FDSix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNWLFVBQVUsRUFBRSxzQkFBc0IsRUFBRTtHQUNwQzs7Ozs7R0FDSCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0csQ0FBQyxXQUNBLHdCQUFDLFVBQUQ7S0FBUSxTQUFTO0tBQU8sV0FBVTtlQUMvQixhQUFhLE9BQU87SUFDZjs7OztjQUVWLHdCQUFDLE1BQUQ7S0FBTSxJQUFJLE9BQU87S0FBVSxXQUFVO2VBQ2xDLEVBQUU7SUFDQzs7OztZQUNIOzs7Ozs7RUFDRTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdERldGFpbHNTdGF0ZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0ZlZWRiYWNrJztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tICcuLi8uLi8uLi8uLi9jb25zdGFudHMvcm91dGVzJztcclxuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcclxuY29uc3QgdCA9IHRyYW5zbGF0aW9ucy5wcm9kdWN0RGV0YWlscztcclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3REZXRhaWxzU3RhdGUoe1xyXG4gIHN0YXR1cyxcclxuICByZXRyeSxcclxufToge1xyXG4gIHN0YXR1czogJ2xvYWRpbmcnIHwgJ2Vycm9yJyB8ICdub3QtZm91bmQnO1xyXG4gIHJldHJ5OiAoKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgaWYgKHN0YXR1cyA9PT0gJ2xvYWRpbmcnKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdlxyXG4gICAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICAgIGFyaWEtbGFiZWw9XCJMb2FkaW5nIHByb2R1Y3RcIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLVsxLjNmcl8xZnJfLjlmcl1cIlxyXG4gICAgICA+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkxvYWRpbmcgcHJvZHVjdOKApjwvc3Bhbj5cclxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGxcIiAvPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctMS8zXCIgLz5cclxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJtdC00IGgtOCB3LWZ1bGxcIiAvPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cIm10LTMgaC04IHctMy80XCIgLz5cclxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJtdC04IGgtNjQgdy1mdWxsXCIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlIHAtNlwiPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMTAgdy00LzVcIiAvPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LTEvMlwiIC8+XHJcbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwibXQtOCBoLTEyIHctZnVsbFwiIC8+XHJcbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0xMiB3LWZ1bGxcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgY29uc3QgbWlzc2luZyA9IHN0YXR1cyA9PT0gJ25vdC1mb3VuZCc7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uXHJcbiAgICAgIHJvbGU9e21pc3NpbmcgPyB1bmRlZmluZWQgOiAnYWxlcnQnfVxyXG4gICAgICBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LXhsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UgcHgtNiBweS0xMiB0ZXh0LWNlbnRlciBcIlxyXG4gICAgPlxyXG4gICAgICA8aDEgY2xhc3NOYW1lPVwidWktcGFnZS10aXRsZSB0ZXh0LWZnXCI+XHJcbiAgICAgICAge21pc3NpbmcgPyB0Lm5vdEZvdW5kIDogdC5sb2FkRXJyb3J9XHJcbiAgICAgIDwvaDE+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgIHttaXNzaW5nID8gdC5ub3RGb3VuZERlc2NyaXB0aW9uIDogdC5sb2FkRXJyb3JEZXNjcmlwdGlvbn1cclxuICAgICAgPC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBmbGV4LXdyYXAganVzdGlmeS1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICB7IW1pc3NpbmcgJiYgKFxyXG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtyZXRyeX0gY2xhc3NOYW1lPVwiYXV0aC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2xhdGlvbnMuY29tbW9uLnJldHJ5fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8TGluayB0bz17Uk9VVEVTLnByb2R1Y3RzfSBjbGFzc05hbWU9XCJhdXRoLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAge3QuYmFja1RvUHJvZHVjdHN9XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==