import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { translations } from "/src/utils/translations.ts";
var _jsxFileName = "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=89206e9e";
const t = translations.repairs;
const fields = [
	{
		name: "deviceType",
		label: t.deviceType,
		maxLength: 100,
		hint: t.deviceTypeHint
	},
	{
		name: "brand",
		label: t.brand,
		maxLength: 100,
		hint: t.brandHint
	},
	{
		name: "model",
		label: t.model,
		maxLength: 100,
		hint: t.modelHint
	},
	{
		name: "serialNumber",
		label: t.serialNumber,
		maxLength: 100,
		optional: true,
		hint: t.serialNumberHint
	},
	{
		name: "purchaseDate",
		label: t.purchaseDate,
		maxLength: 10,
		optional: true,
		hint: t.purchaseDateHint,
		type: "date"
	}
];
export function RepairRequestForm({ page }) {
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: (event) => void page.submit(event),
		noValidate: true,
		className: "repair-request-form space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-5  sm:p-6",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "flex items-center gap-3 text-xl font-semibold text-fg",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "form-step-number",
							children: "1"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 11
						}, this), t.deviceInformation]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm leading-6 text-fg-muted",
						children: [
							"All fields are required unless marked optional.",
							" ",
							t.deviceInformationDescription
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("fieldset", {
						disabled: page.submitting,
						className: "mt-6 grid min-w-0 gap-5 sm:grid-cols-2",
						children: [/* @__PURE__ */ _jsxDEV("legend", {
							className: "sr-only",
							children: t.deviceInformation
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 11
						}, this), fields.map((field) => /* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: `repair-${field.name}`,
								className: "auth-label",
								children: [field.label, field.optional && /* @__PURE__ */ _jsxDEV("span", {
									className: "ml-1 font-normal text-fg-muted",
									children: t.optional
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: `repair-${field.name}`,
								name: field.name,
								type: field.type ?? "text",
								required: !field.optional,
								maxLength: field.maxLength,
								value: page.draft[field.name],
								onChange: (event) => page.change(field.name, event.target.value),
								"aria-invalid": !!page.errors[field.name],
								"aria-describedby": page.errors[field.name] ? `${field.name}-error` : field.hint ? `${field.name}-hint` : undefined,
								className: `auth-input ${page.errors[field.name] ? "border-danger/25" : ""}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 15
							}, this),
							field.hint && /* @__PURE__ */ _jsxDEV("p", {
								id: `${field.name}-hint`,
								className: "mt-1.5 text-xs leading-5 text-fg-muted",
								children: field.hint
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 17
							}, this),
							page.errors[field.name] && /* @__PURE__ */ _jsxDEV("p", {
								id: `${field.name}-error`,
								className: "mt-1.5 text-sm text-danger",
								children: page.errors[field.name]
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 17
							}, this)
						] }, field.name, true, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-md border border-line bg-surface p-5  sm:p-6",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "flex items-center gap-3 text-xl font-semibold text-fg",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "form-step-number",
							children: "2"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 11
						}, this), t.problemDescription]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-sm leading-6 text-fg-muted",
						children: t.problemDescriptionHint
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("fieldset", {
						disabled: page.submitting,
						className: "mt-6",
						children: [
							/* @__PURE__ */ _jsxDEV("legend", {
								className: "sr-only",
								children: t.problemDescription
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "repair-problemDescription",
								className: "auth-label",
								children: t.problemDescriptionLabel
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								id: "repair-problemDescription",
								name: "problemDescription",
								required: true,
								maxLength: 2e3,
								rows: 6,
								value: page.draft.problemDescription,
								onChange: (event) => page.change("problemDescription", event.target.value),
								"aria-invalid": !!page.errors.problemDescription,
								"aria-describedby": page.errors.problemDescription ? "problemDescription-error" : undefined,
								className: `auth-input min-h-40 resize-y ${page.errors.problemDescription ? "border-danger/25" : ""}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 11
							}, this),
							page.errors.problemDescription && /* @__PURE__ */ _jsxDEV("p", {
								id: "problemDescription-error",
								className: "mt-1.5 text-sm text-danger",
								children: page.errors.problemDescription
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1.5 text-xs text-fg-muted",
								children: [page.draft.problemDescription.length, " / 2000 characters"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 7
			}, this),
			page.error && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "rounded-md border border-danger/25 bg-danger-bg p-4 text-sm text-danger",
				children: page.error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "repair-submit-bar flex flex-col gap-3 sm:flex-row",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: page.submitting,
					className: "auth-primary h-12 flex-1",
					children: page.submitting ? t.submitting : t.submit
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 180,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 5
	}, this);
}
_c = RepairRequestForm;
var _c;
$RefreshReg$(_c, "RepairRequestForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/lakshitha madushan/Desktop/Applianceslk/New/frontend/src/pages/Customer/Repairs/Request/components/RepairRequestForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7OztBQUc3QixNQUFNLElBQUksYUFBYTtBQUV2QixNQUFNLFNBT0E7Q0FDSjtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxXQUFXO0VBQ1gsTUFBTSxFQUFFO0NBQ1Y7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxXQUFXO0VBQ1gsTUFBTSxFQUFFO0NBQ1Y7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxXQUFXO0VBQ1gsTUFBTSxFQUFFO0NBQ1Y7Q0FDQTtFQUNFLE1BQU07RUFDTixPQUFPLEVBQUU7RUFDVCxXQUFXO0VBQ1gsVUFBVTtFQUNWLE1BQU0sRUFBRTtDQUNWO0NBQ0E7RUFDRSxNQUFNO0VBQ04sT0FBTyxFQUFFO0VBQ1QsV0FBVztFQUNYLFVBQVU7RUFDVixNQUFNLEVBQUU7RUFDUixNQUFNO0NBQ1I7QUFDRjtBQUVBLE9BQU8sU0FBUyxrQkFBa0IsRUFDaEMsUUFHQztDQUNELE9BQ0Usd0JBQUMsUUFBRDtFQUNFLFdBQVcsVUFBVSxLQUFLLEtBQUssT0FBTyxLQUFLO0VBQzNDO0VBQ0EsV0FBVTtZQUhaO0dBS0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW1CO01BQU87Ozs7Z0JBQ3pDLEVBQUUsaUJBQ0Q7Ozs7OztLQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQW9EO09BQ0Y7T0FDL0MsRUFBRTtNQUNGOzs7Ozs7S0FDSCx3QkFBQyxZQUFEO01BQ0UsVUFBVSxLQUFLO01BQ2YsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO2lCQUFXLEVBQUU7TUFBMEI7Ozs7Z0JBQ3hELE9BQU8sS0FBSyxVQUNYLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxTQUFEO1FBQU8sU0FBUyxVQUFVLE1BQU07UUFBUSxXQUFVO2tCQUFsRCxDQUNHLE1BQU0sT0FDTixNQUFNLFlBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsRUFBRTtRQUNDOzs7O2dCQUVIOzs7Ozs7T0FDUCx3QkFBQyxTQUFEO1FBQ0UsSUFBSSxVQUFVLE1BQU07UUFDcEIsTUFBTSxNQUFNO1FBQ1osTUFBTSxNQUFNLFFBQVE7UUFDcEIsVUFBVSxDQUFDLE1BQU07UUFDakIsV0FBVyxNQUFNO1FBQ2pCLE9BQU8sS0FBSyxNQUFNLE1BQU07UUFDeEIsV0FBVyxVQUNULEtBQUssT0FBTyxNQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUs7UUFFNUMsZ0JBQWMsQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNO1FBQ2xDLG9CQUNFLEtBQUssT0FBTyxNQUFNLFFBQ2QsR0FBRyxNQUFNLEtBQUssVUFDZCxNQUFNLE9BQ0osR0FBRyxNQUFNLEtBQUssU0FDZDtRQUVSLFdBQVcsY0FBYyxLQUFLLE9BQU8sTUFBTSxRQUFRLHFCQUFxQjtPQUN6RTs7Ozs7T0FDQSxNQUFNLFFBQ0wsd0JBQUMsS0FBRDtRQUNFLElBQUksR0FBRyxNQUFNLEtBQUs7UUFDbEIsV0FBVTtrQkFFVCxNQUFNO09BQ047Ozs7O09BRUosS0FBSyxPQUFPLE1BQU0sU0FDakIsd0JBQUMsS0FBRDtRQUNFLElBQUksR0FBRyxNQUFNLEtBQUs7UUFDbEIsV0FBVTtrQkFFVCxLQUFLLE9BQU8sTUFBTTtPQUNsQjs7Ozs7TUFFRixLQTdDSyxNQUFNOzs7O2FBNkNYLENBQ04sQ0FDTzs7Ozs7O0lBQ1A7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQjtNQUFPOzs7O2dCQUN6QyxFQUFFLGtCQUNEOzs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixFQUFFO0tBQ0Y7Ozs7O0tBQ0gsd0JBQUMsWUFBRDtNQUFVLFVBQVUsS0FBSztNQUFZLFdBQVU7Z0JBQS9DO09BQ0Usd0JBQUMsVUFBRDtRQUFRLFdBQVU7a0JBQVcsRUFBRTtPQUEyQjs7Ozs7T0FDMUQsd0JBQUMsU0FBRDtRQUFPLFNBQVE7UUFBNEIsV0FBVTtrQkFDbEQsRUFBRTtPQUNFOzs7OztPQUNQLHdCQUFDLFlBQUQ7UUFDRSxJQUFHO1FBQ0gsTUFBSztRQUNMO1FBQ0EsV0FBVztRQUNYLE1BQU07UUFDTixPQUFPLEtBQUssTUFBTTtRQUNsQixXQUFXLFVBQ1QsS0FBSyxPQUFPLHNCQUFzQixNQUFNLE9BQU8sS0FBSztRQUV0RCxnQkFBYyxDQUFDLENBQUMsS0FBSyxPQUFPO1FBQzVCLG9CQUNFLEtBQUssT0FBTyxxQkFDUiw2QkFDQTtRQUVOLFdBQVcsZ0NBQWdDLEtBQUssT0FBTyxxQkFBcUIscUJBQXFCO09BQ2xHOzs7OztPQUNBLEtBQUssT0FBTyxzQkFDWCx3QkFBQyxLQUFEO1FBQ0UsSUFBRztRQUNILFdBQVU7a0JBRVQsS0FBSyxPQUFPO09BQ1o7Ozs7O09BRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FDRyxLQUFLLE1BQU0sbUJBQW1CLFFBQU8sb0JBQ3JDOzs7Ozs7TUFDSzs7Ozs7O0lBQ1A7Ozs7OztHQUVKLEtBQUssU0FDSix3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FFVCxLQUFLO0dBQ0g7Ozs7O0dBR1Asd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFVBQVUsS0FBSztLQUNmLFdBQVU7ZUFFVCxLQUFLLGFBQWEsRUFBRSxhQUFhLEVBQUU7SUFDOUI7Ozs7O0dBQ0w7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlcGFpclJlcXVlc3RGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi91dGlscy90cmFuc2xhdGlvbnMnO1xyXG5pbXBvcnQgdHlwZSB7IHVzZVJlcGFpclJlcXVlc3QgfSBmcm9tICcuLi9ob29rcy91c2VSZXBhaXJSZXF1ZXN0JztcclxuXHJcbmNvbnN0IHQgPSB0cmFuc2xhdGlvbnMucmVwYWlycztcclxuXHJcbmNvbnN0IGZpZWxkczoge1xyXG4gIG5hbWU6IGtleW9mIFJldHVyblR5cGU8dHlwZW9mIHVzZVJlcGFpclJlcXVlc3Q+WydkcmFmdCddO1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgbWF4TGVuZ3RoOiBudW1iZXI7XHJcbiAgb3B0aW9uYWw/OiBib29sZWFuO1xyXG4gIGhpbnQ/OiBzdHJpbmc7XHJcbiAgdHlwZT86IHN0cmluZztcclxufVtdID0gW1xyXG4gIHtcclxuICAgIG5hbWU6ICdkZXZpY2VUeXBlJyxcclxuICAgIGxhYmVsOiB0LmRldmljZVR5cGUsXHJcbiAgICBtYXhMZW5ndGg6IDEwMCxcclxuICAgIGhpbnQ6IHQuZGV2aWNlVHlwZUhpbnQsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiAnYnJhbmQnLFxyXG4gICAgbGFiZWw6IHQuYnJhbmQsXHJcbiAgICBtYXhMZW5ndGg6IDEwMCxcclxuICAgIGhpbnQ6IHQuYnJhbmRIaW50LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogJ21vZGVsJyxcclxuICAgIGxhYmVsOiB0Lm1vZGVsLFxyXG4gICAgbWF4TGVuZ3RoOiAxMDAsXHJcbiAgICBoaW50OiB0Lm1vZGVsSGludCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6ICdzZXJpYWxOdW1iZXInLFxyXG4gICAgbGFiZWw6IHQuc2VyaWFsTnVtYmVyLFxyXG4gICAgbWF4TGVuZ3RoOiAxMDAsXHJcbiAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgIGhpbnQ6IHQuc2VyaWFsTnVtYmVySGludCxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6ICdwdXJjaGFzZURhdGUnLFxyXG4gICAgbGFiZWw6IHQucHVyY2hhc2VEYXRlLFxyXG4gICAgbWF4TGVuZ3RoOiAxMCxcclxuICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgaGludDogdC5wdXJjaGFzZURhdGVIaW50LFxyXG4gICAgdHlwZTogJ2RhdGUnLFxyXG4gIH0sXHJcbl07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmVwYWlyUmVxdWVzdEZvcm0oe1xyXG4gIHBhZ2UsXHJcbn06IHtcclxuICBwYWdlOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VSZXBhaXJSZXF1ZXN0PjtcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybVxyXG4gICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB2b2lkIHBhZ2Uuc3VibWl0KGV2ZW50KX1cclxuICAgICAgbm9WYWxpZGF0ZVxyXG4gICAgICBjbGFzc05hbWU9XCJyZXBhaXItcmVxdWVzdC1mb3JtIHNwYWNlLXktNlwiXHJcbiAgICA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTUgIHNtOnAtNlwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9ybS1zdGVwLW51bWJlclwiPjE8L3NwYW4+XHJcbiAgICAgICAgICB7dC5kZXZpY2VJbmZvcm1hdGlvbn1cclxuICAgICAgICA8L2gyPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1mZy1tdXRlZFwiPlxyXG4gICAgICAgICAgQWxsIGZpZWxkcyBhcmUgcmVxdWlyZWQgdW5sZXNzIG1hcmtlZCBvcHRpb25hbC57JyAnfVxyXG4gICAgICAgICAge3QuZGV2aWNlSW5mb3JtYXRpb25EZXNjcmlwdGlvbn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPGZpZWxkc2V0XHJcbiAgICAgICAgICBkaXNhYmxlZD17cGFnZS5zdWJtaXR0aW5nfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibXQtNiBncmlkIG1pbi13LTAgZ2FwLTUgc206Z3JpZC1jb2xzLTJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxsZWdlbmQgY2xhc3NOYW1lPVwic3Itb25seVwiPnt0LmRldmljZUluZm9ybWF0aW9ufTwvbGVnZW5kPlxyXG4gICAgICAgICAge2ZpZWxkcy5tYXAoKGZpZWxkKSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXYga2V5PXtmaWVsZC5uYW1lfT5cclxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YHJlcGFpci0ke2ZpZWxkLm5hbWV9YH0gY2xhc3NOYW1lPVwiYXV0aC1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAge2ZpZWxkLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAge2ZpZWxkLm9wdGlvbmFsICYmIChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSBmb250LW5vcm1hbCB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Qub3B0aW9uYWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIGlkPXtgcmVwYWlyLSR7ZmllbGQubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgbmFtZT17ZmllbGQubmFtZX1cclxuICAgICAgICAgICAgICAgIHR5cGU9e2ZpZWxkLnR5cGUgPz8gJ3RleHQnfVxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWQ9eyFmaWVsZC5vcHRpb25hbH1cclxuICAgICAgICAgICAgICAgIG1heExlbmd0aD17ZmllbGQubWF4TGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3BhZ2UuZHJhZnRbZmllbGQubmFtZV19XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PlxyXG4gICAgICAgICAgICAgICAgICBwYWdlLmNoYW5nZShmaWVsZC5uYW1lLCBldmVudC50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9eyEhcGFnZS5lcnJvcnNbZmllbGQubmFtZV19XHJcbiAgICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtcclxuICAgICAgICAgICAgICAgICAgcGFnZS5lcnJvcnNbZmllbGQubmFtZV1cclxuICAgICAgICAgICAgICAgICAgICA/IGAke2ZpZWxkLm5hbWV9LWVycm9yYFxyXG4gICAgICAgICAgICAgICAgICAgIDogZmllbGQuaGludFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBgJHtmaWVsZC5uYW1lfS1oaW50YFxyXG4gICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGF1dGgtaW5wdXQgJHtwYWdlLmVycm9yc1tmaWVsZC5uYW1lXSA/ICdib3JkZXItZGFuZ2VyLzI1JyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7ZmllbGQuaGludCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgICAgICBpZD17YCR7ZmllbGQubmFtZX0taGludGB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LWZnLW11dGVkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2ZpZWxkLmhpbnR9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7cGFnZS5lcnJvcnNbZmllbGQubmFtZV0gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgICAgaWQ9e2Ake2ZpZWxkLm5hbWV9LWVycm9yYH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMS41IHRleHQtc20gdGV4dC1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZS5lcnJvcnNbZmllbGQubmFtZV19XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZSBwLTUgIHNtOnAtNlwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mZ1wiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9ybS1zdGVwLW51bWJlclwiPjI8L3NwYW4+XHJcbiAgICAgICAgICB7dC5wcm9ibGVtRGVzY3JpcHRpb259XHJcbiAgICAgICAgPC9oMj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy02IHRleHQtZmctbXV0ZWRcIj5cclxuICAgICAgICAgIHt0LnByb2JsZW1EZXNjcmlwdGlvbkhpbnR9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxmaWVsZHNldCBkaXNhYmxlZD17cGFnZS5zdWJtaXR0aW5nfSBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57dC5wcm9ibGVtRGVzY3JpcHRpb259PC9sZWdlbmQ+XHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJlcGFpci1wcm9ibGVtRGVzY3JpcHRpb25cIiBjbGFzc05hbWU9XCJhdXRoLWxhYmVsXCI+XHJcbiAgICAgICAgICAgIHt0LnByb2JsZW1EZXNjcmlwdGlvbkxhYmVsfVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICBpZD1cInJlcGFpci1wcm9ibGVtRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICBuYW1lPVwicHJvYmxlbURlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgbWF4TGVuZ3RoPXsyMDAwfVxyXG4gICAgICAgICAgICByb3dzPXs2fVxyXG4gICAgICAgICAgICB2YWx1ZT17cGFnZS5kcmFmdC5wcm9ibGVtRGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgcGFnZS5jaGFuZ2UoJ3Byb2JsZW1EZXNjcmlwdGlvbicsIGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBhcmlhLWludmFsaWQ9eyEhcGFnZS5lcnJvcnMucHJvYmxlbURlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtcclxuICAgICAgICAgICAgICBwYWdlLmVycm9ycy5wcm9ibGVtRGVzY3JpcHRpb25cclxuICAgICAgICAgICAgICAgID8gJ3Byb2JsZW1EZXNjcmlwdGlvbi1lcnJvcidcclxuICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgYXV0aC1pbnB1dCBtaW4taC00MCByZXNpemUteSAke3BhZ2UuZXJyb3JzLnByb2JsZW1EZXNjcmlwdGlvbiA/ICdib3JkZXItZGFuZ2VyLzI1JyA6ICcnfWB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAge3BhZ2UuZXJyb3JzLnByb2JsZW1EZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgaWQ9XCJwcm9ibGVtRGVzY3JpcHRpb24tZXJyb3JcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXNtIHRleHQtZGFuZ2VyXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtwYWdlLmVycm9ycy5wcm9ibGVtRGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xLjUgdGV4dC14cyB0ZXh0LWZnLW11dGVkXCI+XHJcbiAgICAgICAgICAgIHtwYWdlLmRyYWZ0LnByb2JsZW1EZXNjcmlwdGlvbi5sZW5ndGh9IC8gMjAwMCBjaGFyYWN0ZXJzXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9maWVsZHNldD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7cGFnZS5lcnJvciAmJiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgcm9sZT1cImFsZXJ0XCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1kYW5nZXIvMjUgYmctZGFuZ2VyLWJnIHAtNCB0ZXh0LXNtIHRleHQtZGFuZ2VyXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7cGFnZS5lcnJvcn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwYWlyLXN1Ym1pdC1iYXIgZmxleCBmbGV4LWNvbCBnYXAtMyBzbTpmbGV4LXJvd1wiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2Uuc3VibWl0dGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtcHJpbWFyeSBoLTEyIGZsZXgtMVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3BhZ2Uuc3VibWl0dGluZyA/IHQuc3VibWl0dGluZyA6IHQuc3VibWl0fVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZm9ybT5cclxuICApO1xyXG59XHJcbiJdfQ==